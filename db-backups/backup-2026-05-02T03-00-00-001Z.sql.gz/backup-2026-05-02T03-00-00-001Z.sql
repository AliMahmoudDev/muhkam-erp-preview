--
-- PostgreSQL database dump
--

\restrict TRkbub59vHo6ngbmHrx6eTGsXMA94GOrAiDfCDx3R639auEHmeDTELkj3EHPG8F

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    parent_id integer,
    level integer DEFAULT 1 NOT NULL,
    is_posting boolean DEFAULT true NOT NULL,
    opening_balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    current_balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.accounts FORCE ROW LEVEL SECURITY;


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: accrual_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accrual_runs (
    id integer NOT NULL,
    accrual_id integer NOT NULL,
    period text NOT NULL,
    amount numeric(14,2) NOT NULL,
    entry_id integer,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.accrual_runs FORCE ROW LEVEL SECURITY;


--
-- Name: accrual_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accrual_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accrual_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accrual_runs_id_seq OWNED BY public.accrual_runs.id;


--
-- Name: accruals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accruals (
    id integer NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    total_amount numeric(14,2) NOT NULL,
    months_total integer NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    expense_account_id integer,
    prepaid_account_id integer,
    amount_recognized numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.accruals FORCE ROW LEVEL SECURITY;


--
-- Name: accruals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accruals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accruals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accruals_id_seq OWNED BY public.accruals.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    type text NOT NULL,
    severity text NOT NULL,
    message text NOT NULL,
    reference_id text,
    trigger_mode text DEFAULT 'event'::text NOT NULL,
    last_triggered_date text,
    role_target text,
    user_id integer,
    is_read boolean DEFAULT false NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    target text DEFAULT 'all'::text NOT NULL,
    company_id integer,
    is_active boolean DEFAULT true NOT NULL,
    created_by text DEFAULT 'super_admin'::text NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: attendance_deduction_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_deduction_settings (
    id integer NOT NULL,
    company_id integer NOT NULL,
    grace_minutes integer DEFAULT 10 NOT NULL,
    weekly_off_days text DEFAULT '5'::text NOT NULL,
    absence_full_day_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    absence_half_day_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    apply_early_leave boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_deduction_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_deduction_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_deduction_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_deduction_settings_id_seq OWNED BY public.attendance_deduction_settings.id;


--
-- Name: attendance_deduction_tiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_deduction_tiers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    applies_to text DEFAULT 'late'::text NOT NULL,
    min_minutes integer NOT NULL,
    max_minutes integer,
    amount numeric(14,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_deduction_tiers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_deduction_tiers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_deduction_tiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_deduction_tiers_id_seq OWNED BY public.attendance_deduction_tiers.id;


--
-- Name: attendance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    attendance_date text NOT NULL,
    check_in_time text,
    check_out_time text,
    status text DEFAULT 'present'::text NOT NULL,
    working_hours numeric(5,2),
    late_minutes integer DEFAULT 0,
    early_departure_minutes integer DEFAULT 0,
    overtime_hours numeric(5,2) DEFAULT '0'::numeric,
    notes text,
    submitted_by integer,
    verified_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_records_id_seq OWNED BY public.attendance_records.id;


--
-- Name: attendance_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_summary (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    month text NOT NULL,
    total_present_days integer DEFAULT 0 NOT NULL,
    total_absent_days integer DEFAULT 0 NOT NULL,
    total_late_days integer DEFAULT 0 NOT NULL,
    total_early_departures integer DEFAULT 0 NOT NULL,
    total_overtime_hours numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    total_working_hours numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_summary_id_seq OWNED BY public.attendance_summary.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action text NOT NULL,
    record_type text NOT NULL,
    record_id integer NOT NULL,
    old_value jsonb,
    new_value jsonb,
    user_id integer,
    username text,
    company_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id integer NOT NULL,
    filename text NOT NULL,
    size integer DEFAULT 0 NOT NULL,
    trigger text DEFAULT 'manual'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: bad_debts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bad_debts (
    id integer NOT NULL,
    company_id integer NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    reason text,
    account_id integer,
    status text DEFAULT 'open'::text NOT NULL,
    source_invoice_id integer,
    source_repair_job_id integer,
    notes text,
    written_off_at date,
    created_by integer,
    created_by_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bad_debts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bad_debts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bad_debts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bad_debts_id_seq OWNED BY public.bad_debts.id;


--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_accounts (
    id integer NOT NULL,
    name text NOT NULL,
    account_number text,
    bank_name text NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    safe_id integer,
    opening_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.bank_accounts FORCE ROW LEVEL SECURITY;


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_accounts_id_seq OWNED BY public.bank_accounts.id;


--
-- Name: bank_statement_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_statement_lines (
    id integer NOT NULL,
    bank_account_id integer NOT NULL,
    date text NOT NULL,
    description text NOT NULL,
    amount numeric(14,2) NOT NULL,
    type text NOT NULL,
    reference text,
    matched_entry_id integer,
    status text DEFAULT 'unmatched'::text NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.bank_statement_lines FORCE ROW LEVEL SECURITY;


--
-- Name: bank_statement_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bank_statement_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_statement_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bank_statement_lines_id_seq OWNED BY public.bank_statement_lines.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.branches FORCE ROW LEVEL SECURITY;


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: budget_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_lines (
    id integer NOT NULL,
    budget_id integer NOT NULL,
    account_id integer NOT NULL,
    account_code text NOT NULL,
    account_name text NOT NULL,
    account_type text NOT NULL,
    period text NOT NULL,
    budgeted_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    company_id integer NOT NULL
);

ALTER TABLE ONLY public.budget_lines FORCE ROW LEVEL SECURITY;


--
-- Name: budget_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_lines_id_seq OWNED BY public.budget_lines.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id integer NOT NULL,
    name text NOT NULL,
    fiscal_year integer NOT NULL,
    date_from text NOT NULL,
    date_to text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.budgets FORCE ROW LEVEL SECURITY;


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.categories FORCE ROW LEVEL SECURITY;


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    plan_type text DEFAULT 'trial'::text NOT NULL,
    edition text DEFAULT 'ultimate'::text NOT NULL,
    features jsonb,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    admin_email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    signup_ip text,
    signup_user_agent text,
    has_used_trial boolean DEFAULT false NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    email_verification_token text,
    email_verification_expires_at timestamp with time zone,
    verification_status text DEFAULT 'pending'::text NOT NULL,
    trial_score integer DEFAULT 100 NOT NULL,
    is_suspicious boolean DEFAULT false NOT NULL
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: cost_centers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_centers (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.cost_centers FORCE ROW LEVEL SECURITY;


--
-- Name: cost_centers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_centers_id_seq OWNED BY public.cost_centers.id;


--
-- Name: customer_classifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_classifications (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_classifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_classifications_id_seq OWNED BY public.customer_classifications.id;


--
-- Name: customer_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_ledger (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    type text NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference_type text,
    reference_id integer,
    reference_no text,
    description text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.customer_ledger FORCE ROW LEVEL SECURITY;


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_ledger_id_seq OWNED BY public.customer_ledger.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    customer_code integer,
    normalized_name text,
    phone text,
    balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    is_customer boolean DEFAULT true NOT NULL,
    is_supplier boolean DEFAULT false NOT NULL,
    account_id integer,
    classification_id integer,
    source text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.customers FORCE ROW LEVEL SECURITY;


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: daily_incentive_accrual; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_incentive_accrual (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    accrual_date text NOT NULL,
    metric_value numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    target_value numeric(14,2) NOT NULL,
    achievement_percentage numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    accrued_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    status text DEFAULT 'accrued'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_incentive_accrual_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_incentive_accrual_id_seq OWNED BY public.daily_incentive_accrual.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    description_en text,
    description_ar text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.departments FORCE ROW LEVEL SECURITY;


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: deposit_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deposit_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    source text,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.deposit_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deposit_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deposit_vouchers_id_seq OWNED BY public.deposit_vouchers.id;


--
-- Name: depreciation_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.depreciation_runs (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    period text NOT NULL,
    amount numeric(14,2) NOT NULL,
    entry_id integer,
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.depreciation_runs FORCE ROW LEVEL SECURITY;


--
-- Name: depreciation_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.depreciation_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: depreciation_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.depreciation_runs_id_seq OWNED BY public.depreciation_runs.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    company_id integer NOT NULL,
    branch_id integer,
    device_no text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    color text,
    storage text,
    imei text,
    serial_no text,
    battery_health integer,
    grade text DEFAULT 'B'::text,
    condition_notes text,
    purchase_price numeric(12,2) DEFAULT '0'::numeric,
    sale_price numeric(12,2) DEFAULT '0'::numeric,
    status text DEFAULT 'available'::text NOT NULL,
    dual_sim boolean DEFAULT false,
    with_box boolean DEFAULT false,
    icloud_locked boolean DEFAULT false,
    network_locked boolean DEFAULT false,
    previously_opened boolean DEFAULT false,
    mdm_locked boolean DEFAULT false,
    supplier_name text,
    purchase_invoice_no text,
    inspector_name text,
    sold_to_customer_id integer,
    sold_to_customer_name text,
    sold_at timestamp without time zone,
    sold_by_user_id integer,
    sold_by_user_name text,
    sold_price numeric(12,2),
    warranty_months integer,
    payment_method text,
    payment_status text,
    added_by_user_id integer,
    added_by_user_name text,
    supplier_phone text,
    id_card_data text,
    product_id integer,
    purchase_id integer,
    purchase_invoice_ref text,
    inspection_data text,
    inspector_employee_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);

ALTER TABLE ONLY public.devices FORCE ROW LEVEL SECURITY;


--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: employee_bonuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_bonuses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text,
    granted_date text NOT NULL,
    granted_by integer,
    currency text DEFAULT 'EGP'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_bonuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_bonuses_id_seq OWNED BY public.employee_bonuses.id;


--
-- Name: employee_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_contacts (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    contact_type text DEFAULT 'emergency'::text NOT NULL,
    name text NOT NULL,
    relationship text,
    phone text,
    email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_contacts_id_seq OWNED BY public.employee_contacts.id;


--
-- Name: employee_custody; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_custody (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    safe_id integer,
    amount numeric(14,2) NOT NULL,
    returned_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    purpose text,
    granted_date text NOT NULL,
    settled_date text,
    status text DEFAULT 'open'::text NOT NULL,
    granted_by integer,
    currency text DEFAULT 'EGP'::text NOT NULL,
    notes text,
    reimbursement_due numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_custody_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_custody_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_custody_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_custody_id_seq OWNED BY public.employee_custody.id;


--
-- Name: employee_custody_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_custody_lines (
    id integer NOT NULL,
    company_id integer NOT NULL,
    custody_id integer NOT NULL,
    category text NOT NULL,
    amount numeric(14,2) NOT NULL,
    description text,
    line_date text NOT NULL,
    expense_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_custody_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_custody_lines_id_seq OWNED BY public.employee_custody_lines.id;


--
-- Name: employee_deductions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_deductions (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    deduction_type text DEFAULT 'other'::text NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text,
    deduction_date text NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    created_by integer,
    attendance_record_id integer,
    source text DEFAULT 'manual'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: employee_deductions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_deductions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_deductions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_deductions_id_seq OWNED BY public.employee_deductions.id;


--
-- Name: employee_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_documents (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    document_type text NOT NULL,
    file_name text NOT NULL,
    file_path text,
    expiry_date text,
    verified_by integer,
    verified_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_documents_id_seq OWNED BY public.employee_documents.id;


--
-- Name: employee_incentive_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_incentive_assignments (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    incentive_scheme_id integer NOT NULL,
    assigned_date text NOT NULL,
    end_date text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_incentive_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_incentive_assignments_id_seq OWNED BY public.employee_incentive_assignments.id;


--
-- Name: employee_leave_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_leave_balances (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    accrued_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    used_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    balance_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    carryover_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    as_of_date text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_leave_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_leave_balances_id_seq OWNED BY public.employee_leave_balances.id;


--
-- Name: employee_shift_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_shift_assignments (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    shift_schedule_id integer NOT NULL,
    assigned_date text NOT NULL,
    end_date text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_shift_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_shift_assignments_id_seq OWNED BY public.employee_shift_assignments.id;


--
-- Name: employee_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_status_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    old_status text,
    new_status text NOT NULL,
    reason text,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_status_history_id_seq OWNED BY public.employee_status_history.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    employee_code text NOT NULL,
    first_name_en text NOT NULL,
    last_name_en text NOT NULL,
    first_name_ar text NOT NULL,
    last_name_ar text NOT NULL,
    email text NOT NULL,
    phone text,
    personal_phone text,
    national_id text,
    national_id_image text,
    job_title_id integer,
    department_id integer,
    branch_id integer,
    hire_date text NOT NULL,
    employment_status text DEFAULT 'active'::text NOT NULL,
    salary numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    salary_type text DEFAULT 'fixed'::text NOT NULL,
    commission_rate numeric(5,2),
    commission_basis text,
    commission_scope_dept_id integer,
    bank_account text,
    address_en text,
    address_ar text,
    city text,
    country text DEFAULT 'مصر'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by integer,
    updated_by integer
);

ALTER TABLE ONLY public.employees FORCE ROW LEVEL SECURITY;


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: erp_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_users (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    email text,
    pin text NOT NULL,
    role text DEFAULT 'cashier'::text NOT NULL,
    permissions text DEFAULT '{}'::text,
    active boolean DEFAULT true,
    company_id integer,
    warehouse_id integer,
    safe_id integer,
    employee_id integer,
    login_attempts integer DEFAULT 0 NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_verified boolean DEFAULT false,
    trusted_device_id text
);


--
-- Name: erp_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_users_id_seq OWNED BY public.erp_users.id;


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id integer NOT NULL,
    currency text NOT NULL,
    rate numeric(12,6) NOT NULL,
    date text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exchange_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exchange_rates_id_seq OWNED BY public.exchange_rates.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    category text NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text,
    safe_id integer,
    safe_name text,
    reference_type text,
    reference_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.expenses FORCE ROW LEVEL SECURITY;


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: fiscal_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_years (
    id integer NOT NULL,
    company_id integer NOT NULL,
    year_label text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    is_open boolean DEFAULT true NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    closed_by integer,
    closed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_years_id_seq OWNED BY public.fiscal_years.id;


--
-- Name: fixed_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fixed_assets (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'equipment'::text NOT NULL,
    purchase_date text NOT NULL,
    purchase_cost numeric(14,2) NOT NULL,
    residual_value numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    useful_life_months integer NOT NULL,
    depreciation_method text DEFAULT 'straight_line'::text NOT NULL,
    asset_account_id integer,
    acc_dep_account_id integer,
    dep_expense_account_id integer,
    accumulated_depreciation numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    disposal_date text,
    disposal_proceeds numeric(14,2),
    company_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.fixed_assets FORCE ROW LEVEL SECURITY;


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fixed_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fixed_assets_id_seq OWNED BY public.fixed_assets.id;


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    id integer NOT NULL,
    company_id integer NOT NULL,
    scope text NOT NULL,
    key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.idempotency_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.idempotency_keys_id_seq OWNED BY public.idempotency_keys.id;


--
-- Name: incentive_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_metrics (
    id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    employee_id integer NOT NULL,
    metric_date text NOT NULL,
    metric_value numeric(14,2) NOT NULL,
    source_document_id integer,
    source_type text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_metrics_id_seq OWNED BY public.incentive_metrics.id;


--
-- Name: incentive_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_rules (
    id integer NOT NULL,
    incentive_scheme_id integer NOT NULL,
    metric_type text NOT NULL,
    target_value numeric(14,2) NOT NULL,
    incentive_amount numeric(14,2),
    incentive_type text DEFAULT 'fixed'::text NOT NULL,
    calculation_method text DEFAULT 'achievement'::text NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_rules_id_seq OWNED BY public.incentive_rules.id;


--
-- Name: incentive_schemes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_schemes (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_schemes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_schemes_id_seq OWNED BY public.incentive_schemes.id;


--
-- Name: incentive_slabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_slabs (
    id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    slab_number integer NOT NULL,
    from_percentage numeric(7,2) NOT NULL,
    to_percentage numeric(7,2),
    incentive_value numeric(14,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_slabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_slabs_id_seq OWNED BY public.incentive_slabs.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.income (
    id integer NOT NULL,
    source text NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text,
    safe_id integer,
    safe_name text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.income FORCE ROW LEVEL SECURITY;


--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: job_titles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_titles (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: job_titles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_titles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_titles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_titles_id_seq OWNED BY public.job_titles.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    entry_no text NOT NULL,
    date text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    reference text,
    total_debit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_credit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.journal_entries FORCE ROW LEVEL SECURITY;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: journal_entry_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entry_lines (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    account_id integer NOT NULL,
    account_name text NOT NULL,
    account_code text NOT NULL,
    debit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    credit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    description text,
    cost_center_id integer
);


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entry_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entry_lines_id_seq OWNED BY public.journal_entry_lines.id;


--
-- Name: leave_accrual_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_accrual_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    accrued_days numeric(7,2) NOT NULL,
    month text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_accrual_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_accrual_history_id_seq OWNED BY public.leave_accrual_history.id;


--
-- Name: leave_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_approvals (
    id integer NOT NULL,
    leave_request_id integer NOT NULL,
    approver_id integer NOT NULL,
    status text NOT NULL,
    comment text,
    approved_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_approvals_id_seq OWNED BY public.leave_approvals.id;


--
-- Name: leave_blackout_dates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_blackout_dates (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    reason_en text,
    reason_ar text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_blackout_dates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_blackout_dates_id_seq OWNED BY public.leave_blackout_dates.id;


--
-- Name: leave_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_policies (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    leave_type_id integer NOT NULL,
    entitlement_days_per_year integer DEFAULT 21 NOT NULL,
    accrual_method text DEFAULT 'fixed'::text NOT NULL,
    min_duration numeric(4,1) DEFAULT '1'::numeric NOT NULL,
    max_consecutive_days integer DEFAULT 30,
    probation_days integer DEFAULT 90,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_policies_id_seq OWNED BY public.leave_policies.id;


--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_requests (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    total_days numeric(5,1) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reason text,
    rejection_reason text,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_by integer,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_requests_id_seq OWNED BY public.leave_requests.id;


--
-- Name: leave_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_types (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    code text NOT NULL,
    is_paid boolean DEFAULT true NOT NULL,
    requires_approval boolean DEFAULT true NOT NULL,
    carryover_allowed boolean DEFAULT false NOT NULL,
    carryover_limit integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_types_id_seq OWNED BY public.leave_types.id;


--
-- Name: monthly_incentive_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_incentive_summary (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    month text NOT NULL,
    total_accrued numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    included_in_payroll_record_id integer,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.monthly_incentive_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.monthly_incentive_summary_id_seq OWNED BY public.monthly_incentive_summary.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    link text,
    reference_id integer,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    read_at timestamp with time zone
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: overtime_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.overtime_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    date text NOT NULL,
    hours numeric(5,2) NOT NULL,
    reason text,
    approved_by integer,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: overtime_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.overtime_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: overtime_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.overtime_records_id_seq OWNED BY public.overtime_records.id;


--
-- Name: payment_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.payment_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_vouchers_id_seq OWNED BY public.payment_vouchers.id;


--
-- Name: payroll_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_adjustments (
    id integer NOT NULL,
    payroll_record_id integer NOT NULL,
    adjustment_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text NOT NULL,
    approved_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_adjustments_id_seq OWNED BY public.payroll_adjustments.id;


--
-- Name: payroll_line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_line_items (
    id integer NOT NULL,
    payroll_record_id integer NOT NULL,
    component_name text NOT NULL,
    component_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_line_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_line_items_id_seq OWNED BY public.payroll_line_items.id;


--
-- Name: payroll_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_periods (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    processed_by integer,
    processed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_periods_id_seq OWNED BY public.payroll_periods.id;


--
-- Name: payroll_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_records (
    id integer NOT NULL,
    payroll_period_id integer NOT NULL,
    employee_id integer NOT NULL,
    gross_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_allowances numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_deductions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    net_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    advance_deductions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    incentive_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_records_id_seq OWNED BY public.payroll_records.id;


--
-- Name: plan_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_settings (
    id integer NOT NULL,
    key text NOT NULL,
    name_ar text NOT NULL,
    description text,
    price integer DEFAULT 0 NOT NULL,
    includes_mobile boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plan_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plan_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plan_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plan_settings_id_seq OWNED BY public.plan_settings.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    sku text,
    category text,
    category_id integer,
    quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    cost_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    sale_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    low_stock_threshold integer,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.products FORCE ROW LEVEL SECURITY;


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: public_holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_holidays (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    holiday_date text NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_holidays_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.public_holidays_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: public_holidays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.public_holidays_id_seq OWNED BY public.public_holidays.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    quantity_returned numeric(12,3) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    original_purchase_item_id integer,
    unit_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    total_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_return_items_id_seq OWNED BY public.purchase_return_items.id;


--
-- Name: purchase_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_returns (
    id integer NOT NULL,
    request_id text,
    return_no text NOT NULL,
    purchase_id integer,
    customer_id integer,
    customer_name text,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    refund_type text DEFAULT 'balance_credit'::text,
    safe_id integer,
    safe_name text,
    date text,
    reason text,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.purchase_returns FORCE ROW LEVEL SECURITY;


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_returns_id_seq OWNED BY public.purchase_returns.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    request_id text,
    invoice_no text NOT NULL,
    supplier_name text,
    customer_id integer,
    customer_name text,
    payment_type text NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    exchange_rate numeric(12,6) DEFAULT '1'::numeric NOT NULL,
    is_consignment boolean DEFAULT false NOT NULL,
    consignment_warehouse_id integer,
    notes text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.purchases FORCE ROW LEVEL SECURITY;


--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: receipt_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.receipt_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receipt_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receipt_vouchers_id_seq OWNED BY public.receipt_vouchers.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    token_hash text NOT NULL,
    user_id integer NOT NULL,
    used boolean DEFAULT false NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone
);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: repair_checklist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_checklist_items (
    id integer NOT NULL,
    company_id integer NOT NULL,
    label_ar text NOT NULL,
    category text DEFAULT 'عام'::text,
    device_type text DEFAULT 'general'::text,
    sort_order integer DEFAULT 0,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_checklist_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_checklist_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_checklist_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_checklist_items_id_seq OWNED BY public.repair_checklist_items.id;


--
-- Name: repair_dashboard_cards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_dashboard_cards (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name text NOT NULL,
    statuses text NOT NULL,
    color text DEFAULT '#8b5cf6'::text NOT NULL,
    icon text DEFAULT 'Wrench'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    alert_threshold integer,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_dashboard_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_dashboard_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_dashboard_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_dashboard_cards_id_seq OWNED BY public.repair_dashboard_cards.id;


--
-- Name: repair_device_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_device_models (
    id integer NOT NULL,
    company_id integer NOT NULL,
    brand text NOT NULL,
    category text NOT NULL,
    model text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_device_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_device_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_device_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_device_models_id_seq OWNED BY public.repair_device_models.id;


--
-- Name: repair_job_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_job_parts (
    id integer NOT NULL,
    job_id integer NOT NULL,
    company_id integer NOT NULL,
    product_id integer,
    product_name text NOT NULL,
    quantity numeric(12,2) DEFAULT '1'::numeric NOT NULL,
    unit_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    source text DEFAULT 'internal'::text,
    warehouse_id integer,
    is_returned boolean DEFAULT false,
    return_destination text,
    returned_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_job_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_job_parts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_job_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_job_parts_id_seq OWNED BY public.repair_job_parts.id;


--
-- Name: repair_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_jobs (
    id integer NOT NULL,
    company_id integer NOT NULL,
    job_no text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    customer_phone text,
    device_brand text NOT NULL,
    device_model text NOT NULL,
    device_type text DEFAULT 'general'::text NOT NULL,
    imei text,
    serial_no text,
    color text,
    storage text,
    problem_description text,
    technician_id integer,
    technician_name text,
    technician_2_id integer,
    technician_2_name text,
    technician_2_section text,
    status text DEFAULT 'pending'::text NOT NULL,
    checklist text,
    qa_checklist text,
    qa_completed_at timestamp without time zone,
    qa_notes text,
    device_score integer,
    estimated_cost numeric(12,2) DEFAULT '0'::numeric,
    final_cost numeric(12,2) DEFAULT '0'::numeric,
    deposit_paid numeric(12,2) DEFAULT '0'::numeric,
    external_workshop boolean DEFAULT false,
    external_workshop_name text,
    external_workshop_cost numeric(12,2) DEFAULT '0'::numeric,
    broker_name text,
    broker_commission numeric(12,2) DEFAULT '0'::numeric,
    alert_days_threshold integer,
    locked boolean DEFAULT false,
    received_at date NOT NULL,
    estimated_delivery date,
    delivered_at date,
    device_pin text,
    accessories text,
    branch_id integer,
    notes text,
    pre_delivery_reviewed_at timestamp without time zone,
    shipping_cost numeric(12,2) DEFAULT '0'::numeric,
    shipping_expense_id integer,
    shipping_settled_at timestamp without time zone,
    final_discount numeric(12,2) DEFAULT '0'::numeric,
    delivery_receipt_sent_at timestamp without time zone,
    delivery_receipt_method text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    job_type text DEFAULT 'repair'::text NOT NULL,
    warranty_of integer,
    is_customer_returned boolean DEFAULT false,
    customer_return_amount numeric(12,2) DEFAULT '0'::numeric
);


--
-- Name: repair_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_jobs_id_seq OWNED BY public.repair_jobs.id;


--
-- Name: repair_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_payments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    job_id integer NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_method text DEFAULT 'cash'::text NOT NULL,
    notes text,
    received_by integer,
    received_by_name text,
    safe_id integer,
    safe_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_payments_id_seq OWNED BY public.repair_payments.id;


--
-- Name: repair_pipeline_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_pipeline_config (
    id integer NOT NULL,
    company_id integer NOT NULL,
    status_key text NOT NULL,
    label_ar text NOT NULL,
    color text NOT NULL,
    icon text NOT NULL,
    sort_order integer NOT NULL,
    requirements text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_pipeline_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_pipeline_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_pipeline_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_pipeline_config_id_seq OWNED BY public.repair_pipeline_config.id;


--
-- Name: repair_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_status_history (
    id integer NOT NULL,
    job_id integer NOT NULL,
    company_id integer NOT NULL,
    status_from text,
    status_to text,
    technician_id integer,
    technician_name text,
    user_id integer,
    user_name text,
    event_type text DEFAULT 'status_change'::text,
    note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_status_history_id_seq OWNED BY public.repair_status_history.id;


--
-- Name: repair_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_statuses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    key text NOT NULL,
    label_ar text NOT NULL,
    color text DEFAULT '#64748b'::text,
    sort_order integer DEFAULT 0,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: repair_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_statuses_id_seq OWNED BY public.repair_statuses.id;


--
-- Name: safe_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safe_transfers (
    id integer NOT NULL,
    from_safe_id integer,
    from_safe_name text,
    to_safe_id integer,
    to_safe_name text,
    amount numeric(12,2) NOT NULL,
    fee_type text DEFAULT 'none'::text,
    fee_rate numeric(10,4) DEFAULT '0'::numeric,
    fee_amount numeric(12,2) DEFAULT '0'::numeric,
    net_amount numeric(12,2),
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.safe_transfers FORCE ROW LEVEL SECURITY;


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.safe_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.safe_transfers_id_seq OWNED BY public.safe_transfers.id;


--
-- Name: safes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safes (
    id integer NOT NULL,
    name text NOT NULL,
    balance numeric(12,2) DEFAULT '0'::numeric,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.safes FORCE ROW LEVEL SECURITY;


--
-- Name: safes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.safes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: safes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.safes_id_seq OWNED BY public.safes.id;


--
-- Name: salary_advance_deductions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_deductions (
    id integer NOT NULL,
    salary_advance_id integer NOT NULL,
    payroll_record_id integer,
    deduction_amount numeric(14,2) NOT NULL,
    deduction_date text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_deductions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_deductions_id_seq OWNED BY public.salary_advance_deductions.id;


--
-- Name: salary_advance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_history (
    id integer NOT NULL,
    salary_advance_id integer NOT NULL,
    old_status text,
    new_status text NOT NULL,
    changed_by integer,
    comment text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_history_id_seq OWNED BY public.salary_advance_history.id;


--
-- Name: salary_advance_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_ledger (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    advance_id integer NOT NULL,
    ledger_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    balance numeric(14,2) NOT NULL,
    ledger_date text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_ledger_id_seq OWNED BY public.salary_advance_ledger.id;


--
-- Name: salary_advance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_settings (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    max_advance_percentage numeric(5,2) DEFAULT '50'::numeric NOT NULL,
    max_concurrent_advances integer DEFAULT 2 NOT NULL,
    min_salary_for_advance numeric(14,2) DEFAULT '3000'::numeric NOT NULL,
    repayment_tenure_months integer DEFAULT 1 NOT NULL,
    requires_approval boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_settings_id_seq OWNED BY public.salary_advance_settings.id;


--
-- Name: salary_advances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advances (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    employee_id integer NOT NULL,
    requested_date text NOT NULL,
    requested_amount numeric(14,2) NOT NULL,
    approved_amount numeric(14,2),
    advance_type text DEFAULT 'personal'::text NOT NULL,
    reason text,
    status text DEFAULT 'pending'::text NOT NULL,
    approver_id integer,
    approved_at timestamp with time zone,
    rejection_reason text,
    remaining_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    deduct_from text DEFAULT 'fixed'::text NOT NULL,
    safe_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advances_id_seq OWNED BY public.salary_advances.id;


--
-- Name: salary_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_components (
    id integer NOT NULL,
    salary_structure_id integer NOT NULL,
    component_type text NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    amount numeric(14,2),
    percentage_of_base numeric(7,4),
    is_mandatory boolean DEFAULT false NOT NULL,
    is_taxable boolean DEFAULT false NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_components_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_components_id_seq OWNED BY public.salary_components.id;


--
-- Name: salary_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    salary_amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    effective_date text NOT NULL,
    reason text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_history_id_seq OWNED BY public.salary_history.id;


--
-- Name: salary_structures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_structures (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    base_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_structures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_structures_id_seq OWNED BY public.salary_structures.id;


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    cost_price numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    cost_total numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    quantity_returned numeric(12,3) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_items_id_seq OWNED BY public.sale_items.id;


--
-- Name: sale_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    original_sale_item_id integer,
    unit_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    total_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_return_items_id_seq OWNED BY public.sale_return_items.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    request_id text,
    invoice_no text NOT NULL,
    customer_name text,
    customer_id integer,
    payment_type text NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    safe_id integer,
    safe_name text,
    warehouse_id integer,
    warehouse_name text,
    salesperson_id integer,
    salesperson_name text,
    discount_percent numeric(5,2) DEFAULT '0'::numeric,
    discount_amount numeric(12,2) DEFAULT '0'::numeric,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL,
    notes text,
    date text,
    user_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.sales FORCE ROW LEVEL SECURITY;


--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: sales_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_returns (
    id integer NOT NULL,
    request_id text,
    return_no text NOT NULL,
    sale_id integer,
    customer_id integer,
    customer_name text,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    refund_type text DEFAULT 'credit'::text,
    safe_id integer,
    safe_name text,
    date text,
    reason text,
    notes text,
    user_id integer,
    warehouse_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.sales_returns FORCE ROW LEVEL SECURITY;


--
-- Name: sales_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_returns_id_seq OWNED BY public.sales_returns.id;


--
-- Name: sales_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_targets (
    id integer NOT NULL,
    company_id integer NOT NULL,
    user_id integer NOT NULL,
    year_month text NOT NULL,
    target_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sales_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_targets_id_seq OWNED BY public.sales_targets.id;


--
-- Name: scrap_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scrap_items (
    id integer NOT NULL,
    company_id integer NOT NULL,
    product_id integer,
    product_name text NOT NULL,
    quantity numeric(12,2) DEFAULT '1'::numeric NOT NULL,
    unit_cost numeric(12,2) DEFAULT '0'::numeric,
    warehouse_id integer,
    reason text,
    source_type text,
    source_id integer,
    created_by integer,
    created_by_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: scrap_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scrap_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scrap_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scrap_items_id_seq OWNED BY public.scrap_items.id;


--
-- Name: shift_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_schedules (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    start_time text NOT NULL,
    end_time text NOT NULL,
    break_duration integer DEFAULT 60 NOT NULL,
    grace_minutes integer DEFAULT 5 NOT NULL,
    weekly_hours numeric(5,2) DEFAULT '40'::numeric NOT NULL,
    working_days text DEFAULT '0,1,2,3,4'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shift_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shift_schedules_id_seq OWNED BY public.shift_schedules.id;


--
-- Name: statutory_contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statutory_contributions (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    contribution_type text NOT NULL,
    name_ar text NOT NULL,
    name_en text NOT NULL,
    employee_percentage numeric(7,4) DEFAULT '0'::numeric NOT NULL,
    employer_percentage numeric(7,4) DEFAULT '0'::numeric NOT NULL,
    is_mandatory boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statutory_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statutory_contributions_id_seq OWNED BY public.statutory_contributions.id;


--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_count_items (
    id integer NOT NULL,
    session_id integer NOT NULL,
    product_id integer NOT NULL,
    system_qty numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    physical_qty numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_count_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_count_items_id_seq OWNED BY public.stock_count_items.id;


--
-- Name: stock_count_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_count_sessions (
    id integer NOT NULL,
    warehouse_id integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_by integer,
    applied_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_count_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_count_sessions_id_seq OWNED BY public.stock_count_sessions.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    movement_type text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    quantity_before numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    quantity_after numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_cost numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    reference_type text,
    reference_id integer,
    reference_no text,
    notes text,
    date text,
    warehouse_id integer DEFAULT 1 NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.stock_movements FORCE ROW LEVEL SECURITY;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfer_items (
    id integer NOT NULL,
    transfer_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfer_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfer_items_id_seq OWNED BY public.stock_transfer_items.id;


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    company_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    from_branch_id integer,
    to_branch_id integer,
    status text DEFAULT 'pending'::text NOT NULL,
    verification_code text,
    created_by integer,
    approved_by integer,
    shipped_by integer,
    received_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_at timestamp with time zone,
    shipped_at timestamp with time zone,
    received_at timestamp with time zone,
    notes text
);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfers_id_seq OWNED BY public.stock_transfers.id;


--
-- Name: super_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.super_settings (
    key text NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tax_brackets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_brackets (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    fiscal_year text NOT NULL,
    min_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    max_salary numeric(14,2),
    tax_rate numeric(7,4) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_brackets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_brackets_id_seq OWNED BY public.tax_brackets.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    type text NOT NULL,
    reference_type text,
    reference_id integer,
    safe_id integer,
    safe_name text,
    customer_id integer,
    customer_name text,
    amount numeric(12,2) NOT NULL,
    direction text DEFAULT 'none'::text NOT NULL,
    description text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.transactions FORCE ROW LEVEL SECURITY;


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: treasury_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_vouchers (
    id integer NOT NULL,
    voucher_no text NOT NULL,
    type text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    party_name text,
    description text NOT NULL,
    category text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.treasury_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.treasury_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.treasury_vouchers_id_seq OWNED BY public.treasury_vouchers.id;


--
-- Name: trial_abuse_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trial_abuse_log (
    id integer NOT NULL,
    email text NOT NULL,
    ip text NOT NULL,
    user_agent text,
    fingerprint text,
    fingerprint_data text,
    device_score integer DEFAULT 0,
    registration_count integer DEFAULT 0,
    company_id integer,
    flagged boolean DEFAULT false NOT NULL,
    override_reason text,
    overridden_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: trial_abuse_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trial_abuse_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trial_abuse_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trial_abuse_log_id_seq OWNED BY public.trial_abuse_log.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name text NOT NULL,
    address text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    is_consignment boolean DEFAULT false NOT NULL,
    supplier_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.warehouses FORCE ROW LEVEL SECURITY;


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: warranty_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    sale_id integer,
    product_id integer,
    product_name text NOT NULL,
    customer_id integer,
    customer_name text,
    customer_phone text,
    serial_number text,
    device_model text,
    warranty_months integer DEFAULT 3 NOT NULL,
    warranty_start date NOT NULL,
    warranty_end date NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: warranty_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warranty_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warranty_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warranty_records_id_seq OWNED BY public.warranty_records.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: accrual_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accrual_runs ALTER COLUMN id SET DEFAULT nextval('public.accrual_runs_id_seq'::regclass);


--
-- Name: accruals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accruals ALTER COLUMN id SET DEFAULT nextval('public.accruals_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attendance_deduction_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_settings ALTER COLUMN id SET DEFAULT nextval('public.attendance_deduction_settings_id_seq'::regclass);


--
-- Name: attendance_deduction_tiers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_tiers ALTER COLUMN id SET DEFAULT nextval('public.attendance_deduction_tiers_id_seq'::regclass);


--
-- Name: attendance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records ALTER COLUMN id SET DEFAULT nextval('public.attendance_records_id_seq'::regclass);


--
-- Name: attendance_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary ALTER COLUMN id SET DEFAULT nextval('public.attendance_summary_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: bad_debts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bad_debts ALTER COLUMN id SET DEFAULT nextval('public.bad_debts_id_seq'::regclass);


--
-- Name: bank_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts ALTER COLUMN id SET DEFAULT nextval('public.bank_accounts_id_seq'::regclass);


--
-- Name: bank_statement_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_lines ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_lines_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: budget_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_lines ALTER COLUMN id SET DEFAULT nextval('public.budget_lines_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: cost_centers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers ALTER COLUMN id SET DEFAULT nextval('public.cost_centers_id_seq'::regclass);


--
-- Name: customer_classifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications ALTER COLUMN id SET DEFAULT nextval('public.customer_classifications_id_seq'::regclass);


--
-- Name: customer_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger ALTER COLUMN id SET DEFAULT nextval('public.customer_ledger_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: daily_incentive_accrual id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual ALTER COLUMN id SET DEFAULT nextval('public.daily_incentive_accrual_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: deposit_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers ALTER COLUMN id SET DEFAULT nextval('public.deposit_vouchers_id_seq'::regclass);


--
-- Name: depreciation_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depreciation_runs ALTER COLUMN id SET DEFAULT nextval('public.depreciation_runs_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: employee_bonuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses ALTER COLUMN id SET DEFAULT nextval('public.employee_bonuses_id_seq'::regclass);


--
-- Name: employee_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts ALTER COLUMN id SET DEFAULT nextval('public.employee_contacts_id_seq'::regclass);


--
-- Name: employee_custody id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody ALTER COLUMN id SET DEFAULT nextval('public.employee_custody_id_seq'::regclass);


--
-- Name: employee_custody_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines ALTER COLUMN id SET DEFAULT nextval('public.employee_custody_lines_id_seq'::regclass);


--
-- Name: employee_deductions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions ALTER COLUMN id SET DEFAULT nextval('public.employee_deductions_id_seq'::regclass);


--
-- Name: employee_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents ALTER COLUMN id SET DEFAULT nextval('public.employee_documents_id_seq'::regclass);


--
-- Name: employee_incentive_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_incentive_assignments_id_seq'::regclass);


--
-- Name: employee_leave_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances ALTER COLUMN id SET DEFAULT nextval('public.employee_leave_balances_id_seq'::regclass);


--
-- Name: employee_shift_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_shift_assignments_id_seq'::regclass);


--
-- Name: employee_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history ALTER COLUMN id SET DEFAULT nextval('public.employee_status_history_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: erp_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users ALTER COLUMN id SET DEFAULT nextval('public.erp_users_id_seq'::regclass);


--
-- Name: exchange_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates ALTER COLUMN id SET DEFAULT nextval('public.exchange_rates_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: fiscal_years id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years ALTER COLUMN id SET DEFAULT nextval('public.fiscal_years_id_seq'::regclass);


--
-- Name: fixed_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets ALTER COLUMN id SET DEFAULT nextval('public.fixed_assets_id_seq'::regclass);


--
-- Name: idempotency_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys ALTER COLUMN id SET DEFAULT nextval('public.idempotency_keys_id_seq'::regclass);


--
-- Name: incentive_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics ALTER COLUMN id SET DEFAULT nextval('public.incentive_metrics_id_seq'::regclass);


--
-- Name: incentive_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules ALTER COLUMN id SET DEFAULT nextval('public.incentive_rules_id_seq'::regclass);


--
-- Name: incentive_schemes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes ALTER COLUMN id SET DEFAULT nextval('public.incentive_schemes_id_seq'::regclass);


--
-- Name: incentive_slabs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs ALTER COLUMN id SET DEFAULT nextval('public.incentive_slabs_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: job_titles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles ALTER COLUMN id SET DEFAULT nextval('public.job_titles_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: journal_entry_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_entry_lines_id_seq'::regclass);


--
-- Name: leave_accrual_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history ALTER COLUMN id SET DEFAULT nextval('public.leave_accrual_history_id_seq'::regclass);


--
-- Name: leave_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals ALTER COLUMN id SET DEFAULT nextval('public.leave_approvals_id_seq'::regclass);


--
-- Name: leave_blackout_dates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates ALTER COLUMN id SET DEFAULT nextval('public.leave_blackout_dates_id_seq'::regclass);


--
-- Name: leave_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies ALTER COLUMN id SET DEFAULT nextval('public.leave_policies_id_seq'::regclass);


--
-- Name: leave_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests ALTER COLUMN id SET DEFAULT nextval('public.leave_requests_id_seq'::regclass);


--
-- Name: leave_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types ALTER COLUMN id SET DEFAULT nextval('public.leave_types_id_seq'::regclass);


--
-- Name: monthly_incentive_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary ALTER COLUMN id SET DEFAULT nextval('public.monthly_incentive_summary_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: overtime_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records ALTER COLUMN id SET DEFAULT nextval('public.overtime_records_id_seq'::regclass);


--
-- Name: payment_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers ALTER COLUMN id SET DEFAULT nextval('public.payment_vouchers_id_seq'::regclass);


--
-- Name: payroll_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments ALTER COLUMN id SET DEFAULT nextval('public.payroll_adjustments_id_seq'::regclass);


--
-- Name: payroll_line_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items ALTER COLUMN id SET DEFAULT nextval('public.payroll_line_items_id_seq'::regclass);


--
-- Name: payroll_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods ALTER COLUMN id SET DEFAULT nextval('public.payroll_periods_id_seq'::regclass);


--
-- Name: payroll_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records ALTER COLUMN id SET DEFAULT nextval('public.payroll_records_id_seq'::regclass);


--
-- Name: plan_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_settings ALTER COLUMN id SET DEFAULT nextval('public.plan_settings_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: public_holidays id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays ALTER COLUMN id SET DEFAULT nextval('public.public_holidays_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_return_items_id_seq'::regclass);


--
-- Name: purchase_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns ALTER COLUMN id SET DEFAULT nextval('public.purchase_returns_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: receipt_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers ALTER COLUMN id SET DEFAULT nextval('public.receipt_vouchers_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: repair_checklist_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_checklist_items ALTER COLUMN id SET DEFAULT nextval('public.repair_checklist_items_id_seq'::regclass);


--
-- Name: repair_dashboard_cards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_dashboard_cards ALTER COLUMN id SET DEFAULT nextval('public.repair_dashboard_cards_id_seq'::regclass);


--
-- Name: repair_device_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_device_models ALTER COLUMN id SET DEFAULT nextval('public.repair_device_models_id_seq'::regclass);


--
-- Name: repair_job_parts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_job_parts ALTER COLUMN id SET DEFAULT nextval('public.repair_job_parts_id_seq'::regclass);


--
-- Name: repair_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_jobs ALTER COLUMN id SET DEFAULT nextval('public.repair_jobs_id_seq'::regclass);


--
-- Name: repair_payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_payments ALTER COLUMN id SET DEFAULT nextval('public.repair_payments_id_seq'::regclass);


--
-- Name: repair_pipeline_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_pipeline_config ALTER COLUMN id SET DEFAULT nextval('public.repair_pipeline_config_id_seq'::regclass);


--
-- Name: repair_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_status_history ALTER COLUMN id SET DEFAULT nextval('public.repair_status_history_id_seq'::regclass);


--
-- Name: repair_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_statuses ALTER COLUMN id SET DEFAULT nextval('public.repair_statuses_id_seq'::regclass);


--
-- Name: safe_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers ALTER COLUMN id SET DEFAULT nextval('public.safe_transfers_id_seq'::regclass);


--
-- Name: safes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes ALTER COLUMN id SET DEFAULT nextval('public.safes_id_seq'::regclass);


--
-- Name: salary_advance_deductions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_deductions_id_seq'::regclass);


--
-- Name: salary_advance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_history_id_seq'::regclass);


--
-- Name: salary_advance_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_ledger_id_seq'::regclass);


--
-- Name: salary_advance_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_settings_id_seq'::regclass);


--
-- Name: salary_advances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances ALTER COLUMN id SET DEFAULT nextval('public.salary_advances_id_seq'::regclass);


--
-- Name: salary_components id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components ALTER COLUMN id SET DEFAULT nextval('public.salary_components_id_seq'::regclass);


--
-- Name: salary_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history ALTER COLUMN id SET DEFAULT nextval('public.salary_history_id_seq'::regclass);


--
-- Name: salary_structures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures ALTER COLUMN id SET DEFAULT nextval('public.salary_structures_id_seq'::regclass);


--
-- Name: sale_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items ALTER COLUMN id SET DEFAULT nextval('public.sale_items_id_seq'::regclass);


--
-- Name: sale_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items ALTER COLUMN id SET DEFAULT nextval('public.sale_return_items_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: sales_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns ALTER COLUMN id SET DEFAULT nextval('public.sales_returns_id_seq'::regclass);


--
-- Name: sales_targets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_targets ALTER COLUMN id SET DEFAULT nextval('public.sales_targets_id_seq'::regclass);


--
-- Name: scrap_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_items ALTER COLUMN id SET DEFAULT nextval('public.scrap_items_id_seq'::regclass);


--
-- Name: shift_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules ALTER COLUMN id SET DEFAULT nextval('public.shift_schedules_id_seq'::regclass);


--
-- Name: statutory_contributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions ALTER COLUMN id SET DEFAULT nextval('public.statutory_contributions_id_seq'::regclass);


--
-- Name: stock_count_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items ALTER COLUMN id SET DEFAULT nextval('public.stock_count_items_id_seq'::regclass);


--
-- Name: stock_count_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions ALTER COLUMN id SET DEFAULT nextval('public.stock_count_sessions_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: stock_transfer_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items ALTER COLUMN id SET DEFAULT nextval('public.stock_transfer_items_id_seq'::regclass);


--
-- Name: stock_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers ALTER COLUMN id SET DEFAULT nextval('public.stock_transfers_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tax_brackets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets ALTER COLUMN id SET DEFAULT nextval('public.tax_brackets_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: treasury_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers ALTER COLUMN id SET DEFAULT nextval('public.treasury_vouchers_id_seq'::regclass);


--
-- Name: trial_abuse_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trial_abuse_log ALTER COLUMN id SET DEFAULT nextval('public.trial_abuse_log_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Name: warranty_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_records ALTER COLUMN id SET DEFAULT nextval('public.warranty_records_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, code, name, type, parent_id, level, is_posting, opening_balance, current_balance, is_active, company_id, created_at) FROM stdin;
1	AR-1001	عميل - ahmed awad	asset	\N	2	t	0.00	0.00	t	1	2026-05-01 18:46:25.636967+00
2	AR-1002	عميل - mobihub	asset	\N	2	t	0.00	0.00	t	1	2026-05-01 19:18:44.469125+00
3	11	mobihub	asset	\N	2	t	0.00	0.00	t	1	2026-05-01 20:06:31.530355+00
4	EXP-GENERAL	مصروفات عمومية وإدارية	expense	\N	2	t	0.00	100.00	t	1	2026-05-01 20:22:45.119118+00
5	SAFE-1	خزينة - نقدي	asset	\N	2	t	0.00	-100.00	t	1	2026-05-01 20:22:45.126588+00
\.


--
-- Data for Name: accrual_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accrual_runs (id, accrual_id, period, amount, entry_id, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: accruals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accruals (id, type, category, description, total_amount, months_total, start_date, end_date, expense_account_id, prepaid_account_id, amount_recognized, status, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, type, severity, message, reference_id, trigger_mode, last_triggered_date, role_target, user_id, is_read, is_resolved, resolved_at, resolved_by, company_id, created_at) FROM stdin;
1	cash_low	CRITICAL	رصيد الخزنة أقل من الحد الأدنى — الرصيد الحالي: ٠ ج.م	\N	daily	2026-05-01	admin,cashier	\N	f	t	2026-05-01 21:30:07.593+00	\N	1	2026-05-01 17:25:48.152747+00
2	low_stock	WARNING	المخزون منخفض للمنتج (13promax org screen) — الكمية: 5	1	daily	2026-05-01	admin,manager	\N	f	f	\N	\N	1	2026-05-01 21:30:07.5949+00
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, title, body, type, target, company_id, is_active, created_by, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_deduction_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_deduction_settings (id, company_id, grace_minutes, weekly_off_days, absence_full_day_amount, absence_half_day_amount, apply_early_leave, updated_at) FROM stdin;
\.


--
-- Data for Name: attendance_deduction_tiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_deduction_tiers (id, company_id, applies_to, min_minutes, max_minutes, amount, is_active, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_records (id, employee_id, attendance_date, check_in_time, check_out_time, status, working_hours, late_minutes, early_departure_minutes, overtime_hours, notes, submitted_by, verified_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendance_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_summary (id, employee_id, month, total_present_days, total_absent_days, total_late_days, total_early_departures, total_overtime_hours, total_working_hours, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, record_type, record_id, old_value, new_value, user_id, username, company_id, created_at) FROM stdin;
1	SUPER_ADMIN_LIST_VIEW	company	0	\N	\N	1	superadmin	\N	2026-05-01 17:28:12.171838+00
2	SUPER_ADMIN_LIST_VIEW	company	0	\N	\N	1	superadmin	\N	2026-05-01 17:40:28.206179+00
3	SUPER_ADMIN_LIST_VIEW	company	0	\N	\N	1	superadmin	\N	2026-05-01 17:42:38.719517+00
4	repair_status_change	repair_job	1	{"status": "received"}	{"status": "final_quality_check"}	2	المدير الافتراضي	1	2026-05-01 18:52:42.505713+00
5	repair_status_change	repair_job	1	{"status": "final_quality_check"}	{"status": "ready_for_delivery"}	2	المدير الافتراضي	1	2026-05-01 18:54:23.521032+00
6	repair_status_change	repair_job	1	{"status": "ready_for_delivery"}	{"status": "shipped"}	2	المدير الافتراضي	1	2026-05-01 18:54:46.452221+00
7	create	customer	2	\N	{"id": 2, "name": "mobihub", "phone": "01033220200", "source": null, "balance": 0, "account_id": 2, "company_id": 1, "created_at": "2026-05-01T19:18:44.460Z", "is_customer": true, "is_supplier": true, "customer_code": 1002, "normalized_name": "mobihub", "classification_id": null}	2	admin	\N	2026-05-01 19:18:44.481759+00
8	repair_status_change	repair_job	1	{"status": "shipped"}	{"status": "delivered"}	2	المدير الافتراضي	1	2026-05-01 20:22:45.355749+00
9	repair_status_change	repair_job	2	{"status": "received"}	{"status": "waiting_customer_approval"}	2	المدير الافتراضي	1	2026-05-01 21:29:55.266945+00
10	repair_status_change	repair_job	2	{"status": "waiting_customer_approval"}	{"status": "final_quality_check"}	2	المدير الافتراضي	1	2026-05-01 21:30:00.85753+00
11	repair_status_change	repair_job	2	{"status": "final_quality_check"}	{"status": "delivered"}	2	المدير الافتراضي	1	2026-05-01 21:30:51.497992+00
12	repair_status_change	repair_job	3	{"status": "received"}	{"status": "delivered"}	2	المدير الافتراضي	1	2026-05-01 21:32:42.169934+00
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, filename, size, trigger, created_at) FROM stdin;
\.


--
-- Data for Name: bad_debts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bad_debts (id, company_id, customer_id, customer_name, amount, reason, account_id, status, source_invoice_id, source_repair_job_id, notes, written_off_at, created_by, created_by_name, created_at) FROM stdin;
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_accounts (id, name, account_number, bank_name, currency, safe_id, opening_balance, is_active, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: bank_statement_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bank_statement_lines (id, bank_account_id, date, description, amount, type, reference, matched_entry_id, status, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, company_id, name, address, phone, is_active, created_at) FROM stdin;
1	1	1	\N	\N	t	2026-05-01 19:16:04.978648+00
\.


--
-- Data for Name: budget_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_lines (id, budget_id, account_id, account_code, account_name, account_type, period, budgeted_amount, company_id) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, name, fiscal_year, date_from, date_to, status, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, company_id) FROM stdin;
1	org screen	1
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, plan_type, edition, features, start_date, end_date, is_active, admin_email, created_at, signup_ip, signup_user_agent, has_used_trial, email_verified, email_verification_token, email_verification_expires_at, verification_status, trial_score, is_suspicious) FROM stdin;
1	الشركة الافتراضية	professional	advanced	{"hr": true, "pos": true, "budgets": true, "warranty": true, "accounting": true, "consignment": true, "maintenance": true, "fixed_assets": true, "bank_reconciliation": true}	2026-05-01	2027-05-01	t	\N	2026-05-01 17:23:22.543197+00	\N	\N	f	f	\N	\N	pending	100	f
\.


--
-- Data for Name: cost_centers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_centers (id, code, name, description, is_active, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: customer_classifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_classifications (id, name, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: customer_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_ledger (id, customer_id, type, amount, reference_type, reference_id, reference_no, description, date, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, customer_code, normalized_name, phone, balance, is_customer, is_supplier, account_id, classification_id, source, company_id, created_at) FROM stdin;
1	ahmed awad	1001	ahmed awad	01000847074	0.00	t	f	1	\N	repair	1	2026-05-01 18:46:25.538084+00
2	mobihub	1002	mobihub	01033220200	0.00	t	t	2	\N	\N	1	2026-05-01 19:18:44.46064+00
\.


--
-- Data for Name: daily_incentive_accrual; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_incentive_accrual (id, employee_id, incentive_rule_id, accrual_date, metric_value, target_value, achievement_percentage, accrued_amount, currency, status, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, company_id, name_en, name_ar, description_en, description_ar, created_at) FROM stdin;
\.


--
-- Data for Name: deposit_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deposit_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, source, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: depreciation_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.depreciation_runs (id, asset_id, period, amount, entry_id, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, company_id, branch_id, device_no, brand, model, color, storage, imei, serial_no, battery_health, grade, condition_notes, purchase_price, sale_price, status, dual_sim, with_box, icloud_locked, network_locked, previously_opened, mdm_locked, supplier_name, purchase_invoice_no, inspector_name, sold_to_customer_id, sold_to_customer_name, sold_at, sold_by_user_id, sold_by_user_name, sold_price, warranty_months, payment_method, payment_status, added_by_user_id, added_by_user_name, supplier_phone, id_card_data, product_id, purchase_id, purchase_invoice_ref, inspection_data, inspector_employee_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_bonuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_bonuses (id, company_id, employee_id, amount, reason, granted_date, granted_by, currency, created_at) FROM stdin;
\.


--
-- Data for Name: employee_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_contacts (id, employee_id, contact_type, name, relationship, phone, email, created_at) FROM stdin;
\.


--
-- Data for Name: employee_custody; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_custody (id, company_id, employee_id, safe_id, amount, returned_amount, purpose, granted_date, settled_date, status, granted_by, currency, notes, reimbursement_due, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_custody_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_custody_lines (id, company_id, custody_id, category, amount, description, line_date, expense_id, created_at) FROM stdin;
\.


--
-- Data for Name: employee_deductions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_deductions (id, company_id, employee_id, deduction_type, amount, reason, deduction_date, currency, created_by, attendance_record_id, source, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: employee_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_documents (id, employee_id, document_type, file_name, file_path, expiry_date, verified_by, verified_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_incentive_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_incentive_assignments (id, employee_id, incentive_scheme_id, assigned_date, end_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: employee_leave_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_leave_balances (id, employee_id, leave_type_id, accrued_days, used_days, balance_days, carryover_days, as_of_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_shift_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_shift_assignments (id, employee_id, shift_schedule_id, assigned_date, end_date, created_at) FROM stdin;
\.


--
-- Data for Name: employee_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_status_history (id, employee_id, old_status, new_status, reason, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, company_id, employee_code, first_name_en, last_name_en, first_name_ar, last_name_ar, email, phone, personal_phone, national_id, national_id_image, job_title_id, department_id, branch_id, hire_date, employment_status, salary, currency, salary_type, commission_rate, commission_basis, commission_scope_dept_id, bank_account, address_en, address_ar, city, country, notes, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: erp_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_users (id, name, username, email, pin, role, permissions, active, company_id, warehouse_id, safe_id, employee_id, login_attempts, last_login, created_at, totp_secret, totp_enabled, totp_verified, trusted_device_id) FROM stdin;
1	Super Admin	superadmin	\N	$2b$10$8Yyyg3U7DjoRln9LYB1KxeXQQnvCjqd/A0BGELdc.Q0hU2bxYoLia	super_admin	{}	t	\N	\N	\N	\N	0	2026-05-01 17:28:09.075+00	2026-05-01 17:23:22.648011+00	\N	f	f	\N
2	المدير الافتراضي	admin	\N	$2b$10$aypRahHDkeHCGjQGwoGvbeqQcyuD1pkhZIeF..q.H2wLxIVrQfbuO	admin	{}	t	1	\N	\N	\N	0	2026-05-01 21:30:05.351+00	2026-05-01 17:23:22.73754+00	\N	f	f	1777656345929-xckqoyv8-111
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, currency, rate, date, company_id, notes, created_at) FROM stdin;
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, name, company_id, created_at) FROM stdin;
1	مصاريف شحن صيانة	1	2026-05-01 20:22:44.982858+00
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, amount, description, safe_id, safe_name, reference_type, reference_id, company_id, branch_id, created_at) FROM stdin;
1	مصاريف شحن صيانة	100.00	تسليم بطاقة صيانة REP-2026-0001	1	نقدي	repair_job	1	1	\N	2026-05-01 20:22:44.982858+00
\.


--
-- Data for Name: fiscal_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fiscal_years (id, company_id, year_label, start_date, end_date, is_open, is_current, closed_by, closed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: fixed_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fixed_assets (id, code, name, description, category, purchase_date, purchase_cost, residual_value, useful_life_months, depreciation_method, asset_account_id, acc_dep_account_id, dep_expense_account_id, accumulated_depreciation, status, disposal_date, disposal_proceeds, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idempotency_keys (id, company_id, scope, key, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_metrics (id, incentive_rule_id, employee_id, metric_date, metric_value, source_document_id, source_type, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_rules (id, incentive_scheme_id, metric_type, target_value, incentive_amount, incentive_type, calculation_method, currency, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_schemes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_schemes (id, company_id, name_en, name_ar, description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incentive_slabs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_slabs (id, incentive_rule_id, slab_number, from_percentage, to_percentage, incentive_value, created_at) FROM stdin;
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.income (id, source, amount, description, safe_id, safe_name, company_id, branch_id, created_at) FROM stdin;
\.


--
-- Data for Name: job_titles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_titles (id, company_id, name_en, name_ar, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, entry_no, date, description, status, reference, total_debit, total_credit, company_id, created_at) FROM stdin;
1	JE-00001	2026-05-01	تسليم بطاقة صيانة REP-2026-0001	posted	repair_shipping:1	100.00	100.00	1	2026-05-01 20:22:45.133772+00
\.


--
-- Data for Name: journal_entry_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entry_lines (id, entry_id, account_id, account_name, account_code, debit, credit, description, cost_center_id) FROM stdin;
1	1	4	مصروفات عمومية وإدارية	EXP-GENERAL	100.00	0.00	\N	\N
2	1	5	خزينة - نقدي	SAFE-1	0.00	100.00	\N	\N
\.


--
-- Data for Name: leave_accrual_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_accrual_history (id, employee_id, leave_type_id, accrued_days, month, created_at) FROM stdin;
\.


--
-- Data for Name: leave_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_approvals (id, leave_request_id, approver_id, status, comment, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: leave_blackout_dates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_blackout_dates (id, company_id, start_date, end_date, reason_en, reason_ar, created_at) FROM stdin;
\.


--
-- Data for Name: leave_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_policies (id, company_id, leave_type_id, entitlement_days_per_year, accrual_method, min_duration, max_consecutive_days, probation_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_requests (id, employee_id, leave_type_id, start_date, end_date, total_days, status, reason, rejection_reason, submitted_at, approved_by, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leave_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_types (id, company_id, name_en, name_ar, code, is_paid, requires_approval, carryover_allowed, carryover_limit, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: monthly_incentive_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monthly_incentive_summary (id, employee_id, month, total_accrued, included_in_payroll_record_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, company_id, user_id, type, title, message, link, reference_id, is_read, created_at, read_at) FROM stdin;
1	1	2	device_alert	⚠ تسجيل دخول من جهاز غير معروف	المستخدم "المدير الافتراضي" يحاول فتح النظام من جهاز مختلف عن جهازه المعتاد. الرجاء التحقق.	/settings/users	\N	t	2026-05-01 17:56:29.847519+00	2026-05-01 18:57:21.016+00
2	1	2	device_alert	⚠ تسجيل دخول من جهاز غير معروف	المستخدم "المدير الافتراضي" يحاول فتح النظام من جهاز مختلف عن جهازه المعتاد. الرجاء التحقق.	/settings/users	\N	t	2026-05-01 18:45:16.277751+00	2026-05-01 18:57:21.016+00
3	1	2	repair_assigned	تم تعيينك على بطاقة صيانة	بطاقة REP-2026-0001 — Apple Apple Watch Apple Watch Series 9	/repairs?job=1	1	t	2026-05-01 18:52:12.624684+00	2026-05-01 18:57:21.016+00
4	1	2	device_alert	⚠ تسجيل دخول من جهاز غير معروف	المستخدم "المدير الافتراضي" يحاول فتح النظام من جهاز مختلف عن جهازه المعتاد. الرجاء التحقق.	/settings/users	\N	f	2026-05-01 21:27:36.853443+00	\N
5	1	2	device_alert	⚠ تسجيل دخول من جهاز غير معروف	المستخدم "المدير الافتراضي" يحاول فتح النظام من جهاز مختلف عن جهازه المعتاد. الرجاء التحقق.	/settings/users	\N	f	2026-05-01 21:30:05.628026+00	\N
6	1	2	repair_assigned	تم تعيينك على بطاقة صيانة	بطاقة REP-2026-0001/W1 — Apple Apple Watch Apple Watch Series 9	/repairs?job=2	2	f	2026-05-01 21:30:34.116334+00	\N
7	1	2	repair_assigned	تم تعيينك على بطاقة صيانة	بطاقة REP-2026-0003 — Apple iPhone iPhone 13 Pro Max	/repairs?job=3	3	f	2026-05-01 21:32:16.677196+00	\N
\.


--
-- Data for Name: overtime_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.overtime_records (id, employee_id, date, hours, reason, approved_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: payment_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_adjustments (id, payroll_record_id, adjustment_type, amount, reason, approved_by, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_line_items (id, payroll_record_id, component_name, component_type, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_periods (id, company_id, name, start_date, end_date, status, processed_by, processed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payroll_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_records (id, payroll_period_id, employee_id, gross_salary, total_allowances, total_deductions, tax_amount, net_salary, advance_deductions, incentive_amount, currency, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_settings (id, key, name_ar, description, price, includes_mobile, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, category, category_id, quantity, cost_price, sale_price, low_stock_threshold, tax_rate, company_id, created_at) FROM stdin;
1	13promax org screen	HT66275178447	\N	1	4.000	8500.00	8500.00	5	0.00	1	2026-05-01 19:12:31.784522+00
\.


--
-- Data for Name: public_holidays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.public_holidays (id, company_id, holiday_date, name_en, name_ar, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_items (id, purchase_id, product_id, product_name, quantity, unit_price, total_price, quantity_returned) FROM stdin;
1	1	1	125	5.000	10000.00	50000.00	0.000
\.


--
-- Data for Name: purchase_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_return_items (id, return_id, product_id, product_name, quantity, unit_price, total_price, original_purchase_item_id, unit_cost_at_return, total_cost_at_return) FROM stdin;
\.


--
-- Data for Name: purchase_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_returns (id, request_id, return_no, purchase_id, customer_id, customer_name, total_amount, refund_type, safe_id, safe_name, date, reason, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchases (id, request_id, invoice_no, supplier_name, customer_id, customer_name, payment_type, total_amount, paid_amount, remaining_amount, status, posting_status, tax_amount, tax_rate, currency, exchange_rate, is_consignment, consignment_warehouse_id, notes, date, company_id, branch_id, created_at) FROM stdin;
1	a661297e-9efd-44f9-beee-f2e0420036fd	PUR-1777663032152	\N	\N	\N	cash	50000.00	50000.00	0.00	paid	draft	0.00	0.00	EGP	1.000000	f	\N	\N	2026-05-01	1	\N	2026-05-01 19:17:12.153926+00
\.


--
-- Data for Name: receipt_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, token_hash, user_id, used, revoked, expires_at, created_at, used_at) FROM stdin;
1	dffa400883196520df22f7e7ec7f8e36e40fe3bb99e615415e5d94426a3a3c62	2	f	f	2026-05-08 17:25:45.731+00	2026-05-01 17:25:45.732344+00	\N
2	a40b5556924418cd3ac7908cf6ae17d74bd495b570a2014675a146375696276e	1	f	f	2026-05-08 17:28:09.075+00	2026-05-01 17:28:09.075701+00	\N
3	fa97ba386182950213f776d26d117b1119cae86da32a1cb2dbd576c7c93fabec	2	f	f	2026-05-08 17:43:16.016+00	2026-05-01 17:43:16.017366+00	\N
4	0d147a03a190e8886ece0f2597f3317b8a24259817fa86527de4dbc582878b26	2	f	f	2026-05-08 17:56:29.6+00	2026-05-01 17:56:29.601394+00	\N
5	1c726571e13e2438829df7aa38e6deaec874de37eebbfcac56750ed456e2fd58	2	f	f	2026-05-08 18:45:15.823+00	2026-05-01 18:45:15.823797+00	\N
6	b16bc25258e530cc29054b438a32c350313f038e3f43b6843821768d3d6a35bd	2	f	f	2026-05-08 21:27:36.587+00	2026-05-01 21:27:36.588036+00	\N
7	c9dc7f19303135019686a69814c6ba6b8779420aa85633854242167ed8a44a87	2	f	f	2026-05-08 21:30:05.351+00	2026-05-01 21:30:05.35242+00	\N
\.


--
-- Data for Name: repair_checklist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_checklist_items (id, company_id, label_ar, category, device_type, sort_order, is_system, created_at) FROM stdin;
\.


--
-- Data for Name: repair_dashboard_cards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_dashboard_cards (id, company_id, name, statuses, color, icon, sort_order, alert_threshold, is_system, created_at, updated_at) FROM stdin;
1	1	انتظار	["pending","received","waiting_customer_approval","waiting_parts"]	#f59e0b	Clock	0	\N	t	2026-05-01 17:43:27.677945	2026-05-01 17:43:27.677945
2	1	جارية	["in_progress","in_repair","initial_inspection","diagnosis","approved","diagnosing"]	#06b6d4	Wrench	1	\N	t	2026-05-01 17:43:27.677945	2026-05-01 17:43:27.677945
3	1	منتهية	["done","repaired","final_quality_check","ready_for_delivery","qa","delivered"]	#10b981	CheckCheck	2	\N	t	2026-05-01 17:43:27.677945	2026-05-01 17:43:27.677945
\.


--
-- Data for Name: repair_device_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_device_models (id, company_id, brand, category, model, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: repair_job_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_job_parts (id, job_id, company_id, product_id, product_name, quantity, unit_price, source, warehouse_id, is_returned, return_destination, returned_at, created_at) FROM stdin;
1	3	1	1	13promax org screen	1.00	12000.00	internal	1	t	scrap	2026-05-01 21:34:06.573	2026-05-01 21:32:41.780344
\.


--
-- Data for Name: repair_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_jobs (id, company_id, job_no, customer_id, customer_name, customer_phone, device_brand, device_model, device_type, imei, serial_no, color, storage, problem_description, technician_id, technician_name, technician_2_id, technician_2_name, technician_2_section, status, checklist, qa_checklist, qa_completed_at, qa_notes, device_score, estimated_cost, final_cost, deposit_paid, external_workshop, external_workshop_name, external_workshop_cost, broker_name, broker_commission, alert_days_threshold, locked, received_at, estimated_delivery, delivered_at, device_pin, accessories, branch_id, notes, pre_delivery_reviewed_at, shipping_cost, shipping_expense_id, shipping_settled_at, final_discount, delivery_receipt_sent_at, delivery_receipt_method, created_at, updated_at, job_type, warranty_of, is_customer_returned, customer_return_amount) FROM stdin;
1	1	REP-2026-0001	1	ahmed awad	01000847074	Apple	Apple Watch Apple Watch Series 9	watch	543534534535353	\N	\N	\N	power	2	المدير الافتراضي	\N	\N	\N	delivered	[{"id":"screen","label":"الشاشة والعرض","status":"pass"},{"id":"touch","label":"اللمس والاستجابة","status":"pass"},{"id":"battery","label":"البطارية والشحن","status":"pass"},{"id":"front_camera","label":"الكاميرا الأمامية","status":"pass"},{"id":"rear_camera","label":"الكاميرا الخلفية","status":"pass"},{"id":"speaker","label":"المكبر والسماعة","status":"pass"},{"id":"microphone","label":"الميكروفون","status":"pass"},{"id":"wifi","label":"الواي فاي","status":"pass"},{"id":"bluetooth","label":"البلوتوث","status":"pass"},{"id":"network","label":"الشبكة والشريحة","status":"pass"},{"id":"port","label":"منفذ الشحن/البيانات","status":"pass"},{"id":"buttons","label":"الأزرار والمفاتيح","status":"pass"},{"id":"biometric","label":"البصمة / Face ID","status":"pass"},{"id":"body","label":"الجسم الخارجي","status":"pass"}]	[{"id":"screen","label":"الشاشة والعرض","label_ar":"الشاشة والعرض","status":"pass","notes":""},{"id":"touch","label":"اللمس والاستجابة","label_ar":"اللمس والاستجابة","status":"pass","notes":""},{"id":"battery","label":"البطارية والشحن","label_ar":"البطارية والشحن","status":"pass","notes":""},{"id":"front_camera","label":"الكاميرا الأمامية","label_ar":"الكاميرا الأمامية","status":"pass","notes":""},{"id":"rear_camera","label":"الكاميرا الخلفية","label_ar":"الكاميرا الخلفية","status":"pass","notes":""},{"id":"speaker","label":"المكبر والسماعة","label_ar":"المكبر والسماعة","status":"pass","notes":""},{"id":"microphone","label":"الميكروفون","label_ar":"الميكروفون","status":"pass","notes":""},{"id":"wifi","label":"الواي فاي","label_ar":"الواي فاي","status":"pass","notes":""},{"id":"bluetooth","label":"البلوتوث","label_ar":"البلوتوث","status":"pass","notes":""},{"id":"network","label":"الشبكة والشريحة","label_ar":"الشبكة والشريحة","status":"pass","notes":""},{"id":"port","label":"منفذ الشحن/البيانات","label_ar":"منفذ الشحن/البيانات","status":"pass","notes":""},{"id":"buttons","label":"الأزرار والمفاتيح","label_ar":"الأزرار والمفاتيح","status":"pass","notes":""},{"id":"biometric","label":"البصمة / Face ID","label_ar":"البصمة / Face ID","status":"pass","notes":""},{"id":"body","label":"الجسم الخارجي","label_ar":"الجسم الخارجي","status":"pass","notes":""}]	2026-05-01 18:54:23.31		\N	0.00	2000.00	0.00	f	\N	0.00	\N	0.00	\N	t	2026-05-01	\N	2026-05-01	543534534	case	\N	\N	2026-05-01 20:22:44.466	100.00	1	2026-05-01 20:22:44.983	0.00	\N	\N	2026-05-01 18:52:12.494967	2026-05-01 20:22:45.338	repair	\N	f	0.00
3	1	REP-2026-0003	1	ahmed awad	01000847074	Apple	iPhone iPhone 13 Pro Max	iphone	56565464646456	\N	\N	\N	screen	2	المدير الافتراضي	\N	\N	\N	delivered	[{"id":"screen","label":"الشاشة والعرض","status":"pass"},{"id":"touch","label":"اللمس والاستجابة","status":"pass"},{"id":"battery","label":"البطارية والشحن","status":"pass"},{"id":"front_camera","label":"الكاميرا الأمامية","status":"pass"},{"id":"rear_camera","label":"الكاميرا الخلفية","status":"pass"},{"id":"speaker","label":"المكبر والسماعة","status":"pass"},{"id":"microphone","label":"الميكروفون","status":"pass"},{"id":"wifi","label":"الواي فاي","status":"pass"},{"id":"bluetooth","label":"البلوتوث","status":"pass"},{"id":"network","label":"الشبكة والشريحة","status":"pass"},{"id":"port","label":"منفذ الشحن/البيانات","status":"fail"},{"id":"buttons","label":"الأزرار والمفاتيح","status":"pass"},{"id":"biometric","label":"البصمة / Face ID","status":"fail"},{"id":"body","label":"الجسم الخارجي","status":"fail"}]	\N	\N	\N	\N	12000.00	0.00	0.00	f	\N	0.00	\N	0.00	\N	t	2026-05-01	\N	2026-05-01	64646	case	\N	\N	2026-05-01 21:32:41.78	0.00	\N	2026-05-01 21:32:41.967	0.00	\N	\N	2026-05-01 21:32:16.625932	2026-05-01 21:34:06.572	repair	\N	t	12000.00
2	1	REP-2026-0001/W1	1	ahmed awad	01000847074	Apple	Apple Watch Apple Watch Series 9	watch	543534534535353	\N	\N	\N	الساعه رجعت زي ماهيا	2	المدير الافتراضي	\N	\N	\N	delivered	\N	\N	\N	\N	\N	0.00	2000.00	0.00	f	\N	0.00	\N	0.00	\N	t	2026-05-01	\N	2026-05-01	\N	\N	\N	\N	2026-05-01 21:30:51.051	0.00	\N	2026-05-01 21:30:51.276	0.00	\N	\N	2026-05-01 21:28:29.064777	2026-05-01 21:30:51.484	warranty	1	f	0.00
\.


--
-- Data for Name: repair_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_payments (id, company_id, job_id, amount, payment_method, notes, received_by, received_by_name, safe_id, safe_name, created_at) FROM stdin;
\.


--
-- Data for Name: repair_pipeline_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_pipeline_config (id, company_id, status_key, label_ar, color, icon, sort_order, requirements, created_at) FROM stdin;
\.


--
-- Data for Name: repair_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_status_history (id, job_id, company_id, status_from, status_to, technician_id, technician_name, user_id, user_name, event_type, note, created_at) FROM stdin;
1	1	1	\N	received	\N	\N	2	المدير الافتراضي	created	تم إنشاء بطاقة الصيانة	2026-05-01 18:52:12.618582
2	1	1	received	final_quality_check	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 18:52:42.499608
3	1	1	\N	\N	\N	\N	2	المدير الافتراضي	qa_completed	إكمال فحص مراقبة الجودة — 0 بند فشل	2026-05-01 18:53:54.390354
4	1	1	\N	\N	\N	\N	2	المدير الافتراضي	qa_completed	إكمال فحص مراقبة الجودة — 0 بند فشل	2026-05-01 18:54:23.318435
5	1	1	final_quality_check	ready_for_delivery	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 18:54:23.515063
6	1	1	ready_for_delivery	shipped	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 18:54:46.444581
7	1	1	\N	\N	\N	\N	2	المدير الافتراضي	pre_delivery_reviewed	مراجعة ما قبل التسليم — 0 قطعة · لا يوجد دفع	2026-05-01 20:22:44.467581
8	1	1	\N	\N	\N	\N	2	المدير الافتراضي	shipping_settled	تكلفة شحن 100.00 — مصروف #1	2026-05-01 20:22:44.982858
9	1	1	shipped	delivered	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 20:22:45.348956
10	2	1	\N	received	\N	\N	2	المدير الافتراضي	warranty_created	بطاقة ضمان مرتبطة بـ REP-2026-0001	2026-05-01 21:28:29.071898
11	1	1	delivered	delivered	\N	\N	2	المدير الافتراضي	warranty_opened	فُتح طلب ضمان: REP-2026-0001/W1	2026-05-01 21:28:29.07638
12	2	1	received	waiting_customer_approval	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 21:29:55.252274
13	2	1	waiting_customer_approval	final_quality_check	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 21:30:00.851391
14	2	1	\N	\N	2	المدير الافتراضي	2	المدير الافتراضي	technician_change	تغيير فني أساسي: — → المدير الافتراضي	2026-05-01 21:30:34.111101
15	2	1	\N	\N	\N	\N	2	المدير الافتراضي	pre_delivery_reviewed	مراجعة ما قبل التسليم — 0 قطعة · لا يوجد دفع	2026-05-01 21:30:51.051822
16	2	1	\N	\N	\N	\N	2	المدير الافتراضي	shipping_settled	تم تأكيد عدم وجود تكلفة شحن	2026-05-01 21:30:51.298166
17	2	1	final_quality_check	delivered	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 21:30:51.491471
18	3	1	\N	received	\N	\N	2	المدير الافتراضي	created	تم إنشاء بطاقة الصيانة	2026-05-01 21:32:16.662548
19	3	1	\N	\N	\N	\N	2	المدير الافتراضي	pre_delivery_reviewed	مراجعة ما قبل التسليم — 1 قطعة · لا يوجد دفع	2026-05-01 21:32:41.780344
20	3	1	\N	\N	\N	\N	2	المدير الافتراضي	shipping_settled	تم تأكيد عدم وجود تكلفة شحن	2026-05-01 21:32:41.973652
21	3	1	received	delivered	\N	\N	2	المدير الافتراضي	pipeline_transition	انتقال تلقائي عبر Pipeline	2026-05-01 21:32:42.162989
22	3	1	delivered	delivered	\N	\N	2	المدير الافتراضي	customer_return	مرتجع عميل — استرداد 12000 — الجهاز لا يعمل	2026-05-01 21:34:06.571215
\.


--
-- Data for Name: repair_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_statuses (id, company_id, key, label_ar, color, sort_order, is_system, created_at) FROM stdin;
1	1	pending	في الانتظار	#f59e0b	1	t	2026-05-01 17:43:27.677066
2	1	diagnosing	قيد الفحص	#3b82f6	2	t	2026-05-01 17:43:27.677066
3	1	in_progress	قيد الإصلاح	#8b5cf6	3	t	2026-05-01 17:43:27.677066
4	1	waiting_parts	بانتظار قطعة	#ec4899	4	t	2026-05-01 17:43:27.677066
5	1	qa	اختبار الجودة	#06b6d4	5	t	2026-05-01 17:43:27.677066
6	1	done	تم الإصلاح	#10b981	6	t	2026-05-01 17:43:27.677066
7	1	shipped	قيد الشحن	#0ea5e9	7	t	2026-05-01 17:43:27.677066
8	1	delivered	تم التسليم	#14b8a6	8	t	2026-05-01 17:43:27.677066
9	1	cancelled	ملغي	#ef4444	9	t	2026-05-01 17:43:27.677066
\.


--
-- Data for Name: safe_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.safe_transfers (id, from_safe_id, from_safe_name, to_safe_id, to_safe_name, amount, fee_type, fee_rate, fee_amount, net_amount, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: safes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.safes (id, name, balance, company_id, branch_id, created_at) FROM stdin;
2	انستا	50000.00	1	1	2026-05-01 19:14:43.226296+00
3	كاش	10000.00	1	1	2026-05-01 19:14:51.768938+00
1	نقدي	49900.00	1	1	2026-05-01 19:14:32.372931+00
\.


--
-- Data for Name: salary_advance_deductions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_deductions (id, salary_advance_id, payroll_record_id, deduction_amount, deduction_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: salary_advance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_history (id, salary_advance_id, old_status, new_status, changed_by, comment, changed_at) FROM stdin;
\.


--
-- Data for Name: salary_advance_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_ledger (id, employee_id, advance_id, ledger_type, amount, balance, ledger_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: salary_advance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_settings (id, company_id, max_advance_percentage, max_concurrent_advances, min_salary_for_advance, repayment_tenure_months, requires_approval, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_advances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advances (id, company_id, employee_id, requested_date, requested_amount, approved_amount, advance_type, reason, status, approver_id, approved_at, rejection_reason, remaining_balance, currency, deduct_from, safe_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_components (id, salary_structure_id, component_type, name_en, name_ar, amount, percentage_of_base, is_mandatory, is_taxable, sequence, created_at) FROM stdin;
\.


--
-- Data for Name: salary_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_history (id, employee_id, salary_amount, currency, effective_date, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: salary_structures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_structures (id, company_id, name_en, name_ar, base_salary, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_items (id, sale_id, product_id, product_name, quantity, unit_price, total_price, cost_price, cost_total, quantity_returned) FROM stdin;
\.


--
-- Data for Name: sale_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_return_items (id, return_id, product_id, product_name, quantity, unit_price, total_price, original_sale_item_id, unit_cost_at_return, total_cost_at_return) FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, request_id, invoice_no, customer_name, customer_id, payment_type, total_amount, paid_amount, remaining_amount, status, posting_status, safe_id, safe_name, warehouse_id, warehouse_name, salesperson_id, salesperson_name, discount_percent, discount_amount, tax_amount, tax_rate, notes, date, user_id, company_id, branch_id, created_at) FROM stdin;
\.


--
-- Data for Name: sales_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_returns (id, request_id, return_no, sale_id, customer_id, customer_name, total_amount, refund_type, safe_id, safe_name, date, reason, notes, user_id, warehouse_id, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: sales_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_targets (id, company_id, user_id, year_month, target_amount, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scrap_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scrap_items (id, company_id, product_id, product_name, quantity, unit_cost, warehouse_id, reason, source_type, source_id, created_by, created_by_name, created_at) FROM stdin;
1	1	1	13promax org screen	1.00	12000.00	1	مرتجع عميل — بطاقة صيانة REP-2026-0003	repair_return	3	2	المدير الافتراضي	2026-05-01 21:34:06.571215
\.


--
-- Data for Name: shift_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_schedules (id, company_id, name_en, name_ar, start_time, end_time, break_duration, grace_minutes, weekly_hours, working_days, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: statutory_contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statutory_contributions (id, company_id, contribution_type, name_ar, name_en, employee_percentage, employer_percentage, is_mandatory, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_count_items (id, session_id, product_id, system_qty, physical_qty, notes, created_at) FROM stdin;
\.


--
-- Data for Name: stock_count_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_count_sessions (id, warehouse_id, status, notes, company_id, created_by, applied_at, created_at) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, product_id, product_name, movement_type, quantity, quantity_before, quantity_after, unit_cost, reference_type, reference_id, reference_no, notes, date, warehouse_id, company_id, branch_id, created_at) FROM stdin;
1	1	125	purchase	5.000	0.000	5.000	10000.0000	purchase	1	PUR-1777663032152	فاتورة مشتريات	2026-05-01	1	1	\N	2026-05-01 19:17:12.153926+00
2	1	13promax org screen	repair_part	-1.000	5.000	4.000	12000.0000	repair_job	3	\N	قطعة مستخدمة في بطاقة صيانة #REP-2026-0003	2026-05-01	1	1	\N	2026-05-01 21:32:41.780344+00
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfer_items (id, transfer_id, product_id, product_name, quantity, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfers (id, company_id, product_id, product_name, quantity, from_branch_id, to_branch_id, status, verification_code, created_by, approved_by, shipped_by, received_by, created_at, approved_at, shipped_at, received_at, notes) FROM stdin;
\.


--
-- Data for Name: super_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.super_settings (key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, company_id, value, updated_at) FROM stdin;
\.


--
-- Data for Name: tax_brackets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_brackets (id, company_id, fiscal_year, min_salary, max_salary, tax_rate, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, type, reference_type, reference_id, safe_id, safe_name, customer_id, customer_name, amount, direction, description, date, company_id, created_at) FROM stdin;
1	purchase_cash	purchase	1	1	نقدي	\N	\N	50000.00	out	دفع نقدي — فاتورة مشتريات PUR-1777663032152	2026-05-01	1	2026-05-01 19:17:12.153926+00
2	expense	repair_shipping	1	1	\N	\N	\N	100.00	none	تسليم بطاقة صيانة REP-2026-0001	\N	1	2026-05-01 20:22:44.982858+00
3	expense	repair_return	3	\N	\N	\N	\N	12000.00	none	استرداد مبلغ مرتجع صيانة — REP-2026-0003	\N	1	2026-05-01 21:34:06.571215+00
\.


--
-- Data for Name: treasury_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_vouchers (id, voucher_no, type, safe_id, safe_name, amount, party_name, description, category, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: trial_abuse_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trial_abuse_log (id, email, ip, user_agent, fingerprint, fingerprint_data, device_score, registration_count, company_id, flagged, override_reason, overridden_by, created_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, name, address, company_id, branch_id, is_consignment, supplier_id, created_at) FROM stdin;
1	رئيسي	\N	1	1	f	\N	2026-05-01 19:15:51.801836+00
\.


--
-- Data for Name: warranty_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_records (id, company_id, sale_id, product_id, product_name, customer_id, customer_name, customer_phone, serial_number, device_model, warranty_months, warranty_start, warranty_end, status, notes, created_at) FROM stdin;
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_id_seq', 5, true);


--
-- Name: accrual_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accrual_runs_id_seq', 1, false);


--
-- Name: accruals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accruals_id_seq', 1, false);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 2, true);


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: attendance_deduction_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_deduction_settings_id_seq', 1, false);


--
-- Name: attendance_deduction_tiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_deduction_tiers_id_seq', 1, false);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_records_id_seq', 1, false);


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_summary_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 12, true);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backups_id_seq', 1, false);


--
-- Name: bad_debts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bad_debts_id_seq', 1, false);


--
-- Name: bank_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_accounts_id_seq', 1, false);


--
-- Name: bank_statement_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bank_statement_lines_id_seq', 1, false);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 1, true);


--
-- Name: budget_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_lines_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, true);


--
-- Name: cost_centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_centers_id_seq', 1, false);


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_classifications_id_seq', 1, false);


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_ledger_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 2, true);


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_incentive_accrual_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deposit_vouchers_id_seq', 1, false);


--
-- Name: depreciation_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.depreciation_runs_id_seq', 1, false);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, false);


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_bonuses_id_seq', 1, false);


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_contacts_id_seq', 1, false);


--
-- Name: employee_custody_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_custody_id_seq', 1, false);


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_custody_lines_id_seq', 1, false);


--
-- Name: employee_deductions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_deductions_id_seq', 1, false);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_documents_id_seq', 1, false);


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_incentive_assignments_id_seq', 1, false);


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_leave_balances_id_seq', 1, false);


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_shift_assignments_id_seq', 1, false);


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_status_history_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, false);


--
-- Name: erp_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_users_id_seq', 2, true);


--
-- Name: exchange_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exchange_rates_id_seq', 1, false);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 1, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, true);


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fiscal_years_id_seq', 1, false);


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fixed_assets_id_seq', 1, false);


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.idempotency_keys_id_seq', 1, false);


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_metrics_id_seq', 1, false);


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_rules_id_seq', 1, false);


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_schemes_id_seq', 1, false);


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_slabs_id_seq', 1, false);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.income_id_seq', 1, false);


--
-- Name: job_titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_titles_id_seq', 1, false);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 1, true);


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entry_lines_id_seq', 2, true);


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_accrual_history_id_seq', 1, false);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_approvals_id_seq', 1, false);


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_blackout_dates_id_seq', 1, false);


--
-- Name: leave_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_policies_id_seq', 1, false);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_requests_id_seq', 1, false);


--
-- Name: leave_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_types_id_seq', 1, false);


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.monthly_incentive_summary_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 7, true);


--
-- Name: overtime_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.overtime_records_id_seq', 1, false);


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_vouchers_id_seq', 1, false);


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_adjustments_id_seq', 1, false);


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_line_items_id_seq', 1, false);


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_periods_id_seq', 1, false);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_records_id_seq', 1, false);


--
-- Name: plan_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_settings_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: public_holidays_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.public_holidays_id_seq', 1, false);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 1, true);


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_return_items_id_seq', 1, false);


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_returns_id_seq', 1, false);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchases_id_seq', 1, true);


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipt_vouchers_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 7, true);


--
-- Name: repair_checklist_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_checklist_items_id_seq', 1, false);


--
-- Name: repair_dashboard_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_dashboard_cards_id_seq', 3, true);


--
-- Name: repair_device_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_device_models_id_seq', 1, false);


--
-- Name: repair_job_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_job_parts_id_seq', 1, true);


--
-- Name: repair_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_jobs_id_seq', 3, true);


--
-- Name: repair_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_payments_id_seq', 1, false);


--
-- Name: repair_pipeline_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_pipeline_config_id_seq', 1, false);


--
-- Name: repair_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_status_history_id_seq', 22, true);


--
-- Name: repair_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_statuses_id_seq', 9, true);


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.safe_transfers_id_seq', 1, false);


--
-- Name: safes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.safes_id_seq', 3, true);


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_deductions_id_seq', 1, false);


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_history_id_seq', 1, false);


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_ledger_id_seq', 1, false);


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_settings_id_seq', 1, false);


--
-- Name: salary_advances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advances_id_seq', 1, false);


--
-- Name: salary_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_components_id_seq', 1, false);


--
-- Name: salary_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_history_id_seq', 1, false);


--
-- Name: salary_structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_structures_id_seq', 1, false);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 1, false);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_return_items_id_seq', 1, false);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_id_seq', 1, false);


--
-- Name: sales_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_returns_id_seq', 1, false);


--
-- Name: sales_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_targets_id_seq', 1, false);


--
-- Name: scrap_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scrap_items_id_seq', 1, true);


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shift_schedules_id_seq', 1, false);


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statutory_contributions_id_seq', 1, false);


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_count_items_id_seq', 1, false);


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_count_sessions_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 2, true);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfer_items_id_seq', 1, false);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_brackets_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 3, true);


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.treasury_vouchers_id_seq', 1, false);


--
-- Name: trial_abuse_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trial_abuse_log_id_seq', 1, false);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 1, true);


--
-- Name: warranty_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warranty_records_id_seq', 1, false);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accrual_runs accrual_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accrual_runs
    ADD CONSTRAINT accrual_runs_pkey PRIMARY KEY (id);


--
-- Name: accruals accruals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accruals
    ADD CONSTRAINT accruals_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: attendance_deduction_settings attendance_deduction_settings_company_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_settings
    ADD CONSTRAINT attendance_deduction_settings_company_id_unique UNIQUE (company_id);


--
-- Name: attendance_deduction_settings attendance_deduction_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_settings
    ADD CONSTRAINT attendance_deduction_settings_pkey PRIMARY KEY (id);


--
-- Name: attendance_deduction_tiers attendance_deduction_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_tiers
    ADD CONSTRAINT attendance_deduction_tiers_pkey PRIMARY KEY (id);


--
-- Name: attendance_records attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_pkey PRIMARY KEY (id);


--
-- Name: attendance_summary attendance_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary
    ADD CONSTRAINT attendance_summary_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: bad_debts bad_debts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bad_debts
    ADD CONSTRAINT bad_debts_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: bank_statement_lines bank_statement_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_lines
    ADD CONSTRAINT bank_statement_lines_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: budget_lines budget_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_lines
    ADD CONSTRAINT budget_lines_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: cost_centers cost_centers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_pkey PRIMARY KEY (id);


--
-- Name: customer_classifications customer_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications
    ADD CONSTRAINT customer_classifications_pkey PRIMARY KEY (id);


--
-- Name: customer_ledger customer_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_pkey PRIMARY KEY (id);


--
-- Name: customers customers_customer_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_code_unique UNIQUE (customer_code);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: deposit_vouchers deposit_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers
    ADD CONSTRAINT deposit_vouchers_pkey PRIMARY KEY (id);


--
-- Name: depreciation_runs depreciation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depreciation_runs
    ADD CONSTRAINT depreciation_runs_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: employee_bonuses employee_bonuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_pkey PRIMARY KEY (id);


--
-- Name: employee_contacts employee_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts
    ADD CONSTRAINT employee_contacts_pkey PRIMARY KEY (id);


--
-- Name: employee_custody_lines employee_custody_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_pkey PRIMARY KEY (id);


--
-- Name: employee_custody employee_custody_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_pkey PRIMARY KEY (id);


--
-- Name: employee_deductions employee_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_pkey PRIMARY KEY (id);


--
-- Name: employee_documents employee_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_pkey PRIMARY KEY (id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_leave_balances employee_leave_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_pkey PRIMARY KEY (id);


--
-- Name: employee_shift_assignments employee_shift_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_status_history employee_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history
    ADD CONSTRAINT employee_status_history_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: erp_users erp_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users
    ADD CONSTRAINT erp_users_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fiscal_years fiscal_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_pkey PRIMARY KEY (id);


--
-- Name: fixed_assets fixed_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: incentive_metrics incentive_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_pkey PRIMARY KEY (id);


--
-- Name: incentive_rules incentive_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules
    ADD CONSTRAINT incentive_rules_pkey PRIMARY KEY (id);


--
-- Name: incentive_schemes incentive_schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes
    ADD CONSTRAINT incentive_schemes_pkey PRIMARY KEY (id);


--
-- Name: incentive_slabs incentive_slabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs
    ADD CONSTRAINT incentive_slabs_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: job_titles job_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles
    ADD CONSTRAINT job_titles_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_lines journal_entry_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id);


--
-- Name: leave_accrual_history leave_accrual_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_pkey PRIMARY KEY (id);


--
-- Name: leave_approvals leave_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_pkey PRIMARY KEY (id);


--
-- Name: leave_blackout_dates leave_blackout_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates
    ADD CONSTRAINT leave_blackout_dates_pkey PRIMARY KEY (id);


--
-- Name: leave_policies leave_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: leave_types leave_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (id);


--
-- Name: monthly_incentive_summary monthly_incentive_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary
    ADD CONSTRAINT monthly_incentive_summary_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: overtime_records overtime_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records
    ADD CONSTRAINT overtime_records_pkey PRIMARY KEY (id);


--
-- Name: payment_vouchers payment_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers
    ADD CONSTRAINT payment_vouchers_pkey PRIMARY KEY (id);


--
-- Name: payroll_adjustments payroll_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments
    ADD CONSTRAINT payroll_adjustments_pkey PRIMARY KEY (id);


--
-- Name: payroll_line_items payroll_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items
    ADD CONSTRAINT payroll_line_items_pkey PRIMARY KEY (id);


--
-- Name: payroll_periods payroll_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);


--
-- Name: payroll_records payroll_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_pkey PRIMARY KEY (id);


--
-- Name: plan_settings plan_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_settings
    ADD CONSTRAINT plan_settings_key_unique UNIQUE (key);


--
-- Name: plan_settings plan_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_settings
    ADD CONSTRAINT plan_settings_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: public_holidays public_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays
    ADD CONSTRAINT public_holidays_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_return_items purchase_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_returns purchase_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: receipt_vouchers receipt_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers
    ADD CONSTRAINT receipt_vouchers_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_unique UNIQUE (token_hash);


--
-- Name: repair_checklist_items repair_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_checklist_items
    ADD CONSTRAINT repair_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: repair_dashboard_cards repair_dashboard_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_dashboard_cards
    ADD CONSTRAINT repair_dashboard_cards_pkey PRIMARY KEY (id);


--
-- Name: repair_device_models repair_device_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_device_models
    ADD CONSTRAINT repair_device_models_pkey PRIMARY KEY (id);


--
-- Name: repair_job_parts repair_job_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_job_parts
    ADD CONSTRAINT repair_job_parts_pkey PRIMARY KEY (id);


--
-- Name: repair_jobs repair_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_jobs
    ADD CONSTRAINT repair_jobs_pkey PRIMARY KEY (id);


--
-- Name: repair_payments repair_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_payments
    ADD CONSTRAINT repair_payments_pkey PRIMARY KEY (id);


--
-- Name: repair_pipeline_config repair_pipeline_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_pipeline_config
    ADD CONSTRAINT repair_pipeline_config_pkey PRIMARY KEY (id);


--
-- Name: repair_status_history repair_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_status_history
    ADD CONSTRAINT repair_status_history_pkey PRIMARY KEY (id);


--
-- Name: repair_statuses repair_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_statuses
    ADD CONSTRAINT repair_statuses_pkey PRIMARY KEY (id);


--
-- Name: safe_transfers safe_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers
    ADD CONSTRAINT safe_transfers_pkey PRIMARY KEY (id);


--
-- Name: safes safes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes
    ADD CONSTRAINT safes_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_deductions salary_advance_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions
    ADD CONSTRAINT salary_advance_deductions_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_history salary_advance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history
    ADD CONSTRAINT salary_advance_history_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_ledger salary_advance_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_settings salary_advance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings
    ADD CONSTRAINT salary_advance_settings_pkey PRIMARY KEY (id);


--
-- Name: salary_advances salary_advances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_pkey PRIMARY KEY (id);


--
-- Name: salary_components salary_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_pkey PRIMARY KEY (id);


--
-- Name: salary_history salary_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history
    ADD CONSTRAINT salary_history_pkey PRIMARY KEY (id);


--
-- Name: salary_structures salary_structures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures
    ADD CONSTRAINT salary_structures_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sale_return_items sale_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sales_returns sales_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_pkey PRIMARY KEY (id);


--
-- Name: sales_targets sales_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_targets
    ADD CONSTRAINT sales_targets_pkey PRIMARY KEY (id);


--
-- Name: sales_targets sales_targets_user_month_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_targets
    ADD CONSTRAINT sales_targets_user_month_uq UNIQUE (user_id, year_month, company_id);


--
-- Name: scrap_items scrap_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scrap_items
    ADD CONSTRAINT scrap_items_pkey PRIMARY KEY (id);


--
-- Name: shift_schedules shift_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules
    ADD CONSTRAINT shift_schedules_pkey PRIMARY KEY (id);


--
-- Name: statutory_contributions statutory_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions
    ADD CONSTRAINT statutory_contributions_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_count_sessions stock_count_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: super_settings super_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.super_settings
    ADD CONSTRAINT super_settings_pkey PRIMARY KEY (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tax_brackets tax_brackets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets
    ADD CONSTRAINT tax_brackets_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_vouchers treasury_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers
    ADD CONSTRAINT treasury_vouchers_pkey PRIMARY KEY (id);


--
-- Name: trial_abuse_log trial_abuse_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trial_abuse_log
    ADD CONSTRAINT trial_abuse_log_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: warranty_records warranty_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_records
    ADD CONSTRAINT warranty_records_pkey PRIMARY KEY (id);


--
-- Name: accounts_code_company_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_code_company_uidx ON public.accounts USING btree (code, company_id);


--
-- Name: accounts_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_company_id_idx ON public.accounts USING btree (company_id);


--
-- Name: accounts_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_is_active_idx ON public.accounts USING btree (is_active);


--
-- Name: accounts_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_parent_id_idx ON public.accounts USING btree (parent_id);


--
-- Name: accounts_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_type_idx ON public.accounts USING btree (type);


--
-- Name: accrual_runs_accrual_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accrual_runs_accrual_id_idx ON public.accrual_runs USING btree (accrual_id);


--
-- Name: accrual_runs_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accrual_runs_company_id_idx ON public.accrual_runs USING btree (company_id);


--
-- Name: accruals_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accruals_company_id_idx ON public.accruals USING btree (company_id);


--
-- Name: accruals_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accruals_status_idx ON public.accruals USING btree (status);


--
-- Name: alerts_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_idx ON public.alerts USING btree (created_at);


--
-- Name: alerts_is_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_is_read_idx ON public.alerts USING btree (is_read);


--
-- Name: alerts_is_resolved_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_is_resolved_idx ON public.alerts USING btree (is_resolved);


--
-- Name: alerts_role_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_role_target_idx ON public.alerts USING btree (role_target);


--
-- Name: alerts_type_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_ref_idx ON public.alerts USING btree (type, reference_id);


--
-- Name: att_ded_settings_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX att_ded_settings_company_idx ON public.attendance_deduction_settings USING btree (company_id);


--
-- Name: att_ded_tiers_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX att_ded_tiers_company_idx ON public.attendance_deduction_tiers USING btree (company_id);


--
-- Name: att_ded_tiers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX att_ded_tiers_type_idx ON public.attendance_deduction_tiers USING btree (company_id, applies_to);


--
-- Name: att_summary_emp_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX att_summary_emp_month_idx ON public.attendance_summary USING btree (employee_id, month);


--
-- Name: attendance_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_date_idx ON public.attendance_records USING btree (attendance_date);


--
-- Name: attendance_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_emp_date_idx ON public.attendance_records USING btree (employee_id, attendance_date);


--
-- Name: attendance_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_emp_idx ON public.attendance_records USING btree (employee_id);


--
-- Name: bad_debts_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bad_debts_company_idx ON public.bad_debts USING btree (company_id);


--
-- Name: bad_debts_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bad_debts_status_idx ON public.bad_debts USING btree (status);


--
-- Name: bank_accounts_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_accounts_company_id_idx ON public.bank_accounts USING btree (company_id);


--
-- Name: bank_statement_lines_bank_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_lines_bank_account_idx ON public.bank_statement_lines USING btree (bank_account_id);


--
-- Name: bank_statement_lines_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_lines_company_id_idx ON public.bank_statement_lines USING btree (company_id);


--
-- Name: bank_statement_lines_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bank_statement_lines_status_idx ON public.bank_statement_lines USING btree (status);


--
-- Name: branches_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX branches_company_id_idx ON public.branches USING btree (company_id);


--
-- Name: budget_lines_budget_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_lines_budget_id_idx ON public.budget_lines USING btree (budget_id);


--
-- Name: budget_lines_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budget_lines_company_id_idx ON public.budget_lines USING btree (company_id);


--
-- Name: budget_lines_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX budget_lines_unique_idx ON public.budget_lines USING btree (budget_id, account_id, period);


--
-- Name: budgets_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budgets_company_id_idx ON public.budgets USING btree (company_id);


--
-- Name: budgets_fiscal_year_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX budgets_fiscal_year_idx ON public.budgets USING btree (fiscal_year);


--
-- Name: categories_name_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categories_name_company_idx ON public.categories USING btree (name, company_id);


--
-- Name: cost_centers_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_centers_company_id_idx ON public.cost_centers USING btree (company_id);


--
-- Name: customer_classifications_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_classifications_company_id_idx ON public.customer_classifications USING btree (company_id);


--
-- Name: customer_ledger_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_customer_id_idx ON public.customer_ledger USING btree (customer_id);


--
-- Name: customer_ledger_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_date_idx ON public.customer_ledger USING btree (date);


--
-- Name: customer_ledger_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_reference_idx ON public.customer_ledger USING btree (reference_type, reference_id);


--
-- Name: customer_ledger_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_type_idx ON public.customer_ledger USING btree (type);


--
-- Name: customers_classification_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_classification_id_idx ON public.customers USING btree (classification_id);


--
-- Name: customers_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_id_idx ON public.customers USING btree (company_id);


--
-- Name: customers_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_name_idx ON public.customers USING btree (company_id, name);


--
-- Name: customers_company_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_phone_idx ON public.customers USING btree (company_id, phone);


--
-- Name: daily_accrual_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_date_idx ON public.daily_incentive_accrual USING btree (accrual_date);


--
-- Name: daily_accrual_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_emp_date_idx ON public.daily_incentive_accrual USING btree (employee_id, accrual_date);


--
-- Name: daily_accrual_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_emp_idx ON public.daily_incentive_accrual USING btree (employee_id);


--
-- Name: departments_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX departments_company_idx ON public.departments USING btree (company_id);


--
-- Name: deposit_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_created_at_idx ON public.deposit_vouchers USING btree (created_at);


--
-- Name: deposit_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_customer_id_idx ON public.deposit_vouchers USING btree (customer_id);


--
-- Name: deposit_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_date_idx ON public.deposit_vouchers USING btree (date);


--
-- Name: deposit_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deposit_vouchers_request_id_uidx ON public.deposit_vouchers USING btree (request_id);


--
-- Name: deposit_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_safe_id_idx ON public.deposit_vouchers USING btree (safe_id);


--
-- Name: depreciation_runs_asset_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX depreciation_runs_asset_id_idx ON public.depreciation_runs USING btree (asset_id);


--
-- Name: depreciation_runs_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX depreciation_runs_company_id_idx ON public.depreciation_runs USING btree (company_id);


--
-- Name: depreciation_runs_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX depreciation_runs_period_idx ON public.depreciation_runs USING btree (period);


--
-- Name: emp_bonus_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_bonus_company_idx ON public.employee_bonuses USING btree (company_id);


--
-- Name: emp_bonus_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_bonus_employee_idx ON public.employee_bonuses USING btree (employee_id);


--
-- Name: emp_contacts_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_contacts_employee_idx ON public.employee_contacts USING btree (employee_id);


--
-- Name: emp_custody_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_company_idx ON public.employee_custody USING btree (company_id);


--
-- Name: emp_custody_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_employee_idx ON public.employee_custody USING btree (employee_id);


--
-- Name: emp_custody_lines_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_lines_company_idx ON public.employee_custody_lines USING btree (company_id);


--
-- Name: emp_custody_lines_custody_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_lines_custody_idx ON public.employee_custody_lines USING btree (custody_id);


--
-- Name: emp_custody_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_status_idx ON public.employee_custody USING btree (company_id, status);


--
-- Name: emp_deduct_att_rec_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_deduct_att_rec_idx ON public.employee_deductions USING btree (attendance_record_id, source);


--
-- Name: emp_deduct_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_deduct_company_idx ON public.employee_deductions USING btree (company_id);


--
-- Name: emp_deduct_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_deduct_employee_idx ON public.employee_deductions USING btree (employee_id);


--
-- Name: emp_deduct_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_deduct_type_idx ON public.employee_deductions USING btree (company_id, deduction_type);


--
-- Name: emp_docs_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_docs_employee_idx ON public.employee_documents USING btree (employee_id);


--
-- Name: emp_incentive_assign_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_incentive_assign_emp_idx ON public.employee_incentive_assignments USING btree (employee_id);


--
-- Name: emp_incentive_assign_scheme_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_incentive_assign_scheme_idx ON public.employee_incentive_assignments USING btree (incentive_scheme_id);


--
-- Name: emp_shift_assign_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_shift_assign_emp_idx ON public.employee_shift_assignments USING btree (employee_id);


--
-- Name: emp_shift_assign_shift_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_shift_assign_shift_idx ON public.employee_shift_assignments USING btree (shift_schedule_id);


--
-- Name: emp_status_hist_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_status_hist_employee_idx ON public.employee_status_history USING btree (employee_id);


--
-- Name: employees_code_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_code_company_idx ON public.employees USING btree (company_id, employee_code);


--
-- Name: employees_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_company_idx ON public.employees USING btree (company_id);


--
-- Name: employees_dept_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_dept_idx ON public.employees USING btree (department_id);


--
-- Name: employees_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_status_idx ON public.employees USING btree (company_id, employment_status);


--
-- Name: exchange_rates_company_currency_date_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX exchange_rates_company_currency_date_uidx ON public.exchange_rates USING btree (company_id, currency, date);


--
-- Name: exchange_rates_company_currency_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exchange_rates_company_currency_idx ON public.exchange_rates USING btree (company_id, currency);


--
-- Name: exchange_rates_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX exchange_rates_company_date_idx ON public.exchange_rates USING btree (company_id, date);


--
-- Name: expense_categories_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expense_categories_company_idx ON public.expense_categories USING btree (company_id);


--
-- Name: expenses_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_category_idx ON public.expenses USING btree (category);


--
-- Name: expenses_company_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_company_created_at_idx ON public.expenses USING btree (company_id, created_at);


--
-- Name: expenses_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_created_at_idx ON public.expenses USING btree (created_at);


--
-- Name: expenses_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_safe_id_idx ON public.expenses USING btree (safe_id);


--
-- Name: fiscal_years_company_current_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_years_company_current_idx ON public.fiscal_years USING btree (company_id, is_current);


--
-- Name: fiscal_years_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_years_company_id_idx ON public.fiscal_years USING btree (company_id);


--
-- Name: fixed_assets_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fixed_assets_company_id_idx ON public.fixed_assets USING btree (company_id);


--
-- Name: fixed_assets_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fixed_assets_status_idx ON public.fixed_assets USING btree (status);


--
-- Name: holidays_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX holidays_company_idx ON public.public_holidays USING btree (company_id);


--
-- Name: idempotency_keys_company_scope_key_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idempotency_keys_company_scope_key_uidx ON public.idempotency_keys USING btree (company_id, scope, key);


--
-- Name: idempotency_keys_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_created_at_idx ON public.idempotency_keys USING btree (created_at);


--
-- Name: incentive_metrics_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_metrics_emp_date_idx ON public.incentive_metrics USING btree (employee_id, metric_date);


--
-- Name: incentive_rules_scheme_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_rules_scheme_idx ON public.incentive_rules USING btree (incentive_scheme_id);


--
-- Name: incentive_schemes_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_schemes_company_idx ON public.incentive_schemes USING btree (company_id);


--
-- Name: incentive_slabs_rule_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_slabs_rule_idx ON public.incentive_slabs USING btree (incentive_rule_id);


--
-- Name: income_company_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_company_created_at_idx ON public.income USING btree (company_id, created_at);


--
-- Name: income_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_company_id_idx ON public.income USING btree (company_id);


--
-- Name: income_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_created_at_idx ON public.income USING btree (created_at);


--
-- Name: income_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_safe_id_idx ON public.income USING btree (safe_id);


--
-- Name: income_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_source_idx ON public.income USING btree (source);


--
-- Name: job_titles_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_titles_company_idx ON public.job_titles USING btree (company_id);


--
-- Name: journal_entries_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_company_date_idx ON public.journal_entries USING btree (company_id, date);


--
-- Name: journal_entries_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_company_id_idx ON public.journal_entries USING btree (company_id);


--
-- Name: journal_entries_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_created_at_idx ON public.journal_entries USING btree (created_at);


--
-- Name: journal_entries_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_date_idx ON public.journal_entries USING btree (date);


--
-- Name: journal_entries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_status_idx ON public.journal_entries USING btree (status);


--
-- Name: journal_entry_lines_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entry_lines_account_id_idx ON public.journal_entry_lines USING btree (account_id);


--
-- Name: journal_entry_lines_cost_center_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entry_lines_cost_center_idx ON public.journal_entry_lines USING btree (cost_center_id);


--
-- Name: journal_entry_lines_entry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entry_lines_entry_id_idx ON public.journal_entry_lines USING btree (entry_id);


--
-- Name: leave_accrual_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_accrual_emp_idx ON public.leave_accrual_history USING btree (employee_id);


--
-- Name: leave_accrual_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_accrual_month_idx ON public.leave_accrual_history USING btree (month);


--
-- Name: leave_approvals_req_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_approvals_req_idx ON public.leave_approvals USING btree (leave_request_id);


--
-- Name: leave_balance_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_balance_emp_idx ON public.employee_leave_balances USING btree (employee_id);


--
-- Name: leave_balance_emp_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_balance_emp_type_idx ON public.employee_leave_balances USING btree (employee_id, leave_type_id);


--
-- Name: leave_blackout_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_blackout_company_idx ON public.leave_blackout_dates USING btree (company_id);


--
-- Name: leave_policy_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_policy_company_idx ON public.leave_policies USING btree (company_id);


--
-- Name: leave_policy_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_policy_type_idx ON public.leave_policies USING btree (leave_type_id);


--
-- Name: leave_req_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_emp_idx ON public.leave_requests USING btree (employee_id);


--
-- Name: leave_req_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_status_idx ON public.leave_requests USING btree (status);


--
-- Name: leave_req_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_type_idx ON public.leave_requests USING btree (leave_type_id);


--
-- Name: leave_types_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_types_company_idx ON public.leave_types USING btree (company_id);


--
-- Name: monthly_incentive_emp_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monthly_incentive_emp_month_idx ON public.monthly_incentive_summary USING btree (employee_id, month);


--
-- Name: notifications_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_company_idx ON public.notifications USING btree (company_id);


--
-- Name: notifications_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_idx ON public.notifications USING btree (user_id);


--
-- Name: notifications_user_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_unread_idx ON public.notifications USING btree (user_id, is_read);


--
-- Name: overtime_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX overtime_emp_idx ON public.overtime_records USING btree (employee_id);


--
-- Name: payment_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_created_at_idx ON public.payment_vouchers USING btree (created_at);


--
-- Name: payment_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_customer_id_idx ON public.payment_vouchers USING btree (customer_id);


--
-- Name: payment_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_date_idx ON public.payment_vouchers USING btree (date);


--
-- Name: payment_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payment_vouchers_request_id_uidx ON public.payment_vouchers USING btree (request_id);


--
-- Name: payment_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_safe_id_idx ON public.payment_vouchers USING btree (safe_id);


--
-- Name: payroll_adjustments_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_adjustments_record_idx ON public.payroll_adjustments USING btree (payroll_record_id);


--
-- Name: payroll_line_items_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_line_items_record_idx ON public.payroll_line_items USING btree (payroll_record_id);


--
-- Name: payroll_periods_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_periods_company_idx ON public.payroll_periods USING btree (company_id);


--
-- Name: payroll_periods_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_periods_status_idx ON public.payroll_periods USING btree (company_id, status);


--
-- Name: payroll_records_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_employee_idx ON public.payroll_records USING btree (employee_id);


--
-- Name: payroll_records_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_period_idx ON public.payroll_records USING btree (payroll_period_id);


--
-- Name: payroll_records_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_status_idx ON public.payroll_records USING btree (status);


--
-- Name: products_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_idx ON public.products USING btree (category_id);


--
-- Name: products_company_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_category_idx ON public.products USING btree (company_id, category_id);


--
-- Name: products_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_id_idx ON public.products USING btree (company_id);


--
-- Name: products_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_name_idx ON public.products USING btree (company_id, name);


--
-- Name: products_company_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_sku_idx ON public.products USING btree (company_id, sku);


--
-- Name: purchase_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_items_product_id_idx ON public.purchase_items USING btree (product_id);


--
-- Name: purchase_items_purchase_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_items_purchase_id_idx ON public.purchase_items USING btree (purchase_id);


--
-- Name: purchase_return_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_return_items_product_id_idx ON public.purchase_return_items USING btree (product_id);


--
-- Name: purchase_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_return_items_return_id_idx ON public.purchase_return_items USING btree (return_id);


--
-- Name: purchase_returns_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_created_at_idx ON public.purchase_returns USING btree (created_at);


--
-- Name: purchase_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_customer_id_idx ON public.purchase_returns USING btree (customer_id);


--
-- Name: purchase_returns_purchase_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_purchase_id_idx ON public.purchase_returns USING btree (purchase_id);


--
-- Name: purchase_returns_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchase_returns_request_id_uidx ON public.purchase_returns USING btree (request_id);


--
-- Name: purchases_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_company_date_idx ON public.purchases USING btree (company_id, date);


--
-- Name: purchases_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_company_status_idx ON public.purchases USING btree (company_id, posting_status);


--
-- Name: purchases_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_created_at_idx ON public.purchases USING btree (created_at);


--
-- Name: purchases_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_customer_id_idx ON public.purchases USING btree (customer_id);


--
-- Name: purchases_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_date_idx ON public.purchases USING btree (date);


--
-- Name: purchases_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchases_request_id_uidx ON public.purchases USING btree (request_id);


--
-- Name: purchases_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_status_idx ON public.purchases USING btree (status);


--
-- Name: receipt_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_created_at_idx ON public.receipt_vouchers USING btree (created_at);


--
-- Name: receipt_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_customer_id_idx ON public.receipt_vouchers USING btree (customer_id);


--
-- Name: receipt_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_date_idx ON public.receipt_vouchers USING btree (date);


--
-- Name: receipt_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX receipt_vouchers_request_id_uidx ON public.receipt_vouchers USING btree (request_id);


--
-- Name: receipt_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_safe_id_idx ON public.receipt_vouchers USING btree (safe_id);


--
-- Name: refresh_tokens_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_expires_idx ON public.refresh_tokens USING btree (expires_at);


--
-- Name: refresh_tokens_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_hash_idx ON public.refresh_tokens USING btree (token_hash);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: repair_checklist_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_checklist_company_idx ON public.repair_checklist_items USING btree (company_id);


--
-- Name: repair_dashboard_cards_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_dashboard_cards_company_idx ON public.repair_dashboard_cards USING btree (company_id, sort_order);


--
-- Name: repair_device_models_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_device_models_company_idx ON public.repair_device_models USING btree (company_id);


--
-- Name: repair_history_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_history_company_idx ON public.repair_status_history USING btree (company_id);


--
-- Name: repair_history_job_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_history_job_idx ON public.repair_status_history USING btree (job_id);


--
-- Name: repair_job_parts_job_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_job_parts_job_idx ON public.repair_job_parts USING btree (job_id);


--
-- Name: repair_jobs_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_jobs_company_idx ON public.repair_jobs USING btree (company_id);


--
-- Name: repair_jobs_imei_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_jobs_imei_idx ON public.repair_jobs USING btree (company_id, imei);


--
-- Name: repair_jobs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_jobs_status_idx ON public.repair_jobs USING btree (company_id, status);


--
-- Name: repair_jobs_tech_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_jobs_tech_idx ON public.repair_jobs USING btree (company_id, technician_id);


--
-- Name: repair_payments_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_payments_company_idx ON public.repair_payments USING btree (company_id);


--
-- Name: repair_payments_job_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_payments_job_idx ON public.repair_payments USING btree (job_id);


--
-- Name: repair_pipeline_config_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_pipeline_config_company_idx ON public.repair_pipeline_config USING btree (company_id);


--
-- Name: repair_statuses_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_statuses_company_idx ON public.repair_statuses USING btree (company_id);


--
-- Name: repair_statuses_company_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX repair_statuses_company_key_unique ON public.repair_statuses USING btree (company_id, key);


--
-- Name: safe_transfers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_created_at_idx ON public.safe_transfers USING btree (created_at);


--
-- Name: safe_transfers_from_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_from_safe_id_idx ON public.safe_transfers USING btree (from_safe_id);


--
-- Name: safe_transfers_to_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_to_safe_id_idx ON public.safe_transfers USING btree (to_safe_id);


--
-- Name: sal_comp_struct_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sal_comp_struct_idx ON public.salary_components USING btree (salary_structure_id);


--
-- Name: sal_struct_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sal_struct_company_idx ON public.salary_structures USING btree (company_id);


--
-- Name: salary_adv_deduct_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_deduct_advance_idx ON public.salary_advance_deductions USING btree (salary_advance_id);


--
-- Name: salary_adv_history_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_history_advance_idx ON public.salary_advance_history USING btree (salary_advance_id);


--
-- Name: salary_adv_ledger_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_ledger_advance_idx ON public.salary_advance_ledger USING btree (advance_id);


--
-- Name: salary_adv_ledger_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_ledger_emp_idx ON public.salary_advance_ledger USING btree (employee_id);


--
-- Name: salary_advance_settings_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advance_settings_company_idx ON public.salary_advance_settings USING btree (company_id);


--
-- Name: salary_advances_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advances_emp_idx ON public.salary_advances USING btree (employee_id);


--
-- Name: salary_advances_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advances_status_idx ON public.salary_advances USING btree (status);


--
-- Name: salary_history_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_history_employee_idx ON public.salary_history USING btree (employee_id);


--
-- Name: sale_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_items_product_id_idx ON public.sale_items USING btree (product_id);


--
-- Name: sale_items_sale_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_items_sale_id_idx ON public.sale_items USING btree (sale_id);


--
-- Name: sale_return_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_return_items_product_id_idx ON public.sale_return_items USING btree (product_id);


--
-- Name: sale_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_return_items_return_id_idx ON public.sale_return_items USING btree (return_id);


--
-- Name: sales_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_company_date_idx ON public.sales USING btree (company_id, date);


--
-- Name: sales_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_company_status_idx ON public.sales USING btree (company_id, posting_status);


--
-- Name: sales_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_created_at_idx ON public.sales USING btree (created_at);


--
-- Name: sales_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_customer_id_idx ON public.sales USING btree (customer_id);


--
-- Name: sales_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_date_idx ON public.sales USING btree (date);


--
-- Name: sales_returns_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_created_at_idx ON public.sales_returns USING btree (created_at);


--
-- Name: sales_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_customer_id_idx ON public.sales_returns USING btree (customer_id);


--
-- Name: sales_returns_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_returns_request_id_uidx ON public.sales_returns USING btree (request_id);


--
-- Name: sales_returns_sale_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_sale_id_idx ON public.sales_returns USING btree (sale_id);


--
-- Name: sales_returns_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_warehouse_id_idx ON public.sales_returns USING btree (warehouse_id);


--
-- Name: sales_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_safe_id_idx ON public.sales USING btree (safe_id);


--
-- Name: sales_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_status_idx ON public.sales USING btree (status);


--
-- Name: sales_targets_company_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_targets_company_month_idx ON public.sales_targets USING btree (company_id, year_month);


--
-- Name: sales_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_user_id_idx ON public.sales USING btree (user_id);


--
-- Name: sales_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_warehouse_id_idx ON public.sales USING btree (warehouse_id);


--
-- Name: scrap_items_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scrap_items_company_idx ON public.scrap_items USING btree (company_id);


--
-- Name: shifts_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shifts_company_idx ON public.shift_schedules USING btree (company_id);


--
-- Name: st_company_from_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_company_from_branch_idx ON public.stock_transfers USING btree (company_id, from_branch_id);


--
-- Name: st_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_company_status_idx ON public.stock_transfers USING btree (company_id, status);


--
-- Name: st_company_to_branch_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_company_to_branch_idx ON public.stock_transfers USING btree (company_id, to_branch_id);


--
-- Name: st_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_created_at_idx ON public.stock_transfers USING btree (created_at);


--
-- Name: statutory_contrib_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX statutory_contrib_company_idx ON public.statutory_contributions USING btree (company_id);


--
-- Name: stock_movements_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_company_id_idx ON public.stock_movements USING btree (company_id);


--
-- Name: stock_movements_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_created_at_idx ON public.stock_movements USING btree (created_at);


--
-- Name: stock_movements_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_date_idx ON public.stock_movements USING btree (date);


--
-- Name: stock_movements_movement_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_movement_type_idx ON public.stock_movements USING btree (movement_type);


--
-- Name: stock_movements_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_product_id_idx ON public.stock_movements USING btree (product_id);


--
-- Name: stock_movements_product_warehouse_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_product_warehouse_idx ON public.stock_movements USING btree (product_id, warehouse_id);


--
-- Name: stock_movements_reference_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_reference_type_idx ON public.stock_movements USING btree (reference_type);


--
-- Name: stock_movements_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_warehouse_id_idx ON public.stock_movements USING btree (warehouse_id);


--
-- Name: system_settings_key_company_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX system_settings_key_company_uidx ON public.system_settings USING btree (key, company_id);


--
-- Name: tax_brackets_company_year_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tax_brackets_company_year_idx ON public.tax_brackets USING btree (company_id, fiscal_year);


--
-- Name: transactions_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_company_date_idx ON public.transactions USING btree (company_id, date);


--
-- Name: transactions_company_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_company_type_idx ON public.transactions USING btree (company_id, type);


--
-- Name: transactions_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_created_at_idx ON public.transactions USING btree (created_at);


--
-- Name: transactions_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_customer_id_idx ON public.transactions USING btree (customer_id);


--
-- Name: transactions_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_date_idx ON public.transactions USING btree (date);


--
-- Name: transactions_direction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_direction_idx ON public.transactions USING btree (direction);


--
-- Name: transactions_reference_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_reference_type_idx ON public.transactions USING btree (reference_type);


--
-- Name: transactions_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_safe_id_idx ON public.transactions USING btree (safe_id);


--
-- Name: transactions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_type_idx ON public.transactions USING btree (type);


--
-- Name: treasury_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_created_at_idx ON public.treasury_vouchers USING btree (created_at);


--
-- Name: treasury_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_safe_id_idx ON public.treasury_vouchers USING btree (safe_id);


--
-- Name: treasury_vouchers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_type_idx ON public.treasury_vouchers USING btree (type);


--
-- Name: accounts accounts_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: accrual_runs accrual_runs_accrual_id_accruals_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accrual_runs
    ADD CONSTRAINT accrual_runs_accrual_id_accruals_id_fk FOREIGN KEY (accrual_id) REFERENCES public.accruals(id);


--
-- Name: accrual_runs accrual_runs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accrual_runs
    ADD CONSTRAINT accrual_runs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: accrual_runs accrual_runs_entry_id_journal_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accrual_runs
    ADD CONSTRAINT accrual_runs_entry_id_journal_entries_id_fk FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id);


--
-- Name: accruals accruals_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accruals
    ADD CONSTRAINT accruals_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: accruals accruals_expense_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accruals
    ADD CONSTRAINT accruals_expense_account_id_accounts_id_fk FOREIGN KEY (expense_account_id) REFERENCES public.accounts(id);


--
-- Name: accruals accruals_prepaid_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accruals
    ADD CONSTRAINT accruals_prepaid_account_id_accounts_id_fk FOREIGN KEY (prepaid_account_id) REFERENCES public.accounts(id);


--
-- Name: alerts alerts_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: attendance_deduction_settings attendance_deduction_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_settings
    ADD CONSTRAINT attendance_deduction_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: attendance_deduction_tiers attendance_deduction_tiers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_deduction_tiers
    ADD CONSTRAINT attendance_deduction_tiers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: attendance_records attendance_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: attendance_summary attendance_summary_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary
    ADD CONSTRAINT attendance_summary_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: audit_logs audit_logs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: bank_accounts bank_accounts_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: bank_accounts bank_accounts_safe_id_safes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_safe_id_safes_id_fk FOREIGN KEY (safe_id) REFERENCES public.safes(id);


--
-- Name: bank_statement_lines bank_statement_lines_bank_account_id_bank_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_lines
    ADD CONSTRAINT bank_statement_lines_bank_account_id_bank_accounts_id_fk FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id);


--
-- Name: bank_statement_lines bank_statement_lines_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_lines
    ADD CONSTRAINT bank_statement_lines_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: bank_statement_lines bank_statement_lines_matched_entry_id_journal_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_statement_lines
    ADD CONSTRAINT bank_statement_lines_matched_entry_id_journal_entries_id_fk FOREIGN KEY (matched_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: branches branches_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: budget_lines budget_lines_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_lines
    ADD CONSTRAINT budget_lines_account_id_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: budget_lines budget_lines_budget_id_budgets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_lines
    ADD CONSTRAINT budget_lines_budget_id_budgets_id_fk FOREIGN KEY (budget_id) REFERENCES public.budgets(id);


--
-- Name: budget_lines budget_lines_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_lines
    ADD CONSTRAINT budget_lines_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: budgets budgets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: categories categories_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: cost_centers cost_centers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_centers
    ADD CONSTRAINT cost_centers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customer_classifications customer_classifications_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications
    ADD CONSTRAINT customer_classifications_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customer_ledger customer_ledger_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customers customers_classification_id_customer_classifications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_classification_id_customer_classifications_id_fk FOREIGN KEY (classification_id) REFERENCES public.customer_classifications(id);


--
-- Name: customers customers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: departments departments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: deposit_vouchers deposit_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers
    ADD CONSTRAINT deposit_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: depreciation_runs depreciation_runs_asset_id_fixed_assets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depreciation_runs
    ADD CONSTRAINT depreciation_runs_asset_id_fixed_assets_id_fk FOREIGN KEY (asset_id) REFERENCES public.fixed_assets(id);


--
-- Name: depreciation_runs depreciation_runs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depreciation_runs
    ADD CONSTRAINT depreciation_runs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: depreciation_runs depreciation_runs_entry_id_journal_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.depreciation_runs
    ADD CONSTRAINT depreciation_runs_entry_id_journal_entries_id_fk FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id);


--
-- Name: employee_bonuses employee_bonuses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_bonuses employee_bonuses_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_contacts employee_contacts_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts
    ADD CONSTRAINT employee_contacts_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_custody employee_custody_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_custody employee_custody_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_custody_lines employee_custody_lines_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_custody_lines employee_custody_lines_custody_id_employee_custody_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_custody_id_employee_custody_id_fk FOREIGN KEY (custody_id) REFERENCES public.employee_custody(id) ON DELETE CASCADE;


--
-- Name: employee_deductions employee_deductions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_deductions employee_deductions_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_documents employee_documents_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_incentive_scheme_id_incentive_sc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_incentive_scheme_id_incentive_sc FOREIGN KEY (incentive_scheme_id) REFERENCES public.incentive_schemes(id);


--
-- Name: employee_leave_balances employee_leave_balances_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_leave_balances employee_leave_balances_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: employee_shift_assignments employee_shift_assignments_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_shift_assignments employee_shift_assignments_shift_schedule_id_shift_schedules_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_shift_schedule_id_shift_schedules_id FOREIGN KEY (shift_schedule_id) REFERENCES public.shift_schedules(id);


--
-- Name: employee_status_history employee_status_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history
    ADD CONSTRAINT employee_status_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employees employees_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: employees employees_commission_scope_dept_id_departments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_commission_scope_dept_id_departments_id_fk FOREIGN KEY (commission_scope_dept_id) REFERENCES public.departments(id);


--
-- Name: employees employees_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employees employees_department_id_departments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_department_id_departments_id_fk FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: employees employees_job_title_id_job_titles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_job_title_id_job_titles_id_fk FOREIGN KEY (job_title_id) REFERENCES public.job_titles(id);


--
-- Name: erp_users erp_users_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users
    ADD CONSTRAINT erp_users_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: exchange_rates exchange_rates_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: expense_categories expense_categories_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: expenses expenses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: fiscal_years fiscal_years_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: fixed_assets fixed_assets_acc_dep_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_acc_dep_account_id_accounts_id_fk FOREIGN KEY (acc_dep_account_id) REFERENCES public.accounts(id);


--
-- Name: fixed_assets fixed_assets_asset_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_asset_account_id_accounts_id_fk FOREIGN KEY (asset_account_id) REFERENCES public.accounts(id);


--
-- Name: fixed_assets fixed_assets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: fixed_assets fixed_assets_dep_expense_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_dep_expense_account_id_accounts_id_fk FOREIGN KEY (dep_expense_account_id) REFERENCES public.accounts(id);


--
-- Name: idempotency_keys idempotency_keys_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: incentive_metrics incentive_metrics_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: incentive_metrics incentive_metrics_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: incentive_rules incentive_rules_incentive_scheme_id_incentive_schemes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules
    ADD CONSTRAINT incentive_rules_incentive_scheme_id_incentive_schemes_id_fk FOREIGN KEY (incentive_scheme_id) REFERENCES public.incentive_schemes(id);


--
-- Name: incentive_schemes incentive_schemes_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes
    ADD CONSTRAINT incentive_schemes_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: incentive_slabs incentive_slabs_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs
    ADD CONSTRAINT incentive_slabs_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: income income_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: job_titles job_titles_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles
    ADD CONSTRAINT job_titles_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: journal_entries journal_entries_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: journal_entry_lines journal_entry_lines_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_account_id_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: journal_entry_lines journal_entry_lines_entry_id_journal_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_entry_id_journal_entries_id_fk FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id);


--
-- Name: leave_accrual_history leave_accrual_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: leave_accrual_history leave_accrual_history_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_approvals leave_approvals_leave_request_id_leave_requests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_leave_request_id_leave_requests_id_fk FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id);


--
-- Name: leave_blackout_dates leave_blackout_dates_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates
    ADD CONSTRAINT leave_blackout_dates_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: leave_policies leave_policies_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: leave_policies leave_policies_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_requests leave_requests_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: leave_requests leave_requests_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_types leave_types_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: monthly_incentive_summary monthly_incentive_summary_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary
    ADD CONSTRAINT monthly_incentive_summary_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: notifications notifications_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: overtime_records overtime_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records
    ADD CONSTRAINT overtime_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payment_vouchers payment_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers
    ADD CONSTRAINT payment_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: payroll_adjustments payroll_adjustments_payroll_record_id_payroll_records_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments
    ADD CONSTRAINT payroll_adjustments_payroll_record_id_payroll_records_id_fk FOREIGN KEY (payroll_record_id) REFERENCES public.payroll_records(id);


--
-- Name: payroll_line_items payroll_line_items_payroll_record_id_payroll_records_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items
    ADD CONSTRAINT payroll_line_items_payroll_record_id_payroll_records_id_fk FOREIGN KEY (payroll_record_id) REFERENCES public.payroll_records(id);


--
-- Name: payroll_periods payroll_periods_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: payroll_records payroll_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payroll_records payroll_records_payroll_period_id_payroll_periods_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_payroll_period_id_payroll_periods_id_fk FOREIGN KEY (payroll_period_id) REFERENCES public.payroll_periods(id);


--
-- Name: products products_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: public_holidays public_holidays_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays
    ADD CONSTRAINT public_holidays_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: purchase_items purchase_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_items purchase_items_purchase_id_purchases_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_purchases_id_fk FOREIGN KEY (purchase_id) REFERENCES public.purchases(id);


--
-- Name: purchase_return_items purchase_return_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_return_items purchase_return_items_return_id_purchase_returns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_return_id_purchase_returns_id_fk FOREIGN KEY (return_id) REFERENCES public.purchase_returns(id);


--
-- Name: purchase_returns purchase_returns_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: purchases purchases_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: receipt_vouchers receipt_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers
    ADD CONSTRAINT receipt_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_erp_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_erp_users_id_fk FOREIGN KEY (user_id) REFERENCES public.erp_users(id) ON DELETE CASCADE;


--
-- Name: repair_payments repair_payments_job_id_repair_jobs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_payments
    ADD CONSTRAINT repair_payments_job_id_repair_jobs_id_fk FOREIGN KEY (job_id) REFERENCES public.repair_jobs(id) ON DELETE CASCADE;


--
-- Name: safe_transfers safe_transfers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers
    ADD CONSTRAINT safe_transfers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: safes safes_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes
    ADD CONSTRAINT safes_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advance_deductions salary_advance_deductions_salary_advance_id_salary_advances_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions
    ADD CONSTRAINT salary_advance_deductions_salary_advance_id_salary_advances_id_ FOREIGN KEY (salary_advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_history salary_advance_history_salary_advance_id_salary_advances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history
    ADD CONSTRAINT salary_advance_history_salary_advance_id_salary_advances_id_fk FOREIGN KEY (salary_advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_ledger salary_advance_ledger_advance_id_salary_advances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_advance_id_salary_advances_id_fk FOREIGN KEY (advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_ledger salary_advance_ledger_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_advance_settings salary_advance_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings
    ADD CONSTRAINT salary_advance_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advances salary_advances_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advances salary_advances_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_components salary_components_salary_structure_id_salary_structures_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_salary_structure_id_salary_structures_id_fk FOREIGN KEY (salary_structure_id) REFERENCES public.salary_structures(id);


--
-- Name: salary_history salary_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history
    ADD CONSTRAINT salary_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_structures salary_structures_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures
    ADD CONSTRAINT salary_structures_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: sale_items sale_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_items sale_items_sale_id_sales_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_sales_id_fk FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_return_items sale_return_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_return_items sale_return_items_return_id_sales_returns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_return_id_sales_returns_id_fk FOREIGN KEY (return_id) REFERENCES public.sales_returns(id);


--
-- Name: sales sales_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: sales_returns sales_returns_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: sales_targets sales_targets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_targets
    ADD CONSTRAINT sales_targets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: shift_schedules shift_schedules_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules
    ADD CONSTRAINT shift_schedules_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: statutory_contributions statutory_contributions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions
    ADD CONSTRAINT statutory_contributions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_count_items stock_count_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_count_sessions stock_count_sessions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_movements stock_movements_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_movements stock_movements_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_transfer_items stock_transfer_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_transfers stock_transfers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_transfers stock_transfers_from_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_from_branch_id_branches_id_fk FOREIGN KEY (from_branch_id) REFERENCES public.branches(id);


--
-- Name: stock_transfers stock_transfers_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_transfers stock_transfers_to_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_to_branch_id_branches_id_fk FOREIGN KEY (to_branch_id) REFERENCES public.branches(id);


--
-- Name: system_settings system_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: tax_brackets tax_brackets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets
    ADD CONSTRAINT tax_brackets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: transactions transactions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: treasury_vouchers treasury_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers
    ADD CONSTRAINT treasury_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: warehouses warehouses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: accrual_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accrual_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: accruals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accruals ENABLE ROW LEVEL SECURITY;

--
-- Name: bank_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bank_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: bank_statement_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bank_statement_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: branches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.branches ENABLE ROW LEVEL SECURITY;

--
-- Name: budget_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budget_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: budgets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.budgets ENABLE ROW LEVEL SECURITY;

--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

--
-- Name: cost_centers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cost_centers ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customer_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: departments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

--
-- Name: deposit_vouchers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deposit_vouchers ENABLE ROW LEVEL SECURITY;

--
-- Name: depreciation_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.depreciation_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.devices ENABLE ROW LEVEL SECURITY;

--
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: expenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;

--
-- Name: fixed_assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fixed_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: income; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.income ENABLE ROW LEVEL SECURITY;

--
-- Name: journal_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: accounts muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.accounts USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: accrual_runs muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.accrual_runs USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: accruals muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.accruals USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: bank_accounts muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.bank_accounts USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: bank_statement_lines muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.bank_statement_lines USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: branches muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.branches USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: budget_lines muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.budget_lines USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: budgets muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.budgets USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: categories muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.categories USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: cost_centers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.cost_centers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: customer_ledger muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.customer_ledger USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: customers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.customers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: departments muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.departments USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: deposit_vouchers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.deposit_vouchers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: depreciation_runs muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.depreciation_runs USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: devices muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.devices USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: employees muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.employees USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: expenses muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.expenses USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: fixed_assets muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.fixed_assets USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: income muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.income USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: journal_entries muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.journal_entries USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: payment_vouchers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.payment_vouchers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: products muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.products USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: purchase_returns muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.purchase_returns USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: purchases muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.purchases USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: receipt_vouchers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.receipt_vouchers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: safe_transfers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.safe_transfers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: safes muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.safes USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: sales muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.sales USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: sales_returns muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.sales_returns USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: stock_movements muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.stock_movements USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: transactions muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.transactions USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: treasury_vouchers muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.treasury_vouchers USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: warehouses muhkam_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY muhkam_tenant_isolation ON public.warehouses USING (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.current_company_id'::text, true) IS NULL) OR (current_setting('app.current_company_id'::text, true) = ''::text) OR (current_setting('app.is_super_admin'::text, true) = 'true'::text) OR (company_id = (NULLIF(current_setting('app.current_company_id'::text, true), ''::text))::integer)));


--
-- Name: payment_vouchers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_vouchers ENABLE ROW LEVEL SECURITY;

--
-- Name: products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: purchases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: receipt_vouchers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.receipt_vouchers ENABLE ROW LEVEL SECURITY;

--
-- Name: safe_transfers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.safe_transfers ENABLE ROW LEVEL SECURITY;

--
-- Name: safes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.safes ENABLE ROW LEVEL SECURITY;

--
-- Name: sales; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;

--
-- Name: sales_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sales_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_vouchers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treasury_vouchers ENABLE ROW LEVEL SECURITY;

--
-- Name: warehouses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict TRkbub59vHo6ngbmHrx6eTGsXMA94GOrAiDfCDx3R639auEHmeDTELkj3EHPG8F

