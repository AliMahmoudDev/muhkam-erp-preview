--
-- PostgreSQL database dump
--

\restrict emieJbesgMPtRjJDlA11Vbph0rBQ4KPvC4HXPJQp5ryIFWwYnP5FCbciF7Jfk50

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    parent_id integer,
    level integer DEFAULT 1 NOT NULL,
    is_posting boolean DEFAULT true NOT NULL,
    opening_balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    current_balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.accounts FORCE ROW LEVEL SECURITY;


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    type text NOT NULL,
    severity text NOT NULL,
    message text NOT NULL,
    reference_id text,
    trigger_mode text DEFAULT 'event'::text NOT NULL,
    last_triggered_date text,
    role_target text,
    user_id integer,
    is_read boolean DEFAULT false NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    resolved_by integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.alerts FORCE ROW LEVEL SECURITY;


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: attendance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    attendance_date text NOT NULL,
    check_in_time text,
    check_out_time text,
    status text DEFAULT 'present'::text NOT NULL,
    working_hours numeric(5,2),
    late_minutes integer DEFAULT 0,
    early_departure_minutes integer DEFAULT 0,
    overtime_hours numeric(5,2) DEFAULT '0'::numeric,
    notes text,
    submitted_by integer,
    verified_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_records_id_seq OWNED BY public.attendance_records.id;


--
-- Name: attendance_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_summary (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    month text NOT NULL,
    total_present_days integer DEFAULT 0 NOT NULL,
    total_absent_days integer DEFAULT 0 NOT NULL,
    total_late_days integer DEFAULT 0 NOT NULL,
    total_early_departures integer DEFAULT 0 NOT NULL,
    total_overtime_hours numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    total_working_hours numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_summary_id_seq OWNED BY public.attendance_summary.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action text NOT NULL,
    record_type text NOT NULL,
    record_id integer NOT NULL,
    old_value jsonb,
    new_value jsonb,
    user_id integer,
    username text,
    company_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id integer NOT NULL,
    filename text NOT NULL,
    size integer DEFAULT 0 NOT NULL,
    trigger text DEFAULT 'manual'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.branches FORCE ROW LEVEL SECURITY;


--
-- Name: branches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branches_id_seq OWNED BY public.branches.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.categories FORCE ROW LEVEL SECURITY;


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    plan_type text DEFAULT 'trial'::text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    admin_email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: customer_classifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_classifications (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.customer_classifications FORCE ROW LEVEL SECURITY;


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_classifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_classifications_id_seq OWNED BY public.customer_classifications.id;


--
-- Name: customer_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_ledger (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    type text NOT NULL,
    amount numeric(12,2) NOT NULL,
    reference_type text,
    reference_id integer,
    reference_no text,
    description text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.customer_ledger FORCE ROW LEVEL SECURITY;


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_ledger_id_seq OWNED BY public.customer_ledger.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    customer_code integer,
    normalized_name text,
    phone text,
    balance numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    is_customer boolean DEFAULT true NOT NULL,
    is_supplier boolean DEFAULT false NOT NULL,
    account_id integer,
    classification_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.customers FORCE ROW LEVEL SECURITY;


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: daily_incentive_accrual; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_incentive_accrual (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    accrual_date text NOT NULL,
    metric_value numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    target_value numeric(14,2) NOT NULL,
    achievement_percentage numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    accrued_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    status text DEFAULT 'accrued'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_incentive_accrual_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_incentive_accrual_id_seq OWNED BY public.daily_incentive_accrual.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    description_en text,
    description_ar text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.departments FORCE ROW LEVEL SECURITY;


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: deposit_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deposit_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    source text,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.deposit_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deposit_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deposit_vouchers_id_seq OWNED BY public.deposit_vouchers.id;


--
-- Name: employee_bonuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_bonuses (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text,
    granted_date text NOT NULL,
    granted_by integer,
    currency text DEFAULT 'EGP'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.employee_bonuses FORCE ROW LEVEL SECURITY;


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_bonuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_bonuses_id_seq OWNED BY public.employee_bonuses.id;


--
-- Name: employee_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_contacts (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    contact_type text DEFAULT 'emergency'::text NOT NULL,
    name text NOT NULL,
    relationship text,
    phone text,
    email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_contacts_id_seq OWNED BY public.employee_contacts.id;


--
-- Name: employee_custody; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_custody (
    id integer NOT NULL,
    company_id integer NOT NULL,
    employee_id integer NOT NULL,
    safe_id integer,
    amount numeric(14,2) NOT NULL,
    returned_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    purpose text,
    granted_date text NOT NULL,
    settled_date text,
    status text DEFAULT 'open'::text NOT NULL,
    granted_by integer,
    currency text DEFAULT 'EGP'::text NOT NULL,
    notes text,
    reimbursement_due numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.employee_custody FORCE ROW LEVEL SECURITY;


--
-- Name: employee_custody_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_custody_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_custody_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_custody_id_seq OWNED BY public.employee_custody.id;


--
-- Name: employee_custody_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_custody_lines (
    id integer NOT NULL,
    company_id integer NOT NULL,
    custody_id integer NOT NULL,
    category text NOT NULL,
    amount numeric(14,2) NOT NULL,
    description text,
    line_date text NOT NULL,
    expense_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_custody_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_custody_lines_id_seq OWNED BY public.employee_custody_lines.id;


--
-- Name: employee_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_documents (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    document_type text NOT NULL,
    file_name text NOT NULL,
    file_path text,
    expiry_date text,
    verified_by integer,
    verified_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_documents_id_seq OWNED BY public.employee_documents.id;


--
-- Name: employee_incentive_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_incentive_assignments (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    incentive_scheme_id integer NOT NULL,
    assigned_date text NOT NULL,
    end_date text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_incentive_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_incentive_assignments_id_seq OWNED BY public.employee_incentive_assignments.id;


--
-- Name: employee_leave_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_leave_balances (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    accrued_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    used_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    balance_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    carryover_days numeric(7,2) DEFAULT '0'::numeric NOT NULL,
    as_of_date text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_leave_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_leave_balances_id_seq OWNED BY public.employee_leave_balances.id;


--
-- Name: employee_shift_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_shift_assignments (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    shift_schedule_id integer NOT NULL,
    assigned_date text NOT NULL,
    end_date text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_shift_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_shift_assignments_id_seq OWNED BY public.employee_shift_assignments.id;


--
-- Name: employee_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_status_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    old_status text,
    new_status text NOT NULL,
    reason text,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_status_history_id_seq OWNED BY public.employee_status_history.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    employee_code text NOT NULL,
    first_name_en text NOT NULL,
    last_name_en text NOT NULL,
    first_name_ar text NOT NULL,
    last_name_ar text NOT NULL,
    email text NOT NULL,
    phone text,
    personal_phone text,
    national_id text,
    national_id_image text,
    job_title_id integer,
    department_id integer,
    branch_id integer,
    hire_date text NOT NULL,
    employment_status text DEFAULT 'active'::text NOT NULL,
    salary numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    salary_type text DEFAULT 'fixed'::text NOT NULL,
    commission_rate numeric(5,2),
    commission_basis text,
    commission_scope_dept_id integer,
    bank_account text,
    address_en text,
    address_ar text,
    city text,
    country text DEFAULT 'مصر'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by integer,
    updated_by integer
);

ALTER TABLE ONLY public.employees FORCE ROW LEVEL SECURITY;


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: erp_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.erp_users (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    email text,
    pin text NOT NULL,
    role text DEFAULT 'cashier'::text NOT NULL,
    permissions text DEFAULT '{}'::text,
    active boolean DEFAULT true,
    company_id integer,
    warehouse_id integer,
    safe_id integer,
    login_attempts integer DEFAULT 0 NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_verified boolean DEFAULT false
);


--
-- Name: erp_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.erp_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: erp_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.erp_users_id_seq OWNED BY public.erp_users.id;


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expense_categories (
    id integer NOT NULL,
    name text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.expense_categories FORCE ROW LEVEL SECURITY;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expense_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expense_categories_id_seq OWNED BY public.expense_categories.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    category text NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text,
    safe_id integer,
    safe_name text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.expenses FORCE ROW LEVEL SECURITY;


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: fiscal_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_years (
    id integer NOT NULL,
    company_id integer NOT NULL,
    year_label text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    is_open boolean DEFAULT true NOT NULL,
    is_current boolean DEFAULT false NOT NULL,
    closed_by integer,
    closed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.fiscal_years FORCE ROW LEVEL SECURITY;


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fiscal_years_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fiscal_years_id_seq OWNED BY public.fiscal_years.id;


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    id integer NOT NULL,
    company_id integer NOT NULL,
    scope text NOT NULL,
    key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.idempotency_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.idempotency_keys_id_seq OWNED BY public.idempotency_keys.id;


--
-- Name: incentive_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_metrics (
    id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    employee_id integer NOT NULL,
    metric_date text NOT NULL,
    metric_value numeric(14,2) NOT NULL,
    source_document_id integer,
    source_type text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_metrics_id_seq OWNED BY public.incentive_metrics.id;


--
-- Name: incentive_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_rules (
    id integer NOT NULL,
    incentive_scheme_id integer NOT NULL,
    metric_type text NOT NULL,
    target_value numeric(14,2) NOT NULL,
    incentive_amount numeric(14,2),
    incentive_type text DEFAULT 'fixed'::text NOT NULL,
    calculation_method text DEFAULT 'achievement'::text NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_rules_id_seq OWNED BY public.incentive_rules.id;


--
-- Name: incentive_schemes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_schemes (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.incentive_schemes FORCE ROW LEVEL SECURITY;


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_schemes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_schemes_id_seq OWNED BY public.incentive_schemes.id;


--
-- Name: incentive_slabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incentive_slabs (
    id integer NOT NULL,
    incentive_rule_id integer NOT NULL,
    slab_number integer NOT NULL,
    from_percentage numeric(7,2) NOT NULL,
    to_percentage numeric(7,2),
    incentive_value numeric(14,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incentive_slabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incentive_slabs_id_seq OWNED BY public.incentive_slabs.id;


--
-- Name: income; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.income (
    id integer NOT NULL,
    source text NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text,
    safe_id integer,
    safe_name text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.income FORCE ROW LEVEL SECURITY;


--
-- Name: income_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.income_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: income_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.income_id_seq OWNED BY public.income.id;


--
-- Name: job_titles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_titles (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.job_titles FORCE ROW LEVEL SECURITY;


--
-- Name: job_titles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_titles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_titles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_titles_id_seq OWNED BY public.job_titles.id;


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id integer NOT NULL,
    entry_no text NOT NULL,
    date text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    reference text,
    total_debit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    total_credit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.journal_entries FORCE ROW LEVEL SECURITY;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entries_id_seq OWNED BY public.journal_entries.id;


--
-- Name: journal_entry_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entry_lines (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    account_id integer NOT NULL,
    account_name text NOT NULL,
    account_code text NOT NULL,
    debit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    credit numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    description text
);


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journal_entry_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journal_entry_lines_id_seq OWNED BY public.journal_entry_lines.id;


--
-- Name: leave_accrual_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_accrual_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    accrued_days numeric(7,2) NOT NULL,
    month text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_accrual_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_accrual_history_id_seq OWNED BY public.leave_accrual_history.id;


--
-- Name: leave_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_approvals (
    id integer NOT NULL,
    leave_request_id integer NOT NULL,
    approver_id integer NOT NULL,
    status text NOT NULL,
    comment text,
    approved_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_approvals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_approvals_id_seq OWNED BY public.leave_approvals.id;


--
-- Name: leave_blackout_dates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_blackout_dates (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    reason_en text,
    reason_ar text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.leave_blackout_dates FORCE ROW LEVEL SECURITY;


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_blackout_dates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_blackout_dates_id_seq OWNED BY public.leave_blackout_dates.id;


--
-- Name: leave_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_policies (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    leave_type_id integer NOT NULL,
    entitlement_days_per_year integer DEFAULT 21 NOT NULL,
    accrual_method text DEFAULT 'fixed'::text NOT NULL,
    min_duration numeric(4,1) DEFAULT '1'::numeric NOT NULL,
    max_consecutive_days integer DEFAULT 30,
    probation_days integer DEFAULT 90,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.leave_policies FORCE ROW LEVEL SECURITY;


--
-- Name: leave_policies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_policies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_policies_id_seq OWNED BY public.leave_policies.id;


--
-- Name: leave_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_requests (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    total_days numeric(5,1) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reason text,
    rejection_reason text,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_by integer,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_requests_id_seq OWNED BY public.leave_requests.id;


--
-- Name: leave_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_types (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    code text NOT NULL,
    is_paid boolean DEFAULT true NOT NULL,
    requires_approval boolean DEFAULT true NOT NULL,
    carryover_allowed boolean DEFAULT false NOT NULL,
    carryover_limit integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.leave_types FORCE ROW LEVEL SECURITY;


--
-- Name: leave_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_types_id_seq OWNED BY public.leave_types.id;


--
-- Name: monthly_incentive_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_incentive_summary (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    month text NOT NULL,
    total_accrued numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    included_in_payroll_record_id integer,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.monthly_incentive_summary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.monthly_incentive_summary_id_seq OWNED BY public.monthly_incentive_summary.id;


--
-- Name: overtime_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.overtime_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    date text NOT NULL,
    hours numeric(5,2) NOT NULL,
    reason text,
    approved_by integer,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: overtime_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.overtime_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: overtime_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.overtime_records_id_seq OWNED BY public.overtime_records.id;


--
-- Name: payment_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.payment_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_vouchers_id_seq OWNED BY public.payment_vouchers.id;


--
-- Name: payroll_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_adjustments (
    id integer NOT NULL,
    payroll_record_id integer NOT NULL,
    adjustment_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text NOT NULL,
    approved_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_adjustments_id_seq OWNED BY public.payroll_adjustments.id;


--
-- Name: payroll_line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_line_items (
    id integer NOT NULL,
    payroll_record_id integer NOT NULL,
    component_name text NOT NULL,
    component_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_line_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_line_items_id_seq OWNED BY public.payroll_line_items.id;


--
-- Name: payroll_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_periods (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    processed_by integer,
    processed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.payroll_periods FORCE ROW LEVEL SECURITY;


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_periods_id_seq OWNED BY public.payroll_periods.id;


--
-- Name: payroll_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_records (
    id integer NOT NULL,
    payroll_period_id integer NOT NULL,
    employee_id integer NOT NULL,
    gross_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_allowances numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    total_deductions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    tax_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    net_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    advance_deductions numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    incentive_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_records_id_seq OWNED BY public.payroll_records.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    sku text,
    category text,
    category_id integer,
    quantity numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    cost_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    sale_price numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    low_stock_threshold integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL
);

ALTER TABLE ONLY public.products FORCE ROW LEVEL SECURITY;


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: public_holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_holidays (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    holiday_date text NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.public_holidays FORCE ROW LEVEL SECURITY;


--
-- Name: public_holidays_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.public_holidays_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: public_holidays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.public_holidays_id_seq OWNED BY public.public_holidays.id;


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_items (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    quantity_returned numeric(12,3) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_items_id_seq OWNED BY public.purchase_items.id;


--
-- Name: purchase_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    original_purchase_item_id integer,
    unit_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    total_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_return_items_id_seq OWNED BY public.purchase_return_items.id;


--
-- Name: purchase_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_returns (
    id integer NOT NULL,
    request_id text,
    return_no text NOT NULL,
    purchase_id integer,
    customer_id integer,
    customer_name text,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    refund_type text DEFAULT 'balance_credit'::text,
    safe_id integer,
    safe_name text,
    date text,
    reason text,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.purchase_returns FORCE ROW LEVEL SECURITY;


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_returns_id_seq OWNED BY public.purchase_returns.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    request_id text,
    invoice_no text NOT NULL,
    supplier_name text,
    customer_id integer,
    customer_name text,
    payment_type text NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL
);

ALTER TABLE ONLY public.purchases FORCE ROW LEVEL SECURITY;


--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: receipt_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receipt_vouchers (
    id integer NOT NULL,
    request_id text,
    voucher_no text NOT NULL,
    date text NOT NULL,
    customer_id integer,
    customer_name text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.receipt_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.receipt_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.receipt_vouchers_id_seq OWNED BY public.receipt_vouchers.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    token_hash text NOT NULL,
    user_id integer NOT NULL,
    used boolean DEFAULT false NOT NULL,
    revoked boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone
);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: safe_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safe_transfers (
    id integer NOT NULL,
    from_safe_id integer,
    from_safe_name text,
    to_safe_id integer,
    to_safe_name text,
    amount numeric(12,2) NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.safe_transfers FORCE ROW LEVEL SECURITY;


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.safe_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.safe_transfers_id_seq OWNED BY public.safe_transfers.id;


--
-- Name: safes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.safes (
    id integer NOT NULL,
    name text NOT NULL,
    balance numeric(12,2) DEFAULT '0'::numeric,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.safes FORCE ROW LEVEL SECURITY;


--
-- Name: safes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.safes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: safes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.safes_id_seq OWNED BY public.safes.id;


--
-- Name: salary_advance_deductions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_deductions (
    id integer NOT NULL,
    salary_advance_id integer NOT NULL,
    payroll_record_id integer,
    deduction_amount numeric(14,2) NOT NULL,
    deduction_date text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_deductions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_deductions_id_seq OWNED BY public.salary_advance_deductions.id;


--
-- Name: salary_advance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_history (
    id integer NOT NULL,
    salary_advance_id integer NOT NULL,
    old_status text,
    new_status text NOT NULL,
    changed_by integer,
    comment text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_history_id_seq OWNED BY public.salary_advance_history.id;


--
-- Name: salary_advance_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_ledger (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    advance_id integer NOT NULL,
    ledger_type text NOT NULL,
    amount numeric(14,2) NOT NULL,
    balance numeric(14,2) NOT NULL,
    ledger_date text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_ledger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_ledger_id_seq OWNED BY public.salary_advance_ledger.id;


--
-- Name: salary_advance_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advance_settings (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    max_advance_percentage numeric(5,2) DEFAULT '50'::numeric NOT NULL,
    max_concurrent_advances integer DEFAULT 2 NOT NULL,
    min_salary_for_advance numeric(14,2) DEFAULT '3000'::numeric NOT NULL,
    repayment_tenure_months integer DEFAULT 1 NOT NULL,
    requires_approval boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.salary_advance_settings FORCE ROW LEVEL SECURITY;


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advance_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advance_settings_id_seq OWNED BY public.salary_advance_settings.id;


--
-- Name: salary_advances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_advances (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    requested_date text NOT NULL,
    requested_amount numeric(14,2) NOT NULL,
    approved_amount numeric(14,2),
    advance_type text DEFAULT 'personal'::text NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approver_id integer,
    approved_at timestamp with time zone,
    rejection_reason text,
    remaining_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    deduct_from text DEFAULT 'fixed'::text NOT NULL,
    safe_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    company_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.salary_advances FORCE ROW LEVEL SECURITY;


--
-- Name: salary_advances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_advances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_advances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_advances_id_seq OWNED BY public.salary_advances.id;


--
-- Name: salary_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_components (
    id integer NOT NULL,
    salary_structure_id integer NOT NULL,
    component_type text NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    amount numeric(14,2),
    percentage_of_base numeric(7,4),
    is_mandatory boolean DEFAULT false NOT NULL,
    is_taxable boolean DEFAULT false NOT NULL,
    sequence integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_components_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_components_id_seq OWNED BY public.salary_components.id;


--
-- Name: salary_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_history (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    salary_amount numeric(14,2) NOT NULL,
    currency text DEFAULT 'EGP'::text NOT NULL,
    effective_date text NOT NULL,
    reason text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salary_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_history_id_seq OWNED BY public.salary_history.id;


--
-- Name: salary_structures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_structures (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    base_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.salary_structures FORCE ROW LEVEL SECURITY;


--
-- Name: salary_structures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_structures_id_seq OWNED BY public.salary_structures.id;


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_items (
    id integer NOT NULL,
    sale_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    cost_price numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    cost_total numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    quantity_returned numeric(12,3) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: sale_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_items_id_seq OWNED BY public.sale_items.id;


--
-- Name: sale_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    total_price numeric(12,2) NOT NULL,
    original_sale_item_id integer,
    unit_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    total_cost_at_return numeric(12,4) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_return_items_id_seq OWNED BY public.sale_return_items.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    request_id text,
    invoice_no text NOT NULL,
    customer_name text,
    customer_id integer,
    payment_type text NOT NULL,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    paid_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    posting_status text DEFAULT 'draft'::text NOT NULL,
    safe_id integer,
    safe_name text,
    warehouse_id integer,
    warehouse_name text,
    salesperson_id integer,
    salesperson_name text,
    discount_percent numeric(5,2) DEFAULT '0'::numeric,
    discount_amount numeric(12,2) DEFAULT '0'::numeric,
    notes text,
    date text,
    user_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    tax_rate numeric(5,2) DEFAULT '0'::numeric NOT NULL
);

ALTER TABLE ONLY public.sales FORCE ROW LEVEL SECURITY;


--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: sales_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_returns (
    id integer NOT NULL,
    request_id text,
    return_no text NOT NULL,
    sale_id integer,
    customer_id integer,
    customer_name text,
    total_amount numeric(12,2) DEFAULT '0'::numeric NOT NULL,
    refund_type text DEFAULT 'credit'::text,
    safe_id integer,
    safe_name text,
    date text,
    reason text,
    notes text,
    user_id integer,
    warehouse_id integer,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.sales_returns FORCE ROW LEVEL SECURITY;


--
-- Name: sales_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_returns_id_seq OWNED BY public.sales_returns.id;


--
-- Name: shift_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_schedules (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    name_en text NOT NULL,
    name_ar text NOT NULL,
    start_time text NOT NULL,
    end_time text NOT NULL,
    break_duration integer DEFAULT 60 NOT NULL,
    grace_minutes integer DEFAULT 5 NOT NULL,
    weekly_hours numeric(5,2) DEFAULT '40'::numeric NOT NULL,
    working_days text DEFAULT '0,1,2,3,4'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.shift_schedules FORCE ROW LEVEL SECURITY;


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shift_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shift_schedules_id_seq OWNED BY public.shift_schedules.id;


--
-- Name: statutory_contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statutory_contributions (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    contribution_type text NOT NULL,
    name_ar text NOT NULL,
    name_en text NOT NULL,
    employee_percentage numeric(7,4) DEFAULT '0'::numeric NOT NULL,
    employer_percentage numeric(7,4) DEFAULT '0'::numeric NOT NULL,
    is_mandatory boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.statutory_contributions FORCE ROW LEVEL SECURITY;


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statutory_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statutory_contributions_id_seq OWNED BY public.statutory_contributions.id;


--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_count_items (
    id integer NOT NULL,
    session_id integer NOT NULL,
    product_id integer NOT NULL,
    system_qty numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    physical_qty numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_count_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_count_items_id_seq OWNED BY public.stock_count_items.id;


--
-- Name: stock_count_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_count_sessions (
    id integer NOT NULL,
    warehouse_id integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_by integer,
    applied_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.stock_count_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_count_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_count_sessions_id_seq OWNED BY public.stock_count_sessions.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    movement_type text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    quantity_before numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    quantity_after numeric(12,3) DEFAULT '0'::numeric NOT NULL,
    unit_cost numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    reference_type text,
    reference_id integer,
    reference_no text,
    notes text,
    date text,
    warehouse_id integer DEFAULT 1 NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.stock_movements FORCE ROW LEVEL SECURITY;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: stock_transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfer_items (
    id integer NOT NULL,
    transfer_id integer NOT NULL,
    product_id integer NOT NULL,
    product_name text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_cost numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfer_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfer_items_id_seq OWNED BY public.stock_transfer_items.id;


--
-- Name: stock_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_transfers (
    id integer NOT NULL,
    from_warehouse_id integer NOT NULL,
    to_warehouse_id integer NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    notes text,
    company_id integer DEFAULT 1 NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.stock_transfers FORCE ROW LEVEL SECURITY;


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_transfers_id_seq OWNED BY public.stock_transfers.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tax_brackets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tax_brackets (
    id integer NOT NULL,
    company_id integer DEFAULT 1 NOT NULL,
    fiscal_year text NOT NULL,
    min_salary numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    max_salary numeric(14,2),
    tax_rate numeric(7,4) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tax_brackets FORCE ROW LEVEL SECURITY;


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tax_brackets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tax_brackets_id_seq OWNED BY public.tax_brackets.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    type text NOT NULL,
    reference_type text,
    reference_id integer,
    safe_id integer,
    safe_name text,
    customer_id integer,
    customer_name text,
    amount numeric(12,2) NOT NULL,
    direction text DEFAULT 'none'::text NOT NULL,
    description text,
    date text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.transactions FORCE ROW LEVEL SECURITY;


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: treasury_vouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treasury_vouchers (
    id integer NOT NULL,
    voucher_no text NOT NULL,
    type text NOT NULL,
    safe_id integer NOT NULL,
    safe_name text NOT NULL,
    amount numeric(12,2) NOT NULL,
    party_name text,
    description text NOT NULL,
    category text,
    company_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.treasury_vouchers FORCE ROW LEVEL SECURITY;


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.treasury_vouchers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.treasury_vouchers_id_seq OWNED BY public.treasury_vouchers.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name text NOT NULL,
    address text,
    company_id integer DEFAULT 1 NOT NULL,
    branch_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.warehouses FORCE ROW LEVEL SECURITY;


--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: warranty_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warranty_records (
    id integer NOT NULL,
    company_id integer NOT NULL,
    sale_id integer,
    product_id integer,
    product_name text NOT NULL,
    customer_id integer,
    customer_name text,
    customer_phone text,
    serial_number text,
    device_model text,
    warranty_months integer DEFAULT 3 NOT NULL,
    warranty_start date NOT NULL,
    warranty_end date NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: warranty_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warranty_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warranty_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warranty_records_id_seq OWNED BY public.warranty_records.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: attendance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records ALTER COLUMN id SET DEFAULT nextval('public.attendance_records_id_seq'::regclass);


--
-- Name: attendance_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary ALTER COLUMN id SET DEFAULT nextval('public.attendance_summary_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: branches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches ALTER COLUMN id SET DEFAULT nextval('public.branches_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: customer_classifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications ALTER COLUMN id SET DEFAULT nextval('public.customer_classifications_id_seq'::regclass);


--
-- Name: customer_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger ALTER COLUMN id SET DEFAULT nextval('public.customer_ledger_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: daily_incentive_accrual id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual ALTER COLUMN id SET DEFAULT nextval('public.daily_incentive_accrual_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: deposit_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers ALTER COLUMN id SET DEFAULT nextval('public.deposit_vouchers_id_seq'::regclass);


--
-- Name: employee_bonuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses ALTER COLUMN id SET DEFAULT nextval('public.employee_bonuses_id_seq'::regclass);


--
-- Name: employee_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts ALTER COLUMN id SET DEFAULT nextval('public.employee_contacts_id_seq'::regclass);


--
-- Name: employee_custody id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody ALTER COLUMN id SET DEFAULT nextval('public.employee_custody_id_seq'::regclass);


--
-- Name: employee_custody_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines ALTER COLUMN id SET DEFAULT nextval('public.employee_custody_lines_id_seq'::regclass);


--
-- Name: employee_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents ALTER COLUMN id SET DEFAULT nextval('public.employee_documents_id_seq'::regclass);


--
-- Name: employee_incentive_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_incentive_assignments_id_seq'::regclass);


--
-- Name: employee_leave_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances ALTER COLUMN id SET DEFAULT nextval('public.employee_leave_balances_id_seq'::regclass);


--
-- Name: employee_shift_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_shift_assignments_id_seq'::regclass);


--
-- Name: employee_status_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history ALTER COLUMN id SET DEFAULT nextval('public.employee_status_history_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: erp_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users ALTER COLUMN id SET DEFAULT nextval('public.erp_users_id_seq'::regclass);


--
-- Name: expense_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories ALTER COLUMN id SET DEFAULT nextval('public.expense_categories_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: fiscal_years id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years ALTER COLUMN id SET DEFAULT nextval('public.fiscal_years_id_seq'::regclass);


--
-- Name: idempotency_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys ALTER COLUMN id SET DEFAULT nextval('public.idempotency_keys_id_seq'::regclass);


--
-- Name: incentive_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics ALTER COLUMN id SET DEFAULT nextval('public.incentive_metrics_id_seq'::regclass);


--
-- Name: incentive_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules ALTER COLUMN id SET DEFAULT nextval('public.incentive_rules_id_seq'::regclass);


--
-- Name: incentive_schemes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes ALTER COLUMN id SET DEFAULT nextval('public.incentive_schemes_id_seq'::regclass);


--
-- Name: incentive_slabs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs ALTER COLUMN id SET DEFAULT nextval('public.incentive_slabs_id_seq'::regclass);


--
-- Name: income id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income ALTER COLUMN id SET DEFAULT nextval('public.income_id_seq'::regclass);


--
-- Name: job_titles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles ALTER COLUMN id SET DEFAULT nextval('public.job_titles_id_seq'::regclass);


--
-- Name: journal_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries ALTER COLUMN id SET DEFAULT nextval('public.journal_entries_id_seq'::regclass);


--
-- Name: journal_entry_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines ALTER COLUMN id SET DEFAULT nextval('public.journal_entry_lines_id_seq'::regclass);


--
-- Name: leave_accrual_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history ALTER COLUMN id SET DEFAULT nextval('public.leave_accrual_history_id_seq'::regclass);


--
-- Name: leave_approvals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals ALTER COLUMN id SET DEFAULT nextval('public.leave_approvals_id_seq'::regclass);


--
-- Name: leave_blackout_dates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates ALTER COLUMN id SET DEFAULT nextval('public.leave_blackout_dates_id_seq'::regclass);


--
-- Name: leave_policies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies ALTER COLUMN id SET DEFAULT nextval('public.leave_policies_id_seq'::regclass);


--
-- Name: leave_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests ALTER COLUMN id SET DEFAULT nextval('public.leave_requests_id_seq'::regclass);


--
-- Name: leave_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types ALTER COLUMN id SET DEFAULT nextval('public.leave_types_id_seq'::regclass);


--
-- Name: monthly_incentive_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary ALTER COLUMN id SET DEFAULT nextval('public.monthly_incentive_summary_id_seq'::regclass);


--
-- Name: overtime_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records ALTER COLUMN id SET DEFAULT nextval('public.overtime_records_id_seq'::regclass);


--
-- Name: payment_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers ALTER COLUMN id SET DEFAULT nextval('public.payment_vouchers_id_seq'::regclass);


--
-- Name: payroll_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments ALTER COLUMN id SET DEFAULT nextval('public.payroll_adjustments_id_seq'::regclass);


--
-- Name: payroll_line_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items ALTER COLUMN id SET DEFAULT nextval('public.payroll_line_items_id_seq'::regclass);


--
-- Name: payroll_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods ALTER COLUMN id SET DEFAULT nextval('public.payroll_periods_id_seq'::regclass);


--
-- Name: payroll_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records ALTER COLUMN id SET DEFAULT nextval('public.payroll_records_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: public_holidays id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays ALTER COLUMN id SET DEFAULT nextval('public.public_holidays_id_seq'::regclass);


--
-- Name: purchase_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_items_id_seq'::regclass);


--
-- Name: purchase_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_return_items_id_seq'::regclass);


--
-- Name: purchase_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns ALTER COLUMN id SET DEFAULT nextval('public.purchase_returns_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: receipt_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers ALTER COLUMN id SET DEFAULT nextval('public.receipt_vouchers_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: safe_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers ALTER COLUMN id SET DEFAULT nextval('public.safe_transfers_id_seq'::regclass);


--
-- Name: safes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes ALTER COLUMN id SET DEFAULT nextval('public.safes_id_seq'::regclass);


--
-- Name: salary_advance_deductions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_deductions_id_seq'::regclass);


--
-- Name: salary_advance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_history_id_seq'::regclass);


--
-- Name: salary_advance_ledger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_ledger_id_seq'::regclass);


--
-- Name: salary_advance_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings ALTER COLUMN id SET DEFAULT nextval('public.salary_advance_settings_id_seq'::regclass);


--
-- Name: salary_advances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances ALTER COLUMN id SET DEFAULT nextval('public.salary_advances_id_seq'::regclass);


--
-- Name: salary_components id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components ALTER COLUMN id SET DEFAULT nextval('public.salary_components_id_seq'::regclass);


--
-- Name: salary_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history ALTER COLUMN id SET DEFAULT nextval('public.salary_history_id_seq'::regclass);


--
-- Name: salary_structures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures ALTER COLUMN id SET DEFAULT nextval('public.salary_structures_id_seq'::regclass);


--
-- Name: sale_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items ALTER COLUMN id SET DEFAULT nextval('public.sale_items_id_seq'::regclass);


--
-- Name: sale_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items ALTER COLUMN id SET DEFAULT nextval('public.sale_return_items_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: sales_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns ALTER COLUMN id SET DEFAULT nextval('public.sales_returns_id_seq'::regclass);


--
-- Name: shift_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules ALTER COLUMN id SET DEFAULT nextval('public.shift_schedules_id_seq'::regclass);


--
-- Name: statutory_contributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions ALTER COLUMN id SET DEFAULT nextval('public.statutory_contributions_id_seq'::regclass);


--
-- Name: stock_count_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items ALTER COLUMN id SET DEFAULT nextval('public.stock_count_items_id_seq'::regclass);


--
-- Name: stock_count_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions ALTER COLUMN id SET DEFAULT nextval('public.stock_count_sessions_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: stock_transfer_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items ALTER COLUMN id SET DEFAULT nextval('public.stock_transfer_items_id_seq'::regclass);


--
-- Name: stock_transfers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers ALTER COLUMN id SET DEFAULT nextval('public.stock_transfers_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tax_brackets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets ALTER COLUMN id SET DEFAULT nextval('public.tax_brackets_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: treasury_vouchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers ALTER COLUMN id SET DEFAULT nextval('public.treasury_vouchers_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Name: warranty_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_records ALTER COLUMN id SET DEFAULT nextval('public.warranty_records_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, code, name, type, parent_id, level, is_posting, opening_balance, current_balance, is_active, company_id, created_at) FROM stdin;
53	AR-1001	عميل - 111111	asset	\N	2	t	0.00	0.00	t	1	2026-04-18 09:14:22.690564+00
54	REV-SALES	إيرادات المبيعات	revenue	\N	2	t	0.00	-500.00	t	1	2026-04-18 09:18:23.882188+00
2	EXP-COGS	تكلفة البضاعة المباعة	expense	\N	2	t	0.00	0.00	t	1	2026-04-18 06:04:52.02999+00
1	ASSET-INVENTORY	بضاعة المخزون	asset	\N	2	t	0.00	0.00	t	1	2026-04-18 06:04:52.025181+00
3	EXP-GENERAL	مصروفات عمومية وإدارية	expense	\N	2	t	0.00	3500.00	t	1	2026-04-18 06:06:10.970616+00
4	SAFE-1	خزينة - الخزينة الرئيسية	asset	\N	2	t	0.00	-3000.00	t	1	2026-04-18 06:06:10.984859+00
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, type, severity, message, reference_id, trigger_mode, last_triggered_date, role_target, user_id, is_read, is_resolved, resolved_at, resolved_by, company_id, created_at) FROM stdin;
1	low_stock	WARNING	المخزون منخفض للمنتج (3333333) — الكمية: 0	47	daily	2026-04-19	admin,manager	\N	f	f	\N	\N	1	2026-04-19 17:17:00.016468+00
\.


--
-- Data for Name: attendance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_records (id, employee_id, attendance_date, check_in_time, check_out_time, status, working_hours, late_minutes, early_departure_minutes, overtime_hours, notes, submitted_by, verified_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendance_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_summary (id, employee_id, month, total_present_days, total_absent_days, total_late_days, total_early_departures, total_overtime_hours, total_working_hours, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, record_type, record_id, old_value, new_value, user_id, username, company_id, created_at) FROM stdin;
1	create	sale	1	\N	{"role": "admin", "invoice_no": "INV-1776492247852", "customer_id": null, "payment_type": "cash", "total_amount": 500, "customer_name": null}	2	admin	\N	2026-04-18 06:04:07.865423+00
2	create	sale_return	1	\N	{"date": "2026-04-18", "total": 500, "return_no": "SR-1776492292015", "customer_id": null, "refund_type": "cash"}	2	admin	\N	2026-04-18 06:04:52.04142+00
3	lock_period	financial_lock	0	\N	{"lock_mode": "manual", "locked_by": "admin", "closing_date": "2026-01-31"}	2	admin	\N	2026-04-18 06:07:02.498047+00
4	lock_period	financial_lock	0	\N	{"lock_mode": "manual", "locked_by": "admin", "closing_date": "2026-04-30"}	2	admin	\N	2026-04-18 06:07:26.6428+00
5	unlock_period	financial_lock	0	{"locked_by": "admin", "closing_date": "2026-04-30"}	{"unlocked_by": "admin", "unlock_reason": "اختبار النظام"}	2	admin	\N	2026-04-18 06:07:26.777917+00
45	create	employee	1	\N	{"code": "EMP0001", "name": "صالح المليجي"}	2	admin	\N	2026-04-18 07:07:44.706188+00
46	update	salary_advance	1	\N	{"amount": 500, "status": "active"}	2	admin	\N	2026-04-18 07:08:09.969524+00
53	create	customer	1	\N	{"id": 1, "name": "111111", "phone": "0000000000000", "balance": 0, "account_id": 53, "company_id": 1, "created_at": "2026-04-18T09:14:22.685Z", "is_customer": true, "is_supplier": true, "customer_code": 1001, "normalized_name": "111111", "classification_id": 1}	2	admin	\N	2026-04-18 09:14:22.699193+00
54	ADMIN_PASSWORD_RESET	erp_user	2	\N	{"reset_by": "super_admin", "company_id": 1}	1	superadmin	\N	2026-04-19 05:59:09.087637+00
55	ADMIN_PASSWORD_RESET	erp_user	2	\N	{"reset_by": "super_admin", "company_id": 1}	1	superadmin	\N	2026-04-19 05:59:18.099341+00
56	ADMIN_PASSWORD_RESET	erp_user	2	\N	{"reset_by": "super_admin", "company_id": 1}	1	superadmin	\N	2026-04-19 05:59:22.05308+00
57	CREATE	company	60	\N	{"name": "البركة", "admin": "b250", "plan_type": "trial"}	1	superadmin	\N	2026-04-19 07:16:49.887495+00
58	create	sale	47	\N	{"role": "admin", "invoice_no": "INV-1776590636323", "customer_id": null, "payment_type": "cash", "total_amount": 500, "customer_name": null}	2	admin	\N	2026-04-19 09:23:56.42155+00
59	create	sale	48	\N	{"role": "admin", "invoice_no": "INV-1776590675764", "customer_id": 1, "payment_type": "credit", "total_amount": 500, "customer_name": "111111"}	2	admin	\N	2026-04-19 09:24:35.856384+00
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, filename, size, trigger, created_at) FROM stdin;
1	halal-tech-manual_2026-04-18_06-02-30.json	1398	manual	2026-04-18 06:02:30.97375+00
2	halal-tech-manual_2026-04-18_06-06-40.json	8850	manual	2026-04-18 06:06:40.117426+00
3	halal-tech-sale_post_2026-04-18_09-18-23.json	16751	sale_post	2026-04-18 09:18:23.969809+00
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branches (id, company_id, name, address, phone, is_active, created_at) FROM stdin;
1	1	1	2	2	t	2026-04-18 09:13:54.01714+00
2	1	500	jfjfffff	011111	t	2026-04-19 10:46:32.022676+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, company_id) FROM stdin;
2	666	1
3	2222	1
1	222	1
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, plan_type, start_date, end_date, is_active, admin_email, created_at) FROM stdin;
1	الشركة الافتراضية	professional	2026-04-18	2027-04-18	t	\N	2026-04-18 06:02:08.768889+00
55	محمود	trial	2026-04-18	2026-04-25	t	m@m.com	2026-04-18 08:30:13.715161+00
60	البركة	trial	2026-04-19	2026-05-03	t	\N	2026-04-19 07:16:49.665135+00
61	حنكوريا	trial	2026-04-19	2026-04-26	t	m1@m.com	2026-04-19 11:15:16.372977+00
\.


--
-- Data for Name: customer_classifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_classifications (id, name, company_id, created_at) FROM stdin;
1	55555	1	2026-04-18 09:14:18.585981+00
\.


--
-- Data for Name: customer_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_ledger (id, customer_id, type, amount, reference_type, reference_id, reference_no, description, date, company_id, created_at) FROM stdin;
1	1	sale	500.00	sale	48	INV-1776590675764	فاتورة مبيعات INV-1776590675764	2026-04-19	1	2026-04-19 09:24:35.765083+00
2	1	purchase	-300.00	purchase	46	PUR-1776590797017	مشتريات آجل PUR-1776590797017 — 111111	2026-04-19	1	2026-04-19 09:26:37.018473+00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, customer_code, normalized_name, phone, balance, is_customer, is_supplier, account_id, classification_id, company_id, created_at) FROM stdin;
1	111111	1001	111111	0000000000000	200.00	t	t	53	1	1	2026-04-18 09:14:22.685646+00
\.


--
-- Data for Name: daily_incentive_accrual; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_incentive_accrual (id, employee_id, incentive_rule_id, accrual_date, metric_value, target_value, achievement_percentage, accrued_amount, currency, status, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, company_id, name_en, name_ar, description_en, description_ar, created_at) FROM stdin;
1	1	حرامي	حرامي	\N		2026-04-18 07:07:01.376677+00
\.


--
-- Data for Name: deposit_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deposit_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, source, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: employee_bonuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_bonuses (id, company_id, employee_id, amount, reason, granted_date, granted_by, currency, created_at) FROM stdin;
1	1	1	500.00	\N	2026-04-18	2	EGP	2026-04-18 07:10:33.441319+00
\.


--
-- Data for Name: employee_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_contacts (id, employee_id, contact_type, name, relationship, phone, email, created_at) FROM stdin;
\.


--
-- Data for Name: employee_custody; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_custody (id, company_id, employee_id, safe_id, amount, returned_amount, purpose, granted_date, settled_date, status, granted_by, currency, notes, reimbursement_due, created_at, updated_at) FROM stdin;
1	1	1	1	5000.00	0.00	6	2026-04-18	\N	open	2	EGP	\N	0.00	2026-04-18 09:22:55.287826+00	2026-04-18 09:22:55.287826+00
\.


--
-- Data for Name: employee_custody_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_custody_lines (id, company_id, custody_id, category, amount, description, line_date, expense_id, created_at) FROM stdin;
\.


--
-- Data for Name: employee_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_documents (id, employee_id, document_type, file_name, file_path, expiry_date, verified_by, verified_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_incentive_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_incentive_assignments (id, employee_id, incentive_scheme_id, assigned_date, end_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: employee_leave_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_leave_balances (id, employee_id, leave_type_id, accrued_days, used_days, balance_days, carryover_days, as_of_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_shift_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_shift_assignments (id, employee_id, shift_schedule_id, assigned_date, end_date, created_at) FROM stdin;
\.


--
-- Data for Name: employee_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_status_history (id, employee_id, old_status, new_status, reason, changed_by, changed_at) FROM stdin;
1	1	\N	active	تسجيل موظف جديد	2	2026-04-18 07:07:44.699872+00
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, company_id, employee_code, first_name_en, last_name_en, first_name_ar, last_name_ar, email, phone, personal_phone, national_id, national_id_image, job_title_id, department_id, branch_id, hire_date, employment_status, salary, currency, salary_type, commission_rate, commission_basis, commission_scope_dept_id, bank_account, address_en, address_ar, city, country, notes, created_at, updated_at, deleted_at, created_by, updated_by) FROM stdin;
1	1	EMP0001			صالح	المليجي		01117144442	\N	28403152102251	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABJUAAAK6CAYAAACAHm0HAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAP+lSURBVHhe7P13uC3Hed6JvlXVveLO++SADCKQAAEQgQFgAEklyzStsUTJQbIlWyMH2X5sP3c8czX30diesTzPjO+94zRj+RlburJkUZYlWcwkSADMAYHIOZ28zz47h7VWd1fdP76vunutvfYBtiSKhPD+gDp7rQ7VlbpX1dtffWVCCAGEEEIIIYQQQgghhOwBO7qBEEIIIYQQQgghhJBXg6ISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEIIIXuGohIhhBBCCCGEEEII2TMUlQghhBBCCCGEEELInqGoRAghhBBCCCGEEEL2DEUlQgghhBBCCCGEELJnKCoRQgghhBBCCCGEkD1DUYkQQgghhBBCCCGE7BmKSoQQQgghhBBCCCFkz1BUIoQQQgghhBBCCCF7hqISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEIIIXuGohIhhBBCCCGEEEII2TMUlQghhBBCCCGEEELInqGoRAghhBBCCCGEEEL2DEUlQgghhBBCCCGEELJnKCoRQgghhBBCCCGEkD1DUYkQQgghhBBCCCGE7BmKSoQQQgghhBBCCCFkz1BUIoQQQgghhBBCCCF7hqISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEIIIXuGohIhhBBCCCGEEEII2TMUlQghhBBCCCGEEELInqGoRAghhBBCCCGEEEL2DEUlQgghhBBCCCGEELJnKCoRQgghhBBCCCGEkD1DUYkQQgghhBBCCCGE7BmKSoQQQgghhBBCCCFkz1BUIoQQQgghhBBCCCF7hqISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEIIIXuGohIhhBBCCCGEEEII2TMUlQghhBBCCCGEEELInqGoRAghhBBCCCGEEEL2DEUlQgghhBBCCCGEELJnKCoRQgghhBBCCCGEkD1DUYkQQgghhBBCCCGE7BmKSoQQQgghhBBCCCFkz1BUIoQQQgghhBBCCCF7hqISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEIIIXuGohIhhBBCCCGEEEII2TMUlQghhBBCCCGEEELInqGoRAghhBBCCCGEEEL2DEUlQgghhBBCCCGEELJnKCoRQgghhBBCCCGEkD1DUYkQQgghhBBCCCGE7BmKSoQQQgghhBBCCCFkz1BUIoQQQgghhBBCCCF7hqISIYQQQgghhBBCCNkzFJUIIYQQQgghhBBCyJ6hqEQIIYQQQgghhBBC9gxFJUIIIYQQQgghhBCyZygqEUIIIYQQQgghhJA9Q1GJEEIIIYQQQgghhOwZikqEEEIIIYQQQgghZM9QVCKEEEIIIYQQQgghe4aiEiGEEEIIIYQQQgjZMxSVCCGEEEIIIYQQQsieoahECCGEEEIIIYQQQvYMRSVCCCGEEEIIIYQQsmcoKhFCCCGEEEIIIYSQPUNRiRBCCCGEEEIIIYTsGYpKhBBCCCGEEEIIIWTPUFQihBBCCCGEEEK+y7y0LIGQ1xMUlQghhBBCCCGEkO8y/+wLEgh5PUFRiRBCCCGEEEII+S7y4CngzLqEB0+N7iXkexeKSoQQQgghhBBCyHeRB07WPlNUIq8jKCoRQgghhBBCCCHfJc5vAF98sfr+5ZeA85v1Iwj53oWiEiGEEEIIIYQQ8l3i9x4HLmwA3sv3lW3gE0+NHkXI9yYUlQghhBBCCCGEkO8CLy4Bv/cY4IOISlFY+sRTwCsro0cT8r0HRSVCCCGEEEIIIeS7wO8+Amz3gcJL8B4IAejntFYirw8oKhFCCCGEEEIIIX/M/MYDIiqVVkqh+hwC8Kmngd95bPQsQr63oKhECCGEEEIIIYT8MfKVF4F/cZ9aKBWAL+RvUVRWSyEAv/IA8CBXgyPfw5gQQhjdSAghhBBCCCGEkO8Mt/2vgLOAtYBz8tk5/R6DfgeA3/2p0RgI+d6AlkqEEEIIIYQQQsgfA8+eC7jlfw6lRZL3aqWkFkt1S6UYAODDvwK8tDwaGyHffSgqEUIIIYQQQggh32E+/rDHj/+bAkadJ8XV3uo+lUIAQtxe2w8Af/e/Avc+PxorId9dOP2NEEIIIYQQQgj5DvH8WY+PfrXAf/6mR3BG573JX+PMxafB6TarAQB+4Brgh64FLpkZvRIhf/xQVCKEEEIIIYQQQv6IObvs8dEvZvjoV3L0Cgs4g+DkryhGBsFa2DFi0m4ikzESdzMRYemHrgX2d0evTMgfHxSVCCGEEEIIIYSQPyK+8kSOrzye47MPZlhaD0NCUrRUGrVYisLSbmJS/XsUlgBgpg286zLgbUeBW47WU0HIHw8UlQghhBBCCCGEkD8kT75S4P/577dx4rx6144Ys7uoFL9bMzTVbdznusg0jsOTwD94D3Dl/OgeQr5z7NIcCSGEEEIIIYQQ8lpJ3OgWJQSEwg+FuLRb/Xtc/c3HleDiYXFVuNrqcLuxm+BEyHcKWioRQgghhBBCCCF/RIxOfyuxpmahNGytFKz8fTXH3aNWTJz+Rr7bUFQihBBCCCGEEEL+iDm77PHR+wb4rfsz9AYy7A62PhWuNv2t5mMpCku7iUnOAe0G8KE3A3/qOjrqJt9dKCoRQgghhBBCCCHfIZ4/7fFb9w/w218ayIZX8a2EV3Hc/aG3SLhsdvRKhPzxQ1GJEEIIIYQQQgj5DvP/+9wA/8fv9gDgVUUlOAPrzI7V3/76ncCP3zIaMyHfPSgqEUIIIYQQQgghfwx85Ykcf+dfbwFm1GIpCkvD4pKzKK2W/vmPAG+/bDRGQr67UFQihLwmXjmziC898DgeefolPP/KaZw9v4ql9Q30+wMEeZgA0LniIaD+aPEmRZKkSJIESZLAGIMQAow1sMYizzMMBhlCMYDNNtHf2sD68iLy7XVsri3hlhuuxbVXX4Z3vf1W3HbbTUgSB+ccjHEIwUMuHRACYK0DjKYlyO91MLWMADAwCKjSaEw8IADwsMEjMQbBe2RFAdgUBSySRhOF94AJWNzI8Uv/+7/CtZcfwbvuuBVXvel6rPcN7v/mE/j9j/8+jh2YwF/8sx/AlYfbKHwLOVIMQoJgm/j9T34K/V4fP/6Rj8AXOf7r730M3/jmt3D9ddci669hc30NH3j/3bjllpuROIfzC2cBX2BudhapswA8vPewZbrreRiHrxWEAeDKQgnG67kBMAE+BFjnYIxBlmWwMHDOIfgCvsiRJA7e51hZXsbTTz2DL3/l6zh9bhELF9bx0olzWO8N4BoTSFsdNDsddLoTsM0u4FIYa2GMA6wBjIV1DknSQJKmWm9W68YgGKknaIpj7ozWaWE9BolHK2siKaxuK+ANkJgGbAEYBGTow8IA1iI3BWAz5AEIroUCDbTzPhqhDyCgZ1u1MhtPLGZTpg4I2u7jn1GMAQb9bbjUoZPm+Ef/3d/C8bk2kkEPxqbIy/NyWZQ1yD0EU7tGCHLfxLrW+weQdmqskfZvDLz3gDFw1iIgwPsg6ZZbomwrukn+xnvBWoTgYY2VNmZtmRZNCBDv35g+SU6ZrvjdWnORMpH44u4yLTGhukWjK/MOvW48N14ypkvSo/v1mWRgqvRrzNWJNWrl7b2Hcw4+hKFyKs+r1UFMYz0e1MpUNg0dIcT99cqp79a/9evuLKOKuLWevh0HlB+q8yVpVZrjYXq1svy912eF1r+eUKYpxPai548yWgLSruQKAdq+fVWPMYUS/8jJMZuQg4K2/Zjm4D0CZJuxBkUI+rMgqQsAjHXwALyRs4KR1hJLoLxk2LlUstFEjf62AEARdi7JlBcem1s9vHzyNB598hmcOXcek9OzOHDwIKYmJ5EmDr7IsLK8ghdfeAkvPvccVpeXURQFYC3a05M4evxSXH7FVZidmUNvq4ez505jY30VM1NdXH3FZbj2qiuwf24anWZatoOYHwO/o/zr7X0YE/8vqbfl+CnAV8++EgNrRpe+Cggoyv3l1lh4ofYZsuLVa8GY+u9adY9JWs3Qtfy4SLXt7iSePxpn7Yh4n4xrmGOQ1vjaGL1WfVv9XpU6rR4+Ma3WSmutx+NMrQVL45DPtfTXSqv8NI5Q3lcWDgaNNEEzSTDRaiLdddkzshu3/a01eYapmCR/RWQyIxZLzgLf/O9GYyDkewOKSoSQXVlcXsd/+vj9+PQXH8STL7xSdUSAoS6IIB0xo4IAtFMTQkCj1YWxFlY7NjIghRxvJOR5jnywDZtvI+/3sLFyAYOtVYTBFrLeOt50xXHc8tY34603Xo+7734vnLXI8xzOWhQ+wFirA4bYG9a0Vv3DYYJ0dVHrjAFAXuRopAlCkQM+qIjkYIyVH/5QIE0dtooGTi9tYWZmBmnSwCOPPo7P3XMPtgd9vOfd78QN112N6U4Lthgg8wbPvXQS//5X/yN+9q//LfzyL/873HH7rfjQD/8pNJMEeV7g//73/wF5nuHn//pfxcryEiYmulg4dxbra6tYX13B9NQkrr32Gh3cBKAc+ghjB60lcnzV0baAdEclHoNKiANQ6ODQGK3P4OF9QPAe/X4P3/72t/HAAw/hxZdOYHl1HSdOncXGdo7MO7SnZpG0ukgabbhGE2mzCZs0EVRMssbJYMY5NBotWJeUIlYAIOMx7TRHIWGkCk0cCNqARmFhvUOAQW6B3BRIUoOQ57DBwBemit8A8H0YExCsQ45UBMTggQAUJnnVDnVsXkOl/Sq/ogYBWTaATQzaSYZ/8j/8bRydbqJRZCgKIFgnbcvnOji2pZgzNBiqiSbx+sYaFIWHsxY+DpiDhzFWBtlBBulFnosQa0UsKu8/vR/lQ20QpXksb5/yS5XzmJZ4n0eRM+igY1zdyQaJTMSEkevU9g9FENOm4kU9nfUKiCUTouhWxrEz3UMCg26LabHWoCgKue9H86BxRSElHmAwLF7Vu1fj70/JY/36QFV/MZ8iDchzUsTwGN9QqWmUkm8REqVuqrqQf6OIE8+NbSGeP1pv8cgYnzy/6yLTcLnXy6BOPD/WPbQKYhoLL+04Eq+DoRoepryUlsnFRCUEvW7ZPnYXlYZyMEZU2o0Yj9Rrleo899jcFlHpsSefxelzCxcRlV4sRaW8KGCsRXt66o9RVFJGRO2IfAwIWm47GFLatDBMfI7V9gUpb4mk2u792Fh3YMxoSx3FSFsIAWGM0Ae9l3YibahqxjURtUSO2f3aw/xhRSW96Yc2WQSp1/qzTftTkRiXGalrrcLhKMtjxpXVayNxCbqtJma6bSS1e5nszrOnCvz5f7opL9texcfSb/41g6sPjMZAyPcG7hd/8Rd/cXQjIeSNzStnFvFP/+1/xt//pX+Hrz38NBaX13TPxTpRcbRtJViDJEmRNppI02Y1OIgWF7V+U+wIWYNahyaIsBM88ryPhXNnYAywsrKCLMtw/NhRHYCIoLRbqkpGDqh326pOmFi0ZFmBYBIUJoE3CfICgHWwzsLAy0DSNtCenMWJU2fwXz/+adx7/314y1uuwU/8uR/Gmy47goZzCIXBg99+Cvd+9QFcf9Ot2OzluP/LX8Pb3nYL7r/3Xnz5/nvx9FNP4IXnn8MHPvh+XHbpJZibnQJCwPLSEp577jlMdDs4euQwjhw5jKULi8izDK1Wa8hKaSgPsa+7g1oeS9RSwOhnBBR5DgMg+ALWAD4UCADWNzbx6KOP4xOf+iy+/JWv48TpBTz9/Ak8++IJFKYBk3bQnp5He2oOrYlpNDqTsM0WTNqEdSmMS2Csg7EiJjWbLSRJKm1FalHyECADaNQ7uTUM4LWpuWDEusoGeGvgjYVxBrnvw7gczklcFn2Y0NOOtYUDkFgD+ALeWKlnJHotKYedjKRELl0jftmRYmnzGq8zOT7wnneimxokQayIYC188LAQKzEEiIVCfOscLTGsCgwmWsmokGoqswJjpC1Y3WaNiFNJksAHEQajhZOp348qzEZrk8J7OGdLwUr2VyJNZZESLZaiSBDk/KIo35gbuZsBaLriNbV86sdY63QwLPmIzdmo1VUIHs66Mj5pu2otpHmH5j+UlizDdRK37agxSUT5fKqndQeaV2OM1pEprZpGryebdm5DXVCKm1QUinF7FVwkTZLrmC6gzEwVgR4nx4s4FQtHalyOrd9ZsQyhrTgeVQ5I4+CwbGcah5ahVYHJut0HkaYe90jZGyvfnRux0tPtF2NHqcZyrg+my3TK74XcjwYw0oZLDUTzNuapM2bLRYgFGBE9C1lRYHVtHecXl7C+uYlWq43uxARazabcY8Gj1+thZXkFK0sX0O/1RLizFmmrianpaczOzaPdaiPPcmxubWDQ76HVbGDf7Cz2zc2i226NWItIYkRaGmHc83Ucsb5qP9qhDFqrIQapPwlySrw3q0KRNA0LSpXAo7ewXuFiBMDUJcDh3Eh8sdWNE0ouEn9NKJU/444drejd2UV+G0vMfz3onqFtVoOJ4qnWZ/k3fh65J2JKTLxY/fvQhxq1uq/YeaD3HtuDDCubmxjkBVppOiQUk53MT1kc22dx78PZ6C6gVl//+MMWb79iZ5kT8r0CRSVCyBD/7Jd/B3/3n/wynnjulZE9ZTdlZLtiYrfVwLoESSrTmlySoCi8DhRkAGHiIMSKRUa0xkgSB2st8iKHLwrpCvsCeTZAkjgsnDsLY8WqqShyHDt6BM45OCdWGfW4ACDUOkwY7j8NUQ34DHwwyL2BTdtY287x9PMnsLrVx8T0HLxJAJcANsFLJ87ho7/1e/jC/ffjwKF5/NiPfRg3veVadBoOg+0+vDeAbeDC6jp+4798HOvbOd717vfi2eeex8lXXsZf/cs/ibveeQduuP4aXHLJJZjfN4+pqUmcfOUlPPboIzh06BA67RYuv+xSbKyv46UXX0RR5Jifn0czTXWayM48xM5rHOTvJG6M54faG9+ABFKO1hi4xMF7j+dfeBEf/8Sn8eWvfB2vnDiHEyfO4pkXT2GlV6A9OYf29D50pubRmpiBa03ANTpA0kSwCeBSBBhYm6DZaqPVbsO4FD5I/VRySyUoxVTGzvFQqnUcYmBgPZBbj9x6EZqCRRIsjA9ILZAgh/M9zLh1HJ9N0dvcgLFtZEUAgodFAW+MWihZWPhdBg+RqkDrd0I5YFBBYhSDgKLIYaxB6jzuvvMOTLUS2CKDdQmqF/MyldNAphaYqB2U1iZhSCQAoFMTZaoWohUJZEAub/wrixVEkSoKJ1EcUiFIBA0VgozWh15HpsXV25mkK8aD8roiTDkVseRwA2NE+A1lW60Gg+V21EQczXtZnPol3uNW20Z8rojQgtKySOKBRDAUkdZbbeAl19ZtWlbWWfjCwzqnaa5ahgi6IlwZHUjFstSIymtFxrUL6PZSRNFDRlt9eW5dBKgLM2OuGbdF8VnqSUu5dm792KHjgj6r1arJRsspjTMAlcVYOXCt8jKOobZSy0ss/1LsiXkeH01JvEx5flk32l40nnjd2L4QP48RlQwqC82I5GwP6MFlHEYsMLM8x+raBs4vXsDG5hYarRYmuhNojopKKytYWVpCr7ddir2VqDSHdquDPM+xuVmJSvOzs9g/P4vOH1JUivWzY1+0YNshLtQKTz/LIfXtI00iPsQ1qirG4ZLepRnVCNJWTS2SeM5oMndu2JV6/Y9+Hjly5Pvu7EVUGofeZtqe5bM1gIOkT55F4k5APsXfUy2eoGW1S0nUc7IzV7HuR7dj/NFBnh+DLMfK5hayImCi3Rw9jNS4+qjD0lrAky8XUmf6/It/f/R2h59+N8U58r0NRSVCCADggcefx3/7P/5rfPpLD+mWnZ2FCulmVUfIm3pjLNJGA84lsDYBjEMI2qn3Hl7FJaODw2j5EDv+pT8fa+F1alv05xN8gaIosLi4CGsdtjY30dvcwvFjx2CtQ5qkco3gq5QZIx1YAyAOYsdkq95ZDN4jmBQPPfoM/uW//VV86VuP4HNf/Bqef/kMjl1+NU6fX8XHPnsffvXXP4r5+Xn8xI99GHe9/a1oJ9Jp7+cW/9s//zd4+LFncNMtb8PShXNY28rw1NPP4MjhQ/jQn/pBPPHIQ3j5hafx3jvfiYluC41WE6vrGzh9+gxWLyziyOFDmJ2ZxvTUFF588XmcPnUKV1xxBY4fO4Zmq4VBvy9v/2p5Ge3wDuc11lYslzA0Q8HodwMgMWKxU/gCCwvn8aWvfhW///ufxAsvncSpMxfw7AsncGF5E0l7Cs3JWbQnZ9CemEba7MI12rBpE3ANeCNWXy5N0Wy20Wg0Ya0rLXNcIlM0QpB3yNY6uCTRgaukxQKwQUKVA2l7NgCJt/AWCCZAfGEB1iewhUGjKDCRr+JoYxUfecdRvPuaeZx+8VmsDRyKpIsCCWwoyolAAYBVq6xxjI4nqqHGcGd7tB5km1geWWuQuoD33XUHplsJXChEVAuxrcapDNEfkg60jVid2NJiSISlKLCYKAQYI2Ks+vkJ6lspTpGz6sNMrB8k/VHcjVMeS1GnLvoYmZIi14/X0/owMlCXLMg97JxFnsl0O2hZRbHBqohidNAqV5JrBbVUihY/km9ttbFYy/KQQrcqgnktuyj0SIXpSZqfKhIt7pgH1A6Fjti0TuIZ8bhYNrUExbOG0znCmGahzWZU8KpbGmldlEJbLZKhc2rf4zTE6GOoJhCUwl5Zx6NRVf65RESSFIrQWLcIiUcLQcWcKPCNpxL3rLbt+qEGsShqolcpUI0erefUhD4ppmoKZhQ/6vHV251U705RSWpAyytGPvbqF6EWXyyzSlRax/nFC1jf3EJTRaVoqeS9R6+3jZXlZRWVehcRlTJsbm4gq4lK+1RUSvYgKl2U2v54v9UR7UDir2N0uriEyoImpqUkxLRpiQdIOo34CqqODvp9ONSJx9W/RcalfTcMtM3o70+V9uHU78x1hVxvOMTj/6AhikblNhWUrJYvIGmtU/9eer8a8SNVHhHjKD/Xg9TV+FzsxOs1YuhlGVY3e2gmDo00GT2cKIfnLD729Qx56WRRyreVGvzCn00xNzG+vAn5XoGiEiEEv/Gx+/E3/9G/wfnl1dFdIx0JAGrJEvtNxlq4JEGSpkjShjhiNnG2vxwfuyNW/fTUIh8iaOcncUllkaDiSRw0GGNw6swZJEmCLBtgc3sbl15yqexDbRChb4dR9ZeU6kvZTdPOv4kDuqSNf/erv459Ry7F3/q7/wDXXf8WfOWrX8WXvvxlPPjwQ+hMTOHP/bkP4/3veydmug24PMfSwgX843/8T3H08mvxrvd+APd9+cv4xje/iRMvv4yP/Oifw5uvvRq/8Wv/AccPH8CHfuiDuO3mG5HagOWlC1hZWcGJk6dw8OBBXH7JUaRJAp/nWFg4h15vG2++/nrMzs7AGgPvRWwbyklt8GKtQ6j54ql3OH3QqTWA1GwcvKk/kzwvEDyw1evjni/ci09++rN47Imn8PKpc3jqmZewuLwJb5qYmt2P9tQsujOz6E5Mic8sl8K6BmzakMGEtUgaKVqtFpJEtsVrSVqko2riVC0tex1nSF2GOLBTywltCJInEV7E/j/AllOrDJLQRze/gDdNbeEjbz+Oayc3MWfWcHB+Gk+9fBo9NDEICSwsbIhp8ur4td7WR9DNckQ12KgfPtqxB7QjHwrYxMGZHO99122Y6TZgi1wc1BqZ2iVtvNbxLwfGmvcQLY1UQAoB1sZpV1KXrmZZI+fGwZoUow8eSZJKWWs8IVosqQhVXrQcjI3kKe4bGtBomeh965y0w1EqAUmJ6Rtx6m1ttGY0lYVNeb4eE8U0oLJQqqVbzqrVicYf231ZVbHO9YTyOVATZSKSBi2RONBTq7JY1vVSi2FnScR6FrGudokyD/W2FIWduH80zvJYAxEi6hFKYsvyK4eVQxet6jBAB8alIDNc/mXhyQllfUTKdGm7RGwuurnu/Lyk1paiUFrtGr2CEtuX5s9qekJZj/FcrW/dWV1Xj4/RlwN3yavRPO56/V0wNSFCLiFtOc9l+tvC4gWsb22h1Wyh0+mi2Wzo1L+A7e1trKwsY2VpuRSVYA0arTYmp6cxMzODVruNIs+xubmJwaCPdquB+dkZ7JuX6W/J0DREyX/8Dd4rpT4yjlr51MNoizCo1VV9uzFVM6oH/W2KoRRUyuPr1621j3qhA9Jay6Y+rh4NrFpOl+k2BtHWB9D4y6PjteL+8dTTXuUBMEae8a8eqnKRFwHD3+vlGRc+EQvwSjRGrDZ9zhd6T8niJvF0yYO1bljsN9V9EkJA8PJSof7sLdtFaXVWm+7o9RlRC7kPWN3qwRqDTrOhsZA6c5MGG9sBj7xQaBuTe+wv3JXgB2+mA3TyvQ9FJULe4PzLX/s4/un/9Vvl9zio1x4UALUWMFDBSB1pGlkVLElS2CSRaS96YiVEQTpuw85nKsoOW62DFgcgKkCFOJA2BnlRoPAeHhYXFhfRbDSwvrEJXxS4/LLLarHIKmaAEeuXMR1axJ9tPSl2OIuigGt28cgTz+KV0+cwNT2Ds6dO4PyZk3jztVfh7vfchQ/c/V7sn59EkW2i6PfQTttASHBucRWf/Pz9uPn2O3DDjTfik5/8OH7oB34At9xwHQ7vn8PbbroBl196DM3Eor+1joWzp9Bpt7G0vIKrrn4TpqencerlF/D8s8/gmmuuwaFDBzA5OYVOp63JjOJKlZ96HgAdUFqDxCVwzqlPHSlXsVCJf61YnziHvCgAWPR7A3zt69/EZz/3BXztmw9iYXEFjz/1PF45dR6Zd+hMzqMzNYfO1Czak9NI220EmyDAwqVN8Y9kLZI0RbPVRqPREEfnqPWYR9pGSeybWj1cneMaAEXhkTRSePWnVBggJA6bPkeeAANfIFgLB4sWPDrFEq6Y2sKP3XkJ3jSxholiGabYxuRkB25iDs+fXkJmWvBI9X00AAQE4+P76Spdmrb6Z8lBNayQAY9mb/Rc3SQCCZDYAnffeQcmWw62kM5jPNkYHQTVnCDHQYwVB1EoiuhwV8WZ2mBdTpVBSJGLxZJz0v5ji3HOwReF+kmKq3WJryWrvsmiw2+EUK6AFqlnsW5pGNSSKQrBPk5RG7GW0UKq4lKi76ZIiFYncVCmU7GMptGWopWUj1A58S4HWjqgj/eJGRFJyvSpSCUX19jK8t+NSqCRutgpQA0lbwySCk2PllFQKzRABoTyWSPS+ONZZTy6XZ6dOy8Yas9EqxYk8bpjGcp3fCjXMlNmTo/V+xfQRKDylfRqDN83MtVOG1YteTvTGeOO55dZkq1VWY2IWiX68qHcEdtY7cj67vGM5HAozbIvQJ7LWVYTlTa30Gy10e500Gw2kTpZyXR7e6s2/a0nQq81aLRbmJyexvTMLNrtOP1tE9mgj3azibnvkKi0I39D1GO8WOxVqVYlHO/HGOqCS+xBRDEGQ/di+dlAxGQjx8qVhuus/F5WS+01md5v5fEGMAi1a8b0y3mR4X21+P6IQiUiVflH6UNJRSYrz8Ro4Vbk4oOv/jwToadqg8aKe4G4TcqzurcL71H4akW/oEIRjDx3ob8N3lfxxoKo/USUT8ThINs3egOEEDDR4nS4cVx60OLT38qw3Zcynpsy+IUfa2KiLWVIyPcyFJUIeQPzL3/t4/j//MrvDW+Mv11Dve0AlG/vLZx1Ms2tFJPE1D2uRxIjqjp6Y1aeqSH9Eu14lB02gzRN9bpynEscfNDvIeDs2XNoNloYDAYwBjh+7FjZ2ZKpdFamA13k4tWgMXbkLLLgMDW3D5/7/BewtLiA/voFvP/OW/FDd9+FQ/NTaNiAxAQ899yz+PVf/0+44a03o9mdxg033Y4nn34eH//4J/Ded9+Fq6+6AsEPcPmheaSmwNRkB4N+DydefglnT59Cs5FiamoSR44ew5nTZ/HKyy9jZqKDt7zlzWg0EjhdwasaAIYhQUlTXVVTbVvQAWnwAYM8E8FA38qGICsfFV46iEUOPPrI4/i9//oxfONbD+PEmXN44pnn8fKpBWxsF2h2ZzA9fwi22dWpbh2YRhPButIJN4yFSxpotduyTTusMk1PBsX1ZMZOc+ygG90Wp+FFUQk1IWmAgDwB8sSi17BIDs2je2QOpit+klzmMZlv445LJ/CnbzuKw+k5dIpzyAOwnlnkNkV79hBePreGC5sFctdFQAPBiKAjCZR0V2msJVp3yxFVfkrJRgWWHajlmHUWDjned9ftmGk3YL2sLia1Gv/F8PX1q0xFMnAuOsiurj9UrvXP+ubaGBFbnHOyopk18IUIi3JOlVGZ/iSDemMMCi8Ot6tSGf5QOg/XOKR9iaAEg9IvUXVKlcJ6fM5Vq9fF6X3R6snUBy2qDsTVzUZxTqZtSVwi+ogoo2i7hP4balYRpfJQVny0yolHaxRlNmSb1YEtUD4qq2toNLuiwnlMQ3l6OeUttisMpWGUelkYFXjklPjEiMJcrb2Wp+we7xCahnrcZZsPsW40Lv37ajFX2dIjQ1X/ZZvc7b5SYtlUh5QpHGLHllFRychdbaJrtRh2ZcwBGl8l4yoFSkul6FOp2Wqj0+mg1WwiKUWlbRWVLoioFMR6sNESUWlmZg6dTgd5lmNrawuDQQ+tVgNzM98pUelVqJcfzM7yUMrD4nNWz6nqNbbSStY3xpSfRUyJnyXoQdWzRyIs98U4ZLOKP3Ff+RwfDvG8HYweaCB3QoyrFurWT3+4oAnWZ6ox8nLBqs9DhIAiL+R3HvKskj6a/MbHmgghiH9JfbkRrY7KZ+rQSwx9cRFfRsUCUUtjXxOaEG/7qpSAMd9H2epnFJZ2YaJtcG454HH1rfRn3t7A972NUwbJ64P6Lw8h5A3Eb3zs/p2CEkb7yfIldvecS5C4FGnaUDEh1eXQrcpG9e6YnBsnwV0MiV9tp32Asw7SZbNIm22krQ5s2oRrdtGamEbSnoRtdmEbHTz74is4s3ABDzz0CB546GHkWQ7vg/iV0OleF6N6wyadMouAdquBr3/tK0gs8KMf/hD+9s/9DO687SYg20TTBTz71OP46tcewJVX3wyfdPGv/u9fwbn1dWxkfbzvfe/D9sYGtlZX8M7bbsbdd92BZsMiy/pYW1vFtx99FIO8wMHDR3HFFVej3xvgyccegw0Frr3qSlxx2WUixAS1bnFWOq+htFm/KEYtMbz3pU+UaCIviDDoC4+iKHDu3CI++9nP47Of+QJOnz6PF0+dwUOPPomV9T5sOoXO5AFMzBxCa3IeE7MHkHQmYdttmLSBYB1yY1HAImm20Gh3YJMmjEsBk8AY8asVO/z18cTQ59o2G6p9IVolNRJsmQK9psV6CnSOH8T89Vei+6bjMIdmMXn5UcxecQyDpkPSspifnsDqwgIGvQEym2KtMYvnel18/WQfD72wgJl9BwGIc+/CGnhjEOCAkFRzYUz8Z1gM25VXrZravCi9q4x28gN0+hm0QdasU+SNsI5WICJNGd8YxJ+FWBiZ6EQ6hNJxdmnhE9tDLXNG06GjBoQQdKqcB+qWKHV0o6ayWnEMIoQl6ierHHGNYPTNefC7DXqHr1rdrkG/DYeiKGCMiJnWSBBruTpVnDJ4CtWS4/XLlZ+rlEmzkHYRy8kHGahBBRe5TWsFswtyrK7upp+B2OxEGC8HcGXEF4lQD/ValpIMtQCB1IdEp/VTRnfxOAG5IYO2zfJZEmS7H5pqG+Mars+dA2YJZVlWB8L7AigtLvS410iVnVfL03hKbbnOHqMq63Hkc51ovGuw1/hHD67k7Vd7UsXqroc/FKYWiwko1Tjjq88AgKCiff2K8bvXIO0URtuKrUQVY9VC0Vr5PYyfVVyRxWalncS/emoZX71W47dxpTVuG0bOKYNe77UEEfVGghGrqNEQbwu5b+XYxDm9t3MURYbC5/AIMC5OATfl96AvZwL0r967WZ6j3+9ja2sTy8vLWF1dLcUkEcLklnaJk5cF+uzIslyPE8GsXBxF+2lliC/8dpbUaHHi/PomFtc2RzcTAO98cyUivfN6Tnsjrx9oqUTIG5AHHnsef/N/+jejmwGg9oY1/hWLoSSR4PQtaBEgQlI5lUI6LrH/P9qd2NmtGKbq91U+O7yXQad1DkbFEuk0ytQd7wt473HixMtotRq4sHgezUaKI0cOA6WvEpneszvaeQVgQoAzAVkRkLa6ePzJpzA50cV1b7oc+aAny7LbBF/8+rfwu5+4B6+cWsQHf+CH8egTT+Nr3/gWNra28K0HvoHrrrkcd779VrSdQRo8VpYu4My5Baysb+LI8cswN78PjWYDZ8+cwdrKMi45fgxHDh3CRKeNvBjAWundWQN4XVq+Xh915C1t7buR3qTR1duSNJHl6XWQJoNui7ML5/DZz3wO93zuXjzx+FN48cWX8NjjT+L86hqStI3u1DwmpvdhcuYAGu1JJM0OTNJA0mwAzooQYx2StIF2ZxIuacJYpzKiVTFJBEeoDxVJb61NxJegIXay434dZCPAG4MeChTNBJOH92HflZcgnZtEzwbkPqBpHLbX1pFYg/mDs1heXcSZUy/j/KlXcGiqi+lOC+d9ByeLKTx6NsfjJzbx4sImMttB7lrwas0jq+gkCIjTCMoiHW49ZRpr1A4YPwAO8F4shBJT4O673o7pdgLnZfpbUEsuGVxFBUCEHxl4o7yi1K9cMF6rfsXS0qiWjhB92AQPpz63kkT+2vq9a0UgEdFBLIWKIi/PKQettYGbfJV706hlnVgqyXPC1yyf6imNWfJFIX7AdJvEVR1j1Dwh5jVaHTmnTt9HiGkVh/1y1bhUPcoyq8otQPJV5aFSz0ws/1qKJBlaZjWxqspZ7fuY+hlLrSyBaJUmA2V5FNbKbZfIyu1D+aw+y7O5GjjuHmc9otqOgOFnTf0cyeyOfA7V5ejOsdTiiGVS/bMrsU7iNcqUj+RrRyzjLJWCChIjh44UxbjNOzeUBxp11F1Nf9vY3EKzWVkqyeqN0VJpGctLS+jXLJWa7TamdPpbp62WSpubyLK+OuoWS6XOLpZKCGOshUfa3Sg7764Rxp1c31b7bEqn3VJfRgWTan91bH0FMxFkdGGPIcGo3hZjPuLzMrad6liZXqcXLhn9vjvltf/AYWcc1kTxbDjI9YZDef+q2O8LaSsXlpexuLiIZquFRqOBUKs3sUaSlwy9/gCbm5tYXV3D5uYmer0++v0+0jRBs9lCnud63bgaqFP/jMCFCxdw4cIFDAYDebGYJEDthcewbqrtbUfYuW+910e3kdJ59wjH91t86psZprsG/+BHW6O7CfmehaISIW9AfvYX/iUWV9aqDTqADUC5WpuIRfI2qt1uq2BQm6NvnNggBQ+EQl6W6VS4aMAuXYcAo2+0dzLcwTPa35CVquQNjXSmrDgBt2IRFYw4lhQhwojFzZnTmJyYwPrGGlqtFvbt3yeDM+2VybBaX9tBOnhygXqXJyAUObIiYHZuHu9617uwf34eX/v61wCXotmdxgApvvXoU7BJivPnziKxBn/1Z34a7WaKl154Ft/3gffig++7C4nx2FpfxdmTp/DU009jYmoKx45fgqnJKSwunseZM6dw5PBBHD92FJ1OG9YY+FDITLHSGqAaCEakc17/XnWM4wDUOYdOp4vZ2VnM79uHLPcYDAbwPmB5eQWPPPooPvvZz+OJJ57BmbOLePK5F3HyzHkk7Uk0J2aRtCbQmZpHszMF1+zA2wRpqwO4BHAOHgY2aaDZ6iBttGCMg1Xn6lmWAzoFEdoZdqWoJEP4ykxJ6jBEfxq1PHgLZNZg0DBIpto4eMlRzB6Yx0a/hzMXFtFpd9DOCqyfPI3ll07Bbm9j/1QDc/unsLR4Htn6Km698jg6LseJrIHTeRsnFzfgtwZiDZU0sW1SBBhEOzvAwceOPABTd/BkxFrHBLG8Qq31Dvepdw7UAqLPIgOLHHffeYdMfytynVaggkY1BB+6RiyTeKXoK0i69BWxXRhoG4rOt9VXmFV/SkmSlNPKvLY166rBRH2UkKhPpaHrlf9Uq7VFESnooDDoPW/MsEgzZOkSLbTqoqMeI1NXK99fMU1xWlt8wx4p60J9OlkV1mxtakd57NB5OjhSoUXSXzVGKXt9TgwVcPUxDg7ru6SI9MShWqowmpaqrKpV/VDeLfGaw/ELVdy15lGeL/Fr2q1M0dNHfTkgjAzFWysf3TDyXagEuRERI164HAjvQi3NiGWhf8t2UtbBuFhGhU7ZFjHlP/JhRwxGYoif5a4ac9wI9Xjl6N2CxqnNN8tzrK5uVKKSTn9r6vQ3r6LS8oqs/iaiklSYiEozmJmZRbvVRpEX2NrcxKAvotLc7DT2zc+g027COXXYXKV2SMCJ7JZTWU2z/Fb7dyeV/yO9koqP5bbyeVq/WoxNt6hYEolC9+hzIn6TNhXPlX/KW7M8N37Xk5QynTFtY0ohHjMUtB2PBnnJNUYsGg3lf9U1dz02/jwCch9AfNYBRqZQrm7g/OISLiytYJBlyHKPRrOlq+6K7z0YwHtpd/1+hvPnpc1l+pLKq/Puza1teO8xMTEJAwvnEhhjURQF8jxHludYurCEXq+P7V4Pq6vr6Pf6ACwaaaolFuszvlSsvkcxrL61wmBrkGHfZGd0xxueG69weP/NKfZP15+thHxvQ1GJkDcY/+sv/zY+9aUHpcOinfcA1YaCAayDtQnStIEkbSBJUhSjjhmNgTdiXeBMjhAGsox4ERBMEwHy5kl8KeXa+R/ujFW9TYO43gogAxJx2Bs7Xppwa2S6nUlQIEHiHBrOoj/IUeQFvAdOnDyBiYkuzi8uotvt4ujRo6XVhtHpMEVt0BbTiBBgpABgbAoDwJkAi4ClpSX8T//zL+HBx57GNx95Ggvr20jbU9hcOod/+Ld/Bvd86vdx2ZH9eNuN1+PWt74Flx46iKXzC3jl5Zdw9swZNDptXHrZ5ZidncULzz6DjfUVdFoprrriUkx0WqXZuTHqekg7m9CxeNCBe6HWF3EqgBai/NUBrw8BnW4Hs7NzmJyeQqPZAALQaHXQ72e453Ofx6c++Rk8+OC38cqJ03j08Wdw9sI6eqGBdHo/XGcW7cl96EzOIW1PwKQNwCWwjQYKiJCYpG00W12kaQvWJCogAiH4ctl6g6ANSqY1uCBLRItVgBGH27Za6S02LecSWJ2S1ksMwmwHE5cfRvfADFbWl3HhzFm0XYqJziT6iyvYev4lYGkR3R7QWd/AxNoZXHHJLEzIYbZWcMelc5hseTyzbXE+T+BXTuEv3X4dbrr0ILb6fby8OoAzDhYZgs+QJi1kMIDx4h0syJS4YAoEW8hgIKQ6i0Pvm7IlCXGgUkcMzzyCCWgYj7vverv6VMohEy7jucOD8NgOYqcckEFHFASMUTGjNrPORAf36vBYhCL1p1U7P8T4pQoQQjU9Kk4rCRqxiCYq/pj4ZlraZbSMKqePIQoWWjjaNq06BBfhWZtvjfK75jeog34fRaKYVmNKYVWak5aXOrEtyypuLMuxdkX9GJOJeJ7GJSJXFPpqw/FaIuPHEM/Xb1LGMQ8qWdTSUieWg6Q5prv6W6a7nvYamtqy8g20UFA/T/4GtUoL0OnFow1Xifm3RnxTieWCWtCNYOOKjjvEo5G87EIUTCSfUh+S/Fqe63U6gtH8lKJWVMxiCmpxVu2iGrzL9fWcoUtUX8q2PIIM/GtlHEPN0knvOGlDwWMwyLGyto4LSytY29hEo9VCu9tFs9WEcyL0bve2sby6ggsXljDo98sMNFstTE3PYHZ2Fo1GE6EosLmxjsGgj067hfnZGczPTqPdaiBRUQkY9lE3ktLh/NTacJBXN/Hm1YN3loMx8ssNVEIISqElXif+9o9eEbLVSPkMl1glRAy3Kz0rxq9/5QWT/LWIN3aUC0Wsj00qpkvfeUgwqByFA0j0eTMU9JeuHlzpOFvii0Gm3mqvppzS5vS5pS+Fak1cc1XWSpkO9Q9nIO1qeWUV5xeXsbK+jTxYFBBrbmtT9LcHmJ2ZB0KAtUAo5J5dWl7D+YVlFB4IsGoVaxGsUz9LFv1+hrW1DXS7E2WZhuBhncHG5iaWV1bkd8ElKAqZkru5sY1er4cksWg0Uhgr5SxtRoOKSolL4p4deB+Q5QFTHfpXqrN/2lJQIq872GIJeQPxyplF/NuPfgrQznLsMBvoW31rkaYp0jTVN/0X6VQbD+eAIhgY04KxTRTeqEVHBoscSSiQeA+E0msCgpEAaC9DzbPLTkdplBCvq4O6IIOYJE1ktZxGE67RQndyGu3JKSSNFhqNDh769mM4c+Yc7r/vS3jgWw8hz8ThoTMAgkdadriH86VdTyDIKl0IAfAel192Cf75//bP0LDAm664FCk8nnjkQczOTGF2bg5//x/8fRw5egSAhzXA4088hrNnzmAwGGDf/v04fvw4zp9fwKOPPIKp6Slce82bcOjgAfGREMrcSRnUBuZ1BlkmKTQWRSHT/iJeV3trNBrYt28f9u/fj1a7jSRxsvIXAhrW4vjhwziwbz9OnjqL5148hUefegnbRQrXnkZ3eh+mZ/ZhYnIGnclJpM02krSlU9oSWX3NJeh0umi1WrCu5pgYKDvDw9sqvE6JC3AIOrXB+QBbZLA+hzGANwlyk8IGh9xZdI4exNy1VwFTE9goCjQ6XRw9dhyNwmD16ZfQO3ka+WAT1ls0rEWzt4qbpj0+eCjFrXMWh5oFbBqwigTn+w5LmzkmGwkONrdwSWsFc/0XcCg/hZliAS2/jlYSUAz6aIRtpKEPFwqxsIvd/RDE267Ia8PuQUaoWvSrUSuweK9FywzdLAP72pAjxPPk/vWFWFDVBZUQhUjvxZdSvAe9R17k8MEjeA0xjwawLk5fk9THwXpAEIf3kDQayIDOl9MqZbqbqfs6qYU4mivva72mXEPSXBcIvDr6DnHKToiOtyWh9WdSfbW3WObxMvKPpLc8J4qYKlpFC6OgztShYm4ZUW3kN+5RGNOnJVZuFwsw/VJLy6sTj3v1Y722F2PlnqrKpR7HcHxGV8O7GEatu5z63xq2RKrwWj9RKJTrv3q6I9H6JLbDIVHwtVJebtx14/2wO+NEizoXS49BNX4uwy7bynP0gN1j3Y3qDPlkpDbL+0fSGl/PwMjvpUX0SVSJaeMC9K81RheI0AD5Pi5IfcVpaWrZXJu6Vt++W7mMbouVtVu/A6iOGS5XKQ+YKKzX0jU0dS4qS/Wg7aA8JpZuFXZsKDfW0gDE0t+FAKBaXW3o3pQbCAiAgUVRBBSFirr6XNrY2MTW1pa0nyCrZcZFELIsQ6/XKwVjHwL6/T5Wlle0bGrodxHEpG58XuDC+fNl4Vp9ibCxsSGryFqdIK7Tposix8bmBra3e2rdKmUt06dFBAPE51Kh1lGjbc5o+S9vbmGgq9cRQl6/jO8pEEL+RPKvfv3j5cDIAyh8QBHktV3aSNFsNZGmsnJXHODu6JCUFPA+A0KAgUOexbeLBYzJYZDDBA8TxGdM0ElGYv8TQ22gWTrsFOp9SmNEevFqddFsNpE0WnCNNtJWF52JGbS7UwguhTcJvvaNB3Dq9Dl85jP34JvfehAhAEVeyEC1yBGKXPz41Aa31eV0YO89GqkDigxXX3Epfu5n/jLu/ewnkW+t4p/8v/57/KWf+Ah8nqORJEicxerKKp579hlsb23iTW+6Cje+5c3weY7Tp06i4RxuvfkmXH3lFfJ2EzLNLlrzSDntPtAQR9vS+YsOMq0VP1NpmmJudg4HDh7E9PS0bhexadDvwxiDZmKBIseH/vSH8NM/89ewcGEVrYk5TO47gomZg+hO70Nnah7tiWmYpIlgE+Qe8LBImk1MTk2j1e6ImASpnLo/GWH37nQwBsHKW1ITDGwwcDBIYBCKQoURERtz6zFz/BCaB+ew7nMYbzGbTiDpB5x56SQWTp5GY1BgJhjM+hz7BsuY3XwZl7izuGl+G+mZJzGxtYj9bQtrPNZ9E0t5C+c2PILrIgsFGmENP3jzEfzIdW2899Am7r7CYXpwCm2/ARu8tFUT/a0UKotJZ19zpCOgnYwbV4tIU9tYftwZRxyYyz0oVjpxgFVFHa1T9J7TQYTGgKADtqGBupEpbkmSlAJQrM+gtSerAun9FudOaPwmTqnS50HQezGoVY9Xkcp7D68iUAxAQJbJCoS+kEGHnCfxlH9VqBJBbHSJ7HpZSR7LtOoy11BhpXxkBc1XvAY0S7rb60pIeqA8H7w4OQ86BU+eb6NIOQXIAC2oQ+14DegAs/4Mq7JQz8cYoub2KodBrwGjogxEXA56/miI5fBaCJApluJ/LbbJncTncvksMHKXvFaiuBUFD6mf8dcaR/TXFUVTyX9V/3Ha424/YbEt6zdAj5VsxEoYsXKphXEYjXco7Hg2vvY8QtuOlKzey6jSKdeT4+LnYSsZFQ6MTEnePYgTZgkiBjsNVh3fjwZrrDhu1r9jgwpVMW3DYXzZDmde/8Qbvr4RgC3tnKM1URTGJB8ufi5FphELJCNiSKwlM5oYDeP+i5Vafddt2nSGn/nyGxBkR9xUhfhMC+J7y8uaJVV6YLBvfl7aeLzftVwlMmBrc0vvo4A0SXDhwhIK9TsJbUPxlVr5r5FrBARsbW9jfX1D4lM3BP1ev2x70DKNdZumKWZmpkX4CkFWCtVFQGKiRJCKfi13CQY4t0qn3YS83qGoRMgbhMXldfznT325tBQKAKx1SNMG0kYTSZICNf8jVgeR0vGPHYAa3iNxBs6IFZAzAY3EwKKACWLNISuPRJ8xEqLFki/7VqXR9A7itthJkU6qWMk0mi0kjQ5s2kbS7CJtT6LVnUaBBM3OFL7xwLexcGEZn7vnXjz66KNipTEYwPsCTn3NjOu/SgcsAKEAQoGGMzDFALffciP+3s//HK6+9DBaJsdkO0VvewurK8t48vHH8czTTyJJHG66+a3YWF/DI99+GPv3z+Pyyy7Fm66+Es1Ggrzfg89zNb3XXJcrT+l1xyCDNhk0SgdOvk9NT+HY0aOYnJpEmiYwRnzgWM2fSxJZXr3IdZJVwA//6R/Gf/rNj6LZ6cClTbQmptCemEZwDYSkBZu0YJIGrK7m1up0kTSasNo+ooiQOPXdMMSODYI6opbOKWCDgQ0W1iTij8kYwOfw+TYy9DCwA2zn21JPaz2ce/JFrJ9YQNjsIwkGaTBI+hkm+9v4oesO4i/ccRgfvmkW1+4PaNscKwvnMDs5AWcMzm8ZrPoGFvvAM2e38M2Xl7GUGTTRx/uvnMJfunU//sxbJvHhd1yG/e0cARaFSVGYBIUNCKaQlhsMEHRVQlOXP3chlP/Utg1/j19D7XMchGZ5Jp39ocFUbXBlIBYkei8jCn06ePDavuNb4iigBBWgQvAi8GidhChAxc/Rr0+IwlJMbExMZfESUE27s2OmjiAAaZqiKHLx66Rv3qv49a865PWFDE5iuqEDP186mq/aWRQhTEyjCqpBB3GxHKD5jJ9D+TyR9AW15DLqnLxK50ibHqpCjV/zXl4r1mX5Tzx69PzdkcNe/eCggp9B9LuyC7U6vJhwEwer8vniSQhazlFwHG3fr0bZxmI8sR5fI9ZKmVu1NiuKaOEm+51Oy7x4sqL4U6uqoeXnw+5hz4QdBRovsWN77dAqXcPfRXCQdNqaJVJ178k+U2vrFw9ynNMQxQNXExJ2BBP/1qybylDFrY+q4RAzOs5UCfJxSJipNgNSc6Vllg0imBhEEan6a+sCX62cYiLkY237GEprr3oo46lXkqR5NN1lFevmoJbiEvT9kgpJMBbWyWqdufcQv3sB7U4bjUajdt/Unr/GoN/vwXt5ebbd66GvL5XiRUfzJrskDc7JVObVlRXZByDPcxS6OqmROdyaDzl+dmZGnut5DqOCPGDK1WZLh95qLbqj/mthbXsbWf6qv6qEkO9hKCoR8gbhNz5+v3YIpAfUbLbQ1FVnquG+dNKLokDhC+kM2Er0qXeUrLFAUcCGHH6whq2VszDZJpKQwQYRk3LjkNkEXq2hgzEIQYQlIH6OscYOy1DvDAGAdWrSXXhZHjyIf5/WxDQanUmYtI1mdxppewqu0UW/sMiCwzcffAQXltfx+c/fi8ceexxpKh2yPMtgax2sakqe+l5yBs5ZJNYg+Aw25EDRw+0334D33/l2JL6PF559Cg8//BDOnzuLqYkubr/tVhw/dhSPfvthbG1t4IYb3oJ9c7NwBjChgIFHmlhYE5A4K1PsYnma2A2tyldTpvuls+wLjxDEqebBgwcxMzMLYwycmqaHoB1BtQbxRaEd00KdYQd4n+H222/C//lv/gW8z2CteL1C0gCSJrxLkDTbaLa7SBotBOPU+bp24bUTLeN3GYy9GtHWw4YAq9PKQnAokMIkLTSSBGkYIPSXcctN12CwuYSGHwBra7jw7Atwa1to9wOauYHJpeNtYbC/08KNBwLuONDDW+YGSH0fG2jhxNIWOlOzcM7hQtHABhwWtwu8tNXCbz+6jF/7yot4ZqEHt72B/YPTmNl8Hkebq3D5BRgEeCTIjUNhUBOVLBAcvDGVFdOrcPHBrHbq9c6LBLXuSZJUhRE5QD7VrGZCNTABqh57bEMy2Layqo9aGhgjFScDreh7KZ6uS9hreiqxRi9Wv19q58jWKOJU6R+yVDJAkef6FjtOmZN4jLWlMBLzY6wISNDt0KlpxoilXt1xdzlQiuUgl4sp1DzG0qsCUIlPcqTEJdZh6itKvOaPzXskngO1tKp2xIKsHx2/jsayCyH+Uz++lgsdz4rlQq0sdqBX1bqonjP1uONftYTQ6YHDKa1dWw4tr1+Vf/2YkeNHCKFucaEWXzvOu9j5atEXV8uzlVUa1LJVYh5PHNCOResvpm3cf7th6iKGGX5GSrTSMAxUSwGG86l/YhMqT9dj43lyTPRrpFY/qAlLuk9Cld/RMCS8RIufmo8gY2Ql0p2hKgv5PJzmmJayXe484LVRFkvVDur3bRSW5HO0VpKpe5Ulk6anlqbRbWVFjRaQPidHwzgk1otTPrP1c9DHWVBx6dy58+j3B5KbYFAUXtt4wNEjhwEfkCauFFPjs9d76R/5EJBnGbz3cC4B6nUwQiyLPMvgnEM2GGiWLQaDgb7Ekg5cgN7rBkgSh8mpCbVWq1tPW6yvix8m7z1yfTlisFM/HA3LG1ujySOEvI6gqETIG4RP3P8AAgxcmqDZasE6cdQoIfo8qpnAa4cRQd8kq8NIY8SawMCKtYnPcMtbrsLf+bmfwp233YhscxO+CBgUBgPjkDkHo3EC0vOzZcdOOjVA1JJi71FVqHj9shOmaQLgg0ERDNJmG2m7C5O20OxOoTu9D0lrAnAtFCHBl776LVxYXsdnPnMPHnr42ygKict7L6KL5isEYFCzDjEGCEGsrlppAutzuJDDZ9voNiyMz3D40AFcedUV2LdvHk89+QQeefghHD50EFdfdSXS1AGQaW3WAIk6sDYICEUB1N5UlvkNBkVeoMgLGWirWXkcfHU6HRw9chSHDh5Eq9kuDf6j/wVxyRSHEFatgBy8sSiMQYEczmQwxTbeeeub8fHf+Y+YnWkCYQBYjyzkSNIGmu0OrEtKi7Y4babqjNc7qPXB0/gQu+EGBawXK7YCBt41kBVAkfXRsQP8pR++G3/69ltw+/GjWHvmKUzkfRzaP43MD0R8LDyaJkFqUthGG71GC71uC8swGHQOYjU5hq+9tIVz2xa2PYmecVi0KdaLgAwJwtQRnE6O4vH+YfzmN5fwlZc9Tq6JyLJ5/iX41ReRrD2PdPsc0ryPIgsIwcpKh8bAG12pLoi11Thim67yLrmPZRb0La+0uWoKmdOpaHKvyDAx+gUZGnTUBzXlAF6vrZtCzXokTcXxvF5cB0iVCCSbRTzWmw0BMvUrBLnv4+gvXk3vTBms1JzeQ+MdEhY00cYY8ZWklkwxTTLoENEpxhlq09Xi/WitBYKuYlcrW7mqlkLteWL0GnIva9nq9spyASJq6LMp5iU+byQv1XeJN8ZU1U/5tzbIK7NfnieCnjEyzVA+xwiH6zEeJ9eNf/WcaJFUZTgmSjbFeDWVVjIplosqzhsYebSqI24pp9rl499yo/yNz0r5Wx1YL5+gcY2GWPZBxU45T0NNSpK0apvRvA4/bypMFDOM5Kd8MmmZyPaaWDBCLNaSMc+uWK/jwvCUsSrUL2tU/ZF0ShkMpaaetiB+/GL9xwKKbaEUcdRCqywwjV8sc+L9KeeJYDQqBqG0RhKLJMDaaluSOCRuTLAOibVlcKY2DW7XKXIxDepvqVau8T6qM7Q/3s+x3EbqMcTptuqTayjEbdo+Y1XXj/EqVpdx1OLxwUvYLf4QUOgKavWQ+2L4e1EgLwp5Uacv6+rxihGyPOM3Nzbx7HPPYWl5BSdOnUbhg0yBsxZFEOG41Wqi222j1+shUwuhNEngrEW/P8BgMICzDkmawupUuXhThvpNjth0VMzVfZOTk2V7297eVmtWK9ZTOuU+BI+DB/dLW7eVNaxzCdbW1nH69BksXVjGwsJ5AAZFkcNEpwdm97DR6w2njxDyuoKiEiFvAF45s4hnT5wV02ldIlxe7saOXdXBq/rZIx2+et8XImAURYED++Zw3bVX4pGHv4XbbrkJhw8eEF9F2inLCllZy4QCiQWMdt7GdSpr2oqEsiNY+wzIO15rxScUDJJGC0mzA9toI21PoD0xi7Q9AaQt2EYbX/jiV3Duwgo+c899eOzxp2FsIgNIIxZJMkiwaDRbKvsMp60oMiAUCEUGZwL6W5u49JJj2Dc/h2efeRpnTp/Egf37cMftt+HwwYPIBwOkzpYd9uGRS72M45hCRiDBAC6RDmG8unMOzWYL+/cfwKHDh5A2UmRZtrODeBEKY1FYiMiFHAn6SNHHFcf245f+0f+AS4/MY6JlMdVtoKHXrgYDw+2invbXijVG2oRam1hnYRMLYwJSB9h8G3e+7QZceXgeg6Ul3HzpFSjOXcD6iZPothqYmp9G3+TI4THIMuQhoAeLU1s5fuUbz+NXH1/Frz/Tx399KccD5wfIp+bQmD+ArXQS5/sem7mBS9t42623ozO9D2t+Agt+P+55eg1ns0lsbfVxvOvxAzfM4x2XJ9hvVtDob6CBBL4wyH1AYTwKmwEmF4urXS31dw6UrBH/NIW+5TUqsBjdbkaXvS/rNgoJF0MGqfEYq86yZUwqg6YQKjEpHjdUhyowADqI08F+TOtoe5A302LFI1MwZFsUD2DEqk7EC33DHQKcS8pBFXTgkugUTRMFTBUdgqalKIpSeAMAZ2XVyXr7L8unlqnyozE7Wm35KUAzX9+gg/nhIytC/Gd4X7n5YhiMqc+aaKKDX6vTV+NfEcVkUO29F8FvKI4KOaYqz0LjkTYng8ehZ69e87VSPzaWQumba5dnkmQ7imhxSvV4QvRlFdPurNw35dWqEP+NZV+TSceEP3okO/EXY3yQ4+TGkBKX9JjYNGvf600xtpHdylTYuc/oFDZrRWRyUQAaFXtUvC63xelqVoWr0f90VbuhH+h4zXoCdiG2uDhFzQxZUQ1bFMnxO0WkIUb6BDqBHB4qFunnoJ9DkIeaHF+J36OtJJTHjlxjjKh0sfPLELcZdQdQHmdgrJNnZfDo9fs4u3AexjrYJEGvN8D584vIc3nxZa1OvQ7AzMwMnBMB0EfrJC9WzOJXCWg1m2g2WyIkK2XZ6nM6IKq6stojAjA1NaWbArIsLwX5KLhBhS2XOAAyHdk6i6IosLm5hbNnzsEasVra2NjE4vnz8hIliqpar6PBGoO8KJDRYTchr1soKhHyBuArDz0N50RIqcyZhzs40hnSDUD9gw4sZVAaQjTFFiuIpZUVPPHE0zhy7DgCgM2tDVh4pMajaQokoQ8UA/i8D5/1YOHhnK5oUl5gpFM2FHSwOZreEOSVq7GAc0hb4rQ7aXXRmphCZ2oWaWcSwTawPQj4yjcexNLqBj7zuS/gmedeQJbLm78QqgF1UfihIUEcCcRBmXw2GGQDtFtNWANMT03iTW+6Ggf270PiLHyRIy6OlmcD7eoKQ8Vbdpqlqyfbq4EjjJTv/n37cezYMcxMVw4xTSkc7OycjUOqW8rRxCloRR9JGODm66/Gv/rf/xccnZ9AEwOZrqep8kWBPJe3jNhRL68dqx1KD3HYbaxBagukoYek2MQPvO+duO3G6+H7ffS2Brjnk5/HhGujv7yBMydPYmp2EpP7ppFZj8x49EKBnjU4eN0NaNx4N84evR0P2OP46uYEzjWm4A4dwXZ3Gi/1EqxmDlmRYn1lE1srK3jn7W+DS5voJxM42WviyTPrABLsS4FbL5vGnW85hv0dg7aTZZnLqYUI8KZACFIe40t6PEEtbZyVJaJFOHEiwmi7koF2NRCRN+dayqLN7LymgZyjnwMq3yko7xvZX+Q5nK4Ih3hdPT4OImI+TRRzdMn4EALyotC0yUCi8IUcryKJV6fOUDErbaQiHiEOnuWYKEiJWCLWLzAyxTWoxVaR56WPDxstdrTdB4iQZdSaK6bP6HWDPq+GiFYv8djyrou7RXTTA2TKbxArnlgetahqjX/4Lijjr00ZjtEC+gCDOpQuT1cH2npwvP+tOqC2Ov0POkiVAZyU3Ti8ikayQqS0u+gXBbrPqMUQ6mUb49OB4ygickWrsarejTHIdSAoQuMwsU3AyEsI+SXZ/TrS9iS91srnqo0OB6nzqn2FoNeKhR/Dd5FqmtqY+xfxLhXrRylP2T6a7HHnakHu2GTLFdxqfoWi0FQTkcSZ9c7tlexT/TeOep5q1Tw+1AUEHXyYmgXSaEDtd2jo+vqsiv95DdV/KiaV4pJurwtBNZ9rOxrVOOFol+CDWkSNhtHzVfCRUO0r9Nit7R5efuUVFCqqhGDgXILVtXX0B5mKqnIP5HmOZrNRrsIaLZ4CpFw2Njek1IwRJ9rq+ymWXb3OJL9SvtYYNNIUnU4HAJANMmSDTKOqzvchYHZ2Vu9JjyzLVMS2IoIVBVBO1Q/o9Xo4ffo0vJeXJ6Y2dbIeYr1v9PoxdYSQ1xk7ewCEkD9xPPLcCcCIZU9eeJmmYesOtLX/HXsb0tcoiZ08aD9E3o7lGGQD5DnQmdyH5bU+/tNv/x5W19dhTY7QX4frryLtrcIPtmH8APA5AI+s3wPC8Oprr4X6cdJR1Lzo9L203UHa7sCkLbhmB63uNNL2BFyjg9xb3PfFr+D0wnl87OOfxPMvvIg0ERPxNE1F6IIfmScgZt/SpzNwiUOA/C2KAu1WE0cPHyqntvmgA28v69wlzsIaKdi6WCXDMVkNLQbtZiOEgCRxmJ2dw9EjR9CdmAC0A2qMWC6NG7xdjMpvR3TSrgMJeJi8j4MzXfyjf/h3ccOVx5EPenDGAMEjywdwOqVnmKGu6atiAIRgUFiH3DpkPkMxWMdMI8OHP/B2vPmq49jaWMf61gC//el7cWppAybpwpoGehvbOHHiBBqdJib3z6LvPPookCUWKwZ4OW9iYfIo+pe8Bfaqt2LfdTdi4opr8OR6jhcwg7W8if5WQAsNPPfkE9hYOou73nEbGq0mto1FzzYwGBgkIUHRH6DXD8hCgl4BFDag8H0YeNhgYIL4l4oDlb0idajCQSGDfimcakAuU39UyCitS1AOFOoEHRDIl1jOMriIxJoy1gxZrcQBj7wF12WfjVEhRdqZDwFOj3cq6CCIABQFp2g1ExDTEvMnFjYxxT4EsZLUwUbMS/zXRwHJqxCS51ImcVATxVa9fhSlDWR/COpMVuslXjcOiEK869SCJ2KMqD5SdronQNIXJFejT6ig5Sybh/eZaCkUo/CV4GXVAkvqLSLHSlRSJ1Yts6K4paNvLQOpr5HLlsR8GOiLA31uxO2ltZKV2gpBWrJ+2y1aQOtGzpFNMc1uZNpgdYqJNaQH1+pxF0JNxCst2KK4OkK5X68bP8eqKcP40y/Cjhh2Ca8deQZXtV59qoi+ZWI7kHv01TIQT6qQOLTkVfyDtscdjmw0LwEeMCJs12rt4mEkqosG9elnTEzY8LYqSDkZOUBDTObwczeMWifFKWkaPKrPse3H9h//jg0qQo0ePxpGRaJ6GDouVulo6wkytW1jYxNB+wiJE+fWIqADJ0+fQpblKh5Vfi7n5mfL6xsVYI0xyLJMnuUB6HS6UpKxAcS2EetO98lLCGBickL2qaPvKALHvokxQKfdRrfbgQ9ioSQvCQwWzp3HoD9AI23A6O+I0UVViqLQvpq8Axyqe90WQz+jpRIhr1f2NjIhhLwuee6VM7V575VD3IsSpKspnXzpgMSObgjSGYC1KEyCrz/4BD75uS/hzPkVuEaKZtPgA++9Az/9Ez+Cn/8rfxH/7U//FK6/9hoZnMOXmo12reRyu4+TtAs7dLh0fg3gQ4HCB8A5FD6g0Wyj0Wqrr6UOulPTaHUnEGyCAhYPPvQwFpeW8YV778VjTzyBvPDI8gwIQCNtDAs/qrIFBAyyXAQ5iH8IaOfLOguXOGTZAL4okDiLNE0Qgqy25X1l9j6cegAjQpOxDlNTUzhy5CjmZmfFYbFaFMSTQoBYIbxa/dWwCLDlQNMhIIH3Dlnu0UwSuGKAyw/tw//yP/5DXH/NNQheVqhrNRpVb7jMQa2HOkTZVd6xXTrqBsE4FMYhy/uYnWzgIx96P646PAUz2MD6+jp+95P34Nx6hs3QQJa0MfAJ5g4cBtIUL545iebsBOYPH0Cz1UBuCmw3Pda3lrG+fBpba+exub2F7b7HmbUcj13o46HVgM3WNPJBgWYhq/997evfwMb2Nu66+31oT09irVdgI0zi+dU2/uOXTuA/3fs8XtxoYs21kTWAYPowPoPLLWzRQkCC3Mh0uN2Jd44OgnSwa1Abkallhy9qFiOlSCMiorzdrZe4tPmIVdEpbgoI8HF6mQ7OrU5/cC4pBw/RtxF0hSxfm/omFkfq+8YYZHkuNRsCEpeUFjQyVIJkRoWFmAejllbxesHLEte+KMoVCZ2V6RbRQilaJMmzpSb8RJGsJnD5ohjy5STPKPVVhKECg9FWKbJvtOQpox75W4kURvMs3+tHVVSbQ7nfx7LQdi8Ckez2Wj6xrMpTTZR0FE1gFPhidrQ0y7wMp6n6HOshaHqASlCMglW0EAuoiZgj8VSfRQhyuiJeonUmR0QLMi2v8ox4voR4tFGBrV5HFfKsqaekKpcqrhhsnCZYm6IznI8YRr+PpqvO6Hnjto/b/xqo59nEAb621yi27IhZv73q5eRXBAGVVYyXKehimbO7b6AYfOm4frdQXes1JGgIaeESRHSQ503cVoUxH42JT9KSoM+E+PsU81BtU39wtfzJNhW1Q9BTR8ph1MJJ/yt9LA2F4WPq/5Vp0LrQRA6nD5KegwcPYnp6Wq1Yg0zrj30HH7C4uIgQrV11Klmn0xF/efqSwllXWi8PBgMEfZZ1Oh0UunruKGLBJs8qax263a5Oxwa2t7elRWnZSr1ZSafWSXxBsb21jbX1NXkOxDatx6RpisOHD6PZaMLCwNVW57Ol1ZpO1TQGWZGPJpMQ8jqBohIhbwDOLi6JM87YoS9/+MWPT4BHMB7BBBQmiENiXeI+BEQpCB4OUOecIQDWpsiLgEHWR6fTQII+vv89b8df/Qv/DW6+5lK0TQ8t28eU3cKfeu+t+Ds/+xewf7YNa2MnD3A+wHldsh0GBr4MMF4dnXpAfRJ4iNZjjBO/UPq2T/o9FgEWjc4kkvYkXHMCrjON1uQ8WhNzyEKKrYHBl7/+EJ59/iQ+/snP4bHHn5KyMEDhc3h4eQtnIOnwALxHYh0sRATwRZBOnE7fyfOi5h9BBKj4PQ644htLE72iQsaO1hokzmFqchIHD+zH/Nw+JC5Bocu/G/V1IAMDKSFrnEhFwegbTu0cx7fNGuLkAAMDEyyMHu+DlKOxFlnWgzU5EpuhnfTxC3/3J/B9d74ZadhEagEEC5c0gGD1rbcXN9vGw8a3jXFAg9qraSVAfEbABHH4WRg4JCgyj42NDRS+QJIk6Pf7WFtbg0ktbOKQZwPMz82g1Wlh7uB+dGemcWrhHJBadKYnYFKHUAAzmcVR20G6vIXNE2ex/MoCVs6vYXVpC9vrGfpbAMQIByFpIEmn8O2HH8fp02dwx7vfhxObTXz9bIELk1fhdDaPc34O27YLGAtbFHC2ISvgWYij8Sg4lIOeOFyKZaCCTvBl8EFW37NWOtHQ6Y0eajFijJSNFzHG6Io6Q6MryP0Sxd1R8UNbl/reqKw4tNGUYlEcpOWZOKX3Op0pijRWp6Yaa+GDCAhyYfULpYOOympFjo0DDaPDTevk/Lg9Wmn56CenJl4ZHTRCjxUBQwVVjS+EgMLrNKuan5AQgogvUcSqDRbjubEETXwrr80zbi+JzVbFFhOnntX2GaDcZuKxOk6Epl/+SnmKdZXsjOnLVRSzMrKWga7uj2USt5v47CjLUq2YtI5jOsoBtcYTIOkUqyZtL1DfKFoW8nzRa9byGVudPHM0Tis+T6y1yAtxEAwVquMLCym3WovVuohxxgOsCorxOuUZmrC6JVOZLh3g1v/KvVIdb9SCK9aBtA1pkwhyj8XnX3xqRWSv3M3xuRr3yDXHBG1lrxag1jSVGyLdGp8Jxso2rdeyY24gq5Ia+X2ql1cwsW6qVTZiu5enPlAAKAKQw8szP6AULKIT6HEhNqUYpP3Fv3p/BaBAQKHXK1D7blCGYAxCFInL34aq3MpM1YKUa03Iic6tNUS/bEWQPMS/9c/FSH484u+e9i7K8opP7rh9TD0HjNmm7eK1Bq1ymcoWnw8ihBe+wMGD+3Hw0H4pHy1nGOlzbfVybG1nyL2Up3GAsR4zM5OwRl4yyequEu9gUCB4acsz05OwtpA+gZWFJqpWWVnGtjtNpKmTFWKLAtlgUL54kHorYK3H5GQbCAUSY2B0KvfC+QU4q6vtlc9iYHqyi0uPH0G3nWpfIT7f5Zlta07e43+xnAghrz8oKhHyBmBtYxPazy6HwLF7CsTefRyGVYPZuGXIjLvstlr4YOCSBGliYH0PH7jrdtz65ithemt4+flncd8Xv4iHHn0M+eYq7PYK2tjGR/7sD2Bz4wICchmQBg8bAOutLNu+o0s+LFJEpEOqXXAdMBhjtWNo4Rpt2LQD15xA0ppE2plCe2oeSXMS3jTxyOPP4NzCMu67/0t45ZUT4u/FACHkqvnIG0YTdLWvkQdmOeDVt5DRisJYcQAe0xeidYTuF1NwGUx4X6DZSHHo0EEc2L9P/RlI2df/A+QtIbTTVXW8tA7DmDKrBemUy3WhPqLkLaOIQgiFCCYY4Mi0wd/52Z/Ae99xMxJkMEZEM+cSOKcOxH0B6Z5XLaX8rOVVogMdxG57CLDGYX2zj/u/+i1s9Dy8SXDpZZfh1lveiv72Cozvwxlgc3MLWREQjMPM7ByMNVjfWEcWCrhmAykM9gWLOy67EpO9AXpnz2NzYQXLp5ewdOI8ll84hbWT51FsDZAmKfJg4UwXyIEnHn0EaxsbeMf3/wgePruNR84P4CePoZdMonANWAOkIYhll0ngDSpRKRhtczqIrZWDVIeO8sr2CxXWxEoFIVrxmHIFIe/FfxNC9QbZ6oBZ2o2cXxWtlGo5gPaxjAFrLFySyDE6CBQH/WrJESD7VVAA5HqAiKTGGlmNzYj4E9MUQpDzApDE8xFFC01RFJYCyvYZ0xkgK9/5wouFElCqG9aKFUwkz/LynpEylGv5eAPo88iq5ZTcd7FUVGiKxxq9jqanrDBU08NiHHGgbiD5rTdlPQWoGUN5L1ZWUj6yomSAijgq7EURLAppTi1sTE3MkXqqRBzJn+Rb4pdn47A1jpZrCLGQ5dS4T8Ub6GBO7n+pn3iQkZ36tZYxVHUDSPyxDut/ffCl5ZW1Dih/K1TU1EvF9hzz6DUtMc3xOKk7rfMaRuOA/jWQ9JVtKNavkTq1xiJxiVrnSNqjpVj8rDnT+KUNV9QaSSynocKRcyWnF/lPf1flX8jvrN4vMV4j1V1+tzAw0bGzBhHl9bpxG6pnbWwCASqmqLBU/q3tf/UwbJkj9aVWTvqfR22KF4K8jNmxvbJAjn9j2sb9J+eVsZSxSszlVWuf9Rr6kqQUv6D30458aVmVQep06JhYEUMM13skCktjQ71NQl8uBVloQJ51AQYGSRItSAOmpiZx4MA+uERe3Bnj4FwDRWFw7vwFDLJC261HCDkaDTm3nIZnABiD/iBHCPJsbzRStFupvpyrMEAsKBhr0Go3AONhLVAUeel7L5aP9zk63Racld9xEcAtVldXMRhkZc6LPEPiLDrtJubnZ5AmFsHn2sANsjwT66gy/uFEyW8nIeT1CEUlQt4AbA8CAsQfTIgdHu1GWUBWdgkGLhgkwcGFBAYJjElgjFGroRwwGYLN4a2HcdJJMsYAxQBHD8zhhmuuRDcB+r1t/JePfRrffv4cPvm1p/CxT3wBm6sbQNbD/pkm3nPnLfB+G8EU8Ebe+lkNuvCspCzIm2UEFY5UX5L+0WiPRIgDGWssOp0umq0WGq0WOhOTaHW6aLYn4GGxsd3DN771LSwsLOJzn70HL730snYoRSDyRSHTzIasbmKHPnah9JoYGYyNEDtRAZW41Gw1cfDgIRw8cBBpmkqH+iK+RsYx7IdCBaLhIyR1LsC4AFiPgCgwyRQ6EYHEksl6h9Q2kfiAn/4LH8Gdt9+IkK0CNkOOQt5G+4BW2kBqEm09Vaiv4VMVRxDREAEGOYIZoLABuUvx3MlFfPxzX8HSRh+wBu99zzvwg+99JxKIoNEvLM4trmJzowcXDI4fOgRnLdY2NtHstLDdX8OlB6ZwyWwbW+dPIAkDOJvA5AkaWQMTuUNrcwtJrw+TBbiQIOQBncThpmuvxHVXHMXc7DTu+sD34aHnXsLiwANWOurS0a/yMIqBdMjrW6TNymClsreLfnASIBjkhXz2OjXFqld3aw1CIX6EvI/ihIomQaaPhaDTynTKWn2gHK0/ooAZp7sYI/6zssEAwYuAZdUp7zisiiHOOYTgVZwSB7HWqoVRnJZZCgNxMKbPlR23g9xXBipW6f1lIAIAjEGeZ3pNGf26RPwm+SACgVEBzKjQFt/4R6EsDqyMkdGriET6rKs9L0KsNq06uTdlaomPfqXKZNfqV4WUoNY5EWtFWPF6bevUsbt+D9DpqvFaOniO+ZBjRJiKSkN8hhkpWB1oy1SYsuw1TYjCl5EpRdWzPY5p5RkQhYxy0HyR55U+NsqBudGBZSzbeLKk36LwRemXK9ZRvGZMiwz447XjMbXyVYJaMoUoZMZs1pIsZ+48F5Ao45TKaFklR4t4CAR5WaCfVY7QyFUoj2UJaO6lQRsTvw0/4f6g/IFjqImdY8shlnUUVrQeouVZvMeCTq+qB3ku1YShXUKMJ5Tfpe4kVNeV4+VZFKfXDR0XZJrX6D75rscN7Rv/Wf6J93dNUCrzWyun2ueqHIe370Rvinp4TRUoB/m4CEgAer0BXjlxAgsLC+gPBmU+AWBychLzc7Nqlam5MAH9fh+ra6sIAcgycYadJCmazabmUyySYYAsl9VhpRwC2u12+Wwp06Rmc0GnkTYaLUkHgLzIpcw0nyYA1jh0uxNiZGtcacG1srIm8QQPH3IYG9DptHDo8CEkzqEovK766bG5sYFz5xawuHi+tNCVFGor1jolhLw+Gd+rJIT8iSKEBEACGKeiiHRUpJ8h3WNZMjjAmAwwYk4tJuwypcbZBNYkgG3Cu7ZaKnl4YwCXYGpmRs2iPa69+kpMTkwgbXVgW5NYWV3D8oVF+EEPmytLmJ+eRDbowxsDGVoC8ik6adzZgRvdYtUAYZSgViE2cTDOIm00YdMmkmYH3alZNNpduGYbJmkgDwYPPvwIFpeW8fkv3IeTJ08jSRJ4XyBJnAxytbzqb43FpD3y6p3LLMuks5YXcNZi3/w8Dh86jG63Ix2qEBCCVyedr5XSsH6khACUe/QoY6UPaaXg9P2udiljHCIsWm+QhoC5boq///N/GT/8A3fBYgswOQY+R5K2kGcBwaP0uhnqHji1syqpkCApBIBChCUAuUmB5ixeXFjHZ+/7GtZ7AxRFhrtuvxF/5oPvBrZX0DYF0hCwcn4R25s9eG/RnpiBbbbQTC2avRUcn52CHWQYbGdwLgEKjyQH0tzADQKQS4e18DlM3sNsy+Mn/vT78KH33ob9HQvvBzh0+TWYPn4dlkMXSFKxLDEyirx4HzeILUCoasOXomitdowVS4E45SEA4ig/DmqCTAmFR1Hk0sU2qAZKKrxARZ/6vtLPUClUqFPUKL4UsiS1S8QSSOpDnGaPQ0Qp9cFjVPwxBmmjUQ5gZYAoQoekQ8qpPhCv3xMG1YpeiNOVSsFAhBGZ8qn5jFMkrLwNr1dBTH9ZNvE5oIUZ68vWVrWLx5UHxZyoE1nrHHL194TagNiUVj1RkJGz43S/GG8UvaI4FVQgFqGv8l8k8WlEWljeV/d9FJ/q+YWeE6JYGC2qtOy8TvuLVkCS1ii+xQKJPqtq1TJ0kRF0X60Ky2vF+jNq3RaCTAX26icrhOpur1/DlP/orlhRrxFjoqP7yuH9OGI6A1TU89rWa3mPV46/f+OIZWiMHFLWnX7fkaGLIY1Iw+jvhaTGxFa548WAogJBbYPWd72NV0JC/Iu6CBO3R6Fnl5D7AkXwrxpiXHqjyYuTuL2+Gpqvpy8eUzsf9e362xKnnXnoi6V4P1ef5cdY8xvb1EiIpV6V2givsR3qY2k4jB40BjlWnp/x4ouLF4BgsL6+iXNnF7C2ti6rgXoR72dmp7B//xy8z2DUBYBzDhsbG9I3cSmMSZC4BNPTk3AGUlCxfvU+QRBBLm00RnpQZeoQgvyGNBppvCGQZfKbgSCvigAgTRK0Wy1ARShrLTbWN+QYddadpA7diTYOHtqPZrMhzxudjnfu7ALOLSxg0O9je3tb8qLtV8ol1uNrqw9CyPceFJUIeUMQe8bSwan6FipIBBGVENRjTvSHADkm+AzG57DBw3gPFIXYYJiAQV6gHxKcvbCOpbVtrG9swuQD/OUf/28w37KYTj2uvupyzO6bQz/Lsb7ew7ceeBRJ2kHwDiHIalo+emQoO8lVJ0i6NbFbFHsh2nGsfZf0WjiXwBdBLKCsQ6szAZM0YNMWGp1JtCamkbYnYdI2Lqxu4lOf+wJeeOkV/Jff+T288PwLAMR/iFerhOGrqG6ifbN6F20ncmCz2UCj0cDBAwdw7PhxdCcm1NpAprXI4MUiz+UN4WgYh1x3NGVSo1KrlcVXVhhk3qLwDjApnEthjSutvqQY9fyigA0FUpPDZlv4az/5o/jhD7wLE40CLVfAmoAkTeHjz4eOuqprSgFVWwOCEYudKnWSd+8asK0pvHxuGb//qS/gzPklhCLHTddfhb/3sz+Jaw9PI9lcwkwjRbfRgi8sjJEBeAvAmw8fxlyzjWJQoN/LUGSySlvqEiRqAQQTYEIfR/Z38cPvvwN/5SM/hP2TKbKtVSRFhqa1OPXKGWxsFjC2DWNcOUi/eN1WVKUf0VX2VDgJPpRLdRdFUQ7CxTpGBlJiCSSOTQG5+VySIAQZUMh0NBnNREsio5Y6iJZK6pAb+mY8cUkpHgWNL05ryAaDMSmPokjlTNrpNLU8z4HKMAkwqO6NUtCKccnfWH4+hCHnzgaSIGkREmm0hIrnRhEkDhRDzULCGls5+LaVxU8cFAXoND5tnmWq6o8M6KCp5nw6WiqVxHON1KGJ4o2Kc9DnqQyORASLgpvkTQQoqasqnTHtUXiKYk0UjyKSzGElSPZW5RjLfyijeoKk0ci9Fqc+jiUWikYwXARVtLXrQtueMSgtlWL+vBayrMZX1Qm0vYwfyFdxl+UXBSpNWrxuuW0MUVy1uvKgsdK2ynSpX62yLUoh6dnSuMV6V604da98rmwzTfmErdtq1o4dCfEqWgKQuqyVe5DzdrBrnQ0z1G70Y4i/IYjWPvV7wNT8BY0EPxyiUeLo9jL+eG/qtcdZNFWWR7VratwSfz0t8bzhayDuR7VPMjq+TQXo9vq+oeN22/4dIMizwhhxiO2cWIH3+32cXziPc+cW4H1AI20AwWPf/CwO7J9X3476m+k91tfWxc+dvhea6HbQSOPLKJnqnmcDKRsj90JckW0cIcQVZcUBuAhbhax4qxgAExNdNFWcMkb6RysrazBx2rIBmo0URw4fRKPhUPgcSZJg0M9x6uQZZFkGawycc2i32lqXNdHvO1z8hJDvPBSVCHkDYEMBEwog+HL4X0olIYgIEKBbxbTZBFk83YUcDZPD5lsotpdh+qto+C2E/iocBkgSA28TnFtawyNPPIOiALY31nDVsQP4ez/7k/ibP/nn8J733AXbaGO7sPj2ky/g7OIGYPRNVvDi4lOto6rehXQio9glSY0do509kHJLQDmgz4sCgEXugfbkNJA0kLYnkDQn0OhMwTW7kq6Bx4Pffhwbm33cd9+XsLCwiKCd40Kn0Yh111DqaoORSHyDKp+NrrY3OzuHY0ePYmZmRgQLdVxa5LkMYlTAaDTSkfh2J3bH5Mz68CROuxLn6rk36A8M1tYy9PoG3icocovg43BJYpPCFnerzgWkDmjYgDYy/K2/8uP4offcDjtYR2IyZD6HLt9XT1A5bBLkr4FYvBWmSq2J4oQ16GU5MiR4+dwyfveTX8ALr5zCoNfDobkJ/LWf+DB+8F23oJ1vI2xuwG9vI9/eAvIBmr7A0e4UJtIWsu0eLAJc8GgmBiFkKJDBhz7y3jLeccub8GM//F7ka2ewdPYlDPqbKLIctsjw9Le/ic997PcwWF9HM66QFjvgpYIyjqrEgTgmqe6s8s06pKjEd5jcf+Xg24uoYYz41ii8OMJGHJR5sWyL4gN0wFyXFsTXDkpfFHH6mgxgqvqN35vNRulwW5D2EyMMuhJbHJxXjmWr4TAAebMeT4KcZ2pRIUjUUpxmyLnz8CGyLUlkxcRY4Hq6pK42sAwQix0brXGKSpiJg0xTilIy+BytQqkf/azCSClMxeejimpQYRkxPbXyh6a9jF8HaPXV67wX6zOo8BeCOMK15dS8yiF4UGEqEotT8qBWSVG8qZVRFLUQRcwyLu3ihVD5mNplcDlEkFDLpbYLtUTSaXxGhT9rqimEQcseOu0zRhbTBEiFVG0lXqW6WEyn/NX8lOVXTSMch1xbyj1AxJQoaFojD/DYtstndf2WrwVbrk6l93B938ixF9s+HG+UYhVts3KMTvGulUo8P34qjx6f/ZJatNK2dFsIKGX9eH/sCBq917IqjytrU7eX0df3DIey3mub69cqtwOlsFTGqV8kflS/cvHC5anVv9WxKM8v95Xf/gDE34V6KNM0emhVa3Wi8/6ZmRkcPnwIs7OzgArJa2trWDi/gCwbwMAj+AKzM9NopIn490vEX9nayir6vb5YFRuLJHFoNFM4a6LShyzLSqtHYwxStUIaLSu5B+W+lSxpv6RQFVFSBwNgemoS0JcDgPg73NjahC88Go0GgIDZuRk0milgApwz2NzcwMmTJ0vLJ5ckOHjoIPbv349Ot1tr24SQPwm4X/zFX/zF0Y2EkD9Z/Otf+32YUKDIVQSKHY7Y0wrSGZO3hlYskYoMLevxtrdcjXe//Wa8/67b8P5334r3vOOtuPG6S9G0AS+/9CJ8CHAuRSu1WDp7GpccnMNUK8Wgt4U8G2BhYQFLa1s4ff4CvvHIE3j0+ZPwjSkUcPBFDhcGMCgQDGB0mkKSOBR5odNv4lv82CuXN8aS7N26JbI9DnJkRCA+CLwOuJPEydQXa1EUHhubW3jppZcxOdnFubMLOHrkKCYnJ2GsQZqKxUi0KLDWSY8b1bQkE6eHxI6tMZiemcHc7By63W45WIwdTqPiUr0DKml7da3f1KxojHZwfXxLbxMUwQA2QVYEPPro4/jcPV/Giy+ewj2f+wJuu+V2pC5RS5T4OjI2BC/TsIzGBSA1AabIccP112Gi08HTz72A7bxAsBbZoC+1oNO6bH24ZDReAxTWIlirA7S6FVABmzhYl8DYBrLc4emnn8b6+jqmpybhQo6rrrgUV15xGbY21vHSC88DWQ8N63Fsbgq3XH4FJl2KhfNnMT07ieuvuwbPP/cCvA0ofA83XHMcf/b73okbrjyE0y88ifs+9xlMTE9j/4HDeOXF5/DQlz6D+WaBm268ES+fWsRGbpGpo9cyG7UBRB3ZEmKjLEMUf0IQZ+bWAA1n4Ac9WBNgfR/vf887MNVpwARp9xKVh0MAjJN41BIJsbNfFmwlcgSoL5S4S7fV02sg4p0MqMViwOh0hSoeOU6EAml/9XYKFTuCDuir0aC235oYUk9bjBUqfkl+tP7VisUYFSX03HppagLkXol+rnbkLU4Fk7SNVlWIB1YxAnp8jLvMh36uHVVdT//GdA5trwcVcMoY1AqxPNcYKZ2g+8oD4756nGU0tXj0bym6SNrrbSASB9h7o55PIeizNG6I8ZZFVis/yZ3GVJbnSJlqiMdaK2JPPCr6BJO2JisJohavXl2vL9eOnwNQtse4r7xs/W/5vBTH6daJJaE1Bg6VaCntTqxJYxssg04DsipyxnOMilFl2iBuAYsiYGVtDRcuLGNtfRPtTgedbgfNZkOFL4+t7W0sr6zgwoULsjS8ZrrZbmFmZg4zM7NotlrIsgxbm5vIBwO0W03Mz81g39wMOu2mWGnWMqvvZCQEsTArxZf6vpFQqyp51uj59XqI97k2g4ryOP1XBeGA2Gbq+2P9SRTyDKsdE0+IianX6w4krr1StaPXfnLVCxFB/WJB+gaxZKXttFptdLsdGANsbW2j1+uh3++h223B6iq7ExNdbKyvyf2ghdJIE7SaTYgxbkCR59je3kIIQOIS5HmOyYkJJGki/hMBrKytiyUmIGWkfT7nZGre5ORkmZe19Q30er2yLBNnMT83A2M0DwFYXFySfDjxqTY3N4PZ2emy7JeXl7GwcB6hCGg2Wzh46ACmp6eQJGK1Gcs5NrE6sxPdkS2EkNcDrz56IYS87rH5Bpp2gE4DmGw3YH2B0qOKiVY4AdYWMH4TTbOFmeYAf+OnfgQ/9N7bcGCyAfTXsbl4FvnqBcyYDD/y/e/B3/u5n8K+VsBE2EC72MLRfdM4dPAgtrKAjczh3m88gt+/58v4vU99CZ++7wGcWtxEaHZgmgnSpkWrCTSSAk0HJACQFzA+A4oMaWJRFAOZYlGmVbpkslRx3FhRdvGC/I12WT4YFB6wSVr5VErbaE3MIG1PIjcpbKOLzX6Bb3zzEbxy8hw+c899OLewJA6j+7K8rvcBqZM3htZapGmjNnCTbYlzaLZaOH78GObn55GmqXSm69YW5aD8D05AXNFL1sExVv352ATBOKyub2FxaQ3/7//jX2FyahZZHtBotAG1eKgsVQAYXaXIBLEY07SZALgQ0AgFusjxE3/mg/gbP/MTmG4DJmwjTQ2s8bAmwFk9Qesm5lCmCso3cWTtYILITxYy1Q4ACqQYmDa27QS+/cI5/MbHPo+vPfoMFpdWkOR9/MAdb8VH3ncHJvormDMDTCFD2wyQNh0WVpfx1LNPYaJp8JHvfxeOT3j8zI98EB98+1uwr+FRbG7iyiuuwV/92Z/HFVdehy985lN4+N6P486rZvCOq2ewdeEENntb2IKIX/UBRhwUjlIzoANi1gN0mozaifkC8AP4wSac7yNk27A+hylyJBYiSsrZGipLEK/TL6MDXajIZ6I1CsRaKFrtiKASxSc5tmplNYfeRoSP2GzFaiP6qbHj26WJ1k8QH0vlqmwyyJQpZHJetBgqpx8ZM+QXKQq9QafYWSuDkui7qRzYxTZUs0CSrMXPGmMsF9TyVaswY2qVVG7D8EF7QE7d+7mxhuvWWE7LoigKqeOhQW1VR3/cxDYi9aDi1Rh22bwnjDHIc3WQrpZVYj0mPvukTV/sQtoepHFUW4ZOCcOhvFnrA33dFk9UgSN+cE587NWDFE+QoG7lrAWcM3DO6l/5LCu6xfYD+WUaumRlujPU3qGZCyhFmVHGP6F2wcjxFz1npLjKi+rf8neslFXiWmzV4XGNttFoxm4b+r2QdmCshXEi9lmn/htHwmgfQJ439c8XyeMfAfGeHt64Y4sSc1h9tjag2Wxg3779mJ+fQ5om6PW2cfbsAowRwabRSDE7OyfPd9GSsbm5BaNTyXyRo91qAipseV/AGGCQSd+pqC1k4IMsPuJ9Bh9yhFAgz2WF1xAKGF2kpN/bRuFlMY/gC0x222ikFs5Ke+73tzEY9OASA+uAZivB/v37AO17ra9vYHFxCcEHdLotHD16GO1WE0YtS+NvEfT3YjQQQl6f0FKJkDcAv/yr/xGXHD+MD77/brzjHe/AF75wHxrNtvSCdeAgvaMCWb6JN7/pEvzohz6IpsmxvrSIp599Dk889QxeeeU08kGOdiPF9tY6Zqa6uO2Wt6LTSHDHLW/F2266QTqUtoHHnn0F937jEWyjjcJ0gaSBPADeOWQADDxcyNA0HpccOYDvu/u9WFw4i/WNdUA7G4lLdVqMOspGKKXwyqZhFB0KmLjfaDbFWbBzSWWxZC2sdUgbKQaZrJiS9fs4dfoMuhMTOHXqJI4dOYLZ2RkgSIcr9gvjYKccCMOg1Wphft8+zM7OIkl05byan5hX51U6+4pRYcFD3uoX3iNpNODSBl4+cQq/9V9+F8889wI++p9/Bz/2438eX7jn83jxhefwC7/w36PRMEhcUKfoki4pWykrmYIoqRDLospKwXuPI0cO4/LLjuGpJ5/AxlYfqTo2j/3EsttsoCMmqQWxsdBv2txE8jMAnIZERJ2kga1eD0898wxOnngFoZDpm/PTk9hYWUa+vYU7brweB6dbMLaD+x94GKfOXwD8AJfOT+Mdt7wF3QSwuqIYrMPy2ha++eDj+MpXvgi/fApvv2IWbzvewcbmKh58YRkvbTax5qZf+5uWWE1a92XNBfE3Zk1AYgOcAZqmQLa1hq3NdVw4dxI/8md+EN1GAguPYNQpuPqhitZ3RqIuP8Q6L9uctoMqDA+ixOpNt9WsQErBEGLBZIxag2j8EkUVTzwrJiZeC3qs5LnyvWT0eSKtqIpKtktc8ZHjCxlEOOdK/1EmpjGmWfMa45b8qAADsbqQAVc17S9ou9LWLTWjiY5x/kEZXz4Vu8Vf5qH2KeY3WrjsOLjGmCi/Y4SyvmttZZcEVMVRtYu9YuOUP61XESVFCI0O18ddv9xS/1AbsI6vq+GCjZZKZfso72eJQJptJdoOBy2fke3xeVltk2dnXhRYXl3D4oVlrG9sotlqo9PpoNkQSyXvC2xv97C8vIILSxcw6PdLganZamJ6ZhbTNUul7S2xBm63W5ibncb++Vl0WjstlTAqJMUiGS0aZaTpCaWYLf/Vp78N172pPWWUHaJg+QOgX8uU6cZKOA96upRDPElDrcyH91WM1k09jB47nurZsSsx/UP52Ikp24R8DpD2B/VZ1Gg2sL21BaiPvanJSRS+QKvVxObWJooiR5rK722329Wp0TmSxGFjfRNQUQkAWq0WOh2xggKA1bVVtbSWB6uJK44ioNtto9NpwVh5MXZheRmATHUzCJiankCn04Rzsirn0vKKLLygIuj+A/tkhbkA+CLg9OmzkqduBwcOHoSzImpZU/mTi23Cx5Uta//NT03GIiOEvI54zf1nQsjrlzvedi3+4o99CNdedQmefPzbmOi0q4FM7HVYwFsAzuHKKy9H1t/CxtoyvvHAt/DJz9+Hh59+GQ899RI+8fkv476vPoDV1VUsLZxC0VvFrTdcg+luE2trazi7uILf/8x9uOerDyFvTGE7NNAzDRS2gcIY+DyHDQHwspT9/rlZ3H7zm7Gva/DzP/sXMTPdRfAZ4HPkWR9FnpXdy/KNZhSYtIM0pi851OF1zulbb4vCBwTj0OxMoNGeQNLqIml10JmaRbM7BZe2keXAtx54GKfPnMOnP3sPlpZWZMqbWigVeQ6D2NGVzte+/fuxf/8+dDodNBoNGWSXVkl/9ASgdCZuXYKl5TV8+atfx8snTuLk6bO47IqrsbHVR1YAf+Nv/hze8553AOjD+z6AHNZW3fYAWcHNG4sQbdjU4iZAVgNKmw04C7TMAHe+9Wr8P37+r2FuZhKhGMDp23mxwhCLJ2g9eQPY4JF4DxOifyULDweEBDY42GBggwhdwTj08wJFAA4eOYLzK2u476vfxCc+ex+++vWH8MqLr+Cyw4cx2+3AFx5FEXDy9ALuuvsDWF5fw+LiWfjeFlqwaCYt9AqLx596Eh/9rd/Ek08/jXywhUPTDbz50oMwvXUsrffw4rl1ZKYDG6uqKpoqvCpBhkJB8mmDB3yOUAzQ21zF+vICVi6cweLCaRRZX8QnvfcCjK6eJz/J5RvbcmWxKglGrZECIOU95BA3DsDECgZxae7a4KV0pl0ONCUuW05rGzcsqrbZ0k+Pbtc36oW+IXdqORUHDTE9Rs8JPgqJQJIkpS+pTB2He10tSqKvphTFOGVgJKmO6fZxWl98lpWDUP2rm035z94xOih8bbxag9H01/xVQUUUqddXjwGantcaXisGUkeAZiNcPOP1dO79UScnWBU24+kmCoPa1st6HSEmr7rucAJk+8UTJW2xJjboNvkc98VKGQ5mZApcbKfD/8X6lXIsr6N53Emt7Me1hR2/KVI2sYwk7ljvtXxoEcY87XYfSJnu/E/Qlxneo4gru0WLpdh29XO9nHbmsrZ/5x49v0wMAsQqc0eIL8VG7oU9N/pdkXK6aEyvUVCqTNKqYGoCe55naLebOHToIIIP2NjYxNraGhKdqj41OQHnREQCgk53k2eutQaddgutZhOtZhPNZhNQi+RYwu12C91uB92JLroTnVJI6nRbSFJXWi4BHkmaoN1uod1podttIU3FstiYgCzro9/bljQXGVrtVKbw6W/L2bPnEYJBq9nCwUOHtD5EzIotwalfpiwXX3OEkD8Z0FKJkDcAjzzxKLrdLmAsvvrVb2JreyArg6mPjtKM3DiYpI3nn3oSC6dP4tTJU3jsmefhJucxcG2YVhub/T7ShsHVlx9F08kApN8b4Oz5C3j0iWfxxa8+gHOrmyiSFrxrwhsH7xoIIYcJGZwxCN7CmQQWQNN63HjNJWi7PvJsG1dddxMefvhhEXGsWLDIVKPYMdcOnDHqPLXsJg8NPqqBOuCLDC5xMqXCa+cmyDK5XlcucomshuYHIhj1+z2sra1hZnoSq8tLOHzoENqtFqwVn0pFniNJU8zNzWH//n1oNpvaeZfVhuKAEdrHfW3E3FwcGSxYuETK5itf+zru//KXMTu/H7AJrrn2evxf//bf4e/9/X+AldVVXH3lEbz99puQuABnChHtgnb0pNdXaw/S/7Xq7jsYgzwAg1xEEIcCSd7D7Px+XHLNjXjs8cextraOAAsfJF1Q0S9OEUt9gAu6Cpy18MYAsCooia8lmUbiMSg8jB+gYQvMTrXx1ptvxlPPvYz1nsdzL53CgX378K7b3obJThtpu4P+FvDEsy/gA9//Qbzt1psw2NrCqdMLOHPmAp5/6RReXjiLfXNt/KkfuBvveOdduP1t1+NtbzqGjt/GyvIynt9o4OHTHn07hwRe03YxdL8xagNTGzwCuiKUR/AZ8qyHfm8TWysXcPrEi+j3e0gt8JN//iOYmezqlAQRkyystL84WC0tk0RcksFhlQKjg6/6W98QpyzpsCXeE0Y3BIShqWjGiFBjjK4OVlrVDZeBgUxDs1aXtI8rFsYjQyVaxQFvFJ9MbbUtY8SXUhxcyIpU1WpuZT51YFwmtEb9Hi8HcnFwqvkpR2pqBRSgTpqHs6XUN2qN1gaoZVRjz60jCZZnQNxWlnRVZ7XjxQpHREGodc6rXqaGlEU9/NFQWg7Vyrpe7ELVTmTfjgNelXjfxCmYUTi0RqzOrDo2L9MzluEyHsfOtAsBYulpXTWd0wJwtbZd1knYGaJfspgPGy9UroJYtU0fPPLcY2V1HecvLImlUrOplkpNefHhC2xvb2NpaRlLS0sYDKKlUkCr3cL0dM1SKVdLpcEAHbVU2jc/o5ZK4petrBMzfC/Jnl0KZReMis6VgK33s7bBi5VxfMbUtw0dPvRsk5dAItLVhLoxIcZjyps0xlHbXqNWBIIctDOU+3dmqh5HPX5jtBWMOQfQdlAmrBagPi61/TebTVhYJC6FNbZ00N1qNTAx0cXc3BzmZmbQajb1VxuwLkG73cbk5CRmZmYxNT2NVqsFGPn9CCFgYnISk1OTmJycwOTkBKYmpzA1OYnJyS7araZaLUmfZXpmFtOT05iensbURBftZkP8ATq1bJqYwvTUDGZnZ9DuNvVZb9Db7qO33Ye1Dvv379fnvocYAopvsqCCJPQ3ovwtqYW5yYnhsiOEvC6gqETIG4BvP/IwJiZmMMiBr3z9QfSLAiYBrMuR2ByJyWHyAZwxSKxDmqRY3+xjcaOHkHYA10BqDaaaDj/03nfi++96O1Lv4fOA5fUe7n3oSXzi/gewtOkRTAofHLxNkIcCSSoL2xur/n6QwOQe1g/QSj2abYMrLj2GxBs0g8dMy+Otb7keDz/2GPrBwCQp4MW3jw0GQILCNGAgFjD17mnszxmob259GxggS+XKTpluJFPHHKxzkEXiEiRpE/A5BlkBYxL0tgZYOHcBl196Bc6eOYejx46iM9kBLDA3N4v9+w+g3W5LB1vfwMnAvRoYG6N+dspkyocdHVzFI8iUHidTejxkuV7vizJfPuTwxmArK2CbLQy8xcc/dQ+eevZF3HrrHSiyDO+/805MNSzecfNbMNFMdAVAKUMRfkSwE/faYg0j8kaQhd2MAYxFUOe1MrgSL1UwBknwODzdxm033YBvf/tRrG324F0KD8A6A2eBxBo4oHQwamBhvYENBi5IGXkEeCM+OXzwcNYhMQbGB1xYWMQtN74FH3j3O3F8rou333A17rzlWrRMhlazjbQ9g2898ghefuVFZIMejPc4evxSXHLlVbj86itx9TVX4s3XXYPLjx1Dp9FECo/UeCDpIOscxLdO9fHph09iA5MYmBQDWMCmlbg2FKSOJeig04qvlNRamOCRBg9T9JBggN7GMvL+Os6feQUnTp+Ba05gbn4/JrptfPjDH0KrJSJkUeTlS2wRfHQ6QBxcq3PsPM/FIqgohpxmu+jfyMg0nroohZq4EwfocfATrfeCrsoTxSA5rTo/ijRieVctSx80/yGoU+Q4natmPSB/1cIoeDnGV0NKEQv0WKX8ZkSgEn9NlUP8OuWgLt5oOng3xsiS3SpYQAf8sVyNiXNPoP+IGBT9Go1DjoplVFnWRAFEolKRTnMhz4UoMo2JVwea0VF1HJyJm2fEOaS7htGkSla1MQ0FiTWeqUfvmqY4/pUTqvRHobxaBa4SFf4gGC0jq1Z1RsshQK4b9PKI7VGfqZGgU5JlmlxtlcSRQSoAeCMrgiIO/iGDXPiAZpLCBIMEVqxoo58kg6oMSz9MVQhaRUHLPvoVQnxRE8sPMvU6LzxW19Zx/vwFrKxt6PQ3WardOofgvUx/W1nG0pI66kYAjEOr1cb07AxmZmfQbjVRZANsb8r0t06riX1zMzgwP4uJThupimTxtjAwcKZyJm6NiLtmZMotEF8oVLdUFUeQZ1MQK8oQLTKNWGlFC0XJclX28Xousfrrpv8ZgyRNUWh7c8bC50F+p6MQ5+V3EHofF/oc8D7Ic1N2SFuMQlcQsTpN09JPW+IcgnPykklfBkityi8aYPQFlgrQibaZ4GVFTi8LSkBFGiAgSRMU3sNrgy1vA7XENEaEYnmJVsAiEV+CutKupFPKw1lJo3MOPi9KS6JWs6Hlr2KrPsuD5rUIQA6I9TXUgrW0ZIs5NLCw0qZjk9T6DaHQuoSsrBssQjBIjLzgqJ5lIl95b4DgYE20Eqs9X0JA4iwmJzuYnp6As/LSLxSFPFth4IO2tdioVH+V60OvA8xPUVQi5PWICbEnSQj5E8t/+I+/AptOYHl9gF/7zd/BkUsuw/U3XI+jRw+h02mjkbawsb6Nhx99Gvd/7WHYJIFxFsFn8Nk2ZloWt95wLa570xVopQnyQYbzS6t45Imn8PRzL6DnuijSCRQF0JReKkKSIAs5LAbophaZD+jlHq32FExhYVDA+D5mJix+5PvejVlrsXz+HBrTXUzsO4LnTl/Ar/zm76I9NQ/4VKUJJ9O0rFFnyDVn07WOcbnFyPYoKIW41LfRwXXwcAYweYH+9hZ8PkDWW0VvcxP59iby7Q1gsI1Ljx3E7be+FceOH8RP/eU/j6mpCTQbLQAi0JSDLSsORV8r4x6+RS6OkJ2zyPMMzqUqFIglEGDhkgS/+dHfxvTsPrzv/XcjGIOvfv1r+NKXv4QD+/bh4L45fP/dd2NmoisrtI1xaoqxJQZ1XvtaCPABKFwXT51YxC/9f/8tXjqzDCRNBKjT6EL8NjkVaSQRsiw4oAkI6iBc/zNwMKGA8QUSU6CVBLzvzjtw2bGDsH6AvL+JViOBSTt46pULuOcL9yIrdBU1AzSbDXRaLXRaDbQSh8RapGkCa6WDm2d9DPoZBrnH+mYfqz0Pn3QwCAlco41QZNWQQzu+4wgwKAKQGMCFAi7kSJFjsLWOQX8LK8uLWF5eQggBaXsKre4kus0EfrCOf/d//gscOTAH5LJ6XiiCtG/jEEKuA4Aoh2qbhQwuxLJOhJZE/RjJvnIsVmLUQqhcXav2dj8OPqIgBB24RTGp/Bzv56BL1Ot0Frm1okWVTD8Tx9Pl3iFsaeUkaQLk/NEuSIw3WkYVRVH54RhhbP0EGeHprS9pHxKVqs8x3zEdNqZnl3hjWUXhDhAn6tHCqzy1ZhVWlte4OKskSrn4aC0W63JnnuuMxlkfTI5iIBaEMW3j6giQC9frVzeWUcof+dfE+/oPgdF0x7aFWurj81s+V2mJTcGqhZ21skqodWKJOq6oC91oYl6CCPQhyOpUiHVaHyiPi6iO3k91xrXTEAKyrMB2f4CXTpzC408+g5dPn8Hk1P+fvf8Ot+y46vzhT1XtfcLNobvV6pa6WzlbVk4OcjYOYIwBGwMGmwwvDJiZAWb44cETgAHGMMwwgMFgGwbbgAO2ccDZVrCCJbXULXW3OsfbffM9ce+qev9YVfvsc+9tWYbf87yvrPPtZ/c9Z+/alatOrW+ttWqKDRs2MjI6QqWSkGc5c7Oz7D9wgD1797C8vFwQBhMT42zbsYPt27czPj5Os9VkdmaWZmOF6YkxLr1oB5ddfAEbJ8appr15IZSkIPaLPKloGivtXXrSa4dVxXeBUMqtkBEajQnmWbGu+uesXsxKiemqdQ6TphK5Cr93KFqNJvNz87RbbTrtVtDeEeKpZ04OaZoU92pV0fBSSn4vy8SiL2sAao0NbbVO80DJJEt8EgkBEztS/FxoH6tgxis7V5hgGu/iOiD0HUXsZ3JQiJTZI94QwymrzqKU+HaMVS/5XN0qazPuA1lTRhxPxXcPoLGI2RyBZCyeB2318v3CDPybjIFIMspviczthQ+0EEd8X2pmVR+kv0Fi2Eu3ntMLNMAAAzxjMCCVBhjgWYC//pv3Ux0aY26pCabKOVvPY3l5EYLzxDzLUSgmN23l0MlF/uQv34vXCUZ7brj6Ul5627X41hJ5t8PCcptHnzjAP9/zMOnoBBWjyVSVjhWzsIqSxUUOeG+5YOtGvvc7XkiSKPbsP8juvYc4eOQ0KEOqHWM1xxte8UJGteeB+x9gRVe59IrL2XjuVg4fP83ff/yzdF0FRwUwaOVR5GFBHxYpxZ9VC6B438kHr5XslipZEHrnhHRQhm67TdbtYPMWebdNe2kelbXoLM/isyZv/eEf4Df+n1+lVk9oNRskaaW0SJK/Kggp3xr6wyslO5bdbkf8zViPQ6FMytxSA53UMGmVT378k/zVu9/DL/+7t3Pr7TejjQdlsVmX0aEh8m6HNCx2y6Z4axAXv8V3vyZP68F5j0oMmYWOSzi12Oa//O7/Zu+hU5AM4VWCzcSxqF9H06Svnrz4fvBAZkXDSfkcl3dJVA55h0su3MZzr7mC4XqVTqvBrr0HuPfhJxkeGaVrc5RJZIFvemSh9h6XZ+TKYNHgLDr48tHK4Lwi8xpLgtcJWiektlnQOT6aigVthKJewh/rHPVUk7eX0XkbnzXpNFfY/+STGJ0wMjJOklapDo1hkoRqqmgtz/Knf/wHbD1nClwXFU43tNaLYKFkoR136W1uMcZgrfxVQcsgCjDlvkdYo8fPKjgYdsGRts3zQhtEG0Oe5yTGYJ1Da9EAiARUJE4kO6LNJNoBcZc5CI8xnJaTfSIpUoaKJFUw91KIFoNf3Q+QAvhCs8qRJHJE9mqBBNYXeCJxpY2Ql9L3ovDUj+Lt8EHKvzZchKIY5DL/BD9tUaAq14cv5SW8uDq6EI+Uo2zuJXF/8zG4uvzyzvrjVynRhCGS3+uMSejVf1HW0n0V/T4VhOM6738LEGFb+p4KPmAK7Tf60y/KGvIXH/sgtJfJhPWqujBr9T2CbA2pVJjZ9epvdR2XUcwNZ2mr8v31SaVJpjdsZHRkhLSSkmcZ83Nz7D9wgL1797C0vCy+i9CMj4+zfccOtu8IpFKzyezps5FKScxBIB562qIRPtRdJJViXiVU7/ciEktxLFkvJ4c651BnI5VUMWGWyBCP0UE7Mow17z2LCwvs27uXwwcOcWD/fpYWFpk9cwZrLUmaYJKE4aFhhoaHMMYwPDJCrV4jMYnMOd5TrVYZGRmhVqtRq9Wo1+vU6+IEPUkScVhtRCtZDuqQ31jC/Jgk8tk5i3OeJKkUeY7IMjn0QUUNLK2xLu83Tw5zAmF+0+HwgCRJcNaVSCXZSJE+a0I6miwTgimzOe12OzhqBxM0VFf3Mu/LLVXCmiGg8KWDOeJc6L3H+572X1wJxHniqfo+4bkof4nZXr1ew5gwfr38nmmt5KTZdeZfTyhEQExvQCoNMMAzEwNSaYABngX4h7/7e5JqFZWkrLS7LLczjhw9xfHjJ8BZNk+NcvXlF1IbGqY6toljJ8+w58n9bNl6LudumqazPE+z0WTnY0/w+IHjHJtdxo1uouMVFW/xLvhEcRnKtnAoNmw8hzMzJ7nmkh285o7rqCcOR047t6xkKSdOL3LoyGHmzhzlNS9/IcPVlAcf2sXdD+7htpufywXbtzI5vYEHH93LF+/dRZcqKIMhJ6WDw+BUXDz3sN5CyBM0NTSI4ZsspQshJDzvtFt02006zSVcZwU6y7zyxc/jp972Q1xzxSUol5EmGptloMP50T76k4kLyqeDIDStM/t6lQip4UUgcF7RySyHj5/ibz74D5yYXWDr+TuYPXmKO2+7hcX5M7ziFS9m46YJFKJlk2jZ1XXOo1UiZX6Kqb6vzp4mqeSVoutyUqMBg9NVZha7/M4f/SUPPrYfq2o0Wx2G60MIARjjlPqnKCOoYEPiAUwaBBaLUg7lrfh3cjmpUSQGWs0GuTNQHQ8mCCKcppVU4rW5mHIacQxvdYo3Iigo78Ba8HLqGD6YSiktp+s4MTkRQsnglCJwkhDM/xTiiDvxFlwXlzVZXphhduY4zZUVhobGGR6epFYfQ2vxbaGwTE0Mc9N1V/PmN30PI0MpyommkkLIB2uDdgtiYhTNerz3WGtJk6RPc0dBT/COZEYUDpWQGYXQHU9oC8+dE0KZQPhE87YojhQCkg9mbmWhPaQbqyW2rOSn+K+A9z3thzLW00CKRIFkrUTSrPP+emM95ltM2aQeVdH/AkkWPkvdi9DdF9N68ZbKWWg0hbiiOZgv8tQjLgqsE2dMvw+lcq+5vRqr4pR34tWPaLIX0auDVXgKUik2TkE4rlumpw9fmL5JmiacZBnbvoxYr33VEjScXCBcrbXSR0tBCsT36VVPFPprtZrkJZjj+lABRduUG78E8UGzzoMSYjvmmaXVzfpIpZGxSaanNzK6SlPpwIED7N23V0glK2NybGKCHYFUGnsqUmkykEohW0IKiclVGZFUKr73lWPt75gNmxOibSSkEuuSSmu6pQyH0FY6mNKuNJbZu2cPH/mHf+Dr936dY4cOs7iwIES4l/xprUP55d3cWpmbAwFbHaozMjbK0NAQWsnJYkbrQuuoPjREtSo+pqrVKpVqleGhYUZGR8SXVbUaNJ5qQlQlCaAYGhonSVNxel2rkiSppKEVSZJSr9fCOxWS1BSaVHGuQcupr61mU4j7NIW+jR3RUsIjvyZeSNVms83s/DzNdps8z7FWyPSCBF6DYNK5CmvpG1mq9IKGtvL0SLDSW5Fb7QtfInOLu0r+ixsGaZKQpAnj4+MM1WuAEGqUtLieCrEPDUilAQZ4ZmJAKg0wwLMAH/jAR8ldzkJjhTNLDb6+cw+P7D7E6NgUCZZ6Ps+r7ryB51x5KSapo6t1mplludWhk3se33uAr937INbUyVQVq6u0rMUkBpN1wWsxI7Mttm4a4WUvfxnNruM9f/FeVJ7x6pc9n8t2bGJyNKHVXKadJ2CGGB4eB5vhXRc03P/IEzy8d4asOcctN1zDOeecw54DR/nG40fIqOGVQZOTqo44lkYWgX0oyQEEgTHX8tl4hYkSg/coFXYMlQcDifK45UXazUWuuGQ7b3vLm7jz9puxnWWqWgmRoIP5llJYLzubxogKuSsEom8OJSvKNXczCzpJcF6xvNICbfjff/Jn3HjTrVx/0y384yf+iU434/abr2Okpjh/yxYqiaLbaWFUMOEBlEpAGTwG5bNApp0dhYD4NEkltMZ6jwraPw5NRsqKrfJbf/Cn3PON3VhVBZ1itJjweaJevJwq55342VFeg5MFtkqFOPHeoZXHF+YInjTR+HDKmHOgdFWE0EDq2XAamg7+oVRwZOq0QTxSSTmDwj+44CPKObRIPoXDcq/kbSGUpE40Vi5vSVyG7qzQ6bQ5dfoUR48dYWJikvrwCPXhcZJKHaVSvDfk7SWuumQ7P/FjP8qFO7bi8g6Jciifo4JPHWtzHIpEp3jvcUFAzq0Vba/gGNjmtjDzAYpw2ogJkAkmcd65grSJglyW54V5QtRQiiSBD6Sci/6BAjwiEKZpIqYqhfAo6UfyKwr4a/tOHGsls7Gw7Ii+ofoQtKLyPEPrnnZNJAV66O2wx+8QJKW+25FIEjIIFcxYwn0bzAjFV1U4uW71GA5RxpglXSGvpPyisSSBJJTnX2r+Fup3bTG+KeQdv04bUAiNEiRqU/levUWsSyrJXBVLppS0Wy9PRSnijaeFqKlkAlkZ22ht7mP9lUklSa9Xf1L++H0NovJM6WGZVOr10V6Qs7VZRPSvI5/DW4GMivUckeU57W7GwSNHeWz33hKptKHQVLJZxtzcHAcO7Gfvvn1PQSqN0QikUmulwfRkmVSaoJYKqeKL3CnUmg5Vft53u4/QDKULmkVivhZJJYXG6ARTcnQe5yn53ItHIT4CtYLlpWW+9rWv8Du//Vvs27uX4WqNczdv5pd+8Rc57/zzi3mm0+mwvLzM0tISM2dOc+bMGQ4dOsSBAwdYXFwSYgzZnHDO45zFO0+e5+Q2x+ZCQkHwV+bFhG9dscfD8MgwGzZsYmh4VMimWp1arUalIk6y07RCJcyRmzdvZmZmhrHxUbacey4bN21i46ZNTE1Ns+W886jVajRbTSGEvMcoSaRsUiikmcc5xezsPDMzpzFJSh7zFzXJgtbP6u4ofbXXYePj1f1WeUTDW5VDlREJ4kAaO9EE78M6dSY+yoTE9d6GfErv37z5HMbHxwBHnkd/kOulXUKYkwek0gADPDMxIJUGGOBZgN/9o/ez1Fjm3m88yKmFZRZaFswwlaRK1WdsHvW8+LaruWTHeTgMi82MnXsPsNJ1HD11htOzizhdJfcJTtfIMEAX5boYB85qjHJou8KPvPG1jE6M8fmv3MfDj+1DkZDqNrc+91KuvPBcxoZTdu05yN59Rzlv6w4uOP98qrUUZxQPPX6A+3afoGYs1QQqlYTZ+SWsGSanglMapRwacW5cogfWRRScci2CsyFBe02iK4GccChj8WR4ZXHtZW69/CJedOfzeP4dtzBST0jIUU5OrTNKg1doZbDOghInl6pkJrR+dnoSTwxP0FYqC0LaJHQyj0pSHt31BNYbPvHpz7Bz52Oce+65fN/3fi/e5nzxC5/np3/qrYyP18g7XbqtJsvzi5x/3lZABD6nxBE5SqN8T/W9h5I/mFK+xQzKlvIcHEAH0xSlhAAB8QPhrQUvp9d4bchUhcW254/f83/58td3kqkK3lcCLRQdrebBl0RwFutV2FIXx+TRTwqISUokTkR4l3w6Kz49epoJHuts4d9CBS0Q5T0+bNOKEBUiiL51vEV7oSjlZooNO8iE57icRIMhR/ucrN0g9TmnDz/J3OIyHesYGpukPjpBfWgYhw/CR84F27fx6pe9gBuvuYxqKlpjaWJ6JnpaiB9ZmEsWVOi7UVMpCrzSJGWBIwhwpc/FL3pBHIT+WSIIVNDsiu0aKzX2Y3m9lyaUfIjE+JWQOkXXCdo7USsqxiNmptKPQrfvw+peqYKmUcxJrAfKeYp/i5fiH/ngY9+O5Y4J+xi2lxGlgqPtkE+lRMsgmq7FNH3UKoqvhnz08l96Lg1VkDaxftYi5IFe/EXUYWz6Ul1+M4RaEifTIS/exVys1uApKgNijcR6LqqplHKYC3odrK8a5WuprZ8uynW8Gn13Sk0YP8S5qxxH7CvxlYioGUI5y4EAqqRp8VnI79KbMV995Y73hJQu12tRb6s0O/IsKzSVdu56giMnTjE6NrG++dv+/ezbt4+l5SWslfocn5gQ87ftq0ilRoPpiTEuuXg7l198YU9TqUCcCZ96UwFiuXokRTn/NjjnttYWPpUUouUZtXQi4njpxeML8mlxYYF//OhH+bM//VMOHTrAa171Hbzlh36I5z/vDsZGR8Uxf3jPBc2oqKGU55JuNFNzToiMTqdTEFArKw3m5+eZnZ1laWkJay3dbpfl5WXa7RbLyys0Gg26nQ5ZntNqNWk2m3Q6HRYWFllZWWFxeUXyHSfk0B+ck42QaFKntWGoPixzvfcMj46yYeNGXvXq17Bl63lcf8MNVCqpaC4F/0Ox70h/1XivOXrsBIuLy6LppBOy2Hdin1s1zvoQTD+jo/QwkPteEFKpdCt2bx/zIWZ9Phyo0BdmNUrjwKvg6DykJ0WTz0aLH7Cp6Un5HV4T5dkKBJedt3n1rQEGGOAZgAGpNMAAzwJcccd3s9hoMDQ+QaY0Jq2SKgPdDnfc8Bxuu/FqqibHuZyclHsefISv3vcwqjaCqQ7RzSxppUqeOVApDoX2LapGnAw7UnAZw2nOj735u2h1unz0M1/h8KkVcpdQ0R1Md5HXvOx5bJocYnxyA5/41Oc4cvgEqalw8aUXUxmuc2RmgRMLHu9ytHaBTDBYr3EkQYsEvHJo7zFxzRUXaqWFbLzv8Vif4xFnmSapYXQi5k/KkqiMauowKuP/8+Nv4ZW3XYfR4F2GwmJU3I0OGjVo8KKb8/SdWgsJYp0lTStieqSDLo0Px7kju36YKl4bPvbJz+B1Cibl7z70IX7+Z3+G44cPcM70OM+79RaanRUyl1ExCY984yFsJ+P6515HvV6VZZ0ODrAV4bj6tatEWUAG0sYIGSN+fHJ8UF1XKvhEiEIlIqimSQVvg8CqfagPEaQzVaFhE/7ru/4P9z78OKgRvErxSnbsTWKwTsyGitNy4klESgSFXh7ls0cW0OV18WqTjkIuje97ERRV4cdCBQ23/iWuQnxAoDzVap1ulgVh3oPPSXAYL47l2yuLYDOOHNxPc2leiKTRKZKhMXRap1qrkGdNlG/zYz/6Jl74vFup0EXZDnjEp4dJUMF5rvdxt1dW/RohX6Lj6zzPS36KhGRSKpB8gfDLrS18LkWSKZokCNEjZKDzniRoLJkQp2gPRX9Csvz3vkcglYV97+U0NhX6TgxLiVS1zpImadAIEE2qNBWh6+mi3FOLt1aRB0W6JTIr3oso5905K2ZqIa6zmkmFHfVYL2HoF7mSj/K50KKK92K9xXopYT3SZD3EUEopOXVKbHbXxNfD6ngl35FgdOF0J0k/soD95JBojEk/cU583pTLSfge6yS2ezGPBcIwz3KSJDlrva4HSUL6T8xX+f0iCyFT3geH6CHfa8pfej/GHR6Ui0yYEQpzKaXEybzcX12na6GUonekaOl++K+/uTx5N6eVdTl4+Bg7H3uco6dmzu5T6cn97HtyL0tL4lMJNBOTQipt276dsbExGs0GZ87M0W6sMD0xziUXbeeKSy5iw8RYj1RSUglxbilqa50G6tXVKhPDgKiVm9scG+abwqdSYmReCu8Tx2KA9x5nRev04x/7GL//u7/HiePH+Hf/9u38h1/7VarVaiDvA+miDVmW9Zounj5ZxCgoUvSeLMtoNpvMz88zOjpKtVpFBd9HxdgLfcNoXcypeZaTZV0WFhdpNhqsNBq0O20AWu02CwsLLCwsMDMzw7Fjx3jg/vs5eOig+EhCY5Qhy3I6WZduN5PTT5OE73jVq7nuuut445vexNDwMNbnJEnYQPCeJEnpdDIWFpc4dfKM/AY4pOxurf+ksyJOecH3kgwh6cUoOQ2PUl0Vr8UNi6BhnaaigYVSZHleCtmPPrIw/B73RpgTolVpFJ4k0WzZci71er0gYCWctMXZMCCVBhjgmYkBqTTAAM8CXPqiH8SGHTBrLVMjFW647AJuvPJipsaGWGl36TjN4weO8NDu/TTaHZwyZBgyNF6nIgQ7i/GWqtGcf+4U1197NYcOH+GeBx4BLJfv2MJLbn8uuVf81Yc+wbKtkrkE47rUfJexiufW6y5n2/mbSap17vvGTnbvOUxXGzre4nWFRI/hdNgFcw6jNCoQDx6FU4pcgfGOJExf65FKZYHC513SSpXMQydoyygsZC02jVV50W038D2veSUXbJ6mTgtnwwlcGtld1CoQSSYYVMVF+lqhYn3IQtKYlNzZnpZP0IjRSnP6zCy1+hDv+78fYOv523nksd0okzI5vYlNG6aZHh/lzjtuRuUdVN6lYy33PvANFhcWWJqb54brr+PcczYxOTGKVw6vHOjglNyl4MUkIkKF+tXFqTdCUjhrg4NwOVlPB9MGa2U31IZjmpVTGAxOgdMelEOR4/M2KqnQVVUWu4p3v/+DfPrzX8dSBS3OsVWSYoMfCeF7ZPErTRacn6LAi48TwkJU6r4oQe97II16wkNcucr3hByNRWii0I8IJN4qKCVHQCcaUqNEG887fNam01ji+NHDNJaXUNpQGxlleHQSndZRuoLznkpFccsNV/Jdr34h288dI6GD8jasoRVGV0iSipjGOaGWAn0lndbaVWyZOHwVIVb6ePQXpAhaNd4XhEbkDMpmWdL3eiZzUsboVNtLXUaNmCChRBFEBQFRQoXQKoy5+KUw8ZL8RjMuX2iD9ZM9Tw1JO2q9xHRdNA0LCZXzIijuFDEV/SHUWW+eKD/rh5S3Z9ZWmOCF8L06Cnnqvdirt5hOaXl1tvRWQ3qClFtMwSSO9Vdqqq+8gqgxEL4VL8awpe/xmRRKnq5r/rYeZK4thZY+Zs/iAPwsiH2mSG81qRT/Czf75vhviVRC3i5F7sK4eFqkUq+Yq272o5TV0j1P3o2aSkfZ+dgTHD01w8jYJBsKUikRUml2jgP7D7Bn395w+pvDo5icnOwjlZrNJmfOzNJqrDA9GUiliy9iw2SPVFJEwb+XK8VaMh5VduRdJg16ZYlaQ9ZaMpuHvi+/YyYxoiGqpP6L9i+1hVGaJ3bv4j+94x185Utf4q0/+qP8zm//NyYnJwGPzTPuuusu6sPDXHn1Ndx9911Uq1Uuv/zyECbkpdSmyoPNMrIs473vfS/vfe97WVlZwRhDGk6IGxoaYmhoiNHhEarVCvX6EJU0RWlNrVZly5atXHbZZVx5xRVMb5gW/0fhZ8EH4tS7YDKnFFm3CwqybobNLe12l7n5BR577DEefPAb3P/gg3zla1/DOcdzrr2ON7/5B3jBC17IedvPx3kvhL4x5DYny3KOHj1O1nU4p2TDSkHGWlIpzsfl0RHbTCv5XU4STaWSUq+KPyOIP6oynxWdP2wwxZi8l/i73S6NZgvCmmA9nE1klNuyASfmrNINRoaH2Lp1K97nFLPZWeKIGJBKAwzwzMSAVBpggGcBLnnxG9HK0G61uO6aq3jJ82+mri2Jyul0u5yab/LFux/k0Mk5qqPTotmhxOFkN3eotCq7T86jbMZovcIbXvsKzt0wwehIjQ/+w4fZtXs3r3nlyzh/4yRn5pf5P3/1AYYmNmLSKt3E4POcundMVDx3Pu96RkdHMZVRPvm5ezk5twJGfPSgNEm1SifLsM5RSSpgS8IbHht85sSjb1eTSmVhQilQgTCxPsdrR2I8C3OneM3LXsSP//Ab2X7OBqpYtO2iXbdYjPmwmC48V8qSPHxeH+tPqb73rpJyeq9J0irdLMckKe997/uoD48wNjnFX//1X/Mf/+N/4IIdF7Dr0ce49tprMAqyThuc5cl9e1lcXOHw4WNceeXlrCwvcsvNNwhRhhBKop0T85oUC8kyZCGaFISS92Jyo8IzkyQiZBaLajk+Wcg+g4okhyZobVmM0eTW4XWFrtM4lfCuP/tb/v7jn6U+PIapDOF1Su6EqFMA3oZT0IJ2law8oaQJI597effI6WzF4plwIlVcswZzOlAlUomeM3Ulwr8IXKXdfJ+TaIX2lopRuG6LTqvJ0vwcR48coVqpMjw8THVoBKo1EmNQeFKt0Srn1/7929mxdQP1JEf7Dj5rkaQJSolZh/cGY1KUTlE6QTaHe21jdCBlSlo5fSY9ShVETaEVFIS9NE3FxxTir0NIQ/ElUm7PuOJX4Sjt3NrCFM4TTSBlJ9tFnzehPVTIgw8CesxjLIHzIlTYoP3mnAs+x6SZyqNDyr1WM0KaJpjmhX6n+vqCtGP056TLjsSLsVaaF8LpbPhevcT3VkNHsrWov7OTSuW6JIydswnVT5dUgp6j6iLfsU+vgSrKWtwJjMHqeUgRTOlKRFX5T0H+he/lcspoE41FreVQBmdFo1ApMbmJz0WjZL3Mrl/+WNYiPR+pndXlEm262NeiJt7qcP11zlM+d0Ez0xhTkKCedafKom7K9SJV/XTKGkmlLoeOHOuRSqPB/G10lDQVUmlhTkilvXv3sLi8HIhgxcSUkEqF+Vujn1S69KIdXH7xhWyYHKdWMn8TYkgV+VRFvgXSfKvzuxbWWfGnFLSUbDjRqzB/i2N8FWSMQKe5wkc+/GH+w6/+Kpddeimf/fRn2LhxQ/Fep9viK1/9KsePHWd8bJwvfOlLvOD5z+clL30poyMj0m9LJJcKubZ5zoc+9CHe9ra3ybgO2oN5IG900PaM6I2nQF4Hgrxaq/H+972fV37HKyHMi3F+8N7R6XRJEiGr8jzvzcPOCXHnQSnNSqPBv/+VX+W973s/eZ7zmte+lltvvZUf+OG3kDtHmqR0uh1QitnZOWZn5wBNt5tjdIIyhsydXVNI0NPW0zL4sDanXq9z/vnnBfPX0Jnjhou0fGlekM8y14VT7VAcOnKYTnb2zbLV80qB4n5Yg2nZLPPOsn3bdqq1RPJytvdLGJBKAwzwzIR5xzve8Y7VNwcYYIBvL/zF3/49115+Ma960fO48cpL8J0G7azDEweP8KWvP8Q9D+9msWVJq6N4UyHzhhyN8wqtPFXfZXIo5epLL2Bhfo52N2Px9Ck2jlSp6S6XXbyNpblTXHnJhagsY2Jiiuc+9zouu2gH504NkaZQS2qsLLVYWWmzsLRAUh/mG7ue5MR8m4w0LGqCtoxzeGTB750PhkLiH0fj0D23y1LA1Wvi4rYsuPIg2CbKMpzCC25+Dv/+536c7331S9g0WkXbNtpnuFyODXYerBNzKeKJLhAWZ66kobQ64bNDFrBiuoQytNodMuv5yEf/kW07LuDyK67iwx/9GFvOP5+rrriM5cU5Lr1wG1s2TlJRjhPHjrD78cfp5Jb9h47SaLTYMDHJeedt5ZzNG6hUNU7lwrQpBT5BkQLxeOR+KKXEVCWo42sjJgEiNIkAF817ZmdnGRoeAsQMwQTno7JOdShlUcqCUtI6XnxPpUBdwxXPuZ6h8Sl27tyJ1ilKJVhx+iRRKKRulccRj6kJi+CQV8lzvBvhg48tiyoM2zzaizlbDOu0windO1Y8/gmF7YVUGN+hajx5p0nWWmLxzAxHDj7J4sICI6OjjE9uYHhsElOpo9MUrRxbz5nita98IT/xI9/P9s0TVFWO8ZZEaRJTxTuFxoimm9MoDEqnYWe6lydFIPBKi3dZ9AdtpZBxF9rMlI7VFvk2mF+pqNnTI3NiwxZEQCBVXJ/pWAhW4kWiOR1IhYVoQrxxV1ryQxS0kLxFoie8Wm643r3V7Rm+Rb9KvbEnedQx70GzJJIMRbhSBotbSsrgEZM18Q3WC9crYAhf9mMVn8U+WPxXFqR693rOaMP4iI+L+2WsFbDi/Bcdf8v3khZeH1QpM+GOAgjtQTBXU/FwgfI7MrbiO96LWVAkMPvKiZK4om8y5yAI457e6XexP62H9fMf8xv7VS9P4WnfJ9FMCv38KeKM6LVxMAMKRY9v+RBGyX89orQ/mrNjnYDxN6cPwQwxt5bFpWVmTs+ytNKgUq0xNDRMNZwe5pyj1WyxsDDP3Nwc3W43dDFFvT7ExPgE4xMTVGtV8jyj2WyRZ12G6jWmpybYMDXJUL1GYkTjJbaRVESvXWP2lCpqvu9ZfKV8xXb1LvjdiWSy1uLPR8uvNIHoUMiYi/EfPXKYP/iDd3F6ZoZf/4//kZtvulHMtWLaWtHNc266+SYuvuAiNkxPc/FFF7N546ZgvitxaRVXA5LXVqvF7/7u77J7927yPMcHbew4jmK/lNEAnnAwAYgWrxYH4p1Olz179/Ddr389w8MjhdmcCnO0UnIS3dGjxxgaGmZubp48y6jXq3LshBMyODGGF7/4RQwPD/PFL3yR3bt3cekll7L/4GHOO38baVqRcEnCyZOnyLM8EPgGguaoL50yuv7Vaxc5kVT+JkYzPjYS6sqHjZ5AMMmvS6mRpTaUjgceiI+qlUaD3J6dVBKUO34kinr3fDBt98HrvdaGoaF6acZ5amwYG1l9a4ABBngGYEAqDTDAswDN3HPFhdsYNtBuLHNmYYmv3P8IX/z6w6xYQ6ZqqHQIi8GhyJUhR4mjZ5tx/vQob33T67jjxudw8Ml9nJlbYHlxgcbSPJsmR6gnnisuvRBsjlYJuTfiO0Y5xoc0F2w/nwu2XcjVV12LxXDo2DF2P3mIhY4joyKOkV1GErRUokmP0RqcLFCjeZQCcTlbCCDRNKhYLUmhC3sqsLZLY3kOnTf4g//66/zAd72MrZPDVFybhJyhaoJRitzmgSzROIRYSlI5ElcikwVdSKCX1nqIrwDW9o6ozy3opMpvvOOd3P/Aw1z73Ot473vfxy233MKmjZs4dOAAP/D938Pll1yM8RajLHmnw0c+8hEmJia4/8FvMDG1AYXj9ltvYmp6AmM8ScXICV3OBQ0ggyIBL36owsoRj5xwlOeWx/fsYWR0TO57qFZrWBdPa1E4B/c/8A1Onpyh1WpzzjnnkGVdlBKzODHMEDJIyiqEklKJqNvbnKpROJNy2ZUXcM7Gc/jc5z5PtT6C1jWcU+F98U/lFKGe5KjkssaAKjVpEG8KEknFz4pAJoWFdxAjnAonuhVxRaEkiCdK4gNLxbdoLc2RKsfxwwc5fvgQtUqNiclpRsYnSYdG6HqNTjStpTPccctz+aWf+3Gec8UFDCeWmnFUEgXW4x14ZcBFUymDR6FNhSSRU96KwsX8B2JGFvviE4TQPhI2CFbhKPXYzYR46pFIZY2zqDEUBaVIzkQhXRX/rf4bnHGHSAshviBcQvxaHKY7LyZqKphRmnD6nCIIt71u2P+5fK8QPfrF3UITqU/bppe/ImzpQzmt+J68G9NWfcKQQOqxSC9obPWe9tLwvleumJgIon2hi/tPC94XBIO0cdA2WxeqLw1K6RSmg32keD+kv/XqRojIUI7iv1L4cEPijdoZYqaojRBKZ0nqKfNAjDt8lnjlbhGu+K+nx3S2OCPKj4uPqvfFh/EmZFkv7Opynw09aqN8xXzJFUkh78TB9cLi2Ugl6XOtVpP5hQXm5uZod7thjlDU63UmJnqkUvQhlGcZw/UaG6bG2Tg1xXC9RpKEfBCZhzDPFvkOf/v6au9ZHMPlKxLZvnQ8vApzkTE6+IILRFIp3vj3nru/xuc++1nq9Rq/+Z/+E9PT0/IbH4hxpTVTU1PUa3UqaYXzzz+fifFxKUPw/bMaHnHS/dGPfpRjx47RarWK/BLGvC+cT4vmXz+UbFwhPuLm5uf4qZ/8KUZHR4vT7mIcy8sr7HzkEd75zndyw403cOutt3L8xDGuuvoqjh49yj9/9rM8/vhums0m287fxq233srefXvZtesxUmPYcdGlbNi4ibHxMax3dLpdzpw+g9Zygq11liSJB4CUyR+51uvrMvZkfhAfao48y2i32jSbTZrBCXmr0aLRatNotmiWrkazSbfTYXmlQavd4szsHN0sA0x/4n0X/Z8LQqkXRoW82TzHeUetXmN4uLbO3NA/98ZYNoyN9t0fYIABnhkYkEoDDPAswOOP7iLrtDk5u8A9O/fyqbsfZWbFYWpjeAxOJXRNlUwleO0x2uFshtaKPM8Zrlc4b+MEVd/hluuuYmHuNEfm5jm13EKbVJyDanDeMtvo8hd/8w88vu8QM7PzNFptnK7QsRl7ntzLkePHaHQcaW0URSIOt7FBw0EVCxqFHDOvCcdyKzF38krjSMXXjpYdvrhWjGru1uc4LBjP/NIstz73Un7qh9/Ar7/9J7l48yhV28DYNhrZcc1zUetXKJwSh9MqrmXDDmRv0aTBJyGvcVEkC6mo9SEOL3tEQO6kjvcfPsHp+SYj4xs4cuwMuVMcOXKU73ztq/n8Zz+F6zb5vte9hlqSgLXsf/IAKystpqc3sX3HBSwuLHLHrbdw2YU7uPTibaRVj/cWYxKwCm81mngMuwOVoXVG5sCbCrmTfc19+w5w/4MP4b3i5MkZztu2HaXFdMopT6vd4dDhY+w/cJTZuWW2bNnGjgsuEiFUg9KSbqwW742Y2IlL8J6mkNZYD9Z1qBrHJds3cPmVl/C1ex6ik6c0WpbUOHTiyLB0lccoES4dCqeM9ATvCrIIwGNAhXSIglMkjgLNFEkpBd47DJ5EO7zL0AQzPgupTuR0P52BXcaunGHu1DEOPrkP182ZGJtibHwDlfoYpFUypWjajGuuvIh/88Ov5btf9WIqdEl9jsHhbC6OzsNx4z6YJMpnMaUUbSKPDWYOYdO46E6+EKwDuVHy/RQFehfqF6QO5B1Zlsd2UdHBbSB2dFngKmnDUDYZAgiEgdZKSI3oH0mHTh2ESRBzMnlJUi7iiaSvj2NB8iZma9H0QsZZ9HcUfUUVEZZGXdRKiuUnCrHxbwzYS1I+Fye69ccpH0qMVLkCAimHDzv5pfyUEYXnggCMZFcpzpi1dSSqIs1em0S/WCq0TfwbwhWfYjuXND36iiHvxTh676yHHkEY57lYLWXEMOXP8VZZq0reX3udDb2+FQi0XoUVfU0V/afXtr389cetkLDRr4tW0n4xvKe3/xAdNqvw26Oi8B79vX2Tf35d4T9kUlKS20HzM8tyVlYanJo5w2IklerDVKsVEmPw1tFqtZlfmGd2fo5upytlUjBUH2J8YpyJyUnSSoXMWhrLK+RZl9GhOhunJtk4PcFQvUqS6OAWSDKkgt++eMW+IeNm9YVonYohtYzT0LY+aFs5awsCUetwBefMCoXRYk5ojME6RzfP+OdPfZK7vvpVbrzxRn7oh34IkyTizy/UuSLGEQqsAtkXNC/XvRCNn0ajwUc+8hF80FIi9IEy5JX+fyaQxtVKBZvn3HrLrbzlLW9haKguRJnWWJtz/Phx/umfPsnRo0d4+SteznOe8xxuu+02br31Ni684CI+98+f54Mf/BBf+cpXueuuu3jlK1/JxPg4lTThIx/+MPNzs9xyxws5b/sOqtUKaZLQzXIWFpfJrUepQAph5fdVJdI+qKApHTQNSyWJFdD7bZB5o9PN6XQyWp2Mdjun3cpotfPe905WXJ1OTqvdpdPNaHdz5KBBE37F1/6TVMLnMLflLgel0CYJeQwNg5JDHbTCpIbx0WFMoZgbzYblUjrOAxatFdOjA1JpgAGeiRiQSgMM8CzA5+7bzb0P7eYzX/k6800LSRWdVlBaHJQa7UnJGTI5vr1I3mlSMQbC0bDd5Tk6CzNcvG0LebfDc6+/ga8/8A20STh06AAT46OkeGpJQqfV5pFdT+BMlcVWzsGjp3hy/wF2797LmdlFMqtBJXiMaHEEx9eq2EsVQoC4dAqLEOU9yrtCO8VoSI1o5qgkxeJJKilKO6qJo+q7LBw/wC+87c382s//GFdsP4fUdklcVxYwSmG9kD0uCl+qSLXIE6wjFCmCmCICkai+K6qVCt0sK8zK0nB6mlcKkyTcdfc9/PzP/wLHj5/gySf3cecLX8gFO85n4/Qk3/GKl3DVlVfKcfMo7r7nbg4fOszxE8c5fWaG7du3cd7WLVSrVarVqmgyEH0h+EAiybHFxhi0Mihl6HQs2lTwKBYWF7j77rvJul3SNKVWq3LZZZcxVB9CKTEBaLe6PLH7CRaXFqlWU6666jLO37YFrT14R7PZ4uGHdnLe1vNKPl+i8LI+PJ7EO6rOs23zJi6/4lI+8cmPMTo2RCUId84rrNIkHiEUg+SnofC3FHuFDw5NZVHaay+BfC7IJRTVSoKzuRgtekOWC1GSGqglFtteIlueRXWaPP7YTjrdjLGJjYxOn0MyNE51eIxqvY7yGcuzx/nFn/oRfvD1r2LzhjFwllqaopXkr7ewDv04+o3CR0YObURo0CJBSBtqEcacjz6MBFEwi+GEtJQ2juVVhGrwwbF66LORuCFovxCOBo/xr+7WESoQUM7LCYCFuUuIV5KS7+HL2eML7RMdxYrQXsqvNkLGBi2kcjipz0h49cahCuSWxCWCvQpjUeINZARImPheqCi/6rn3wQ9IqONAXxTpSfD1CidzQO9RIEgCQbaeplMZ0u6i4UXQkDp7RQb0Cikt5QMBFkjt9fP5VJDyK3pttR7OHm94P5AD3yri7BXrPWqpEkxyI0mvQvmiiZ6QT2vTi+Xoa/dQW7FPx/oqwhTFXmeufwrIa/FXa3XNlb+Jo/hunrO0vMKpmTMsraxQqdapDw1RrVYDwdGvqdTt9DSVyqRSpVohz3OaKw3yLGNkqL7G/K0oeSTM4oTyTSGzZqw1L7dACcFscyebDy48VchvTTxMIBCr0VwM4MTJE3zj/vv42te+ys/+7M9y6623ih+r2D7fQp2XEd+7+uqrufPOOzly5AjNZpNKpUKtVqNWq1GpVKhUKoXj7jRNSdOUJAm+oEJfGB4e5t/+23/L7bff3tO8dI48z5mcnOS5z30u1113HRdccAFpmrJ161a2bNmCUoqrrrqKN7zhDXznd34nb3rTm9iwYQPdbpckSXj3u9/N0tISV117Axs2bWTTpo3UajW00pw+fYYkqQQtP9l4MGEOiLNQ3EzROmio9l2ReCpWKmE8lRpbxXZap46jVmzpt0WGQyRYe5dQixFhhgwbcKBIE3FhIBtakos4T6dpwtjosGxKlKDC6aU+nHSaJgnOWqbHRHt6gAEGeGZh4Kh7gAGeBbj+tW9jpWMhqeNVIoK6IjiM9ijXZSjxbDt3mjtuuYGZ2UU+/YWvkGNAaUxniVq2zPd916vYvPkc0uFxOqT8zd9/hJn5eVTe5eW338T2TdOMjo2x++gsn7nrAbqqRp5BzViszVE6pZM5krSO9YjjYuICShYtUcCQ5UfJ30tYXMnaSKG1oZtbVCKOhnWiSLQjby9z3vQYr3/1y3nZ82/lnMkxKibDZW0Spci6HZQxKJPilGgcKcRXE94XJle95U/Ii4q5E8iOryzgnPPkWUae56RpikeEeK0N1ubk1oNOcGg+/olPcXJmlmuvvY6rrrySifEREg0275JnXY4cPESr1aRaqbC8vMJ555+H1oqpqUmUUrhw3HBiUskvrk8bBgXe63AZrPWcmDnF8soKWSC88m6X8847n8nJyWJROXP6NKdOnWJqcpqVxjLjY6NMb5hCBT8Ri4sLzJw6zf79B7jooosYHqqzZcumUDs94aAssJehvCPBi+p/UuW+x57kd/7oL5hftjhdg6QqO6U2wwfPVR7Z/dbeor0cV+zRgQSk1B6rUxPEp1qJI3DnNcorEk3oK0sY12Fl7gwzx4/RWF5maGqK+ug41fooKq2hdCKH/3WbvPQFt/KqlzyPi7afS7e1gg8O45NEg7NB+yf23PBXqYIUcygxDUxSMXtQsruso08aY3Aux1lLWkmxuQ0aNtHPTiBTCpKiR9JEMVCXnFU7J8eAi2mNkBvaGHGoHIX3vl7da0OjdUFAFWZRXkies5EkEestKmJ8UbCPf33phDUdCINYzgLhe5wbopNueRQdmceRvKo3FOM5CFs+klIhXpAcn6UrFT15PaEsEFoEIaz/Wfgbnp8dvXxHcmZteClfEWlB4q3XDqvfpf/dNffLkL5GKFrfkzUFjAgaZKFvnD3c+ogkaXT+HcnF8hwiWemVvcA6ddW7VZqDQnfyXgRdF0g0yWsklUok1TqeuvsE9YAo+K9BfL2IzwsJ1Opw9PhJHn50N0dPnmJkbJLp6Q2Mjo5SSRNsljE3N8f+A/vZu3cfy8vLwdRMMTU1zbbt29i+YwfDY6O02m1OnzxFu9ngnOlJLr1oB5ddfAHTk+NUUhOyIHNooH/XNvc6UKrnM9CHfhZpsyzL6HQzsizHetGGTYyhklaoJGlBfHjvMElKnotz7z179/Df/+s7+dIXvsAHPvABXvWqV/U0KCMB+C+AD+sX0SgSx/HxfqfTodFo0Gg06HQ6YiqY53Q6HVqtFp1Oh9OnT3P48GFGR0e57bbbuPHGG0mSBB2016KZX7lfl/PsQ7vGd3wwDbThAIyZmRnuuOMO9u/fz1t+8he4/KqreOUrX06tXqWx0uTEyRm8L5Gy2ospeemk1lgmtc5vqkM04FYjhlv7pIRVkZVjX51ORBFv8bvhUUbM+5VSyEG50q5xc8R5R7VaYdt555IGs0wfOpZsSoGzljzLyW1Os9nk9uuvK6U6wAADPFOw3opkgAEG+DZDhxRXGSEzdbokslC04kxY4zAKxkaHecHtN3Px1g3ccu1lXH/FBSTZCs25k+w471x+9K1vZXxqmrmFRZYWF1CdBm/7ge+lXqtSGZng7m/sYjk3LLUsoxNTVIZGwMgJYJkz5F58LaXVYbqZRdZrstMWlk3h/54IEfdMPeEUGxVU8nHkzqF0gtGKROVUfIvG7BFefedN/Pn//C3e/LqXs3VyiEregk6TeqJQPqNaraCUwatEFtyK4OxS6kJ5hQqJiV+ioMVU+GwSOOewzpLnlizLMEnCyOgIK40V6vUhnHXkeQZezAMSDdiMV778JSTKYVROvarBZTRWFpibneEzn/ok+/btI00Tsjzjpptv4Nwtm9m4cRqUJ0k1zudUq0nw6VlePsrJabmz5M6idIIyFQ4ePs7dd99DlmU8/PDDHD16lGuvvZYN09MoIMtzHnvsMXY+8giTk5OcPn2Kyy67lOkN0zjnqVXrHD16lC98/ovMzMxw+eWXsWPHNrZu3QK+X6yKi01K/jdATMwqpoJ1oI1iyHiuv3wHv/mrPw80SFPxL647TvyMF7HG1hfIwt5Hw4wgKEq4op8I9VgIQgQzB7zHeE/FeIxt4VrzkC2xf89Ontz7OEZpNm3cyuj4OdSGJ0mqQ9LTbJtNU0P8t3f+Kj/5I9/PpdvPwWTLVMikTV2ODYRizGopx6V8h7+xyYKgG4WrJOzSRi2kbkeOrhZi0sopc8GcLdZvFOYlbvkb6z3PMim7EdOJJEnweOmrwY9If+2GeMIVyZ2oJRXbMhI/5RaKL/rwdz0Z0QdB3oeWiX+FoOoRVTqcfge9QkWyTppftCCcF4fmQrYJybu6LEBBegqRIJpB0d8QSHwx0z5+LZ6F+izdKqMXvtcXFaKlFIVO6NXdaigIpi1e6iCSHGdFqI9V96JDXBU71dNESLYX77fwrkDKJ4JtPI3tW0dMVWKJ2i/SZpGAVNHX1dMgrop5IlRnbCPpW6u1nNYrc6yY3hVbpu/y/Vfxtu8ZvHrK03ToJF76S98Lq4PQmz/Xz+NZUHolxkMR1ze/vBeiIl4+XHmek+WWbpbRzqIJlZhTdbOczAqBbZ2TOLw4c/fe01hpcOzYMZRSXH755SSJnE73zdrxm0GVfM5prUmSpCB46vU6GzZsYNu2bVxyySXccMMN3HLLLbzgBS/gFa94Ba997Wt561vfyjve8Q7e/va3c8stt1AJDtNZ5SsuztHxs8xFknZMP/ZLFQ7AAKhWq3LKbThB8tGdj3LvvfeSdeUkuTjPaa1Fw1TJJJpoTaI1Rin5Gz6v1VQCo0Er338ZhTYKU76CmWLvu8Io8U+pWSeOVRfe4tdcDuXFQpHoA1NBmImkjcIcvWZu8ZB1u8ycPMnMiZPMnj5DY2kZn4v54gADDPDMw0BTaYABngW4/NU/iUvqOJ3iPaSuA50mtVRz1dVXsvOxXTRbTTaOVfmuF93K9PQUwyMj3PP1+9m4eSvjE1O0Gw1mT8+w54nHmRgf47lXXcLI2DgLtsoH//GzNFYaDFUrbJqeYv+RY/h0CG+qODQ6LCrEEkeTJEZIJUVY/QpJIFSAEzMhRMuDktCFTFqgPF6J6V7eWqK1cJLvfPkLedPrX8WVF59PLZGztpzN0UphXS4+EsIi1zoVNIdE+NDkGJ/LAqg4LU3SFvTSjyeqAOLLSfUEQx92Lk+fPs05mzbhEdklCltZ5lA6Ja1W6XYzVpaXqaSGu+/6GtdcfRUnT51kfHyKbedvkzry4rxTAdblhbaK1gqbeYyuAA6HxSsRYZTRdDuOM7ML7Nr1BENDoyjlabebXHnVVYyPj1NNUxYXFjl27BhnZmeZmZnhxhtvZNu28zDGo01Cp91FkbDr0cdIkhSt4fxtWxkZqeN8IMuQBbjIwmf/KdG5CAAuOGT1QCvL8LU6D+49yLv+13s5dmyFihnDm3ZoEd0zg/TxhDeH91GLSbR8KPE0/SjddRmpBvIMY9uovMnK0mlOnjhKp2sZHp6iVp+gUh/DpRWU9uTdBuMjKd/1qpfwkhfcxsRQBZV3MMqjohPqQG4IoSGCvSvqQYhIr2TBrrw4a0cZdFIRsy+HkJexnFrjXB7Ik0DgBEesRMElliuYKayGCySQCM4SUEfCJJwsZ4IvmbgT34d4ilfJMTZBWHLOyilFZSEKguAKlDV2pDrC3RBe60LLKMYrmkq99KKfpfh+jC7mN5INkk6otxCGMDLj+yD9LqbVHyrUn1pLxBT5jvGo9QXg+JpkpRe4/F5/ZGUEciQ878/Banip5ZBgL/p19gVL9dKDvL8WkdwI+YZY2NVVsm75BUUBV33+5oiCui9prsW+Slk7pPSOCu/Jl7XpqIL4jJp98X0pY7mvEqNQoR+oYCa2TlWtt1SO1LWnX7lJ9iRk/EmqYLOcVrNdaCodOXmK0bEppjdsYHRkhEolxWYZs7NBU2nfXpaXeppK09MbzqqptGl6ksuCptLUxBjVSoLy9Ah2pVDraLSsjzBXhYrzQSOmmwl51OqItlJuRXM0SQy1WoV6pUIlTTBKo03sSXIoxKc/9Sl+8m0/whWXX8b9999PpVIp5g+esm89NWIc8W8kgniKOMvtuPp9wnu+RNr3zYMlrM57/G0uh5ubm+P2229n7969/Nwv/RpprU4na/Ojb/0RtDIcPXJcNn+0wtqckdEhpqcnCbrkfXGtO1fHvivDpXd77ZT2TcdmX3Wt81tefhznDBXGqnQtTZ47ZmdnybpZ8bslPh8N27dtLTTovBfW1eUZi4sLdFotjJbNEmstL3jebaXUBhhggGcKBqTSAAM8C3D5a38aG07m0jpFuy43XHEBr37R7QxXE/YfP8V7/vYfaLdbXHTuJHfeeiPTY3UmxkaZnV+kaRM++c9f5ol9BxgdHqbbWublL76Niy+8EF2ZoOVSPvCRj2C1IsssCVVQ4ueoS46Jpipxld0nDAWSRgUTKeXpdDJUkpJUa3Rziy2ZlWklDrkTZbGdZS67YBu/9FNv5TmXbMPkLeqpBzxOBfIhOG8Wn0zBjAqF9ZA78cOUJgqXd4SwcgZjDFluMTr4bAraFOBRWv6ebXGWZznDIyPs27eXc8/dgg++lfJczLoqlQoOyLKcBx54gKuvvBJwnJ45xUUXXYx1QbgrNtM91opDZ2PE505csnc7ObValdx6rPPUanUOHDrEk/sPYJ3n9JkzTExMcsP11zE1NUXW7aKNYdejj9FsNIoF86233RbMoRy563Dq5Cm+8pWvMVQb5rZbb2N8fIy0kogGkRJyRySmUjsGaay3mO/9tKhQ/8YpnEroAFblJDojdTknTq3wk7/4G7SSSXKV4FSFjgMb+onRiBZZEKxjuxakSvwZ8w5nXeFkVe57TJ5hXBd8h1Rb7r/vbvCe8ckNVOrjQiapFJVWqaeavLPM8265jjd+z6vZMFZB2RaJEhFNnJJLf1CUd1WD76xg5oX35NaSpilGy0k4HiEzTRL9mRkhnoLPI2vl5B9p/x5h4+Nx7yUTsejgWAQI6Y8SPpjABaFaqqDncDoSOGWyilIVal02tQvxRQE5+AtyQZvKeembiUlKRI/URQ+xH4ReGzt3+N95Lzv2Ja2D/vEln+WUo57JDGfRIIp1ED/LBwkf/fWoEMiHOHQ0ZynytwolgqyMXg69EMuhfQpBs49464UXcz35roI2mApEoPdBw2YNfHD+LqSytHmsr3JdSU/whHYv2m4doXRdqKIWy6vD3rjuwQezyGhaWQjgZ6vHkLeY3egrqdzHzob1VqqyYRB8hAWtJhPSX4NIIMTxEvoEse2DJpxoqZZeC++uB9krkGc+9JH4uo98ZSihyy2tZpsjx0/y8M5AKo2L+dvY6CiVSorLcmbnZnly/3727Vtr/rZ9xw62bd/GyNgYjWaDM6fP0FpZZtPUBJdfciGXXriDifFR6rU0kEqigwsqSv5PCe+DRlZBrPQ0TDq5EErLjRaNdodOlmOUopIm1GtVhmsVhmpV0jShkhjyMN8563j3u9/Nf3vnO/ie138373vf+6hWq6uT/rZCJID279/PzTffzMLCAr/+zv/Oueedz/z8GV784hdhnWdublFGRFhfTEyOMT09SRrGdaz7Ys5bBa/Arb3dP9k8FdYJJ1/9Gl5pbe8J86+S/qWVCaTSHGdm52Q+03KibqVWZce2rSTBoTt4vJVxq7xjcWGR5aWlQgv3jttuXp3YAAMM8AzAOttcAwwwwLcbFJ7UKKqpQSHaLwee3McjD36dxVOHuHDzBC99/i0kxvDEwRN8/aFHWVhY4szMSYarKR/58Ec4fGKGoanN5OkI6cgUdz38BHuOneH++x/hHz74d3Q6LTp5Rq4TrE9w1uC8xptoYoYsTVQUxuPl8MoF30CyBK5Ue0csG+WpVAxaOZTPSLQl7yxz0XmT/Mbbf4J3/Zdf5cZrLqKqLPWwQxuFIpQP/oa8LJSU1IUKJn9pkqBQZHlOHk65SVOF97mohQciYfX6bO0Cq4ckTel2u0xPT3PyxIlCYE2SCkohx+zaDKM9N990A8eOHaFarXDppZeKMB/yStRM8GBMQpqkOOfRSk7HS5IUkxgcoE3C3Pwiu3bv5eTJ0xiTMjIyws233MQdz7uN0dFR2q02s3NzPPjggywtL7Fl61ZuvPFGbr7lFqzNabXbHD5yhIP7D3P3XffwvDtu5/nPv5XpDaNUqkpOBFJiHog3/YQSYYXb+9L3uasg0wavkdPXXJsh12CsfQqevIuVh/+RH3/pJVw8tICxbWzWJtFQSQ0mOPvsIQhJRfRSR+K3yJFqxKzTddG2g8ra+NYSrflTnDj8JA8//AC14VE2bNnO0MRmhsY2ktaGqdSq4DtcuHWSX/7Zt/Izb30zm8brGNclKfkZQYkWgmhRhXwp5CQoREjVCozRJFphsy42zySrvVwD4ktCCIkeURN9Bfmg3ReJIFto8gSyKAiJsY/E3ETzMaMN3nk5VapE9olD2EgSrKpLwNqgSeRKgneoZhW1hLRoBeA9aZr2CCUPzgpJbIJpiPdyqtl6iMKXMSaQWRJnf54k4jIhFMmgs6GvVEoyL3UmpnJFd4oaXUU9noU9egp4KDQVIykmRGAws4rCVwjrw3wS8xffUyWyqTQFhCtqTmhUOEmsh9V1FcpC8B0lN0phni76+8V6kJPqehp10UyIviRjaeVanXOpv9VlWO9aC1fy+QUy5mL6q6EKDSh6jNc6gvrTQ8H49/K3KipFMItbtwTr57GMs/XwNXfXuxE0jc5SFeuiaLeYW09frq115NaRO09mPZl1dHJHN7NkucUFk79I0sWx1W63mZ8TkuHqq6/ujZFvJXPPMERSrt1uY61laGiIRqPJ5MQE119/vfjQqlSCBnMwpQsmnkop8auk/Jq/ay7i+mTVVaxbvsm1TrgY5+q01KoLCO8EveHifoij1IXi3Lp6tHk81ntGRkeZmp6WMfUvHpMDDDDA/68xIJUGGODZANsRTY28QzU1ZFlGu5vx+S9+iRMnjrMyP8NLb7+e73jJC9BpnSf2H2HXvoM02jntdsabfuDN1IdG5Vh6U8OaOiu+wqe/cj8PPbaXPBOfL1nWBRTOKazzeK/Ff5FIln2XKhwvy+JXlsGQ5ZY8ON3Msw42a+O6TVI61FSHUZPxzl/5Bf78Xf+Z1730FjYMK1LXpVZNyKzFKhO8BMh+vRYdLTROjqZHFjci9AXTJCyJcnjXodtpgM/R2mNtFoTlsCAqyRFnWxLHXfPh4RG2bt3K0WNHsdaTB80nk8hunNGKxCguv/wyarUa3SwTIbC0YIy1kmc53SzHe1BonBONMJNW8Bgy6zh9Zo6h4WHSSoWRkVGuu+46tm/bRr1WpV6vcejQQb7w+c8zPz/P1VdfzebNmzHGUKmknDkzyyOPPMyeJ/ZwZmael7zopZx/3nmMT4xgEgeqCyoPi04NRG2d9VCuGSmDSSvoNMHpnNS0GHWLJKf38sRn/i+HvvYPjC0+ztXjK/zMd93CeZunSAzgc/Ks07fO9J5AXqmgEhAWq96hvEW5HO0zEp+hsjauvYJtLXLm+CEee/hBVpaWGJ/cyMTGLdTHN5HUxvA6wdkuiWvy4z/0ev7Hf/5VbnnOxdR0h1riqaZyUlt52S37/+HkGxXFP8lkp90WzRvv0AoqiRZiLAgbZWgjJ/0RBGRrbXEkdpKII+9IhhQoab4Qxo4OjmpV1P4okVDiHFtOYpI+HzQ5zrJ4j5pW0cdTkqaByJIGEGGw9658l3wo3dM2khOi5L2C3FgHotkifltW10+BoKklRJvcOEvIQpCJZpZEjY3o18MH2UUXem6hl8bPYT4qX0Xs/SjeCWRXQQohJIOcmtcL6Uu+dMrpxVfi/fWuIrQntENxsx9e+plCCD7P2dv6XwtpM6nbog+uSWttRkOXwYdiKxXL32uTp4MiZrWW1ClDlebrSOrFCnyK19aFCP3rvRfuK9FgKg5lj9N5X1AJu5pYWU0ErXl+lkZffdeXbz5F/41YHa3UULi8EpNj5wOxJCRSJ7N0uhmdLCfLhWySZvVkoR9opVleXGL2zCwK2LJlSyCav1mOnvkwxrC4uEie52zbto1ut8PIyAjVSlVOntNC3Jf7UvFZOujav6uu1YTQepcOGnU6/GIr4km6Z7/WSWrNJXkO7/Q9KF3InF7MvaugVPAlpRXDoyNMbdyA/PgPMMAAz0ScTSoYYIABvo3wM295Az/4htcynHhU3sUkhkxVsLUJ7npkL6dm55k9cZDbr72MKy6+EJ1WuX/nHh578hizK22c99x5551ilqYTrE6wuoapj2PTOjapoXQFo0XtvlhgeId2Du0Vyuu+SzRdepc4zZZT2ZQRp8JGOVJydLfBZNXzPS+7g79412/ymudfy5BdwXSWMXkL79p0sxYq0VgFViHCg3cYH04Pi4YAwa+NR4nGku9SsU1qdom6WyFNkBNwlEMbJW6VCpIn/n925Ln4xPFOjl6enJzi+PGTgCHLrDg+DUe9KyW+FPLcolUSCLi8cIIZU9NB60PrRE7z0gmtjuXQkZM88uhu7rv/QXZcuINTp09w4UU7uPLKy8myjNnTs5w6eZqPfewfmZ2b48abbuL666+nXquD97Q7bR64/wGefHIfnXaHyclJrrvuOqamp4OgLIKFVsFduYpCVdiNfkr06sx025jOElW1hF/ex6lH/omj93yYsZVDbKjmJLZBxTawCyfYuklIpcSIk2lJK/YX0RDyBCmxkPoteCvt7DJ81oJug8XZE+x/4lHmF+bYsHkLo1PnkNYmSasTGFMDbzG+yQtuvpL//bu/wauefy2N2cMkroHKm3TbDbKsK76bykRlMKNU4XRE0SAJGmmpwQVCLFHSh/tNj3r1JottWXBHB7DaaAj+QRRBkAwOuqPwHn3PEM3Rgl8iHxbxIPdjG/qowQRkWRbGwfrt54PD6NxatNESPmik+OBQO5p5ST5dUf7Ytwnxq5DHdeQJCIKXDQ5+i/Dr5UtBlmdiJuJ9EI3WR5S/olYSJaEt1p08D+MwEMa9VNdJ/yyQeqQ3K0QNqiiYxXyGvhrTKeddtMIi4Xf2tFWhoVQ6/a9vDPQq2kUH131aIetd/0qE9lWxr4U+FlEku056PtZ0oTkWiJa+UE+NskkowWF4uV/32kfuKYWM4GJu6yGE6LtXRtE/+29K/ovbcsiDXBKb/Lr1Chb7QBnfvMxnCREHVq+iV0E2Jc42AD3lvhERC9TfGD4Qys55cufJLVgnlws0e6DrZOMkYGFhgb179zA5NcUVV1xR3F9Tl99msNZy+PBhvPdMTU1x8OBB2p0OKEWSpjLeg1Nw6J/3pPoDVRNMNlGRrey/VHi1fMXxVmg4rSGZggPudUio2Irf9IrcEV5aP2zYSWnCZghhTgjm4HJfQsjvuMcHX4sdm2MqKdObNhb1MMAAAzyzMCCVBhjgWYChfJFNw4rv+65XYnyGtxafDtFOJzmw4Pjs1x6gsbxMZ+kMr3nFi8TMqjbKQ48fYGahweLSMkO1CtVEYW2GNimpNuA8LqmwnEObCk5VsU7jtEJrT0KOyTtoFxaq8WS1YhdX9cglb/AYrDY4REg1WrG8MMvbfvj7ec///n3e9qbv4txRzZBdoOK6KK+F8FAOyLG2hVIZKPFBJPEmECglqzSWBIs4+VbektgWNd1m8fAuPvvh99NsraCUw3srC6D11+NnhdaaPMtJ0hRjDMPDw2w6ZzOHjxwlSSs4F078wpNluRynHoyr8uLkE1kIykJe3GFoZcQxOIZDB4/w6KO7OXFyFpA0lPJcd91zGB6uUqkaHn10J5/4+D9xz133ccGOC7jh+hu48MILmZycJEkSzpw5w4kTJzh56hQTE5PccuutXH/D9ZjEYW0H5yxGp3hn8D4FkrCctKF+V5/SUq6ofkFlKJujvnKAE/f8I7s/9Ve0Dt5FpXOU1GR01TDLeiO7ZxV3H5hjudEsFruJEXOfXrTSX6LfEyFrguabsyhnydpCBj2+6xGO7N/LcNUwsekchs85j+rYJqr1KRJVwXVabJ0e5p2/+vP8/I+9iamap+o6JIkHLN5lJMqTKFeQSDru5AZfFiJMhsV/uPJc2tRojfMW7yzhqEMIsoG8JcJtnsuuftTy0EpMoSIKYqg4TUnI0UggxdOWtBFzN+mz8R0xQ1MKbC6mZdFEqSx8lBEFcyFlhPAgkFcQ/C0FYd4H304iwPQETwKpJYKF5Kcfkq7zohGlgmZTTwdrbb7i1yK+Is5y2NXplIT5wl+T1J2Y8QUTvfDdF/Ge7VoHPrZlIB6QeoiOolU0awvtEf0sEQioWJ8qmBYWka5CjJ/QbySUxLH6kjmxdyR6fH/19a+FCtUb+5pWkfTrwYe01ylSuFU2QZQZZm3g1d8FhdAaCbu+ySJMVyHGMCyKe8XHfwFU7Nsl/iU0TSmM9Av59xSIFeQjERlvPjXWhAg34hiMvx1PibM8790uIg2EQNwAUjjkWFMVfr+kGJKuDZrG3nvm5+dZXFxkeGiITZs2CbG7ntPpbzMopdi5cyfOOer1Ops3b2bfvn1y2IFSdLsZzlrpHQXxHUkXImMTTNTCd6nlVddaxP65fg8vvbPe46eNXjx9mnhhDPd6vcxrvhjcPSLMK7DOYuNvG55KNR6UMsAAAzzTMCCVBhjgWYATJ06xsrTApskRrrvmYrxr0bFdWtbRJWF+sc2J47O0mx2GaobNGzcCFawa4Yv37uLuh/fwsU9/FpVoKpUkkEMajZiYJNUKzvpwT6HwhZ8kwrHzSslpXq7kO0QpMAqMdyQ4OYHNd0loMzEEt157EX/5v36Ht37fq9kwrBmvaxLtsLYrCxIv8drc4a0lUQqsRcVjo8NqX+sKCiGXskSzkhiaSULXOZLuMsce+DI7v/IZmjNHOLrrAVzexnuFtxrtVPD35NEOjNNSBuUlTEGWxXWfCMp5nmOSBJMkJIlhamqCI0eOiPBoPWmSYowcPawVGK1kZ1FrlDF4ev5vEOoE6xyNZpO9+/aysrJMtZKgleKaq6+hVq3RanZotzI+/anPcPDAQc47byvguOTiS8TRufPMzc7y6M6d7Nr1GN12m2uuupIrLr2EamLQ3pEaI78MicJpj9ZRjBAR1qugFYQl1aC1k3tx8esdigzjW1TtAunyERYf/zz7P/8+5nd/heFsAbod2jZlplvnsTOer+1b4OBKFTe6FasqeF0hc5rMaXKLnMKnwmF82uNwaOMxZBjXJnEtdHcF25hn5uhBnnxiN0ppNpy7ldrERtKRMVSaYhKFUR02TVV46fOv4zd/7Re44qItkLcwyuJ9jkHhrIXQV60vEg6ClezlKuQ0OaVSlDPS9tqRpCnaGIxy1LoLtE48RuPkbmpuhdRnaJuReIeyDkVCJa3hrQjk1gm5VBAPIpmK1ltuIcieLmgM+HiSm1LkWSZ5Dk6vszxHaUWe5+DBJAkEU6VCcllHNtFaNJ+MMcH8LbxXjNlAavQJ8OKQV0VNq0A+OReIspJDcHkmAq/34ehuYzCJEeEioE8gjqRZUS8yeUh/kzj75KMo9EfNoSA/FRpe8US8oCkmgk5PE8U7EfDFF5QQRvJAKium5Sm48pBIEKBU77Q6Ia+ERFI65MuJECXFCARTQajEMpUqoPgY5rTi8/qImkpidlhkHoq3enFLzfXKXiZBYmpnu3wgG33Qiir6bQkx7HpQJRIufvdF2/cI0lg3q+NxoX2LdlYI2RECx3vEdkLas7hXqoki/lWFjMOw73580wciqMwHqWDuGfvpqvs+5s8HKiaQBz7+poTNhNjXvHfir62kdRLTjn4IvZI+J87GwyZNkfGngKIXrri8nHCqvezJKIcLpr7xH8F0HBUdnMtvvkLmsUpaJU0rtNstTp06zsL8GUZHRxkdHcUHYjvP86Ldvx1Q9CUvBw9451haWqabe6bPOY/NW7Zw1VVXisaxUuQ2Q4vn6jBexc+jmJMV3aL4zTnbvzUdds1F6W8cCKVrDcJGwFOgN24UPmjreiebHcYEkh7kdzL0Dee8rJNQqPBbKpEojDIoLb4iu1ncEBxggAGeaRiQSgMM8CzApz5/D2fmllmYO82dt13P9VdfhO8sUtVdUnJ87vC+giNlubFC1u2AN1hqtNUouw+fJjNVSFPRQEDhnUIpIwtJPEYpEiWHzCssHodTCq/k5DMXdqOCbgm5s1ibo5XD5W2M61JVOc3542waNfzuO/4dv/sbb+fGy7ZQc8skrolWOcporKlgtQFtggCpMVqcHFeSCjgxKxFBx9HJHO3c01YJyyZh39ISH/zcFzi9ssLskf08cvcX6bQbZDZn99c/R96cxyhZPDtrcUpIJYXCWNmhlkWT/BeXb2LEFwQGBc5ZETCVY2pqgunpSY4cOYI2BpuLM2UJbnEuLwTcLMvxgNKG3FlxgApoo3ls12M45bnssou58opLuPqqy8F7lhZW2P3YHh59ZDdZ1/Lc51zLeedt4YUvvAOU58TJk9x3333s3bOHUydPctmll3LNNVexZfMmqonGdlskCimJUjjlseSAaCWVhZeesYMIHBYrn2xOgkXnK9TyWZKFfRy95yOcfOCTVBb2MeyWwULTjXBoqcLX9i3z2JxiLplmkVGOz3ewGHILylTp5gobTczweJ/hfRelLc62qeoM31lBdVdoLsyw++H7aS0vMDQ0xNjkNJXhCbq6hlMam7VYXjjBrTdeym/86s/y02/9XiaGPK6zgibH+bBjaj0G2X23WovmnJI89EmXHirK4CxoldDNHS2t6OiEjnOkOmfpyC7O7P86p/beh1s+Qc1YUuXweUZiEsDgPCRGowGLQgcyR3b8c4yREwjleGYvZGUwQVNhXe6Dw+zQ9UQQDdoAUUsmzzIxtSr6ZhDICwFBIM7gxa9SQRAEDil+FQImEgoloqoko4g2gog9zkm/cXhyZ9GJ6VWjErLUh3hjXpQKhSm+hHSL9MMR9MaE8oRR0sukZDyUv2w6KPUm932h5RJJikBQhDjiMy8ZFHI85MtHsi1orTji+Aj1GmW3QLbEug//FeFiOpFMEDM/KX98V5Zr8b3y57Mj8BJrWjm2X39etAh94YGSgCGZ1cRDCKMkfRVMIbXu7wNF1EVi/Yi3fAgm2nq9fmWD5qbuS7MvhtAuRXUV+UfFU7V66Ut+Q3uHjBZZJJj4rnfFfhCuPsSqDVeMS/718qaCw30h4FQg36PJUHksxv/D30gklR0hR1MjHw+46JVR5soysRQzuRZrylmU16K0Q+lIXFnp2z6SsL0xJL+L8ltQ1I1SKG1otBocO3aE+dkZbr75Rur1etFndOmUxGc0VlWtfHVk3S779x/Ek1AdnmTDps1UKhWmJqeInKNTHq/Dr6t3omEYO0KpFz3lv9Cv171KPTbylKWuGvK6uvVLz8vcU1kzLzxzKKzv/QYoxI9gsTYK40YjGyN96YT8JTqROS5s0MU10QADDPDMw4BUGmCAZwFmFzPuufcRZmfmOXPsKC+96Tk878rzuWhSs33CcP01F7JpyxTNvMuuJ55kYamJQzRyulmnMJkR/ycImbRqQah6a5JV8FSNIyFHR8fcxqDSCk4b2t1MTIVsxnmbpnjHL/0sf/m/fp8rdmzBtxsol/VIDU/h30b+llORy3qP04rMObrWQZJgjWalVmdvO+fPP/Vl3v/xL3Dg9DwnZmeYOf4kw5u2sDi+hXNueyE33349Q6pJlSWsXySrdHDK4pQXokU7jFWYePqZKpZQko+4Ax1NsxAzIZvn1Os1hoaH2bt3L845siyThZRJih0+pRRJkshCzUoYpaCbdWm3W9x0043ceeednHPOOVTSlJXGMo899igPfuNBXDiB6c4X3snlV1zONVdfxcjICEeOHOGB++9jbHSEHTu287KXvYQdO7bhvSNJNCghJbI8wwVdduM8ifOAwypNrlIsNSwVIWnwdKwj8xqSIbxOSVNN1TdIFo5w5pEv8eQX/x5O7GSSLjUqmHSKk80q9x9c5uHjbRaSSRZ9hdlWl8Wsy9imachbpCpDuy7VVMzIov8b5T0V5akqS+q75K1l2o0lDh8+ypETp6mNbWBkw2ZGpzZSGx4hrSRUDOisxWU7tvDLP/8zvO2Hf4DRaoLrNtE+l5PivEV5G4S0IBkiu8XiOymQaH0ChMJ5gyInN9AZGecbp9t8/rFD7Np/iKyzQrs5jxoZo4ti5tQJVpZmyb0jTyq0lMIZsL6N9W1yWqgkxzrRMPLIqX95lmGC9o/WmjRJxGwsTQozEx3M58QHVeiOIvUVxER0uN1v/rYWcgpbz2dSPAVOdpp7mil4gkAZTN0oDYPoz6ePFJFq1YXj1hDch/qO2iZhIIvGRSBaitFdFCmkIeUWQb1HxOC9CDnR11N4Lr6gRAgqCAYlRJOEl2cSRvIt2oKxfCJYlysvxv9UUEg8Yk4YpTt5RykRuKTfSbyREJR3V9fB07nWQvIZ0iH0DVgTXr6ViDUf018fMXz5Tw9qnR+FkMeiA/TKGMmk2D/7fUL10Bdj/FJOKoTvvVfOZSQuY+LhRSWflYqfv/m1nlDfP7CCWH+2wRbKGtvXlzTr+lFO+FtFKV9ny0cJkpN/eXphpICCTrvD7OwsJkm46qqrqdVqENu6ZI767QXp151Oh/sfuB+0/J5v2XIu1lnqQ3VZA5X6f0Tsev9qxCG2+v7ThCr+W32/17axX2ktWto6mNymadDaDVi9TivDhfkoamwnJmgwDTDAAM9IfLvO6gMMMEAJi80GR06c4K6v38/ycoNTR49zzSUX8bqXv5iXv/B2duw4n8Vmm11PHuKr9z6IT6pgEpJKKqYrGnxQYZYdqbinK5C16tkXA9Y50UyKCvvekuUdbNYiVV2aiyf56R/9fv7P77+TN7zsDiZNTsU2qaguhiycFEfYNtN4Z4JfnbUrJ+s8nSwnR+FMQtvBjKnxd1+5h9/7kz9j/uhBfvzVL+LfvPFVjOsFcn+GdPNmHj+1wuj0doZSWDywm87JvdRZRJmueGTyQiplRnbVVHCaW2QrLMZ9WDTLqk5OJdPxVCwPU5OTbN++nUOHDxUCfp478syGU7rEZEgpxZP79/M3f/M3HDlyhEd3Psrs7CxKKZJwBHuj2WDPnj0kacrQ0BBXXX0lN910A9VaBWctR48d5XOf/2eOHTvCVVdewVVXXcHWrVvQRgRMrcURufMWrxyJUSQ+I7WO1CkSp9Fedk+NUxhnME4IRW8MpFVwkOZthu0Stc4Jlvd8jSe/8CEaT3ydamOGmu/Q1nVO5qM8cKzFPYeaHM3GWK5s4kxT084M9doItaRKa2GJlfkZqiqjQkbiumjXxdsuiVZUFCQ2Q3WamKzNqWPHObD/IO0sZ2RimvFN51IbmyIdGqFWr1FJwXWX+bEf+l7+n1/+OW699jKSvElVZZC1Md6Bz4udf+nB8ZPqiVhBmyXCK8iNopHAfGI43O3whUd38tm77uLxfXtZWGqw78AJGm6EE8spQ6MbmKgnjPoGlbyBz7t0MznpLRGbB5TROJeHPhFSD+SOd54kOnVVYLQJWhxCaDjv5bS4Iv+QhL5lwnuRNHFeNO6c7REXZTjXI2CgZ7pF6O0uCsByQ/pq2HovC/8STvJbCNVKtEfKPldi/sThd9QmCcSKUjK3FBxMGFchfXFaL3NR1FSKOdBl87MgwKhAaEndBhO8eEJdSQMp1qEqRxhS9aW+4MsaSNE30CoChPCeUtHsrdeTfMhHQSYVRFbQfkLqTuoqTHff5Crnt4yeIL+KBFvzsRzBWSI7C3z475vxFz5M2+U+4gnmYYFYUcE5PeVwMXCJI4ljVkZs+Faqz16IWL/hfiRCpVsWYeLfp3WV89GXnzLW3oHQrqX67bXJ2eu83G7xc8wLRJOps6QXwz1Vw/ShiLX47PtyV065DOlnCsWZM2fYtesxvPds3bqFNBDb0p8jmfbtB+cdMzMzLC0usXXLVtrtDhMTk3gP1WoVgtlvnO+kL61Xl/9yhJVJ8b1Iq3yt237rYW24okc40agl9EmjdJFu3zTj5fnqfNnciok2ohUu2ngDDDDAMxEDUmmAAZ4F+NEfeROVWsrM/AKf/uLd7Nx7lP2HZ3jokSfY/cQBHn50L5/50j18+Z6H6OQJXavIgVa3Iz5svAiwsvMfjupeg6e4m6Q4pbDeYQyk2lKhw+UXnMMbXvVCPv6BP+f7X30nk5WcquswlHgqymJ8eZERF7EKXehlx8VTKS2tSGtCinmTcHJ2nv/+p3/OwaMn+f5XvYpf/MHXszldIW2eYCxxNBttRrdeTiuZZHx6K3t37eHEE4/z6Fc+x8yTu0hdhgkuJrzvmcLJqiounkSXpe8KEp7yXjRNFCSJIUkMtVqN8bFxjh47hnOWSqWCMQmVSoXEJLID7uGCHTt44/e/kX179jI+PsaWc8+l2+lg85xWs8muxx5lbHSUDdPT3HLzTQzX6zSbDZy13HPPPXztq1/logt2cO01V3PxRReglMfZDO/E3M7arNBe8HiU9hifIW5YNTaYgYkxhZx6Frxi4X0OrsOo6jDcOkV7/308+fm/5dh9/8RI5wwV28GrGvN5jV1zmruPdtm7UqM5vJUlNcp8G6rD46Rplazdob28wsTIMI/tfIjmygL1VEHWoKYtVeUg7+CzLnm7yezJY+x74gma7S4bzjmXqY3nMDIxSaU+RKVaQStHJYE7br6e//OHv8erX/YCJuqaus6paYv2GfWKAS8nrEkjivq9V+JBCkDF03KkkQGFU9K+XWWY1ylfeOQx/vYTn2Rm5gQvvelq3vaGV3Dnzdew5dzNuNoEp1spPhlm7uRx9PJpTHOWuu9S05pEKbz1OKdwzqCQE96i4KvjMe1a0+l2RAjz0Rm4aOFoLWRGlufiZDvkVeswTpUK/bQ3UmLc/WNWwuhIPKkwvpyEEcKEwrmsCsSNj+ZtZW2hshjixRkrIV1rLWmaCqEZTpkj+uIIY4Yo+IeYevkuslnk1TpxQK5ieUNJbTg9T4V0I2kk81ePVBDSJoQphY8aWZFUi2RcmXxSgSiKBEEkg9YiaHqFchWtEeIRsyJJO57kF1kiF/PQK/i/CpK9QFqF6Ip6D4/K39em2NcIcqccqK/46+S59FUH4iw6mLc2mABpqa9ulqECid6P2FJySZlCwpGUi/0z1K33nkQL0ZpocWpPSayO7vGljZ/etZZRWo9ZWluDZfhIsBSfV4eQyIr7a56vheQtfF79bNX39dDfauW6LmP194BQN3mes7C4yBOPPwHec+21z4XQJpHw/XaF1pr77rsP7z1btm5hYmIcFX7/VRjjkVQCqbP4t7j3dBEbq3SV10T/Eih6LrzUGrPQ8smGqjDlS41BBy3rfshvlmzVyJzmvZwGh3hECAfZKZyzLMzPr3p/gAEGeKZgQCoNMMCzABecv4HnXHslK52MhUxzz6MH+OSXHuDTX36QL9z1EPftfJKTCxm5GSFzCbk3KJPgcGS5EA8gQhVxpztKQYWWztkXvM1OFwsY7VBZg8bsUV7/yufxP975K/zij7+JHRvrjCcdKraJxpG1W2hE6LHO96njKy8ERxBHABHKQBZl2hjQCRZNq2tZaWc8eP+DvPbFL+H2Ky5jWrfpLJ9k9swpMlclr5zPEzPQUeMcOz7LjTe9iKX5ZbrLy0xVKlSdx7i4sPIoxBTOI/4ufDC5s1584thw0pwP+QcxffM+OC7WikqaMj09zeTkJIcOHSqcMzvnsZkVp+coKmmF8dFRXvayl3HxRRfz5L59fOxjH2Hf3j2kieH665/LBRdsZ3pqAu8sWsOT+/by0Y98GKPhphtv4IrLL2NqagJwVFJDtZKSVgxJooPZYTzW3uKcBeVw2pNpyLTGhZ8JpSxKdVGqi/Fdqr7JiFskWTzI8a9/gmP3fozq3B7GWUY5S0cNc6I7zAOn4P6TipNqM4vJJk41PFbXGJuYopvlzC8sUKlUqFRSVlZWmF9cZufOnTRXFhiraVRnGZU1odtieWGOPU/sZu7MLLWhYYYnN1EfnWBoZIxqtcpQrULeaTBS0/zqL/88P/4jP8CmiWGM7ZBiqWhHaoKafVi8S08y2L4DlkN38sFxaujqXiGmf8qw1HV8/Mv38rmv3c+N19/IG1/5Um7cNERjz9dpHNuNz1dYyi17j89SndyMxXDswF6OPfEwtBYYrxm0dShv0KqKtwblgj8UL35qfOjTzloSI2ZvkYTpmbvJeNQlgiNCBQ0lAhlSDNCgsdNDb+AKoRTuqCCghvQ84vDbedEAigSYViLYu2jGVYJHNKtA4jLGkGeZkCzhXgxXRnTMHcmeiGLUB6JARzO5UB4Vnjnneo6x43MVNYnkrycSKKF9Q34KoqhEQsXvPfO3oG5TIiYiVpeF0vvF9ziDBbKKIi8STsgkoTr6iYa1sT8d9PIfzcqkJovYwoenjv2pn54dvXKXY3Dhd0Q0lMTpfJwHdZgnfTwZsKhkyXeBUuX3ZPNABJa03eIYpvjZKv+qxEvCrr57tmvtnd4l/30L9VWYvq0aQZ4Q2eq4VO9jLFv4LE/X9suIb05cxF9XCddLefX3HtakrxSzZ86wuLSI1podO7ajAmnig4biN8/HMxPOOh5++BGUVkxOTrJhwwa63YwkSWUMukB6h/LHWvj/t9pYrw+VvyvA2ZzlxUUW5udoNZthbgnjoNRR4ppREX5PvRxOkiZJsXGTdbqsLC33XhpggAGeURiQSgMM8CxAY/EMz3/e7Vx34804M4QensaMbkINb4D6FHpoClcZxSbDYCqgDe2sC1oFUynCGeqyOBASQhZHxRo/LCC01oXZgqyFPdWKRuVNRlLLy+64lr9/zx/y9h97I5uHHVW7hMlWcFlDtGeUgaRC14HTCUpX8EFjprcoCRozQeiVS5Kz1mGtp93N+cv3/jX/411/xHt+77fY9+C9nJ45xULHwthWZtw0h9jKqQ03cffhDFPdgG1Y9pxqcfntL2Ip0zz80C6as02MTtHKkCiFCafxWBydTodOt8tX776bv/rrv2G5lWG9wXo5tUxORkmkeoLwZK2lm3XxwPDwEFOTUxw4sB9rc9mpN6LNRPBR4L0nTRL27tnDV7/6VU6cEIfb1sppYErB0tIiR44c5rOf/Sxzc/Nce+1zuPKqK9i27bwgpFmMVkJuOYu3ot0BHm3ENE9rg1cKn1ToKMgSh0ssuc9BO7zKcbpNqhtU8jkqCweYf+iTPPnZvyI/dB9j2RmSvEXbV5mxozx0Cu4+6jmqziMbuYjFzhDdrMrU6BQVrVmcn6WddRiemmI5y2jkOZmC0Q3nMjwxzYMPPsDsqWNUlaW9NMuJIwc4cuQgleoQkxs3MTK1kXRkEl0dxgPd9gpToxV+5q0/wP/8nd/kwi3TVFyHxHdxWZss6xRkiHWebm6xXiPn2CnxIaY0KFP44pF/kWRRYBKcSnBplZnFBodPzPHm7/4+br/4UiaWF9nUWuDyDTVOH/gGe3bdTVc3aSpPd2SKHTc9n+FN54CyDKeezvI8qVZoneK9oWKqpK5k8hbGmWhuCMEUx5ZSYkYmhCAQiBOldUE65Xlw9h4uHcpDdD4f/BqJkEdw4t37HsWdKBfEMR2JFhXSsyEuSo6IJUuSR0W/ppKQPaK5R3TyHcivSHoQNKIihHgpvsVX5b0ojBeEkZhRJUnSr2UVn4c5iajMoYLgFL5L+XraLpIPST0SaZIfyYX8670nwlPQ8Apl8ZHkUqKB1GdqF9tOBYfXhfBVcj4esly0ZggT75SehH7bQ8ybJ5rQeax1otUWwqoiD4FsC9HHLJax+ll8vxegP0w5rA/EEeEdcewd+ptShXP42AdtJArDd4ksphojjQmHdOIVReKYfkkDL/5dD5F8kqtHM0fBt/xsdRml/8Y+HPtF+f5TXeEdH08PI/ijiWSghBG/XP1pyoCJFRE+xwCrSKreO6WqQuqn+BEtFUqF+zocVCC14bHO9TvzD3DOoZUmyzMWFxcBxYte9KLCaXpM+9sVKmhpHT16BGcdGzdsRBtDq9WiWqnIoQtao40hzzOss4XmltammHdWY21/CVf457w4+xYfcGuhlEbH37V4aXGMrYOJNb63AUDoOeW05PdG+icenLMsLy6wvLzI8uIi87OznDxxPJ6TGrqUaLd3Op1Ci0l+z6ScLs/RStFqNllZWpK1yQADDPCMxIBUGmCAZwFOzTQ5fXqZbedfSGpStHMYHFp50UxRHqvB6Xg0cVxfyq6SRoeT3qJA60CvEiYCnBMbeSWSOM5aKtkSN1+xjT9/13/mN37pp7hw0wg136Tiu2gsLjiCzpQh15pcG6wSLRkhlMJyXgE4lBKNGo8shFRpDZ3nDrziPX/xV/zxH/8pb33bT1Ct19lx+VX87/f/PUt6I+///KP86Se/zJ9/4jP82Qc/yp5HHuXSLZu4/Y7beOR0g8XRTey49YXseM5NjIxvFCJBSR6MC+JkOCXLOU+z1aXRylBpjS4JqjKEUxUa7ZzMRsG8tOgPi09QnHvuVqamNnD48FG0MhidCImlDVongMZax0UXXcQFF1zAy1/2Mt74xjdSqaRoBd7mNBsrnDk9w9TEBM+74zauuPwyxkaG8c5iVBSGRBzok8IkJ73LG/JuQoqh4iwV26HqLRXvqNoO1dYclcZx3IGHOPDFv2dx5+epNk6Q+Jw8HeWM2siu5RHuOeHZ2xqiUd3IUp6w0moxNjrE2EiNxfnTrCwvUq8Pga6w0sppdz2drqWx0iGjSm14konJDezbu5cDT+7jyX17abZaTE5vZHxqivrIGElaRStFajwLZ07wHS95Hr/+yz/L82+8iiGdUTeWxGco2xU+QSGkWbzCWX1lcdH7aEIlL8SWU1qjTELuNR2v+cauvfze/3gXd1x7GV/74udZabTJfcLsbJMnTywwfP7VzFc28cixBjaZ5AsP7uUDX/4G9QuvJRvdQMck+ASsFnJSaQe+jVEZient9EazskiIKIJfnkiUhHDEhT5iYhFNqJSC3OYQTimLl8djkgRVcoYsJGWvb/SJnUrRzbKC5IRgbuY9Rht8Qb4Qc1ScVuejIB8F0LJWBaKxEMOI1Fw8LMII8RA0S6L5WhB6Yj3E8vswNgnmeLHMQkyIYBTz4ctmbsRJL4ySmBclcUftpXiCXnkU6ZB3a22Rn36UyleccrYqnO+FEwe2Pb9QpRHaCxoIdV+6T8h3OW8FgjNdyYZonnovdVjEexaB9v8t6EAcnb2O5O+6iOaVKmiSre0o3wLkd6OcltRar2fFZwW/UgoT664fvTeLeFal8dQI4QKRtBo+nLJVutPXJ84KL4Vw3mO9w3pLHnwcOickhC0REhLO43xvzvDeYb0QkdEX2dngvCPPczqdDidOnkApxe2339HXXmv6/rcTPCwtLbFz504Atp63FRt8BplAqriwKbem9f4V1fLNX5V5P3yU9INpsncek/Q2DdaDClqmCtEiVXETL89FkIx+CcPvQ5FW6C8qHCYhc5b4wlNhXs67XeZn5+i0O2eZGwYYYIBnAgak0gADPAvw9Yf28PFPfYkP/d1HabbahV8cwjHxcUUif2RREBetIlVpuVBBp1mEktXwYRc8LhqNMWRZlx/+3u/kD3/rN7hw8yQV16ZuPNrlwXdP1BIJRJJy+NKJanHhXCw14lG8Mc2Y11CMSlph12O7ee9fvY9f+ZX/wEUXXcLKQpOHn3iS86+7iQ985X6+vPMQNk/4yR94E2963Wt53Utu5VUveR6LKyvcdOd38Lf/9EXmbMqGHZfhtZx2FskIhUJ50SLSSlMfGua883fw2u96PY/u2sM73vlb/OTP/ALv+78fYrmZYUmDYNLTxIgLN2stnU6H8bFxxsfGOXDgANZacmtRStPNMnzwN1OtVnjFK1/BVVdfycLiPA9940HuuftrNFZW2LhxA5dfdinXX/9cxP2KSEJpmhb+C6LKeR96TV00Z2pqJBhUbsVngknwWQvTPEN2eCf7P/sh9nz5EzB3nDTr0LWO2Txl/3LKfUfaPHZGc5oJFnydhXaOUYaJiVGarSXmFs5QHxmiNlSn2Wph85y806XTbJO1Mxbml9HVYXR1mNrwOKPj07Qzy8SGc5jcdC5JfZikWgetMdqjs2Wuuvh8/vB3/zM/9oPfy+bJIYZTT0KGcTkGTyVJ1l9wlzXclPh1MIGdlAV3EJ5cMMFUhq6Fex98hHe/7/9yyaWX8bzrr+I7X/tq7nroEU51NCe7Ve56co5//Po+7n7iDHtPNOh2DNdedzsrfogvPnKIkfMup6PrmNoQTqRC0P0AAP/0SURBVGsZVsgR3k5ZcisaRgRSoUy2eO/FcX4QTOSvjICoCZBlWeHw3QcH3pGcUoimiI7OsoMZBlETSam+cR3kA7z3VKvVQnOEoHkjBEbQeAnkjNZS23kmzltjfo0xhVPs1d2QYve6l3xPW0u+xzmlTCiowndZjxwLgbFOTEqj76ZIahkjpFuM0zrxWVUIekHQKTggL5pPgfEo3pOyC6y1EDTKzqZpoErhVGi3vroO9e28aHoQiDrJmxBrzgu5JXUTNJlCej6EWYteGkIQiKZUD/E0vkjqSDT913rxfmtQpTZUOhDzPd5O6rl/pu9D0YaRsFwd4OkizsHF99IVnsc+L/N0ZJV6c3fsJ6WXivaLUcb/5P7a3K57L9zvxRPTOQtCXosaK/JViifeUwBCTPlgYugCORbD+kAkWSuHCMQrz0UrqdCE8RLXuvDSPnNzczz80MMYY9i27fz+8fltDI9ncWmRgwcPkqQp9XqdoaEhACppCsi4LWtiRpylRp82nmr89No5ED7hu8w1simhtQ5Os9dHHL9Rq9U5J5pG8XnIg4znsjagkPm6ON3Nkwe3CnmWMTNzWsgpFTI6wAADPCPx7JjlBxjgWY6jsyucWW4zND6FShIy63BKzH28Mig0BoUJ/oq0EnfTsvJQYaqI04XvI30KKBEWRLASLSJrLWmScOrwkyzOHEXbjnivCb6PRBMpkFUhbkWGIi+8E2nv0b6XnEcs8WRBLA9kHSLEic0yrrziSv7Dr/06//13fo+v330fqa9w5NhJOtUqi5UqD+0+yHmjk1xY0bzy1mt5/StvxyiL0nXu+cp9/NOnv8TeQ6dwZghLz5TPIY6ctdckKuw6Ws9FF1/K/OIKb/2xn2JxucX3vvEH+dRnv8Cvv+M/s7DSKiwTehoCJe0AZHE3vWED55xzDgcOHEAp2QGUd3wQkC3tdgvvHLt27eLgoYOcPnOaxx9/nGq1yujoKB4Rop0XYsrHE95CWn2QdWX/5SG3GXiPxdBVKU1tsL7NE/d9jsP3foLK7D4mkw42y2n4OqfyIR483ub+oy1OZmM0zARzLYc1CSMjQ1Q1zJ+ZoVJNGZkYp21zOnkmZck7dBpLZK0m42OToFK8SsmdInOa6sg4I1ObGJ7ciKoM43RK1zoarSbtxjz/5ifezK/9m5/gqgvPhWwZ223gsjY+z3A2F98962mFxApQXvoXDu3lKvdreSuY4ng4fPwkf/zu93Djbc/n+9/0ZpZnTnHixDGSsQn++jNf5HRlA+/+1L10R8/j4mtupZIOc+WFl7BhZIyXv/Q7yNNpDp/JsOkYXWtwygQNKo/XnjxoYhQL64LgUGhtpA8Gh89EPaqowRM+p2mKdS7sKiuyblb0OefEQaz3UKmIf4+oZeN89FvTX1c+3Ol2OsF0SdKPpE80FQyiSmH2QNRqKu9Sl5xpF/GXxkJfylExsRjj8qbEIZ99SVMpmoq54Lhb63BKYWF6JvUlZE7vs2gbBtM0Qr6dC+YokZCS9HUgjigTjy5oFRVaXOsjCnNSZ+Ww/e9opQvyThtx3B7bSCst5S/5GFKBbBJzSCGteuiRBTFd6c9CDPhQjijwRz9XUvPl61+P0IryOcw98X5MonzS4Gr4EvEopnurQwSsIcTKVdIfd8xHOV8SKgrd/WGkvuK9Ve1X/uqLWFYn+dQohS3yAGvaoMhHcaPvcdE3pZ/K89gHfCCNcpuT5zlZnvVd8XeHWJQQt7W2IGp7TbR+I1hrmTk1w8zMDGNjo1x55ZVnb69vN3horDRwzrFp40YWFxYZHx8HIK1UIJJKq0wHC8L1LHX6TRGG6tnqObZ9cYV/WZ7R6XTxYZ5O03TN6FcSQSCf41zrsZn8zsYwPm4whPTK81xuc/ntCXO2VgprHadPn8Y7h9EK0R8eYIABnqkYjN8BBngWoGsMeZKSGUNuEnxtiExXyXUNRw18BWMNxiNnl/lwjHoUWL1o58RdptLKeQ201iQmKRYTiTEsLy3ydx/6EAuLS+i0ijMpmQ8+bFBoHMbnJGRoMgxdDDnG2yDsi6GSIpoxlVMPn8IK2CiNUYZXf8er+JM//mP+7oN/x4f+7gNcf/Xl2MUz1LVi7sQc545t5NzhURIFXdtm5xP7+cVf/A0++Kfv5dUveCW3X38HSVLHmARd0vJxyqC8OFNO0wpaJxiTsHfffrw2vPhlr+C6G2/hxS97JXfdcx/Ly62QNYkgOhWPAn7UHHHOMTQ0xOTkJEcOH0HH01SMIc/E31IStCxuuOEGrrjiCrZt28ZznvMc8rxb+N/xXo6fT1PRUInCdoQqmi5WZOkCct2hqz2dSp2T1vDPu3bz/o/+LadOPMaYm6Hu52jmSyyolN1zhnuPtDiaj7KoJ1jsaJqNFiP1CqmyLC/N0mqsMDk+SbdjWZhfoZspWs02tttiafYE5CuMjg+TKc9CpytaSEmFSm2Y+sgEujpCrmt0vIGkClpzycUX8fu/9U5eeOMVpN1FXGuRmvYkyuPD0fGgSJMUbx3e2b4+29+/vfQxLMaLJsQaeIW1nk3nnMurvvN17Ny9hwMHj5OoEfJGk7/9wF9TmZrmiaWcbOJctm7fzotuvpq3v+V1vP4lt7ClrhlxjuH6JO99/4fpZinOJShSrAO0JnOQmwoE4gBCEwUhwLmebx/KGh6B0HHBgXTWzdBak+U53nvSSiomKyVNnbgjXWjBACqYcvaP7dBngSRNCxKGkhmekHZgTCL3JFP99Y2QMyVpVBCFjhLpFItorZRHSBwReDxlTaWeqRglTSUdT6cMwnPcgYcgWZfMhmJbK4IQhIxPpTVGm56GV5DUfAynJH0fiB8C0eFKeeu/ZLybMC+K8FWujl5Y513hd8gFc7rYRuX/pU5KwpsLvqoii1AKSqirSGqLCWEPRR8o7qzNf//f8v2z3VsLccBdOvmrRCj252BtXArR4lKRXHrqpFYhxFsmYiKKupU0y0J3uVx9beX7I1oTZ7zX+6//WfFbsLqc8XP53pofvHXQnxnJv3yR2UE0GLtZl263Q7fbpdvp0m63abfkarVa8rndptPp0G636XY6dEJ451wwfYt1c3Z0u11OnTpFnufU63U2n3tu0QZlIqWo61XXMwa+R9zFyznH3r17cM6xceNGTp06Sb0+hPcUPoViPa5FZNKfJsLv3LqIXatIppee92LG2Gl3OH36NDMzMywvL5PnQvxErebyhRNffMrLX8IppHEoxGaVkyolfDFLehgeHobgU80HzciFhYVwmmjwJajEJG6AAQZ4ZmJAKg0wwLMB3oiPGA/aObTNMD5H+Rx8jsdilUUUsqNWUvCjpAAceAvOBTUhAyhEgT4cSR/8g+Zxl9+DwVNLDfOLSxw7eZy/fv9fsjR/GtvpoqwCJ/6CCDv9RqXgK3ifyolcXmHpmbt5kHI4jUYHLYVgmhaN+nyOoYOxS9x89XZ+/52/zNLpI7znf/4hQ62c7MgpRttncLbFf/njv+B3/ugv+YV/+07+7N3vwXVmeNsbbuSqbSPUyPA55D7BmwSrFBaD11XauadjDZmvokhJjOfWO27m1hfeyW+960/42Z//Zf7n//pD3v72n2Hz5gkx7cOQWbBOduhQcvqJdRnOy6lwFs/Y+CiTUxOcPn1KjllHNCa8FxMEPIyPj3H1lddw/XNuZLQ+SopBxMQMr3JylZGRY5XDKYXTFq9zvLKiFRPkFGUM1ntUasiUp60czQRmqyP887E5fuXvPsJffO0LHF2cxauE5azKSb+RvYtj3HsEdi6PsJBsZtkO0cjAVKuMT07SbnVYXl6hWq3jE8Pp+TmarQbt1jKd5TlOnzxOq9VBJUPUR6ep1obJu12yxiKjqSJvLrJhcog08VRqKSQKU0lwNkNlTUbocPrAHkxucVkX5TPyvC076Wis1zg8lg4q6QB5jxj1lCgFuaJvJacUHguFzy7p27nLyLImKV1e95I7eOHVF/Dnf/Df+eyX7+WiS6/lRS94BU/u3sexQ/uZUI7JWh3lE7q5oZlnnGx3eM8/fJgPfOCv2DhZR9HFY/FkGB38ljlDmpsgpIj2i1I9x9s+LNJ11LhxTvLuZUxoJWM8TSvBIXTUPBESKAo0zsv4lHd7UkfU6Cqv6X0UAs4i+KmgnegDoVII+0FoUVFI8r5w3lroJTopt1HSJkZpvBXBQkiXHuFUkCqBMOyZ4EgeCy2h0s64UkrImUC4+ELQFqEqmg2KVmXpXiDshCDqERmRwJH3ArHkPN46+escGjkWO0RY1JWiZ54o5oHxigKpmCPFvBPrKLQ1EjLEFz6HMgoJZfoE/ehTKt4RLSyZz2N/kHtCVkiyQSMr1Gn/Fcylgn+UeEm++sNKeutcMW8l7biQfPGeC1pf5bgi5GsgFsNDOYqcwuRGUSLNwxXvh9fX5EsehvoqTJTVmqtMvnvCPcBHU3LVfynlw+dAXAM2ywtnxypkoCiPDz+gTnwXEYhUqaqeCTOhPxlkDPV8HIX4NMWppDFa5T1Gi/Zrs91mqdFksdlmodFhvinXQqPDYqPDwkqb2eUGc8tNFhodGu2cVuZodSydLPhj8pbMZuAzvMtCfwzjVIFyjpkTx2guL1Ov1kmTao+YLY+LstPo0tXXgE91xTorRkTvCquSXjhsuMLcUb4A0X22Mv9/Kwgkig+Hh3gFDz60k46D+tgkmddUqhXq1YR6NZVDErzCOfk9Ml7h81zaKEmwPrRfvHC44KagfMW+nGhNog2JNhhlMEoX5vnOSr8xSoe+JX2o02pzZmaGmVMncd0uGs/i3CxLC/MkWsz8cydrBUJ/sl7qxvocnUA3b9NorkAgqcVLp8H7MBa9w+cZGsfGjdMM1esyX1mHzSxzp8/QWmmEcefxSpN7Tx76yQADDPDMw4BUGmCAZwV0QSopLwtX5UUjKS7IPHFDNJqklXeDy6svJc+iEK5UVHIpFvCy2y9/W502ufM0Wy1OnDjOxz7yYXyeB5VnI/41+gStkDYSb7FADtmQMgRyoHTFj0p58DmJsiR0mRxJ+YWf+Wl+8i0/yv6du1k6eoIx3+Xgvj0cm5ml0crZcu4FLM4v8d2v+05Oz81TG55g83nb6TiHNdB1OcqkeJ1y6NgMf/Qn7+EX/s2v8e/+7X/igx/5Zxa6hhPzy2zYtIm6Sbnxmqv4P3/we/zQm98Aqks79xw5tcCxmQVyIsHkpO6CkOrjGWRaMTIyQrVa5fQZ8TXgEQ2MKCTbIJhobcqr4h4CgaK9RjuN8gbvjRBMSkSzaO6lk4Su0nTSlOU05cH5Ff70n7/M//z4p9nT7LJkajT1CIuMs79R5+4jHXafUSzqKRZdjfmmx+sawyMTWOuYnZtDa029OsTKSpOVRguHYmVlhZXlJZaXFqlXq6RpSn14BIdheaWBVtBcXmCirnj7z72NP/6D3+YN3/VKlhdOoXwXfIZSHqM8nVaDRx56iN2P70JpT553cd6K/x6/ug8FyfIs6HUhERalM/UEfE/QvtOKivaMVQ3f+dI7+fG3/CAf/sdP8O73/BV55rnisqtYnF9g66ZNHDt8jJMzCyy34Gtf/wa//Tu/xyP3388Nl27n+151J3WdU0mkHXyeYRBzU08gTaJGRzAf7ZmVRm0Y0ZDx4dS2npaREEnieFWcvZc1l0SKDmM0xBNJXRUFfXpEh9aaLMuk3wUhUAidqAEneZX3pT5dIHBMOMGwICqCyYRCSKgoMOe5aOOITw0VyK1eesX9oAXUR4it6fprbkh55E9o1zBPFM/7O0foAfJO7A7EGyH+UjKyw947qVEr2Yl3rkekxTaL5JYOJiJFnKGLhuoP6Re5KGUiQtpKBHPxj9Wrm56ZmArtIn05llMVl9SF5NG7MJ/0pfMvRS+NXlr9Gl8lRudfiW8ljtX5WlXHEfF2+YqPSt/jHNF71iNM+p4VSa2KrIzw27YqSrlRjiqEi+GLYGuz2nfX5jlZntPpdml1OzQ7XRrFldFsZzTa3eJqdro0211a3Zx212KDCXD0yxVGlfTDQCpJET1LCws0V1aYPXOG593xPCYmJvty9f8qzqLEtbpX9Ob31U9ipZX7xdNEnE8VRT1775lbWARtGBoZJUlTkjSlGg7WkPqSdMIsEHIHhDVPAV/U8lrExg9NLP1N7kVNRxM0LrvdbqHJubi4yNzsLN1uJkS+l/Wgd47G8jKnZ2ZkfaCjr7WehqvA0e12aKys0O22Q4eMlSCXzHGAd2yYnmJyarKnwQQsL68En3tSX87LRhdKQ9TSHWCAAZ5xGIzeAQZ4lmHNonUNwuIofotCjhJ/QoWw7inIpfJKyGglGjZehOQkTVhZaeCsZ2VlhUcffZS/eu97yfIc60TQtU4IlrMhLlu/2T/CUq2sNaGUAufY/ehOWksL/NNH/4Fzpyd56QvugG6LU0cOcurYES6+4AIe3b2Pbde8gNtf8QY6yRCNvEOm2pgkQZuUk6dO8+rXvpZGJ+Mnf+rneNnLXstffvAfeeGr38Cbf/THOHb4AP/jN3+NX/m5t/L8m28Am5FWFB0M7/jtd/H9b/lxDp6YpeMUXqXFbjeB4FFhAZdnGeNjY0xMjLPSaBQLQhu0wEAWck7boI3kQ5toFAbtDMYZEmtInEY70QAD0VZRiOmX844OsODgZOZ53+e+wn/867/nCweP0q4Pk1bqJNRYbFW5d98SXz9hOZlsYJ4RZpe7eBQTk1N4FDOnTpPllkpaodls0Wy1yHPH8vIK83PzzM7O0+3maGWo1upUKlW0VmHBq8iyDt/7hu/m/X/xR3z/617O+RuH+em3vpFf+aWfxrYWcN0GGov1nv2Hj3F05jRfvutr3P/gA6BVodGjlCzWFQZFClTivn4BHxbh615xaS6dPoSXRb8GbKeDzbrcetON/PZv/xc2bZri45/4/7L3nvGWHVeZ979qp5NuvrdzS2pJrVbOkuUojI1hMDCYIQw5eDDRYDADAxjwEAcMxthEExzA2DjjJOccJNnKOUutzn3ziTtU1fthVZ1zbnfLyO+8H17hu+5v33PODrVrV9q1nlrrWe/nwIHHOXr0GDjN6lqXT3/mS3z/D72YN7/lnSy0pvnFH/5Brtizg+XH7kGXHYpBD2sq4kjhbEkUQ6WMhOnGgzAeENBKE8UxURTJFkfEcTxs88PnwoNOAbQAkiShMpVwLXlybudXxZ2TKDz4tiVKv1dvlABEcZJIhCCk4LT20dpC9Dcf5S1Y34n1oBB127FIXwFQsMFN01vdBTBG6QCw+gry5wQrJbxVR0hHnWjFI19wUrn+SKhHn16oyyceauQ8590FfVk4b0EjsrHUBWgLAM/ILTCOIt8mR1ZXAqR5ZW0sDYfPn5N+LRYz+LoQIEzS8G3DPw/I/aJILJXCcxnrrdvcmMXYEwIWPn8nlOmJok5l5fO1yPB857f/f8mTydGJ/S2I8/X/hPIEh4bt3acdfp2clv89Pj6F/WME81LBfhuC6fLbWosxAiwVZcmgyGXLCwZ5QT8v6Oc5g6KgP/CAkj9WlBWVcRjr8IZ53irY3zZkxUeoW1ld9dyAij179pBlwiX0pEUQhg2bE8f84WZQo0WtcVs1b02mxq9RarjQAGNmc0FU+BfOeXIS6t0Ft2Dfhx/fv58kSZibm2V+fgGAZqMx7IBhLAhZCePCxj71RK1tozhOfocZ754m1s2GSEdUVcWxo8dYW10dXiljqYwlcZKgtGYwGLB4/DjOGCKlMGXF2soqi8ePcfzoMRaPHWd5cYl+rycR3E4cE5QjjjXWGqamJpmZnkb5aG/OWdZWV1lfX/OAVbCmBRi3VNuUTdmUp6JEr3zlK1954s5N2ZRN+c8lf/EvH9owFcUrCSfOrtRQMQmTOb93bPI2WmUL4WNHEzqZIDmwFbG2JMoRuYotEykT9YSqGKCco9fts7K6xplnn0XkJyAyCRqtZv+/kzAxkxX8kF6cxOgIbrn5Rp55zeW84ldfykX7Tuc5z7iSb7z2GXzTN17LN37DM7nm6Vezc8+ZvP3d7+GmW77M0665FKUqtKuB1TTqGS/8tufyzf/luUzMTPDo4YPccNvNzM7UeOlP/iAv/6kf5rwzdlDaktyWuCgCp8lVi+s+8Rm6/QG3334Hz372c6jVMl+ajgiH8txRzivt1lrSLCUf5EMNTiFuNFpp0E7c2UAskHw9CZgSOLDkGqM12ilS40iszLvzSNNPUxYrx2fvf4g3f+ozXH/4GN2pOUpriW1Jregw3e3RaA9QJRQqY2VgMAW0WlNEaUZ7vU1RFNQbdZxztLsdiqKk3+vT7nRod9p0Oj2SJCWOY6JELG+stZRliYoitm/bxote9J0897nXkmpDZPsklGhbsO/ssyjLknvvuZdBv48zhiOHD7G8eIwksRRlQRzHbFlYAOOIPPH8uJIwglhOpbBtlJHVnZQhiBVHkqS+fXmrFAytySZraytcftllxHHE3Xfezq6tW5idnKRVq3Px+Rew57Q9TGcJX/nUh0mLZZ5x9aU0ZuYo4jomqqOqilgrirLAxSmR8tYvkbiwhbYg/BWyqltVlbcgGnH0aO/yFiRM0MuyJIoijKmEvNvP/q0x3vpJwCQdRVgPnomyM15qo9FgvI8qLe4M4XrnJMoPY+GnQ3kLn4+4XY2HlQ/KFX6FOwqcO15BijxZtZwSrKnkUeWnrKo7G4AWOTDMr/8kqJ4hjScaZ3x64ULnRhH38PcMY52MfiNR/jLtLboCv9OGWw0v8lqYk9TCdRtUyfG2qthgwYU/X07zmv3wRhvrTnaduMeXgVeEgzWYHtbHRpF7btxO3hNO3ngt/lFCfuXWpzjpBPmPzgl18dXkq58zKl/pL+P7T9jCsbGHFdc3f8VYXYV8j+9zFoqyZHW9zfGlZdbbHZI0o95okibZsN33+z1WVldZXV2lKIphGvV6nanpaWZmZkiThKIs6XbbVGVBs9FgYX6W2dkZ6rWUWOsxP0ARg6M0hkFeMigrSituWHLWCHE0FgojlnYOed8orbEWispQGkNpLMYpYgVpFJGlCbU0JY0jIgWLx47ysY9+hMcf28/P/uzPsm/fvpOb35Oo36GMnTb+VGoEEw2PWRUCeYy2yi8rhF7sYGTy5dvHWLV+TSKLPOLWqhCeoV//jd9kvd3hiquuZvdpZzA5NcVpu3eQZSnOQWUMa+21seeXcXdqepo4jnyuv7oodUJhhHocHpenUSiqquL48eOUVenbkyLSjMaSMcBbKUVZFPT7PfJBzvr6GkWey3hsJUCAuNd6V16fnr8r+KAOrVaT7du3iaUwcm2eFywtLvpxTs4Xt2D5bSVL7Nm9a/gcm7Ipm/LUkScPyW/KpmzKU1j8CufYBAQ/iR7fZMbgFUs5ySvZJ0y3lHeSc+JG5adzgEFTEVOQ2j5TScVpszW2zM1Rq9WFONlaVpaXuemmm3jXu95Fr9cdTl5Fcf+/l0hHOE94qxSkseMZV13M6/7s9/nln/sJdm+dJGFAK7XMTkS0aoaIAUmkOHp8md/7/dcwM3smDzy0ysc/cTPvfu8nuO/+AxQl7Np1OvsfOcbP/8LLeeXv/Q4/+N0v5K1/82p+9Du+mYVmBgoefPwI3/At38Pv/9k/8aWb99PtV7QaTX7wB36QJM14+S+/nGPHjo94OYaKsufIAKI4xhpLa2JiOPmUT28ubv2S8XAyLddZhHPBaouJDGVUoSlQlBjtKHVMX9VZpsENR1b5nXe/h7/7/Be4p1dQ1SZI+z3mih5beytsWT7G7NoSs85BbsgHhmZ9krnpWcpBzurKKkkSk6QJg8GA1bU1yrKk3++zuLTI6soKzoe110r4s6qyotPp0Ov30XHElVdczou+6zs568wzMOUAqgHalqhqQFTlZK7gZ3/sB/ij3/41EpujTU4aRbQ7Pe65/xHue/AxvvClL3PzzXegfUS+sJ4titVY2x1v/6cUmYQHUGrcFUEBzla4qkTZisiUJIN1Lj1rFx9951v42LvewtZ6xLMvO5/v+S/P5bzTFtizbZozd8xw2aUX8l+/9/u47FnPpbXtdPqkGJ1RWYWOM4yNyOIGlN61UymqSiJ5GWuHVkrau8FFUUQcxSOFxkcuE4BForGJZYIhTVOsNcSR9Anh5xJLI+uc5+MRvhWvhyAYhSga1XhEsaGVjfzhRsSskpfgJiHAV4hKpoZ59NxLHnQJ+VTBRUyPQJURGCV7dBSJUuPPUYzqc6i8n/i54XtQZIYHNvwKEp5r49GxhuDFIWnbYBmmRm59zol1UcjkxmcJlkNj4+y4cu1kcx5QlBv5/n9Crsf5nQTg86x44xZHHngbJjy8Qcier80NL4cTzz/VPp/AiZskedImde7AA3ujPH01Gd3rxHeVFNnJ9SJyYton3kd+b3xmn1fcGFfgaNsIU4TN1+lJ6Zy87wnFl4NDsiVtxFsfDU/x6YXNn8uwnfr++FVFLIyFtslSVRbjNj6lwWGco6wMeVlRlIayMhjjqLyVkrHIAoZv4+FT2pFYPB48dJDHHnsMpeCSSy7+v/No8lUcmpf2ANHIGSvU9WiBJsYRO0eCI/XbKAuhvCW/4f94GwnlPb6dStRY4AP8GFgUBUePHAUUVVmxdetWjDU06nW5RwgmMXwmcRVTasyWKuBdG7ax4BJOuJFkPBj132FelexXPnplWZaYsShtOIP1VqDKB0Nw1mB91FStNc448v4AJbRKaP9WNGXl9ylMWQYoyJeIjGmtVpO5uRm0hkhBrBX5oM/S4nFv6eqLIiw+DKM6yjtrUzZlU56asmmptCmb8nUgf/EvHxqfM4GfEJ1qSj5UR8Ysk4bhtoeTLysTiwBM2YqIitgVpBQ0IsvcRMbcZJ2y1+bxxx9nx7YFkhiqfIBWMQ5YWl4iihW7TztNlI2xFXbnRpOijVpLOGP8+0iUV1rChAmHAExKoXGkkSJSTmglrSH2SpdSmrJSHDq8xr/+63uJkoy3vuPtfOXW2/n0527h/R/6GNt37ebd730X//APb2Hv2fv4w9//XZ79tMtoJgpbFhxfXOFd7/0gVz/9OSytdXn3+67j5rvu5dEH7+Xxhx/kovP28f3f+9/48vVf5KrLL2V6ckLAD7ySpyQinvAYhNDiYq2hvBVDmMCHp3feQgk/ydTO+TQtKgKrxT3OaCiihI7KeKAz4P233cEbP/UZHhsUlEkmBKGDAbP9LhPtNWZ6XeZNxYQpKFbXSXREs9mkLAsG3R4W0EnCwEcK6g/65EXO+vo66+02VVkSSEyV0pSeQ6EsS2r1Glu2LvDsZz+b884/n8nJSZIkIY5lgp5EGq0gjjSRB1hO27Wb03fv5oYvfJFyMCDWmrW1dYpCSLhNZYiUZtu2raCEnmGkMDxhSznhL0yLw/HwX0ARawxxJEBlohWJs0y1mjzjaVdz7bOeyX95/nM5e/d2MlWyfWGas8/Yxem7trF12wIz8wtMz81z/S13ouqT1FrTqCjGes4iaxwReqgmxXEsIJAHHMRlTJSGABwpNYqWZr0blLQT/wReeY+8FRKEKGHiphIUfRVIrb2SKFHEpPxCVLdgXRYskIZR1k7okUPLJ+UtxLxCJopZ6JvSvvEK0PjY5Ky/v2/Q4bfwtAlHU1DiGI5h8swhKeWP+RvjfPltOC6XndQyZLzx+VWj/If0NlziQiQyaWfBhU+efwScKa+Eh7Fs7HElGX8s7B+W6xgPiUI0z5Cl8WdUHmCKgnI2HPt8mYd0hgmP50HqCjZyMYXTw/fQltRYWftcbZATn20oQ0sgf8XwwvBAo7SklDbK+J3GHuMUZ3qk5VTHhnXq8zN2SmgukvjJTzE87sU5zwPzJMVZR1GWrK13OLq4yHq7S5xl1BuNMUslQ7/fZ2VlmdXVVcpyFOq9Xq8xPTPD9PQ0aZZSFAW9boeyLGg06izMzTE3N0O9lhGPWdbhn6YyVtze8oJBUVJaAyrwzsmDWCsubnllMJVEm4yjCB3FsmRkxdqpMgbrHLFSZElMEkekSUyaxChruPWmm/jMZz5No1Hn137tV0nTJ14sCv0tiGOsAQSjOV8nw93OtwclcF/YJwk4MTf1z4dPb/ie9ak4ZAwMcxtp1ePnbJQT83kqqYzh4KFDvPZ1r2PL1u2cd8GFnHnm2SRJyp7Td3u3VnFPW19v+z4RWrZlenqaJIo3WMA9sfj8OJkXjMuwn3qQSWtNryuk2BIoQMopjAtay/tWefflSEvACKWEl0kp59uDSKRDwAEEjvTjGmjiOGF+fp40SzHGEMcRg7zP0vFFf6+N46HWEmjFOoexEozk7DNOG95rUzZlU5468n+zfrApm7IpTxEJetGJO934avJJx8eu87M2pZywGVhZzbKAcoZ6bGmonNmaZddcjT3bpmkmcOtNX+ZLX/wC7XYHh0brSCbRaYpzlrIsuOH667nl5puJtQ/N7SdC1vMHyeRDJjwyr5NMKU6e6AM4hCtIdAfRviIdEStNDGjrUFajiIV/yCliIvmuEgZdQ6/Xp6LiT17zJ/ztm/6Bv3nTm5jbeQa/+D9/g7vvf4Q/+OM/5n//9m9y2vw8jUiBjlkZWF711/9E2poi0fDSn34xl16yjz37zuBlP/c/+JWf/0lecO3TOXv3Tv72L1/Luefs5fixYxw5dpzKOJyKwBNvi6IqzxCeCiUTW+2JzRVCwB1IyyMgdpApReIciUIACuXoaujXWxzXMe+7/S5+9R/fwDtuu4OlrAFxnZqxTFcF26nYNuixqzRsLQzJ6hrF6irT0y3qjYy1tVUGg5wi0pSRptfr0ev16PZ6dHt9VlZWWV9fB3yodT9pHgwGFEVOr9clSVPOv+BCrnn6M1hYWCBJUlkJVdLgrNMYG6FUIqTx1pEpR1QN+PZv+gZe+6o/pBlD7Byt1gzr6wVHjqzx+IHjfPmm27jz7nvFRTDWqAhQRtJmo66gwr8Tt7HjAqqK4mGsuIsRqOytJXGOyBhmmg12b5lnMouI7YCo6qOqHiZfx9ku1vSobEXPZTxwYBVDjaqoULZAReKaglJEwfrBE6eGSFHOT7gFvPB8S76PaO/mGRS3qqqGFitDsGKc4NsDRuH5tfZARdjpyyB0feMtlcQKJwAoknbIS7iPgBkjwOfEFXTlLaICL5PzVjvWoyTWBiBJVEXlQSjlM+S8m5Zogz6DQ0uc8OnTCFwzvg2Gc4flMRzc/DVj4hDLycCPNH70xO/hHnglNSTn/BOMN6ph/ryEsW507ETZaJpjjRmWwehaUSmVTw9vuSSXj6CYE5Mf6oFDq6EgYxHufL7kOaUfnFinoRxH30/1HEFGZTHe2EIdu2G+ZH9IbcM2du9TStjtQjsavcjG28GGNuR/Og+knuKuvj2NttGxjfJE+QrpB+DROunjozqURjMsb/9fjY1do/ff2PP7fhXq8mQZveDlktCv9FgdCMhinZPFBaeojPXg0VgbCfUyVp7OiuutMQZTVRRFycFDB1laXuL5z3/ecFxSAUAZ20JaG+rUjaKwSSQ2WSCRyLO+YxkhdTKVxaGoUBKd1QForLGUFnHvC31zWFe+zdmRY7RyPiLrsNxHEvJ6Yj6H+R0rD60U13/pS+AcC1sW2LZtO8YaibzpowCGZiMuZKO2ydiYfCoZts/h5vNwijao/NgrPyCKI7Isleobs6wkVKk1vh35/dYOrZOcj7QZQHntx2drjLQaJQscxliiSDMzM0OSxOBkUchUJceOHfXtXQA160agWQAyra9iXw2bsimb8hSUTVBpUzbl61rGJiTOT1BHcxy//GextkJhibQlVoYIgzElOEvkShLTYyIqmIwGqP4y9991C1/4whdY7eSkEwvkpWW93cY6hKQ5y8QSwxh63S6f+sQnuOvOO8FbISRJgtbah0Efm2WdPH96UuIN/6lliZBIKoXTESpJ/ITZ+glfyZ7TJvm9//0yfveVv8zsbI1PfPxD/OZv/DJlucYf/MFv8qd/9rucffYctloh0X3e/q638lt/8CfcvX+Jt37gk0zv2EFvsEqq+vzRb/4KvWP7uf5TH+Xap13OjrlJXNnn0P7H+PznPs/+/QdYb3dJsgboGGNPnniHyfepxVsv+FKKnCOyjhiNqRyWmMLFrLkan3jgUV75jnfy55/5OEuTLbooyAtaZY/53jo7V4+z8/hhtuY9svUVzOoKzSRhemaKzqDNSnuROAUdK/rOsNLt0un2WV1vs7beZm1tnX5vQBylGCsqaVUZut2+5/XRnLFnD1dfczW7d+9ienqGWlYnjmOZ2hvh4/E2ZBhiLLFfUbZksUJVfZ551aX81V/8Kbu2byVSMY16k2OLKzz48OM8sv8w13/lFm6/+27yssBhBaw8Rbs5UTkeKglh8u834RI7WeRoLCCYgaqy4rLmfNpYjLIYHK7KiW2BrSyPP3aYhJh6pIjNAGdznDJYVaAicSfQkbikBTJt5RUXpbWAuV7xVGPWMIFzSftznAd6zBgQ4bx7CkHxOElR8RZZ3kUtXKcQZViH9ALw4PMEYK2RnupEcbKeLBp/33FLpxHoJaTSoscEMHXU5Z0HSKReJL/WCmeTVIob6mRytv82rL7wZXjKUAEMZXrKc8OzKa/Jj07amP4pZHiNz9GoXQXwJnyGtEYWmc7X68ki7q46igDly0z5NEbXqVAu4+mHn3gNUgUy8dG5YYwJ+ZPfodxHeZByGUWXUlK9Q5eVYIVw4vgV0j+lBODzhH2nLoevUYbthNHze+DzidOXgBRPZguFE+o4tK2vScbaoDz1+BbqRBT7Ey4UZGSD+9HYseHnMHGUPaHPW7m3EGyP3KrDgo61zm9y/9G4KPd0zlFVRsZoK8B3ZSrW19Ypi4K9e/cSRQrnTu3SdGIbkb4D1pVYZ3BYrDh0S1Qw3y7xwDhE5BUc6/U50OtzrKo4Xhk6UUSexuQKTAVqAMrFOBfhrJAsKQvaAkamOaZyOBthzZNXi0J9Ow/aF2XJ/Q88AEqxdetWoigiz3OazcbIkmrsunFxARw8qS5PJaP28WSl2WyOxhff57RSnhdTinXYT0c+d8PrpX7CEOLHKzwnktJkWcrU5BRJkoDn1quqiiNHjuCM58Q7QUJLqoyhMlYWKYdR5jZlUzblqSab7m+bsilfByJE3SeIzN9GP8J//8+NnaCcRSsr6r4yaGdIMCQ2p6YrJuoRtURx7NhR7rzrHo6vdFBpi2xinrQ5y0Qz45y9Z9DvtUljMXkWCwgoqwJTGQ7sP8C2rdvYum0r/X5flGfrvAtQUALGJjkbH+CrinWy4qkihVWaSknoWmMNkdjSQxyTlzlpDS6+8HIOPb7Ia//87/ib1/0dL/mJH+Xnf+ZHOO+cnUzWE6gUH/zAdcS1OjZu8Bd/9Wbuf+gwpVG8733v5pMf/zif//QXOXLgCL/6C7/M+XvPJEsTiqLk9ttvZ3lllbwoOXvvXnbv2s3+xx7DGkuSCHfOkxGvvoVgN6DEHaOoYKAielmN1Tjl/pU1/ub9H+Gjt97FofUuulZHG8OEK5kt+mzpdpjrt5kxAxrVANprxMrRaNbIy4JOpy1ebMZQDAYU+YD1dpsizxl0+3S6HcqipCgKQFZFrXPkeS6r18awc9cOLjj/PM4860wazQbTM9NMTExQbzSo12skSULieZd0FIHMU0UB9pwTKIdzBh1pTjv9NK55xtP58Ec/SlmUKBWxsrZGt9uj3qixurZCEsds37odI8vXUsfj83A3bPYbRKnxpVKvxKhROTuvpyolq+AGsdizw4hdYslgnRP+EqeEVyISZfVd73wHz3/ec8mSxFudiTWWAypnQAl3kPbtUziEIPJE2MaY4XelhLR9qNx4V8kAagQlQSmxvCGQWgfLpTH3qiDOW6gEUR64woMMetz1bnhO6I9+hdz58sFrr4Ty9mTQkeTFDYm4HXFw0fMr5qNLPCgVqsuDXBtlBC5txC/884d0nPNAleR92ASG14jiJDLKx/CYfGyQkKfh71AWiPLmwklj4IkaAztCvk5IZnjMfxvWg1KMIvApeQjlyyQ8j096Q3pqDMwK6Tr/T9wo/clK6l/SCZYI/nqfJxsiBfprokAqb4NLzQkP8oQiY69zAviogN+dQkZlceK+EwttVA4CpMqvAJKO18WopE6Qk291SjkVOMCp8urLpihL1jsdjh5fZL3dIU5ST9SdeBdYsZJdXVthdUWIuv3l1Op1pqenmZqeIkszijKn3+tSjhF1z81NU89S4kjjhPlo+PymEqLwPC/IfTQ3aZsSkEDGBNmK0mCqEq0VSRwTRxFKjUCk0ohlS6wj0ihGK0iiiCTSrK0s8b73vpfDhw7yfd/7vVx+2WWnrqcnEIWMAZEOARfEJdwqRaUUJdAtDJXSHIrg3265kdd/4jo+fNetfOnB+7n1sUd4YGmJB9bXONDtsW4VxDXqqfD7KEApg/LIklIOPPebUxoVndDrT6zLE2TUdxVra6u88Y1v5J577+Pb/+t3YizMzi0wv7CFudkpQN4JRVHS6XQ29DmsY3pmijiWvv0filTexk4+PHby9Wkc0/UucBDc2qT+UTKX+OoiY8cGUWI8ptC0WhNMTE6JBZbSaK1YPH6cqqp83/MXwOheSvmIgh649M+z94zdG26zKZuyKU8NefKQ/KZsyqY8hSVMCMa2MX3vq4snkrQGZ0qUNSTa0aDPTJIzmRrWVha5+fY7uO+xQ5jaFLWZ7TRnd5C15ohrLazStLs9ao067U4HY83QWkkrTT4YsLK0wlve8q/cdffdZLWaRKOywr0i098nldlTSpJkRFFCURqcSjAqo1M4ShIqp3EqpigMKq7z8IFlXv3av+EXfulXaK93eMe/vo3v/s5vZW6qDmVB0S+JVMyDDx/g5f/r9yCb4vf/z59x7OgxeqsrvOkfX8+v/8YreNoznsW3fft3MDvdIM8H3HTzrSyvrIGOqDWaXHnV1Wgd8+Uv38TBg4eojCHLaidm/QlFlCY/p1RgtKKMNHkS0603eKib89Yv3sAfv/O93LK0ymqcodIaaV4w1W2zrddh6/oKC/02U3kf1Vmn7HVoZhlxlrLa69IvS7K0jsktxaCiyEv63QFVL6e9ssra2hqmqiirUvJgDZ1ul6IoKIqCNEs5/4ILuOjCC1jYukBrokmjXiPLMnQUDUE05Vc+ZeW0lAk/BqfEfU8lChU5ohicNlhVsnfv6fz9376WudlJyjInSTKOLi5z5z0P8Oj+Q3zl5tu5/fZ7cCZQjOLb0X/UlIIFgJw07DFKYRWyKq8UVjmsqnBKlBMdQRRJnWil0ERoJW6VlXMYLFFs+PmX/iRpLUbHKc6laJuA1Tg0JUJiGqx/Ri4q4nKggvsa3mLHOYqiGCo+WmnKshxaLRkf4c3hMFUl1/nobDryFlwnbNZzGIW+J5ZNI2sYyYeoBWFzMpwMXSUguHbJd7zSFUApcXNT6EhTGYNWirISIlk8yBAAEFE2/H78zcayfKL4y04ShygxWolbWzhF8j32xXndxqvk4w+x4dwnEGe9G5i/Tiy9xi1xxi/23/1tQ12PZJRL50YR/kZWYWPldcIVbHiu4Ye/Jih3Ui+hLY0/t/PtaTzR0AZDNkNuQxEpNW4Z9CTFSf7D95PlSb+oRKRp4bxVXgDF/KEhuCbtdmRhNNxOTM9LqFLZQvs88ZxTpDe24evRn7whHTcERuUz5OSku4QdwzYTdp50psjw/JD5sdNtsFYSqySCZZLzlkrGYK3xrk54uxI7tG7RnmAf376LsuTgwYMcOXKEyclJ9uw5Y9g+n7wotPKx2pymqCyFcXQKx1K34NFjK9zywMO89QPXccODD/P3H/gA97fb3L24xP52j2hmCw8sr/LXH3g/v/kvb+Dlb3o9f/yh99BxYXEpB9UFtw5mBZsfA9VDR5U3XTq1hHfUE20A7Xabz3z2syilWFhYoKoqjKnI83xonakU3nJrvCI21t742HrytqHiNybjt1PsAqXkvTt8t8jFIV3ZORwaTpaTMwJO6mpiYpKJ1iRlUQISEXRpcYl8kKPRG6y0/G0B7/rmLWnxgLuPPbIpm7IpT0HZBJU2ZVO+riRMS4KyqsbsEkbQjQtnOYt2hlg5tKtQVU5kC1JVMZFaBqtHufPWr3DPvffSL0E3Z8mmt1Ob2Y6uT6LTupARO0WvPxDFMVJ0Om2sMWRpBt7lpigkfO073v52Dh06iDHi4hGdQDoaxA3//UeiqCqHsRFRPMHNdzzEn/zZX/Frv/F7/MMb/40jKzmlS+gXmvd94FN8z/f/LO//yCf4rVe+gj9/zR9x/gVnEsdwy8238fJfeQUr64Z+4bjymmtZXit41atfxwUXnMsv/NxPsHzoQZYPPsyVl1/Ej/7ED3LG3tP45Oc/zIOPPMz+A4c4cnyRc/adzznnnMvdd9/Dxz/xcXbu2slVV1/FloUFz9UxLhumhX6XmMtIrckxqxSljuhGCWtZxifvvY9Xve3tvPcrt3AQzSBJwFlqtmK+zNmVD9jZbbPLFtT7bdygS5rENBpNuv2c5fU2LknRaY1uZ0C/VzIYGNbbA5aX11g+vky/08cYiQ5UVYYiLygKifzW7rQ544wzuOrKq9i1axdJkpBlKVktpTXRopZlpEkikcECmORJO0PkNpk8j9wsHFZ4jSKFdYbKFFxw/tm86Q2vZ35+Fmsd9cYExxZXefCh/Tx+4CjX33gTd9x5L2VpxvRSMesPK/ij7QTxll8jGW9sSn67EqhQ2hJpRRQLqa2OEqIoRUcZUVIjrjcptKJSht17TkOnKYPKUdkIU4EmAqdRUerbtb+X/wyKv/MghQ1uZNaSJMkIePEWTbIKLX0nWPrFsZDjo8T9yZhqrHWFP1nBDq5WLvBvDFe2ZeJvrEQP2qAsegujkM44EDBecnZoYSORDrWP5hZc9oYnh7IXLWzU4f3+UdWMHRvtOQmHEGVmxLcWnjxcJ9+8RRre+s8DiMEFcpikE04X5Ty8NnYvsRrc+MwEqxnr0AhniZwMDm/dozgFV4/wpcl9xFrTyd7RKaNMedV+Q05Hvzzpu/L1L3f2deWfL+zzd4BRS5c6isT1UvuIgXJmyLevq413/SoSwJPA8/UEnEzDJnGKYxv2+803F+XTFeBGjkbedVRcSE8ca8dkg1li2MZvM7YvXLKhL4y+bhS55sRzR48dgKUxceMneMQMhj1geOmGPhGuG/0MLrMOD2SNJTkOeLlgsRTKzco4HLqMzBhkK8qCqhIuJecsVeXH//Y6jUaDnTt3ggtcX1+DWMD5wAREfP7G23jt37+R3/7DP+F7fuhH+dGffAkv/41XcNcDD9Gst/juF7yQ733+C7l8zz7yY6scf/QgeVGwXOU80Fnh/ffeRM8OsOUqDA5jVx9gcOQ2jj98A/fc8XlMsQaUKBzmq7WLE0R5LiEBlqDf79PtdpmcnKLb7VGr1bzlVzHWtkdAYoDmx0EXGKvq4ebBH19vI8+0UKcMI/iFlENrkOvERTVLU+lryr9TnLzjnD9RrhprGD61E7I1OqIUjUaLiYlJtHe7juOYTqfNYJBjrUQBNcEVOohCWpDnCgRvsaskEMOmbMqmPDVFua9tCWFTNmVTnoJyxjf/FMIsFLZIojMpmR5oZ8UyBIvS/piV0Omxq4hsQUxBoitSZem2V3nkwDG6hSNJa6T1FrXmBElWJ05roCKUkkheCkhtzjlnzLEwFRFXbWKnKQcVaVaHWFFWOVVVUVUVURwzPzfPD/7QD7Fr587hKmBw33EId4c1p3LfGXdfkYkTgFUWpercdPtjvOR//SHf823PJU0i3vuhjzC983R+6r9/G294/Rvpdfv8zM98H8+79lmkWoNVfOWmW0ibLVY6Ba/8vT/l3PMup7R9GlnMt77gm/j71/8Nmoq/+cvX8OD9d3PhRefRaNTp5wVvf+c7OHvv2WyZ2ca2Ldsw1rC0uMT+/Y/SajbYt28vczNTUu5KXIEqiwdVDMqFcNaKJM6EJ6lSxDrFYrCUAsFkNVbQ3HzgCO/84g3cdegw1OsSR8yWtPI2k1VJY1AwU1VMGovOB9giJ04iavU6eZ7T7/VRWhPFEXlR0Ov2qKqKsizptNv0+32xQEoF/AhkrlVZ4pxDRxFbt2zhzDPPZGZ2lixNqdVq1OopzWaDiYkJms0G9XqTWq1OvV4nyzKyNCWrZWRphrWKKIqJIjGhJ5Az+7ocTYD9bDjK2H9wkZ94yc/z8KMHiOKEXneN+fkW55y1mz2n7+CqSy7lyssuxVIRx0HBilAkOKekvAM/SQh5PGpFY99HB7SzRBQYnWKjOlanVE6DUyyvLJHnhZCWZhmoHK0N7bWce+64n/PPvZDJZoss0aAqua9Sw7zg2+7w9eyjs4miJ1G+jLUjJXms0Tsniqfy14VPxqybggJgfVoBIBKQL+iwnuvHT/7DgeF5XlHVISKbB7tCmgzdpKSurOdCGs+PpGGJdIT14JexwksVQMZwojXiEqg8ib0dRoELyu8YAe34IID0JzHLCAoVUpe+McmYGGPREFegDDiFrXxZKO3LwhE5R2wd2gEuxSkZX0KURTd0H1MoK65Fyj/ySEF0/hqw0mQkK9ahPSrllCayitgqIisccLk2OOVIlCI2lkKLJd8G5c8rbLjIP5fAUREl2sW+/C1OV1QoH3A99n1ggHIanET4G6+nYD03Ein3DeepsWJF6vBkkRPGu5icdqpzv7o80XXDfAzd3EZ5FDmhzJD2HgC1sN46ihgm1rqi0wfgNPD6SDrD5H3bDW6AdshPBJ1+n8cPHuLWO+5m/6HD1FuTzM4t0GpNkMQJZVmwvLTEY489yiOPPkyv1/XuRDA9M8Ppp+/hjDP20Gy06HY7HDt+hH6vzZa5WS7Yt5dzzz6bmckJsjRG+XdlAHS6RUmn12dtvcN6d0BeVTginBKFXvkInYOipFcaqrKgFkdMNho0sow0jTHG0s8H9PMCYVKKyNKUiUbGRC2m7HW4+cvX84pf+1XOPvtMPv6xj7Fr1y55N5zUfk4tDqk37ct5NYcfftkfcNP9d7N1psGuuRaXXXguV156FZ85cD9bz97Fj1x5DUY7BJ5XxNbR1Zq1suKxlSX+/t1v5k0v+SnyOz7Oga/8O63iGKmxHDM1dlz1Xzj9qu+GeIaKBBTEJ2bqCUTKF08P4PjYxz7Gd3znf+OsfedzxdOeyelnnMnMzCxnnnkml160F1OVOKfptnscO74kgIpCyN+xnHnWHu9K6ttU6F++DTofOEEi8kWUxuJ0hHGO1dUV0jSj2Wz6McbD0N7KLFKK48ePUVUVeZkTJ7G35FNolI8aK5yaTvk68OO4I7jfCigPoFVEkmZMzUwTRzKu2Kqi1+uxsrwiuR49gMcJlVjfWk1RVhRVhVKRtD8t5WCt5du/8VmhiDdlUzblKSRPbpTflE3ZlKe0OBWLYqQUEY4YQ0SFdgJcWOXwsTygHBCZARklqemTlF1qFDRTTTnoc9fdd3PXvQ+QV46s3qI5McXE1AytiSnq9aYHlMbcdhzkg9yHlEf4VPwkY5APJBpUpKmqEqUUg/6AtfU13ve+97G6ujq0ZsHzwMRx5AGlUw1fJ2grXqyRMLiPPHofeTngBS/8dv77D/0Iz3r2c7jvnnt52c/8NN/3HS/gX/7xL/mWb3oBcZSC1iT1jDvuvZ+X/Mwv0y8cf/G6P+eBB28hUY5f/58v51nPvJLf+a3/xfd+94vIsoRLL7uMLGtQFIY7br+TM08/iwvPv4Rz9p7DwYMHuO2Wm2nUM77h2ufwtKddxezMtFfwh5q8uHzhPHmqKLuVUfSLkn6RoyIHqqBUhnWtWc7q3NEreNX7P8yfvOffueXoYUwWoas+MzZnrt9mvtNnZq3PNquZyA1mvU1kLROtJmmWsrS0RFlWxFFCXuSsr60LiNTr0em0OXb0KN1ul0E+QGtNZSoqYySqW55TViVaa664/HLOO+885ubmaDTqtFotGo0GzWaTZrNJo9GgVqtT80BSEsckcSwWPh7oEA3W+UiDQfkLk2pfuV5xiyKNVhW7ds3zj//wOnbumCfSilrWZGWpyz33PsxDjzzOTbfewY033SIuZp7LS8rciruaByfFFkiUwZGM52FMlELpVM51hqoosJXhn//1bfzcy/4nL/u13+I1f/tGDi/10PEkjzx8lFf/2Wv5oz/8Q6qyTxxbHCVllYNyaO3QkeRNkvcT+cBfg0z0hwqHty7R3r1N+XDwQbsdWgd4cMr66HVCfi/WRnigaXgfBLxRIf2hdQMSeWzM+mOYvpNOPlwjHxbdqLxO+uav9VcMwTMHYzYyo1onWFMMXbV8MQWeIicA8xCEG+ZaNiv2ZKLUuIDkaCqgUharLKiSWFXEFmITkVSautPUrCKzjsRaIq88Om2xkaWKS6qowkQGp4V3TnvFbGhN4Ps1Sm5bxYoiFldVogjtIrSJiCpNZCUaZSgBq2QzWoCroKRZHEaBIx5uEv/RW7xZjXIK7SDy6RntMBoqLdGyrNKIA5NGO4V2EcolArwx6gKKDZU6Jk9237icDCj9v5NQtyeLwreVYd94cnLyeWNWIb4aQ3scWq8phPzNv+9Cnw3VLqCW9KWxBMba6fitTlEwJ/72Isl405Lx/Sem62V8v3wLv/2nVPLYd3/UWxnZQMyPkxOUQBbS50I0PKiqkuWlJayzbNu2jcnJyWGZPHkZdhycgm5ZstLtsm16ktf9wR/wD6/+c176sz/NJc+6gt7AsHvmNJokTJLSwjLjBizYFba64+xIBsxFjrnGDDX6TNU1RacDeYHu92lkKbv3nInVGpQjUpYnx2go4obAugBB119/PUVRMj09y/p6mzTLiCJZpBmXsDhwYn2N/xrDY2DoyqmGnIvheucUK0srLC+vsri0RFXJAo9SIw43HUWsr69RFoVYro7NqQLI7VsUeIA7ThJ5Piv3qYwhimMmJ6eYW1hgfssCM7MzPrPgnCUvCtbXJPrr8ECYVyqNVrJgU5QFxlq0FjBK4fuAf69vyqZsylNTTqWVbcqmbMp/MvFr5SgX7JW8JQwGjQEn0d20q6jpktT2iIo2me1T1xVVb50H7r2bO+64k35haE4vMD23lenZOVqT02T1BugIi0JJHHdQQbEVt4ksS2VCUVRiZRFFVMZQliXWWuq1OgBxEtPv9Xnk4Yd5/d+/nmPHjlJV1XBCJRHCOGEKNpIh8OAnxSCWPc4anvXsp7F951Z+9CdezHe+6EXc+KXP8uL//l1c/6mP8QPf/R3MTtcoy4IPXfcx7rrnYUoX8UM/9uN8x4u+m1f/+V8Qac1v/cavcP1nP87b/uUfsVWXc889kxe+8FvoDwY8fvAw7//Addx9zwPs2nkG11z9THrrPd759rfTba/z9Guexumn7SJNI+JIEUd+PdZPGE1lRqbuIBN3p8nSOlpFxFlGGSkGkaOTxjxWOd7yxRt4+d/+PR+5/wGOxzEm1tRcyZzJmVg9zlx7le2lZUsF8Wob1e3RyjKyNGGtvc7i8hJpLaOqDL1ej3yQMxgMaLfbrK6tsra6RlmVGGuGrlaDwYB+r0dRliRJwt6z9/K85z2PhYUFZmZmaLVaw21yctJbKDWp1+vUahlJmhKPgUkCDIjVSnB/82ubKCV1al0A20SJCRGnirKHNV22bmnxtrf+E7t2bMEZS5Y0WFnucdc9D3Pfg49y40238qUbb6KsHFXl+YkUOCecIQ4hQH6y4tAURlFVFoy4iH7m05/k/R+6jv/xM7/AS3/lN+gUjpf9z9/g13/9d3nZS3+FZr3BK17xa0xMpChdobQjyzJ5du+SBmFiLy05jmMBUhAXKvCAT2gzpvIhvYWTaKhQnwBEqROs+AScCRxHnqjWu6GF+8l5nk8lgFMb3ENE2Qz1J+LBKOvd3EIepCJlTJCMDtOQc+TfuFLhrMUab/0URcO8OMZWwK1cY7zlogtJjm0OhVXBqTL0LiE5l7HRgq3A5OKaZhXKOiIgUY5YWbQyKG0kUp+2WG0wcYWNS4gqIf9VECtFrMWyTEUKFSs/0xLwymiL0QJMKKtQRgyjNBqlY+EACllXAh4Z5TAepZJ9AhA5BHjGaf8poJmM86CdI3IW5YnWjYzyuDBW49AYtKvQYqcFQckLBfz/sZx61P5aZATOnErc8H0n7SSU5RPLycr9+BUy9jhvlWkpjaWsLEUlrr8nbcZQVhVlKZa3gTMm/PlRbAwUCL/lXgTQaSxPJ2Uv5C9cs+GQFI4kcXJBhdav/Dgi32VsUPg0nR9nfeougEueeksSGlngCYihGAxyDh46hEJx3nnnUa/LO/1rE4dDOoXF0ev36SyvcsnZe9i7ayv1umI5H7DY66KdZaE1IeOM7TORr2Ifugl718eoH7+Zav+N3Prht3PB5AQrxw7y+ZtvYX/HcLBIWKVFfW4Pen4PSjV83/na27yCoYXNmgdU0iyjLEtqWY04jqnXaiNw0Y+9IQrnMJGxW4//DDUoluUS1MEYi6kMzinW19usrKyKpVlRcuDAQSpjhK/IViitqExFt9sZgnXe29aTIHgLpeGdHFESU1kjY4SOqNfrzC8sMDM7S6PRIElSojhG+UUKawy9fp+jR4+O+pJ/iDDeKhXhnKIqDcYIGCZNcwS4ji8obMqmbMpTTzZBpU3ZlK8DEdrLMdeQoeJmUZTEriBxAzI3IKl6JFWPuiqITZ/lI49z3z130uv2mJ6ZZ2ZhB7WpedLGJEmtiU4ynIqwaIzz4X6DxYmfcGmNkDobQ56XFIXwuWRZhrEVpjJY56jV6hIFLU0ZDAZ0Ol3e9a53kaSpV0ZFYVXBjPoJZDQJD5NzUb7TLKbVqnPOvn382q++nDf9/V/y0h/7XhYmGpgqZ73bhijiwQf384rf+n3a3ZLKwS/88s9z5RVX8LrX/AVXXnopr//rV3PVFedTyxTW5Fhbccstt/CRj3yMqalZzj/vQuZm5vnCZ7/AoNPnwvPP4+orL6fZqIEzOFNRVTllOcCaSqL1BCXfgbIOZWUOGFmoBgVKJxRE9OKU41HMR++9n997y7/x9i/fwmpzAjsxCVgaVU5zbZnJlUW2DfrsdtBot1GrazSsZabVpCxy1jrrRFlMnKXi6tbviQvcoE+73WZleUUiuHl3JGcdbe8Cl+c5/X6fhYV5rnn6Nezdu5dWq8XE5ARxHFOr12g2m9RqtaGlUqMhrm5xnBB58/0oEtN3qSYBEEacSlJ/bggveWXHq2YoUdB0BJGuyGLDwmyDN/7jX3Ph+fsoipJafYJe3/LQY4c4cGSRW++4hxu/fCvOyj2Vc8KF5MnCT1benlgcCp3USOKUCEUWR+w9ey9LK+uotMH8tt2ctmcv6JiF+QX+7q//hpf/0i9y1ZWX0GjEJLEoblVpUcTgYiKdjQBgH7EqkG1b7yoRxcKlJH3BEkUCOkWRcCaFFWg3Bk7i97sQ9c0DtC6AS8EqyXNvMLS2kAKxToBPPDgVlOHx727MvS3U09gggPWcUAKIBWV1xG8TXPnwFiYhz/hUQgQ6AbxG/T9EFtJa0sX5tE/YCFClEsslHGgDkVHEThFpAYBUFKGiGBXHqESjswidRqhEoRONTjRRHKPjGB0rdCwWc3EcE0cxkY7R2rt0xAoXA4kiSrRscUQSxaRRBEaeO0kS0IrcCsAerBSsAutBKHHhlYxbBJwKTxr6RPimFOAMSlkclSwkCMu8KHMocEJfr2xJpEpQBU5V4hI9rtv9f6Xn+fb1fy1fHVOS7IZH9PwsAfg49XZiCmH/CFQBsbRwSLSqojLkRUlRGvKykq2yDEpDXkl49NIYSmsxPg+C7/i0Q7scAjj+fnZ0Rzkux04tp94f0g3Hvb5+koyPCx5rGEool2BRY51E6DJO+o47YS6hvKvqenudY0ePgoJrrrlmGKXyiZ/hiUScux2KopvTX11n23SLOLYs9rv83t+8jlvuvpOZyYxt8y0KZSlMj86h+3j40+/g8U+8mYc+8c/c/9l3sMOt8q3nnMY/v+UtfPnhgzxSJKT7rqE9u5do2wWgZlGuATYWv6+vQRQQaSVtBlhcXMIBs3NzQ9AoyzKwAiyG1Csr/IChXELp+GYr9RH2hwpUWupVaeIkJYoSer0+7XZnCDaF98TRI0eEx8nKe1JHipnZGbTWErDBCbweRQJgBwmtrzIVlXXEScL8lnmmZmdIaxlRLO6SYr0keTNVRVGWHD92fFTXavgko7SdoywNVeVQKh4uPir/XNb4+c9XmddtyqZsyv+/ZbP3bsqmfB1I5KznTQKjYr9pwBHZkprt07DrsqmClILV40e44/bb2X/wMGl9gtb0PLWJWeLGFHF9Ep01UHENS4xxnqdJjyJ5yYTCqznOcvjwYVbX1qiMo9cvKEtDXhboOBZzaGMxlaVWq1EUBfV6nU67zcMPP8Lb3vpW+v3+ULEWBXncYuKJxeEoTYnVmuOLSzz84AOcdebpXHXZhSxMpGS2g7UlX7nrAc676rl85GM38NMv/Vl2nbGLV/zmb3PowBKLR4+j3IDzz9tDLYl4+tOu5NpnP5Ni0OeWm28WhTJJufKqq3na057GQw8+xMc+8lG2b1lgbnqKSy++CFMVOFvibEkcObIklhVCLRMupRRpkpBUAiSJCiNTeKcUOTHtqM7nHj3M777tvbz2w59mPyl5o4V2lsl+h13dNmesrnBmb8BppWN2YLCrbZQz1CdrkMKx9SW61QAbQdcTi66urQqQtLrK8vIKa+vroKAqK4q8IM9zev0eVVnR7/eZaE1w4YUXcumllzA1NUmWJSRpTKNeY2KiKfxJrSbNZp1aPaNer1GrSdS3NE2kvOKIOJbvUeTbjh6zplHCwRAWNIPCPPzlHGVlcRZMZTBlgTI5C7NN/uovX8Wznn01eZmTpHUWl9e5674HeeSxA9xx5z3cfsfdFHnlm2iArDZOgv8jcTjKshyzmCrZc+ZZ/NiPv5g//MM/5qde8lN8/tOf5IoL9/ETP/q9zC+0sLaPo5KIStainUYRgYtRZDiTel4l4bBxCIjknCOKY5x1lIW4GoY8u2Bl5JWY0JaGVjs+rQDm2GBtFAyG8EBMcLPzoJS1Rib9HjgKAI/1bnKhDCCEkSdosycoknJ9sJyyVgj4w7nGiM2M8emqwPHk+UOMFcA5pONEE/f3H5OTfoQNcQOzCqcMRhusFh6r2GoiG2NtQt8lrKmYdmnpFyV5ZejmJd3S0CsNg9yS9y1lH6o+mJ7CDBRmoKnyiDLX5IVmUCoGlWJQWfqVZWAsg8rQKSu6ZUW/CFuJ0ZoKR2VLcIaaVsOw59oDzA58NEKDcmaMrhsUpd8q8JEInTZUqsJGUGFxGhyG2BoSZ4gwKGu8e55Fa4dDACiJtDnqB8O++B/KxvLe+Cnbhuo5pfxHaYzve2LZcIZvz08e1NiYB/kmo3BRGQZFSbefs97ps9busd7pytbtstbpst7t0e4O6PRz2v0B3V6f3kA4iMb7hHOjscx50Hx0P5/X8TwP2/vG5zjx94kyfG53gkuml3EwKdS6kEF7En6fT0sAlAKoJOUyHH/8O7+93qbT6QCOp19zzcjNKjzzk9jw7R6EV6koYbUqiVspKMegrDjQ7bKWaHSWkCQJD650+Ov3vJ+H+m2q6RrJdB2X1tiz73z2XnguH/zIu1lSMf3aFM/85u/i6m/5IS7/1hez/eLnU+gpylAAThZznqyE4lWIlfEDDz4IKObm5nHW0e/3ybJsWAahQzkP1IWyJHwO6yPUm9/l34FhYc06x3pX3teDQeGtOB3OCeDT7fc5fOQwRVUO3yNZLWNmZpoolvFVIvo5WVgcvgOlHJSOmZicZG5+Hu0DPFjna8QvCDnBpbHWseRdHiMdCVi2wSJUrETzoqIyFpQeRngbURhI+1F+UWJTNmVTnpoSvfKVr3zliTs3ZVM25T+XvO4tH8ZpCduNVkTaoV1B4kpSchLTI6OgFjkWjx3hwQceYHm1TZy1qE3O0pheIG5MEtVa6KSGihJQMegYdISKJJIXWladhouYzoGrMHmHpaMHOXb4AFvnZnE+KgjKoZRFa0WZV2JxkQjPjkMU6bIsWTx+nJWVFS677DLKssS5wDPjJ2meaDiO49FEemx6YqjAQaM+ydpaj0998qN82wu/hVarSeUMUZbxyOEVPv7ZL3Pzzbdx4YXn8V+/44U88uBDfPB97+fG6z/Lvr17+LEf+WHSOEEpy9LxRe656x467S4TrUnOOuts0jTls5/9DP1eh2c982ns2rWVRj0BrKwKquAS5C1GtJKJmLdYcFY4W1SkMUpjopiuihg0J7l3ZZ2/fNe/854v38wjnRybtaASy6SFKme2s8puU7AlL2kOCnSeU1UlcZaQ1FK6eZe8zFERlFVJnudURUGRF97drcN6uz20Tqr8CuQgzwVAqSpQin3n7uOiiy9m2/btNBoNGo06jXqDeq1GVquNeJQaDRrNJrWagEoCKKUkSUKaZiSJAEpKqSGwBI44TrAOLGIRYiyeKDmiLEuSOCGOIkxlQEXitiB2eB6ks9TqKc/5hms5dPgwt952O61mg36/S7vdplGvM+j1yfMBu3ftQik1Ih/1fBVKiaIwakOS+viUN7hKaJystDpNbhWveOXvc9ZZe/m93/ktXvi8Z/P8Z1xOLXU4ZciLglrSRBGTxDWvxHueMSf3cVRDZd45JxY5HvRxIOCS72RqjHNJ2s4YABT0GJQonx6IHfUb5yfzcl7oO9ZHXUT5SHNDkt2RUmy98id5kHZrPXBkfD60GrnVhWsUAgiPu9gFC6WgUDjv6oYT4ne85VI4NlRSfVrBmoJwnRd5OvmnPYGvcxXOlSSJtKcBmiKrs6xjDlnHUR2xFGuWYsWShkWtZItjlpKUxSRlMU5ZTmosRQnLOmElSlmKEpbihMUoZiVLWU5jjmvFUgTHnWFJK44pzZLSLGnNca04nihWaglrsaPMYpzWuMoQeU66YQhyNx6rUx4sAAPaeSY833yUjrCAjhPQsVgVOOVBgYI4S9DxKPqTWN9oUBFOJUAs4dydRUcylge+GP1ECp+vE+dGeim+/wx/nvJC3wqH14f26OvXa54hap7ylkfKR4vE1/+woW8Qn5a0WvBWf84J91jk23O4V7gmvLtC/wj5Kk1FUVR0BwXtbp9Or09/IGNjPy/oDQoGeUFeGgZ5Qa8vLsR5XowI5Z2lqixr622OLi6y1u4SpRn1RoM0SYeu3f1+j/W1VdbW1ygKGXuV0tRqNaanZ5iemibLMvI8p9tpU5UFE80mC3NzzM9MU8tS4jGy59BnK+soioq8KChK4y2ogqURvs15CysjLsFKh7FZXGOrylBW0tedk+uSJCZNImIF9959B5/51CeopQkvf/nLqdUyAZxdqKsnIwFYisFqjq2X/OPb3sPlV53P+ZdfzLK1fOXRA+w87XRWV9pMbN3B337ggzxUDljqdrn2Wc+hHMDCZdfyvlsf5aO3P8CaccSV5UdfcC3R0iE0KfM7zkXXp1E6IsaCLlE6WOk9ufV2aZNi9dPpdHjVn/4Zq+02T3/Wc/jIRz7GRRdfzJl79lDLEqamWn7MjFhvt+nnOdJlZPxKkpjp6SnpZ76DWw/uKc9jF/pst9vjyNGjQhKOL1/PKacURJGMr1VZUa/X0VqjlSKOI2r1GoPBYPguM0aoCJSW96COY2bmF6jVauCbkfN5UeGd48SaMh/kLC4uCi9mAIUCn6YSIEpFEZWxGGPFRXesHWx8V0kZbNu2lW3znqtpUzZlU55Sshn9bVM25etA9nzzS3G2EpJZU5JEjlQbIluQKkNkctZXFjl+7Cira+vUW1Mk9QlcVKfWnCLKGqgoRkfxyALCE5QqJBSsiEwIFRaswZoSW5VU3SUG64t0V49x+vYtnLd3L3GsUdqSpAKsZEkdU1miNBpGN8kHAxwSwjqOIq55+tN50Xd+p5BIetPrJE0xRvhMnkgqVaKJcVVKr9Is9XrcePNtrK6v8bSrLmXn1nkefugwL/ruH+anfu6n+PD738Mb/u6vOPuM3aytLBLFMY1WC+cUd911F81GytHDh5mbnWfr9u1oHXHLrbew58w92Kpizxm7wVY4U5ImEdaGiZNfEVRhZRaSJBWOHyUTP+tKiBIGVtFxmmUDn7z9Tq678csc7eeUSYpRMXVjmKwK6lWfybLH1lhRH/TR3ZyqrIjSmKie0i8HDHp9Es/NU5UlZVFQDnIGvQHdXo92vycE1lpjigJnLXmeY71LGkqxdesWLrjgAlqtCYnoNralaSpR3IZbSr3eoJZlxIkARkkSkyTiGhTHCUmcoCPhiUjieAToRDHGOqJE6jWOU+8aV5FEykfakQmpU7FE13JKylZVOF3hlMaqlJW1kj/907/i397xbwTjnqlWg4svOJfTdm3jyssv5rLLLhZrIK9kiVVMUMgQ5dJPknFBSfWnOBCVXWGIyUn57T/8U/YfOMxP/Y8X8/TLL6RGTu4MJor5g9/7I07bcTo/+RMvpl7LcK7EugqtI8QIL0Ip4y2JRsCRWCOF76L4KA/axJG4w4mFjwBCzjmSOKGqKllVHnvNyzkC0igfRVFrjfacReG5rY8uJ9eIK1BwTQiRrULZOL/yHgjPpW1Lv2X4XQvZaxSJMubbvxorV1G+Bcgw1njAdeT+N1KuRJlSWsCXYd7GrFLknj6f1hEpjdIGqypyZymilDWXcOtjh7j+vge498gR1m2BjUDhiHwkNuXAKQHMVRJTGYvWEWkUkRB7hdxrmFrIjJwTi8rKlkSRxliHi2IPfcoKv9EWFTmm0oR9C1t49jkXcP6W7UyUFQ1jMXkuIFMsfFmRlohsoXU6JRaoAE5rjJO+U1lpj0pplHPEobwpZfzHoVWEKZUsCOAVfueE5Bvn3eb8kOVFqRFIFEQP98nZ0vaClYtP19f1xtREnAerpE4lreEz+rxbJwppiCiIk2cICu6p0j2VKCXtSjj5HFqLlcVIpJ2GosCDOcYKoN7uDoag0qAoMQYqW436ltLoSHi6JACAJVbQqteZaNZp1jOKsmL/ocPccfe97D90mFpzgtm5BZrNCZI4pipLVpaX2L//MR579BE6nQ7WR1Ocmpnm9DP2cPppZ9BqTdJur3Ps+GHyfpdtC/NccM5ezjlzD9MTLbIsASv8WyF7/cLQ7fVZa3do904R/Q1NUZb0i5JeXlAUBVGkaTTq1NIUHcniR1UZBA9WxBHEEUy3GkzUEj7w3nfyl695NS/85m/iTW98A/VaTRYGKkMUPfmYag6LrmKchtseWeVbv/8l/MhL/ivnXHUhH/jcF6gaM1xy7jkoZ/nQJz7GirY0ts2xO4t4ztZZvv28M/nQ5z7D3QcO0q8ce7du46e/9VqWb7iOA3fdxDUv+jFm9j0PE7eEZcxWWO18RNAI/aTjvwHOYU3FnXfeybOe8w20+zk//0u/ynUf/ig//MM/wpVXXE6jlnL6adukqaqYQ4ePsby6Np4I9VrKabt3EfsAEmH8tNYPkr6tF0XJocOHcd4lURYm5K0U/o/c3ByNeo2FhXmatVSseZGgC0tLixgj7w8JtKHQWjEzO0eUZsO+Pnp1qOG7BqAqDctLS+R5vrEHOr9ogHS60hjP8aRGQQC8SP+VPmdtxbZtW5icmmTvrm0bztuUTdmUp4ZsWiptyqZ8Hchr33IdkbLUY0ddl9QYkJGTUtBeWeS+e+/l2PElrI6ZmJmjPjlL2pqmNjmLSluoJMNFKUqPSLglXLVGRwIaxHHkuYF8RDlTUBYDqmJAOejQ766DKVlbWSaNEhrNOhaDMYWQeBsJU1tZv+rlLTiEYynBWMPhQ4fIi4KLLryQsizRkRA9i3Y6Iu09UawyxEQkaGqRJq3X+ds3/DP/+p4PcuPtd/EPr389ptfjjq/cyJ+85k84dvAIt9x4I9/yTdfSbMDkxBSHDh4jjhIeeuhe7rvvfp71zGczNTXFAw8+wP3338eeM05n546tbJmfQTkB8LQG40SJF/FTPyUuSJWRFWPnFElawyhFnkAPTVul3PjwAf7i7e/m848+xnHnoFEjVY6mtcz2u+wq+mzBMGtLVHuNYn1dQJx6RollpbOKoUKXBlcZBr0+5SCn3+nRa3fprK2TFwVlVdEvCwpTYQpZgTfWkg8GTE1NccUVV7DnjDOYmJwgy8TqqOYtj2q1GrUs8yTccixsSZoSRQImJUlMNGwrQtIdRRHaK2PKKzcVMUQJTsWsd/t84EPXcez4Ert370YrCY2snI8C6Ky3Ugrt0hEnoLWjqkrSJOWZz3w2g0GPL13/JZrNFlXlWF1Zp9aos9ZeoygLtm/fjva8FOOKamhJYVV3fKKtEMJ72RGiQSkuuvgS8n6HZpaw76zTUa5CJTUqV+PGG2/l4IGjXH3106llGUpVRJFDKekHUSQuXwqZmAdgJCjZCpmoa2/JIuCLt1TynENBtBqtbgdFIljGWU8ePASXQp/xWr3zVj+StuwPlkzKWyPhvNvb8JqxAgr5H7rUSfSiAA6FvAnw4K211IhTSZ5H7iV1LG1jWAbhLtpbYQW93iMCoS0JUCjPaa0bugCXccKR0vCnb38nH7n/Qe4fDFhvNmgnMf00ox9nDJIaeVxnENfpx3W6UUpHa/pRTE9rBnHMQMv3fqTpx5p+HLHuLP04ohPH5PUGazplPauzmtXoJhm9OKObZKynGe1axppWHOkNuOPhh1mtLGfs2onr99EWalGMq4wAgZFYAIzaJGjn2fKUFuY8D6xFSpEoRawU2llv5abRVGhToJ1Fo7EqxnmlVGGIGFl8WWs80Cj1Nqxa/03qewSOC9gz7Bz+NRH60cljMifUFx7wjHQk14cbDhVPDyJJJ/B6tr/RkxClxjiWTnHNEBsa+od5hd3hXbZz+nlJb1DQG5TkpRGybk/eXVhHacQ9Ky/FyjMAolEUU89SKmtYb3c4evw46+0OUZJRrzdI09QDCJZ+r8/62hpra6sURTEETGuNOjPT00xNTZMkCYPBgG6vQ1UWtBoNFuZnmZuZoR4slU6QyjjKsmJQFBSlBMtwjMAKvNWj8dZKEo1V+r3yrsnGOKx3oZXatqRJRC1NsKbk1pu/wi1f+TLf9Z3fyfO+8bke0A7g9MllfiqxCkpniU2EVbDWK3n/+z/C9I4ZDhd9PnXTrVyw71LmmpO85W1v4/Dxw+zbswvn4Nhyl0OdipseOsijq23WeyVXXngFP/Id383E2qMcueEDzEddTr/iapjYhdE1IifWgFZrLLFY652YqScU39ad4/Of/zz/9o53MDk1x77zLqCoDBdfegnbtmwhTWKmJpv+CkW73d1gqaRwJHHM1OQESkkAj9AvJACBgJuVMTx+4IAATZ5DTvs+MaKDEqtBsZCLxOK4KKk3an48FWvgWq1OVVVUpVivO2Bmdp4kSyVHTtKS96tYR8o7Uri/lhaXxeJprJ+H+wdrJeMc+ZDbKYIxa0cBYwVQUjh27NhGq9lEa5idnBhLb1M2ZVOeKvLkx85N2ZRNecpK6voktovtL5NUHWquT9lZZv/DD/LA/Q9gVMzE3DZaczvIprYQNaaxOgOdEMVxmJGPFAgiojglSTNPWhtCwovptlIhmlKJrQpvHSG8M87CXXffy6FDR+j1+hhrGPQHVJWhqgyxjwpXVRIJK80ylNJEWlbUPve5z/Kxj398eBwfGcyY4NpzsrgKyrIEZdGUxLbkV1/28+zdcxqz07P80R++in67zTOuvJgd0zO84td+kV//tV/AmAGrK30+/4Wb+NL1NxAlju3b53j+c5/HoUOH+ewXPke/3+EZT7+afeecQZaAciXWlIDDeLcgmT55bgSfRR1HUnbeAqw0ln5pWS1T7j68zps+/Cle/bZ3cMgqBlFCqjWtos/WQZsdnSV29lbYkrdpdFaxa6u4siSuZah6ylqvTafXphYn6NzgCku/06fb6bG61mZldY3FpSX6gwFVUXpuoIp+T8i6i6JAa8XFl1zCtd9wLQsLC0xMTtBstmjU60xOTDA5NcXkxAQTEy0mJiaYaMlno14Xd7c0FY6oJCZJEpJEXN+Cq1ukI+JI3N+UVxKNsVQuwpDwpRtv5vf/6FXMb9nBX7zur7jvgYdAxVjrqMoKU5bDKHHOh1t3KKzVGCNWDknkaKaO//U/X8Yrfv3XZF+Ssdbpc+vt93DwyCJ33XM/N91869CNTJRhL16BFRXK16Jozn49PRwxKCpiV7IwWeMlP/ZDnH/+Pt79gev43E138tDjK/TziN7A8C0v/Dam56aJMo3TwZVMgCLhd/JtNihuTr4LuCSgivWAjvNZ9FmS7DrZK5N2OTayZPLWGMHqyQMAzrtjAlRV5UGnECFPpgmVJ9OXvAgQOAR+TCCRHhdZYXc+S1oNTUCGQJFD3EeGGj3CsxHya6wZA5tG5wzFMVRWx48GhUW+y/MZHAbNwGoOrnZ58wc+xu3H11ltTtFtTrKGQmUZKkrQOsNFdaq4TpnUqOIEG2m0s7ScYdaUzJcDGqYvW9WjWXRo5B0mXEniKpIkJgeKLKNMM1yUQJSidY1I1YlVnYgmxFN0owbLSZPr7n2Azz/4AFWzjo0TKiN1qaMYo6BSDjsEUrR89zxISimUE96k1BWktkfNdqiZNk3TZsb2mTVrzLs1JoslWrZDanOUsDoJSTcFWgnfl8JbyPn25huilKcv7NDGhlUf2tzwdOk1TyjBQsm3qzjyrp2hm23QVcfcVJUHM78W8dElYeQqtOHgCd/GP+W7luhVRqJHFqWhqCyFceRGkVdiDRT4sgZ5RV4aSuOJ4X35Dd8Hvn+HZ3fOu7ietF/OHVfGnRNwhzBGhHYervHnBpFnlXOFV2nEsYT/LSf6c/351lkqa6msoagqSlNJZLuqoqwMxlrKsiSKI9ZWVzl48CBKa7ZsWQBffdHXEFETn1ejLJWCo8trGHJacw2OHV9ix8Q2vv+bXsSkyvjz1/0lg5V1rpzdzut/6Kd59ff+OI3c8Hg+4OZBlwPtnBd84wuZjprMt6awroezXSZSRXX0AJQ9rK3IVYzRNQwZkYuI7Vg5jm2nEufrwBjDkSOHUUpz2eWXsb6+zmmnnU4aJ2ANpiw3tFdfY6Mdw/YgYnw0UrHwEVC3KAqOHDkqoI0fy0fzLWkfSivQChUJkKlUhFIxRWE4cvQ4BgnNYh3EccLExJRYBrsAKGVUgYQ7QEWhP3rLcIVibXWdvD/wkWpHPUREwCSnhG7BOeWBa0nKbmiPwtI1MzNFs1UXK23EWnZTNmVTnnqyCSptyqZ8HUjLdahVbSZiQ9lf45677+Cuu+9meW2dWnOC6dkFJiZniWotXG0SlTWJszpRHEt4bGeIEL6fKBJS6jgWKxQCF0NZCoeEMdiqwpoKY0of6UyAC621mNprzf3338/KyjK9XpdBPqDX62GM8YCGKJR4ZSmEfHfW0e12+fCHr+NTn/40xofODe5xzivGJ0qiM5K0gYk0hbPEynL6/CRv+Is/olw5zqv/5M94xW//Fv/8ljdSjyom65o0hvvvf4gbb7qVY8vHuOLqq4h0yvTEFjprSxRFh2c842k8/elXC2+SLUk0OFORRBHOgdYJSqd+qA3K4AhYUt6lwyIri91+xf/503/il37rj/ncXQ/Qr9XpuYrUVsxXJVs6Xba22+wqB0yXfcruCjYfkEQJtVqDPM/prK2S4EgtqH6F6zna6x1W1tc5vrLC0bUVOmWBiSNKZCWx3+vR7/YwRUlVlZx99lk897nP5ZxzzqHRaNJsNql73qTJqUlarRatVpPWhD/WECCpVstotoRnqd4Qku4sG4FJQ0DJbw6Ik8QrebIq/tCj+/niDV8hSuusdwa88z3v46qnPYPt23d5zCVEa0NisQeCYmVwCqrKgUtQLpJ1Z23JYsWLf+xHedkv/CKddo96Y5LuoOLWO+/m0JGj3HLbbdz45Rspi1zmx2PKrIAlvt48QOGP+Om0TKy1s8SuJLY5mJxWq8X1t9zB697wNv7y9W/ml1/+v+jnOVFiUXGFdeKK4IwGl6BJwYp7oAuKvI/AFCb2SnmAy0kmnRU+DHxbcgHk8e5ydkwZFfAO4cYKDzZUGOSxJVV5rqqqhmnheZDE3UkAKGN8VEBfPMEtT8Axh6mM58PxVk3B+si39QAAW+fBp+FzjpQ4/5iyz18T7icA4AgYE1e3EZAVQMLRfRWFhcVezie+fCuf/ModUJ+hNAlYTYZG5QPiskJbg3MVpa7Io5IiKlBRwYQuiRYP0zp+kOnDjzN34DHmHn+E2UcfYvrhh5h86EHie+/F3nsvnXvuIV1r06oMiTWo2GBjQ5VYqsRhkgiShNIpXJSS65gyzfjcbbdwvN9hgEThC1YJRoFVShRDpaTVKQRQxYAqUeQkOielR2LWSas1GnaNSbdEbfVu4uO3sXjHR3nkhg8QrR8ks30iayTcNwnOCq+SDe0oWBEFcMO3pSBhIQEl7U+PEzOPtbmgRJ64qcCnNeTd8lZ3IX0lPqvSHPzesTb3tYhzYvHjkEhT45f75uYTF2WXIQAkBx0+CppxAiaVFYUxFMZSWEvuCdkHHmzKjaU0nuB6rI/J/fwzhUdy8k92+ZNPklGOrbXezTBkOXwZP394t+HHqYpsCJgM+9/4T+nr1oNHshXD71VVYfwCUK/X44EHHqDVarFv3z55z4/38VOIlMOJ4I0DZTmSd7n7vruYbWTMTzZ4+IEHueCsc/ngu9/Pv737nSS55QWXX8bf/O4rOGO6xoXzLX71u1+Eu+tOFo4t8rs/+RLOnJ1h/fghauRMUFHXmqqsePSRB8H1iSiHVjYKN2btc7KcmE/nxMrGWUu/3+fzn/8CAPv2ncuRo0fZtm3bkDMwTZOxcVvqOJSv8wTo/gD48dVZ+YyiiP6gz+LSImVZDsfLMO6HSg1RG2XMFmtDpTwgbWGQFxw7vjikLbAo4jSlNTFBqzVBkmbehdO7/oW24NuFApxxrK6s0l5bJx7jr9soMlYHS73haoOTBSBZBBrldXZ2hrm5WbFSjBSVKU9McFM2ZVOeIrLp/rYpm/J1IG/85zcTa8uRw4d49LFHKSpL2pgga03RnJojrrXQWY2k1oQoQ+l46BoDDENk6ygmShJPphwmP8Kf5KzBeR4hWxVUVU5VDjBVSZX3MNXI915rIWU+cvQwExMTpLGEmgdxDTOmIvNcSeDQkXAEiPKhKIqKgwcPMjc3y5aFeZQW95rI88eEySxhMmhlFa8yBoW4UMXaUUs0F19wHvfffTfPvOYKpqbqGFPxyCOPsLS0wp1338Ou3adxxZWX46zh7jvv5sBj+5mbm2TfuXupNWo4a0ki4S9xYxwFSofIZc7TBMv0VdRBmWhXTlGqlK6J+OAnvsir//bNfPKme+mjmdqygFKWhi1pddvMDnpsdRUzJofuOpQD4igiTVMqY+j2OkSRQAJlkVMVFd1uj067S3fQZ7XTJi9LjHOURYExhl6vT1EU5GVJWVXUa3We8YxncPppp1Gr1UmShFoto9Vs0mg0aDWbZJmP5JZmNBqNDSTcIwBJovJEPsS6imKJ9KY1kRJyZq0jIRFWEUVlsSje8e738tjBJR557HFuvPHL/MgP/xAf+9iH+ckX/zhnnLYT5XnBYk9EKg0qlKx8j32UtEiJW5BSMqFNs5SLLrqIqekZrr/hBhyOQZGzsrxCkiRUhShHWxa2yIRdOawTvh4FoxA8YQLvPHeNn9ersErjCUqTrMa5F1zIJz71aa684nKe9YxreOjBu7nqyovZvWsbzlQegAktVUCSQHQtNSl3CMAI+Dx4lwOlFVUlfDthRdtaR6R9P/AcUYpAduzLakxxDHlwXrl3niBb7jmKziYKkAcKwjam6gYAyyF6RHDfk5MEnNK+3oLLhlSfT8e7sQasSyH5Uj7emdLCXoXSYjWClqhFY+T3kVLCt4WsjpdochRL/ZxHjy8x2WxydHWFd37sE6xnTfLGNKUWK8sIB9XIncRoh4mccB9pS6oss7WMFz3veTznksu5bO8+Lty3j4vPOZeL953Lxefs46J953HOOfs44+yz0fU6R9fWIE2wiaaMPJ28r8dKiauPNKUKhcVWJa4/4PS5ec6YmiAucpSKqIhwOhYiXeXQGDSGSBk0FZEbkDIgs23q1Sr1cpmsdxS7/Ajr++9k7eFbWLrvi6w+9GX6KwexKKZ2nI3NZjA6xfgohNpXitSbr1kP8oyPqUFcAF2cjHPye9QfhqKkzZ2YjnNjrpDDNu8vkbfByEUTseYTPdfvlwY0TO+riUKiSQ5/DD+d30YfvmEOz6uMoT8Q97f+IKdflMJdpT3Xls+3tRbjAVdnHZFW1LKERj2jkSVYa1lvdzi2uMTaeoc4TanV66Rp5hdSKvr9Aeura6yurVIWYvEK0Gg0mJqaZnJyiiROGeQ5vX4HE4i65+fG3N+EKyuIA0xlKauKQV5SlBIy3nl3SSldn39jKYzBVBUOhY7FrdJYS+Vd/YwT4AAgTWMSremurfCZT34c7Sw//7M/y5aFBbGi84jaqdrPKatOgTGOA8dWeMMb/oXLrnwG2/ecw1nnXcA//eOb2P/YfiIs337ttfyvn/wxdk0mxMqSoNgxN8Npk03+2zOeycVnnM0dd95Go6a4cs82end/ktUDD+PqU2y/5Dlk2/bhogkgJnL4CItjbeTJiG+36+02v/prv05l4enPfA4HDx3mrLPOZmF+jlarTprETEw0pUUrzXq7w8C7NgZJ45ipqQmcD1Yho6lsi4tiVYySd0QAjmQcFhdNb4MnZe458cK5DgHd80GOtY56vYH2C1o6iqnV60P+Jh3GYbwLnO/QWmkGg5zlldVhXeqhxZ/cFzTGWyoVpRnRJfi+7AsNcGgFrWaT2dlpFGLpKt3RMT+9SdS9KZvyVJRNUGlTNuXrQF71F6/h3vvuZXW9Q1Jr0piaI2vNEtcn0bUmUa0BSQY6JlLCc4PSoCOZeEaJDyUrlhT4VWyCT7yzOFOBkXDV1pSYaoCpCqwtqfIOzlsVoSRCESisgc56l+mpaeHY8eFu0zShMrIK6pwVUu/gp185Ih1jqpL777+XqekpTjvtNJmoaCUcDpFwCYT5YbBi0MGiYUhYC1tmJviOFz6fqVbGgQMHueu+h3nv+z/IxOQU3/RNz2dubo6Dj+/nrjtuY+uWWc4/fx9zc3OifOMkBLgn9A0TPKckIpOOENcop9Bo0jjBWXGfKJ0iakxz672P8Sv/+8/50Odu4+C6gWaTqizYOTPFpMmZ63fZpQ3ztiDqrmLyLpFyJGmKQ9PutNGRPLfwJ0gkot5gQKffZb3fpp8X4lpWltiixJYVeT6gKisGZUmcpFxx+RVccMH5TE5NkqYp9XqdVrNJrSZcSfV6nUajQa1ep1bLqNUa1GsN4U5KEtI0Jk1TsUiKIiIdE0cJcZyhkwy0ppbExD46jdIxOq2T24iPfvIzdHoDbr/rbiqb0u0NeOThB7nhS5/n5S/7eeamm8xMtcBVwyh5KrRRgVfCfHsETAwnsxBpB1ZM6y+57BKarSbXfeSj1Oot8rxieXmNRr1Fr5+jUczPzaC0RSmxuBMQQ6HQEp3PCdgpQa8FyAj5kTm2rNLPTU1w9WUX8pEPvZfJVsav/NJLOWP3LmKlsWWFVmBMRZzGEplPa/QGqzblLfx8RDArE3ilNKYSri49JLOWlWOx0PGEwb4AnI+MCKKMxIE8V4vFmFg++MJCAADpb/IsoswLWGWMBwJ84tZbBwZrEyH0FcvCwMVjrRHXJisuNeG79tcoX6f+1h6EUGg3skxySkiwldI4K2WAq4TUVwKa+fspbBQzUDFH+wM+d/tdvPm6j/CZO+7i2ssuZXHxKJ+66SYGUzP0swYqiYgir3hFdRnblMNFChcJmBVpRYwiMgqlYgaV43i7z+FBn2N5wWJRcWxQsmQsi9ZxvDIsW8MajiLVkGU4nRI7RWaVRKKLxIWQoiCyFucKlCvBpMzXWlwy3yJ1BbiYOG6JV4jKiRkQ2x4ZfTLXp2Y7NGybqHMId/xBVh64kdX7v0T7wRvJH7+deOURap1DtIoVptyaKHeTW8lOu4Qqm8WSetYUh9Pe9eQUivWpQYERECREvx4k9RqitMXRdf4uw0UFgTJGafmL5TotfUkhdQAB7BoBlpL2KfJ1CgmAGXhLUSXP5HDeHcyhAudSaPteTCWRG/t5MeRMkmAAYfwRkNlacVeqvPtgEivqaUKrnlGvyUJMu9vj2OIi6+02aZpRq2XEqVhrmsqQD3JWVtdYX1+nKivvgqhoNltMTU4xMTFBkqbkRUW/18GUJRPNJlvn55mbnSHLMh+JS57PBvfwSkChQe5BMak0r+L7jucclbXkZUVVWXFVUsIcV1lHaYUcWtybQOISgjIVndUlPvmRD9Oq1fipl/wUk5OTUjbDen2CLfjh+U1ZDVXMyvE2L335b/HJG2/nxjvv4z3v+xCLx4+xMNHkl1/84xx7+EG+/bnPIlOOKnLE1pFQcfGZe9gzuwBO8/Ebvsi+fTvZ0jnEY598C1GSccG3/ADZ2c+EbCtW1RBWMuHHs8N5gW8r/9HmBDA7vrjEn/75a1nYuoMLLriYdrvNjm3b2LptC61WE6XVEDACWF1fpyylr1m/0JXEmunpSZwH+6yTejl6bJFut+ffL6MGrPC8cSiqymCMk/1+MSX0QYfDKgdG7l1VhqIsaDSbEBYulMIYIZ1XgEDsIYKn9NNur8/y8jLWWgls4ZxcbZHepSMMmtJzi6HEWjt0Oun3wercMtFsMr8wRywTKA+uW44fO8Zpu3bJc27KpmzKU0o2vjk3ZVM25T+l3P/g48TpBFMzW2lNzpPVp6jVJ6nVWyRpgyiqEenUu0EI4bDWEVGUEMUpaZISx4kots5RWYOxQiDrbIX1JvLWyT5jDdZYcYUz1q/OWz+RFNeCYBmR5yV33nUPa+sdur0Bzlra7S7OcxVYaySsvZOlbq0QgMpY1tbWue66D/PgAw8BmrKswIkyEqxkThzmQjpBKXFjpuzHjh0lihQv+Kbn8+xnPZP22hpf+fINPPbIw1x15RWct28frWaDOI5JY0XsSiJXoRGQweKoABWlOCJMJfS4yhZgBwzKHgNnGUQNHjqS86q/eju//Io/Z/+RdVSckkaWWddnd13R6K8y50qmlCEtC0yvhy1KEpdQi2oUg5JOp0uaZuR5QZ4XDAYFa6tt2usd1tbarK93yHOJ5JPnOWVR0m636ff75HmBUopdu3by3Oc+l9PPOJ2p6WkmJyefcJuYnGTCm8s3G3WyWoj6lpKm3kopEsL2OBJlPFIQYUk870OUZug4Q0UpRWl54xvfTJY1qDUmeekvvJxWo8ba8nF+/3d/h9/57d/kwvPPZc8Zp2MrAZSUJzmXCeuTE+e8e10SgzP80A/8d171f/6QZi0lSxOKouDWO+7gwUce5ZY7buMrt9xMZcRNTEc+xLpTKKelfRELMbJopr6NyeQ5ThKiKCLWmjSNOf303fzg938f99x5O+WgR5kPsFWJ9sTyURRJpKU4xjmxcrBWHCKsc9Trdf8MAsIo7w4arPLwYEpoywHcER1Rjo+3c8bdjLy14fDaMQBgyD/jgaphJLbgEhcsFf29BMzzgIAStzfJsyhA4dxICwE4Q9e14GInCRmtMJGi0mAihVUWvGWOMgWu6BGZnNjkkgfjcC6mqDS9UrNSaO4+ssabP/5Zfv9f385ff/KTPFgW9GJFGWkGZUVphbOFROG0oTR9HAMqehhboYwmrjS1MqZexSRlRFUqOkrzlYP7+cB9d/DB/ffzwccf5wMHDvC+g/v598OP855Dj/O+/Y/xiQMHua89wNSmUWoCXcXERYkqC5wpZatyql6XyBgSp4hJUC4lxlLmPQqVUpCinCEdLDNfHWO+Os5ccYz5wRHmVh+i9cinsLe+m8VP/xNHPvUGVr78LuIDNzLVeYTZ8hgzdoUJs0qdHlEkip1DUW9MEKc1z3USANPArTPescJvUZ5P2oZq8tipY2Os9oTR4Rxpdz6wwsZLNogK1mvBFS6kG074Wjq/F+efQT7HD4hbm7UBKDlZTrUPTjww6l9yq7Fn9FZ+UmSiQPsDOIeAWf6EURo+ryem79MenheODn/Ldc6PHxvOG0sbvAsdzpP8+8dxeLBBrg/vdmMM1hjM2Ga9m1ZVFhw6eIBut0OtljE3PzvM+YnjykkyLAvZlDaktYL5hSbfeO2zWD58nAfvfJCpbJLzzjqXX/7Fl3H8+CHOv+hsOnmXpfUOa2sFS/2CdadYtY4+MasOji4fZPtkwYEb303uNB0a9AsFOgXf5gPPofQB+XvS4p/rvvvuwxrLzMwsys+dlFZkaQrhHTKW7JDPykqUzjiOSNME5RSR1hK1UylWV1dot9swLB4p1eGn9XMkP9eSehEgMvhcOueXPvzCh7WWTqfL8ePHZeHNvzt0FA8tXqUdSLsI1rDLy8tUZSkLiNagvDuoWB1LZM+yLP3Cx6jthn6nvbWsVop6VmN+YWHkuu0bixIUbFM2ZVOeorJpqbQpm/J1IH/6N/9Mc0Lc3OK0SVafJIprKC1RtlCxROdAzPm19lZJUewtlEbWSdabvlvP64B1OG+dZE3lrZQKTFVQVQXGFChTYP1kRybUAjAov8JtrGF1dZWp6WmxOtCasijJsmz4DKKsaiLl+XT8oni32+X222/nrLPOYn5+XhTgyIfi9ZPaMIHcMF/0k5cwh7HWMjk5xdT0rI9kczOrq8uce845nH/eudTSBOVX20xVEitRwoLiExQSpRR4kuPIr3g7HKXSFCphZQBvec/H+ePXvpE77juA1XWyNEXbgpQBe2Yz9p22hanEUncFqt+BYoByhlqaUZYV/X5fInNFEUVR0uv16fV6DAbCTdXudMjzAfkgxxhDv5+Lu0SvhwL6/T67du3i0ksvZd++c5mcmKA10aKWZbRaTRr1Oo1mk2arNeRHqjeEKylEf8tqGWmakWYyKY6TmDRNiLT2nEmxgEBai3WSjrAoDDE6qTEoLUlW5+ZbbuULX/wiM7NzTE7NsHzsMNdcfTln7zmdrQuzpLEQEEtEHAEmxdJp3FVmZIUwEplI48s/imJMJe6aWmvOO3cfO3Zu533//l6SNKU/GLC4vEyaJfT6XaqqFMJZ50iiRAAlz+k0tEpSoWXJptDEsYAmcZxgfBSlhblZnvfcbyCNNY8/9hgTEy0BRz0I5Ky0HevErQekjw3JsLX21kjefWzMUsN4gKmqKgGzkmQI6Cjf/gPY4zwwZYwRa6VhFDgpqHGgCufbcmjTXsQaSPhplAqK1UjZ1d6FTwBAsb4YXRcAKg8sKCVjwdDyUSI1WheAZ0YuiN5CResIrRMqqxgQY9I6uc442i245aH9vOHdH+Bt132Cm+5/mMPtPkWUkdTqNCLNt155NccOHeb6O+6kmpnB1BpkzlAvBzTyHrViQKMy1MqSelHSLCqaeUWrrKiVFVlZklhDqkCbioaLyJwjsQFmdMTWMhHF1EpLrV9QHxQ0ipxa0ade5DTyAVkxIC1zmlVFrZeTGeGgckpTqwxnTk1x0Y4dxMZSd4ast4RbfIDi+N20H7mJlftvYO3hr9B+7C7K5QNE/WUy0yYzXeqqJHYlylUMwQHrwFqsreipOvWd5xEtnEOpW1gVgHeHVoEkdwTEDzGJk/pXaBdjbWRMJ1TDf2O/AfDAZ1BavYsOvm26oY2hXKT8MzivwIY2JNY4o/v/R6LciMtuyGnn3UPtkCzeu3UGlzykfVfebWxQyGdeVuK6i7g4Kw+YSVqhH0MaaepZSrOe0chSrHW0212OHl9kbX2dJMlIsxpJmqJVhKksg/6AtbU11tfXKIvSWypBvdFkamqKiclJ4iQlLwoG/S5VVdBqNliYn2d+dpYsTaV/DS2xPDhUSWj3QZ4zKIuh1aOASr4reiuronKUppLn8HUiTUgAptAokjiSRaWiz0P33M2tX7mRHdu38bM/89OgA7G6k/HMSYmPb6P6G980OHHJuuSSy5mdbnHpxefwA9//X9m2ZZr3/ft72DK/lbe99d386z+/h7e+9f285d/ey7vf8wEOHjjGoYPLHDnS5tjRw9x1w6d52lk7qVaXSJqz6Mkd7L7g6dBaoDCRd89yQ6JraRGnepecWhRQFSXvee+/86nPfJYdO3dyxplncujQYXaftpvdp+0mjiVQxUSr4d9fina7I4FDPNher9XYumULUSQAjXOa9fV1FheX/ZgXLEPDXSWDzjmx/PFje9gXeq8vZd+HpB7CcxZFgTWWRr3uraXkueMoRlmLsZIuzrK0KHxOSZxIvx3j7NNRjAOKUiIhjvVeybN/D6EEjMrSlB3btpGlqfAo+WimIW+tZpO5melhGpuyKZvy1JFNUGlTNuXrQF77xncTpXXitEGSNVFxBsNw0hoIQFKEjmMJ8e55lFAS3SmseobJizHCoySTjApbeT4lU3hOJdmsqdCmHIUxhzDdkMmmn+SXZcnKygoz0zPoSCZiVVkOyS6NkclsEguRpHWyAhYipBw8cIAzz9zD1NSUpOwYckuEVTP8JCvMe9TYxAwUSZJireWeu+/irLP2cNGFFzDZaoKzJHHk3Rz86pzSGO9H4bx7BiEKC2KhhNJgNWWcsVYoPvWl23j13/4LH/3sVzC6Rpxk1BJNVPWYrin27Z5nx2xCXA1Qgw6m1ybT4t7jsKx3OjiHKCDWkhc5nW6XXq9Hv9ej2+3S7rSx1pLnxdAdrtvrUuQ5APVGnUsuvpiLLrqQyalJGvUaaZqSZhmtVot6vU6tXqfREHe3er1OlqUeTKqRJomP6paQpBLdLYoFTIljcafSPrqbjqRdZWmKUxEurnFkaY33fuDDnHn2OWRZxr5z9nL3XXexZWErn/rUp3jus6/hyssvIY0V2hkUBmeMdzHzHm+EsOdSr6dWBEagklICpOAE3NIepDj7rLPYe845fPazn2NQlPTynJWVVQCKoqQsCnbt2EmkI5RD3HY8mGmHSmpQROV+1RD8kYiHUaSJlLhXaG8NNzkxIbwZToizlVIY6wTQ9UqA9hZHQYGW5xg9ZIhgFcChJBHOFnENFKgrgEjhugBKKa2xPp9JIuBXAJ04yUrEl/EJ1k4CDvgy9oTibuw8YyoBo/EdjZOtofylY70T0kSTJrFEL4oSoiTF6RgVp1REFC6mbzSHV9ocWO1xy/2PcN3nb+Qt7/8wH/rCjRxa62PTJiproqKUNK6hjKWmLN98yWWsLS1z03330WtNUGUZzaokOX4MdfAgzU6HbH2NdG2VZHWFZHmZeGmJaHmJZGWZaGWZZG0VtbRIvLxMurRCvLyEXlokWllGLy6Sra2ijx9DHT1CsrREvHQcdfwY0fIS0dIiyfFF4sVFoqVFomOLRMtrtI8eJ8pSXJKQodjVanHZzh3EZUHn2CFu+vR1dA7cgV19gNrgIGnvEHW7QmIqatoSu4LEFWhXoF2Fst61xoH1LoTOlVgU/WSKyTMuwUydQambAiqpMGbJOOgCGD5eMaeQDaCOb/+iHI61ndB2wzVa2tdQwuXht/PubtKYRqcp4c1TAaD2VnCn6PinljFQSUTGDGsd1ojlo7zvgtWfnONA3MaKauj+NhiCSuHu0opHwJIHleKIRibub400xRrHeieASm3iOCWr1UnTdDhG5XnO2uoq62trFEUxLMN6oyHWohOTxGlKkZfi/laJ+9vC/DyzM9PUskQAtzGXQefkfV1WFf2iIC9KGW+GzynirKEylty6DaTQDhl4Az8SiDuhVtDIUrprK9x+05d57OGH+Lmf+Wme/vRrPGeeJQr8d6dwjAh9f3wLLVFpmJud4JqrL+ZZz7iUs87Yzoc/+H4efughztl7AR/+yKcpbY1O37J1do6f+Zmf5EMf/hh/9w9v4T0f/CTXfeh97JppcMEZO7n0sqvYecnT2bb3UpjcDqqOijKM86TRvia109JITs7q2Lg3EgF0HO//wIf40vU3cO655zMxOcnSyip79+5lx84dAKRp6kElUGjW19sURSHjvNLs3LGdLEmG0S473R5Hjx4DD/RLHeBbmx/bQ568ZdBwXB11OVBKbGiVcA2WlUShk/eDotfrEemIWlaTNPDgrhLuN2cti4uLlEUxdKkM7484jlE6wjqojLhFhjocvTu8tauT73Ecs2vnTrIkoapKojB+eG416xdMZmdkDrcpm7IpTy3ZBJU2ZVO+DuQ1b3ovOk7RcYpVQpA85EtSWkCAOBZAyfO3jE/ojbHiHiAzGZwDaytPVhyIussRUbetxEqpKrCVIXIGZ6ohuWcAeZQSdyGUTNCLvCDv95mcmBqd411m3HACr4jiGKWgrEqSRAi9B4MBt916G5dedhlZlqGAylR+kjN8FC9hlVQmQOJ6JIpAFMVs27aFrQvzMhHSSnhbvGVS5FdgLRFWxbJSrUCC9cqkO45T4ReoFKiMWx89zp/97b/wxn99H6u9iLTWIlKOVA2YTAr27phh7/YZpjLo9RbJu+tiCZEmRJFmrdumdIY4TSSsdVGRFwWdbpt+X6yTOp3OKBpPWVGUJYN+n36vL8Tc1nLhhRdyxeWXs23bVuIkpl6rkdUymq2W8CRlmXAm+c+6509K4mRIxB0n8dBkX0dilaSVmO1rDygpHXkXAP89iiFKsXGdA0eX+bu//yeOHDnK0666klqsufTii+i01/mOb3shu7bOoGwpxMWmRDxoZMU0EvMeD1qM+Fr+I1BpOBnXGmcqokim5c5a9px5JufsO5e3/ds7yOoNjLGsrXbIshqd9Q5lXrJ1yxaJ4BMi2ChAi/KtVLj3KAMBCDKmAmfAVkRa4YxhemqSyFsBChiUUlaG2IM7aRx7ZU+eM4A0+LbqvwyVzQAOBYulOImlfw4BXLlOoikKsBRAKGMF6CVEd/NA1lCcA2/xYK31roAhT2Kd4dxYdDg9snwQXjafjB1zy/MKxIZ7jEkWaSI0lhijEipibJSRu4RHDy9xyz0P85HP38i//vuH+eBnrucLt93DA4cX6ZDgatPotCnkuzoi0RGxgwRLI4H/csWVLB49ymdvu53u5ARVnDBrKr794ou5anaey7dv5/Jd27hkxwIXbZvnwq3zXLBtgYu2beHy3Tu4aMscl27dwiXz81yxdSuXb9/GZdu2ctmWLVyxbSuXLSxw1Y5tXLplnit3beeirXNcsn0LF25Z4JKt27ho6xYuXdjCpQsLXLxlgQtn5jhzepb2ygpdDWqihS0rzpqb44rtW1H9Nt2VZY4deJhH776RHVOWqWRAU/eJbZ9IZ8SRJlIW5SrZCM1d2rxz+OhwFpfUybN5ps+8gqq1m1LVRrw4yhKPg0qnUKJPlCGo5MfOYfscP35C21W+Hw7Tl64ofdO3We0thQIwgm8m0j5HLpbjx08tY9efYq9S4pJjvMuPUj466Vi+8aBSvyjoF2KtlJeVcBJ5BV7GfTBWLHqMlVIVS6WEZqPmibod7U6XY8cXhag7ScmyOkkg6jaWwUAsldrra2LN4vtbvS6g0uTkFEmSiLtzv0tVlrRaLbbMzQmn0tBSSd7h8soWN6myMh4YKwVwFIpkz9EjAJuxjsI4qqoSSyOl/KJT6MzyoVEkcYx2hu76Cjdd/0UWjx7md1/5O+zcuRMXABHA4sdq31y+2ubXadAeEIkQ9+lUKy6/7DJuu+125ua38pxrv5GHDx9l/yMPY1ePMDHhuOu+uzje7pNNbKNf9PilX3gJl114HtPz29GtLRBNQtyQSIfD8UlmGhqNcsJoZ08BKuEffbzFRVoDjn95y79yzz33csVVV9HtDVA64txz9zE/N481lnqjTqs5ApXa623KoiTSml07d1CriUW2AvqDAUeOHhuO+cFVWIBaD8iGcpLKleM+Y0NXMr9PKVmoqIzxCxnOW34Kk1qv2yXNUmpZJkCtUhJ0xTmWl5bo9/tyvg68dzLWW0/TZB0UxkjefDRHlF95wQVbOHCOnTu2U8uy4ZOIa/RY9fv8zk5vgkqbsilPRVHuVPD7pmzKpvynktOf8/3+9a5QCGgkq4Fi6h9FYmWitJaoMGFY8NYHYZLhELcc55xYYjgLzhNzlznOFGArTJlTFQPKIsdWJVE1ACs+/5UpscZHbSLM0sQtTjmLyQcsbFng7LPOpNHIwFlazQa1Wk0UaKWJo5havYZF/IYcjqoyRFpz+umn8+M/8RNMT08TecsMmXR5xThE2DqlQnKqfYFrJIif7ImzC5FyRMoA4rbjXERJQuFiVtsl7/r3D/G3b3sfSWOaelYHa4kZ0EgNW6czds+3qGmL6fUwZckgsmQ6IkFR5TntbpeknlHhKKqKsl9QDXKKsqRf5HQ6bZxzlGVFWRRU3uWqKisqI5Zkc/NzXHbpZUzPzJCmKVGkh1HcajXvzpamZLWMer3uTfZT0iTxbm2Zd2kb37Q31/dtKBbgD6eGQFKS1FhbXWOt0+fv/unNnLH3XPbuu4B///f3cNbpOznn9J182wu+EWsEHFRao9UopLDCR9A76TUl03txFfuPZXi1A4XxE28h2s0rh04afO6LN/Cbv/1KDh9ewhlDLYnYt3cPZ562jcsvOZ9rrrmSej3zFkiymk6UjpRP61AEEutwRx+m2gmgo4jkOhXLp4+4EybjMrmWthqsk8YBJeuEtHcIKvn94W5q7HztlXQb3Ib8fuc8UOTvEyR8F6uCkJhPfwzcCp+ShrjoWU8mHK7XUSQuFVqPOJg2AA5D9UgszjyXVBzHRC6hnxuWOn0eObrEsZV1Hnj0Me66514OHj1GrzLEtSY6q4tLo9LotA5xBkoATodFRw6rDVYZssSyUFf87o/9KA8+8ACvede7WNqxnUFrgj3O8b+/73vYMeihqxzrBlgMTklkQodwzKEVkdJD68xYR1gL2im0E2VOA3EkyprwqxmxXEHhVITVkFiHdhalBHx7+Ogyb7/hRm6PNZ3t28gKywtOP52XXHExjUGP3soKK48/zGM3f5rVR2/g6ecscNqkoqX7RFXlx2DhnZK7ipLpnIz3DoVVCqug0BP0J/ey85rvojd9Ln1XwyDggwYSW+CUxihxC0JeASfV2VDGlNkNY2doa8NmNCJlP7WEa70b5YlHNrSdkcjuEegqv0b/Rt+l3Yf8h7ZeeoL71bU1cUHTmkhL31OeeNxUFYOiYLXTY3G1zXovpzMoKY3DClMMeML6qpLoaEUlddJINQuzk2ydnWS2WccYy+Ejx7jznnvZf+AQab3B5NQMrdYEURxTliWrqyvsf+xRDh14nF6vJ4EnlGJmbp7du3ezY+cuGs0m6+0uK8vHKPM+27du4YJ9ezl7z+lMtZpkSSzjkLfuclbeD51en+X1dda6fbG2QgmhMhKy0hpDaRwdv2hRWYvSkQDQTnh7nKBRaKXIkohMO1aPHeQ1f/z76Crn5q/cyK5du7wlp0AKyGxjWEdDOcVagMOCNmin0TaSKJCA04rSwWOHF3nxT7+UqbltXPuN1/LN1z6demeVQ0fuotNps7iSc8u9RznzwvP4/u/6ViYzMMqhVE3GPCfxJJ1yOOUXxVBENtxPYQJh/ROJt+bEW4A9//kv4AtfuoEf/tGf4PGDR9i+YyfPec5z2LFzB0o5ZmamWZibkjHdKR599DGstczOztGamKAyFVprKlOx//HHwUe8HN5Hae8+7oZ8lcZTCYy/A5UMy0NwSGk9dEMmkvYQ3K6t50WSKKmOubk5alkm55uSldVV2u02kXfBFkNaiZTpnBsCSmVlEDvc0NtDfxQuzUjL/GnH9m3Uapnvg+M93L/HRl2Vc846Y+z4pmzKpjxV5Ku95TdlUzblP4lYpYbhjy1CtI1W6DgmTmJ0PJqwiELgvBWS/3Te7N3K72A5gvO//eacEHeH30Hd9c4/Q8uokS+THIUwAdVEccraeodDhw9TloY4ThkMcr9iBlVZYqxYJikl4Y6thSROKCvDI48+9v+w95+Btl1neS/+G2PMstre++xyurqsYnXZKpYs2bIRLmAMNhAbYtMhlxAgDiEELiYGEzqEkkAgCRiCIdjYGHBF7rItWZbV6zk6OtLpdddVZhnlfnjHXGsd2Sa59///EMf7leZZZc81y2hzvM943uflHX/yDtbW1rHOo6KjSZxoNROuM+Y1Y4v3/pztjF1lOS1yKSw6WEm/rBIqb+hbQ9+3+IfPPsQbfvAt/NFffRCjZ0i9RpV9kvoUO+cCl50zz7lLPdrKMVpfpS4HKO1pp228hY21AXXlaKdtTNDUg4LR6gaj9XX6q6usLa+wvr5BWdaURUVZlAxHBYP+AGs9RVlhtOHmm1/MS19yG0tbl8ZZ3LIsj4LbPXrdLt1ORzSUOl3akaHUbrVotQV0yjIBmCahb4kAANqQprloUyhNkrZIsjZepeisy6iGT33uHnSrx/U338oX73uA4yeOcfjQAV5+20u57gXXEoKDIKnRceVU+4qTzZjp5v8XkyM0k9m4KUnPniUafMWN113Lf/iNX6MYDWm12lSV55lnj3LsxCoPP7aXe+69j6Is0UahjSJNJRxSmnFz3Gnti+bcETwlgrWx6Ul7FwDOOQkN8OPwsCAsuyBhfozFseNvGzHVyMZTiJMXpsPTouPcAKsNGy8gekjWyvGb/Zv3DQtEQnjieQFrbQQrJvsDIsQ/zR5pwNu4it+stNM4DSHeRGRP+Ub/KYbXHF8t+dlf/o98/4//3/zUL/wmv/J7/42//cid7Dt0ijpkmLyH1Ql1CLi6kjCN4HC+onYllS0IyuFDTWKAYMnwZHWJDpYsNeAd2ge0Dyjv6XTazG9bYMvOBbZu386u7bvZvX03u7fu5Kxtu9i9dRc75rezfX4b2xe2s31xO0uL21hcWmJh6yLzW5eY37qVLVu3Mre4xJalJeYXl1ha3MrS0la2Ly6xc2GJbQtLLC0usXVpG4uLS2yZnaPXatMyKXkw5CElTzQoK6G1OqPdmWNp5/mcf9VL2XLRy7h7b8X+kwmjshPr3YNWOJ1Qm5zS5Ix0zsjkFKZFYXJKlVKSUOoc3V3AJ11qFxlKEXqS2hHRbkFyBZiauHsxsyUqxqDGVv2cBq+YjJHydwHPvtx2pisZ29X4SP8rNkVtiZtcv4QxTb8nxDarJvuq6AA7J1pCzgvEEMaPNUm+INf73CsTEPmMMYXIGtGRhRGfMz42eR8CtXfUTvSNJJOaP2Mb96/JaWQxZ9xXJ9dzZv+VrdFo9lFIOQQ5hw2B2nlq66mso6odZWUpqpqqtnFzlLWlsrIgIaHlshgkFSb3o2L9NhqKG+trrC6f5sYbrmdmpndGWYVmMeq55SQVcsZ9hBCkrnwaEyJ4AjWBEueHKFWzc9sCv/qLb+fUkWP8/E//W/76T/8zq/s+y/I9f4Pe+0myow/w49/7LXzPG76VjkpJnMEomX+42L6lXcTqCsJQEvBYyu1/alN1URQFyysrEq6rDSdPnqTT6dDp9WS8jPVuIxAUCGijWFxcpN3oGcUFgyNHj1Jb0bIanwe5Thfk9z6y4UJsV35a5zLEzHyx5EIMxfRe2rjsI+2JIO1b6jhw8tQpRkWBNpqV1VX6g0EMyQxoLZqbtfOUtaP2wt4rq1raVNOWfbzHCOBqrfDesbS0RJ5ncZw5s89M/ycQ3/9C+W/apm3a/5a2CSpt2qZ9LVh0Bn0QVoRJUvKWpIIPiJ6LOAuysjiZ4MUJQDNjjcwkolhnCKLhIkwm0ViStMoTh1URdT3ixI0YYiDWTC4m14kyWOc5cOAQzz57gMFgICutlegymURCcEKQcDkCZKmIoOq4Krd//zO8+13vpihKYQ/Fs8gkP7It4sTqS7YvZxM/a3IsAgQJMwsmpwwZ61XKA3sO8wM/+lO85ad/gYFL0K1Z2qkh8yNmkpLLz1vi0rMXmDUW119l5cRx8J6slZNmKYO1DYYbA0ySyETNeU6fOEWxMcSOSgbrGyLEXVWMRgVVWTEqStbXNyhGBXVtcdZx6aXP5zWv+SZ27NwlIW7dLrOzAiRt2bKF2dkZAZZmZuj2enS73bGGUitvkUcGU5blpEmCSRJMImGSSZKQGAmD00qTJilKJ1gX8CpBpx3u+MSdPLZ3P5/63L089ewhbnjRTZx37jmYYPkf//0dXHzheSwuzlNWFVpr6rqeykYUyzzEwkfSJDegRfP+/5tF9hMQgogXazyJ9lx3zeV8+AN/y+6d28iyjFFR88hjT/H0gSPce//DfP4L9zEcVigMWml0XI0VcEmmzM05aKbMcZLfnLcJOQlB4b2EliZJQlWW4vxE7bHEiHZYEwIDEz0aFdkUIGCqj8Kq02XS9D8Xw+OqSrL9EfXQ8jwfX29zjSGCWM4L68+HCA4pRZqKSKvozki4I1PdRhyjWA5TwrHS3ybnEXZkw3qKx/ASijgqRnzh4Sf5/KNPMUq6hN4CureATzsEnVHbIKmzIyMqURpNwLuKECpQJUliMX5Eaockoz75aEBrNODy3TvRtsDbAuU9qVcYC7a0EgKcJrgEfJISTE7QmYSXkZOR0zEdct2ilXTI0w5Z0qKTtWhnrXF/yVotkryFyVqkeYssb9NqyZbnOa1Wl7zVJclbpO0OKk0waUIrz8iSlBRDqkWrRoB4g0lzWr15tp5zCRdecxsXXHUrjz59gtOrgzGY6ZXC6oRSZxS6xajZVEahMkqdUqmUghzdmccnHTwSgjYBRIWRJZkSYx98ziYhMxIyNgGDxs0zvp88P5SKbfXLskKnLTq5U8f5X7LQNKwzN2nPk/egxFlVcu0ShS3AkvcS6lVbi/UO76IjHp+XEhIW2XtTFs8wBco1nyegS2gABetwIWC9x7q4TTnhAmjFbar8mn7Z3Mzke+lfk2ucaDnJdxLKFprvI7OkAZaq2olGVFVTVDVlJeLjpbXU1o3D3Zs6EeH85halzBXC3CMElk+dAue49NJL6HW7cm0NqBXbx//6pghe4b3CBaTccDGzrCU1gcsvfR7vfuef8vrXvIo//J1f5yPv+e/QX2ZxpsMbv+MNnHfe2bRVIDdGtA0bFCZIewjxflTM6Km8PNw9wmCaNrkm6Q/hy7TPo0ePsry8jI/6dc888wx5q0W73YrMbBeBdT1uYwsLC8zOzWKdxXmHdZaDhw4xKkt0IsLXTT025d+EtnsnYukTEGkCSIqmlx+DTdKmJBuvdQIUyjGauhER+hDrdnl5hePHT7DRHxBiGGeSZVjfQEEaG0SUW8ClQN2AsWPAShYgfPB471hcXGRuyyzErK1ffovtloCL/WjTNm3TvvpsE1TatE37GjDvAkoZ0iQjSwUoEOdBUslqIzpL1slE9MxZXmQgBQcNkymySxrnUcAlB3EiIZO2hqkUYiiGJiCMlgYUaKYPEvoWYjY1jVbCgDl2/DgnTp6krCqcjylrnYh/ykRJmA7WOXF8E9GtUErx6KOP8o53vIOyLKNjESfoKjoEoflm+r//mYkjAsIjD1oTshalzjl4esSv/O6f8Jaf+WX2PnuSxW27SYwhN4EtHcvF585x+YU7mG8p6vUVyvVVtKtp5xJ21h8VLK+tkyqF1lC7mqKuWF5bpSxL1tfWWFtdY1iWjKxlVFd45xgOhzhrJXRibY1zzz2X2267jcsvv5w0TQUsanfIsox2u81MZCfleUsYSp0JMylvtSSjW5aRpmkEj6Lw9tSmdQRVorA0KJQyBJVw3wOP8A8f+yTdmQXe+rZ/j857fOJTd/KWt/w4t958Ay+/5QbSUKF8CQQef3IvR0+cjhpfE9/FB3Fyxw5g0PGR9Y87qF/qpMQvCVMuoAA8zjdaWY5Ue3SoufzS8/j3v/jvWF9fQRtD5QJPHzjMoaOneOChx/nCvQ8yHNRoUgl3a0I3kUsTnlVcKUa+DFHU1ysm5yeGJxhDXVsSk0hIQhQfdk5CMJLIMGo0V2CywkwEiATkkcxtDWBDdG5F/8KTZRk+SLvXWlMUBUSHNMRjNk7rhHkUw0eDMKfk3PGzlem/4LRRc6NhWjROdXQymv6ndOPUy3UmxozBKOccw8GQZ48ewbda0G4T8hxaOabVIm21JAth3qKV5mRJFtlxKSiPUjUJJant03ED3MnDtNZOcOPZ2/neV93Ot7zkVnJl8a4k0YqUBEqPLSzKK5SH4BWV95TBUweonDjhznm89fhaXoMN+MqhaouqalRloXKE2uFqi7UWa5vfRTAheGpnqZzHoah9oLA1Vjl0nqBzDUacQVAkRvTtbIBaKdJOm4VtS+w+ZxfnnX8W7W4SGShQBShJGKlsDCgVukVpMkqdUOmESqeUKkPls3ido006BX02/e5L+9e450y3qy8Xyjbd5iL4G0Jk+0gn/gomf/vH9iC2oedu/6hFQIPxHTaXKGi1tHPJvFhZOw4Xdg044+RZ1gA1TTuWMeUrn1v2i2OYFzCgqirJ1lZWFFUl5/NuCmRyWBei4PHk+RuaV+SaJvc+KQ/fsFeav0ex/rGz7r2A117YMpVzsiBRCbN1OCoYFiWjqoqspRrnomuvhE0s9zIpc6WUaMR5j6trHnn4YQAWFxZIYgZJKYOp/77MuPzlN08IwtZxQVGjsSEhmBwfFIpAbjwLMym/+ks/xx/+we/xLa97I7d96w9w/bf+EOx6PjYYgquxoaZQXkJkvcP4mBWxWSzzSvp+w2Qj4JgAiHK7k1YEU+Ufy+TY0WOcOH4SrQ1JknDttdeSZqIT6eL8RCkZg1GKylqyVk5ZlbJAphXHT55kVJaEmLBhTP4OE7kB66yAk85PJU6ZAmQiS8k1gJ6XurdRoH0CKAnoFIK0zywTPacGSByOivEYkGQZ1gVqH3BeFkScDxRlRVlbaichn9KGJ6woHwJ1XdHtdpmf34KNou/Nc/GMrQHAprZN27RN++q0LzMz2LRN27T/0yxNM1KTkphUQCSVQjA4FzN3OAF9lNIxU8f0BCpy6ptwuIaldMYkt5k4NgBUw1SQCcJYEFQ1jq6KipJnTiAERIiT5SATor1793Ly1Cnq2lIUIkrtnWgj6ZjuOTRhQjEMyFqL956HH36I9773b3BWHGIftV/8VEjOmfaVJzTN1TaAgFMJNsk5tVHxng/fyTd/5w/xkc/cjzU9lMnJE0PXOHbNJVx56TYWt2g0FXVREayinbdJjAFvWT51kmA9KihqO6SsR6wN1ljpr7I6XOf02gqD0Ug0lMqCvi0Z1CXD4ZCqrllfX2dubo6v//qv57rrrmPbtm30ej1m5+aYm51ldm6GmZkes7M9Ot02vZkuMzNd2h1ZUW23c/JWRquVkWUp6RhUEk2lNGZ7SxJ5zSLgpNFRbynh9OlVauvZ98wB9u0/wMOPPsG/+smf5vjJFb73+76XP/yD3+Om669hsZfhqw2q0YA7PnoHB44c4/5HH6NfWYJJo2MbndugpoCk5vOXq7dpm9TUZJsImMoe4vBqrbFWwqRUcOjg0Krihhuu4pOf/CgXPO956DRnWFgefWIvBw4d44EHHuHeex6gvzYcs5Qm7SZ6YGOLf41gU2gCZuJn54OEeJok3mEM05tyGBvQyHkv7QVhfzTOG1F3wzVhFFPZ3wQwEg+orqoYjiB9s2EqCdAzET1vfg80XlUECqaZYoosSyf7Iw4QyKq6ig4ViJ6TlMkkpE5HNlPj+DYCsNY5Tp4+jqMkJBarLBhQiYBHSZJJWEzQpGmLwmtqr0gwJKWlU5TM1xWXzPf4ode9mp/94e/lB771G3jZdVdx9tZFskyTdDJspinx2Ci2bnSKcprMG9IQYga1Cq0tGIvXNbUqsZR4KoKqcJSMlGOkA6UK1HicVzKmNkCSB0tMW+9KdKhJvUOXFUld0zaIyHbiCcZB7lFpQggG7T06SJiyaSV4XZAna1SD/czPlSTtggGGDdViQ3VYV13WVZcN3WNgegx1i5HKqVRGTUrpFSFpkbS6BJ2MHfQG2vdquq811T/x9kNkmQUisDjZa/Jv4+COQ2AEgPrKekrSNifPiuntOfv9f7EpB7V5FxrgFXkECKApzrHzAhT44OMzTEDQ0HjhyEASVBOmI9/Josjk+OLsC/OosjVlXbHe77Mx6DMYDhgVBWVVC0MpBAF9GrZJA/KOjzf9vgFn4jP3Oc/gybMz/m286BMoIytpVJQMi5LBsGAwKhgMI7A0KhgVJaOypK7rM5gxLrInp4oTkDDgsiwYDvrMzPS48oorzmAhn3GtQdg1Dcg4ufapexxvnhCIIWsGS0rt4hgaPCrU6FAy35vh1a/9Di5/5Xcw9/yX42YvpDZdQqYgib8jo9bSp5tsoiALYioQAWW55i9lKn2ldjeplKPHjuKs5ZprrsE5x4tvuYXZubnI3lU468ahw9Y5XAR4iPOU48eP09/YkH29sJp8mABxY8DIiaaV81G7cYqFFpr943/Ez8IWim2xAccb0NHL8ata2qExZvy88QDKCBAZ68l5CXcbFWVsRxXDYRGB0pKyrijrShjHIOLx27ZF/Uypt8nWXF/Ax//G1/4Vy3zTNm3T/ne3r/Sk37RN27T/g8ykOSQpXmksUBPwRhGMkvWiYAlBRF8VopMSgsK5IGFrUdi7WbkUFpKDYEVDyTuUjxR5STQ0nikK+8ijVCMkK7gUGJRKUJgoFhp1DbTCK43XKUFnqLTLnqcPcfjoKWwkSg2HA6ytx5OTui5ROIwBowPGgHM1rSzjnrvu4sPv/yDVqJDsVEaEaxsNJ2HAqPGMNviARmOUJlEmToQVBIP3GusNldOsVQnv+/h9/PN/84v8xn/8Y0w+Q5bltBNFz9QstiyXnTXD83e2SYp1fH8VP9og0ZYkhdJW9IsRw7IiSTNZTbSW1f6Q1bUNNtYHrK6usdEfSOYhWzMoCoqipBqWVKOSqqpot9tc+4IXcNvLXsaFF1xAt9ej3enQ63WZm52l2+0yNzvH3NwWet0ZZmckg1C326PT6dJud8ZbluVkeYs8z8izlCxNSBNDO09JjSLPEhGyNRqTanRLMbQV+549zJ6nD/H7//lP2fvUQYzOOXniJKvLx/ipf/3P6Waa2XYH7wI2JIxKuONjn2J1ZZ3F+S289NZbyFIj2d2kFqQ+lIfYbpQKBGRSTIDgotMaH2QGUN4Tov5HCBBQaJOJs6Y86OgMh4DRCaBIkxwQYEGjRSQ9WC553m5+7Vf+b87avYAiYGvN3r2HOXlqwH0PPsqnP3cX68MRTkmbqoMlaI/XzQRZ2FUqmBhiEcWcYwfQBFKj6bRzQhBBZ7m0L51Uqyho7WKGNzcOqTgz1CxERpOPaZ+VUpRFSUCYQN4JY6kBn5yzwgyMIrFM+XXoyCCKwA8RXBqDT9Fx1VHXTPRplLA/AmhlIhuycRgFMJPPEgbbgEwhgmIhBAaDDXF6ajA2gPWEoKlVQh08ma6Z0SVZsUI2Ok574zBn6SEvOmeBb73tOr7v21/N9/2Tb+IbXvIirrzwXHYszJEbTaoTdEggpCiT4RONwpNrUKFGGXEuldfoeK3eN05ZZGIpAaGcB3SC0xL+qXEQKjAepSA1idyrCdhQg1GQZKAMXnuUqmjVG6QrB9hSHmc+DEgDaJWhTQudtvBJBsagdCA1NZlfYfTsPeQnH2OnGWDqEkLCyCtGWc6qyVnXXdZ1mzWVsaZzqrxHqQ0FMFAtRmYW2osULsEpsErho9C48c34PHH+GrQkEs9kPCeIpBLibD7X9HhnaS8gDuWXsy8HLEyDFxOgc9LXJ5AXY77DGNVpFiqm30cnW8fMXiJUHFm0WtLH13XM6OZEb9CFGofHBYdXEl5Ye0Q7jij2LLRDWWCI4IeEtUYwJzJCagej0rPWr1gf1gxLT1VHANI6XO3wzoEP40v2kZGooj5TU54hhiQJG4WoUWjGKd2t8xLm5j2OgENhIxOrDo7KWcpawKWqdtQ2ULtAZQOldRR1TWmtaC45h3MCeCmvYna0hqno8TgS5Rmtr7CxtkLearF9565YdwIiKaTfhyBjSe0tzgSqUFN5cE3YmXNYp6gVeK3QNpc5CUNgiKJCOY8JmuC8gHqpCHBbNJVpU6oWweRRF8vhwgita0zwpK4FIcehsUrYTz4Yalszsn3KZESlHEEZ8CnWgXVyfRK6L/fR6Io5J8+gui7Z+9Re0IrLr7iSqqwJPtDKchG49h6jE1TQ+Dh50UrqvaprlldXWe8Phe8a1DiJigtOxl0EnK4a5mNk0AUvDUXmJtIu5ua2SDIT78aAknWe2trxOOx8iJpaUTMrLiAkSTpWOkLFMG0VwSzvqb2ntJ5RXTMoa0bWMaytbFVNWVnKsgBXgytpp4odSwvo+NzRKqGqAidPr1NZ8CSEkMjc0itJtxdiv2pCWjdt0zbtq842QaVN27SvAWtAIXkV7QBZFbP44FDKS+p2BdYHEZ1UIjoskwIlU3gnq2Qo4WAIsCRaSsQQoMlCX4izlEATFKTiBB8l4VIitB2zz8RV8kAYhz15Ekn/S8KBg0dYXx+IoGhVU5YVVV3hozNUFCMIniTReGcxWjPo9wne8w8f/jAfveOOGArksMFG4GJyrXLegPVKhFStwztLlhhhhaAJJqdWLZ46dIof+6lf5N++7bc5cmpE1urRylK0HTCTVjxv9xyXnb+V+dyhihXscINMQ2YCWnmKYsjGYEMcgRAoqoqyLOkPBqxvDOgPhmxs9CmKijrqXaxtbDAoRpRFSTkqsFXFrt27uOXFL+bSSy5hbm6OvNUai2/P9Gbodrt0u13anQ6tlgh0Z1lOlmYxu1smIW6JsJCMEd0krbUAR0ayIRGkTRCF1FEJXiUUTmNaPX79t/8jJ06vcdnlV3LwwCG+443fzlt+7Ie59MKzuOKSc8iUY9TfIATFO//i3Xz27i/Q6c6wa9cuZrptOq2MVpbgvR17jVI/0m5QYZx1TWuZgAp44iIIKlpeIciKa+N+Oi8OFlrL8aY0maQZCjuvYUApFDgPrsZVA6687ALe8cd/wEUXnk9iEoqi5sGHHuPw0ePc/+BD3H33F9jYGFBVTWhYvGblQFlQMUQMRaKN9I24Qu6txdmKqiwmzvIUE0jrifZYIGDreqyNlKaZOKKxDQeEddWsNCsldaaUotvroVDkrZaATGUpoFQDUEUWX5qkEg6otayWe8lcJ7pr4vw3DEA5PtCwj2JYhITLyWepJ7DOTcI/pmGBOF6E4EmTBFvX1HXN+vqGsJG8OBgmAJH9ooKFah0Gpzh7LuUbX3w1P/D6V/Jj//R1fP/rXsU33HodN119KRefu5Mt3RatVGMSYUVKtkqNDhp8BMC8I081SoPVAXRsD2gBvprrDVK3WsuYpVRC8BoX6RNGG8kQpzyJDuBq0XoigNFUtQOvSUxKUBbNkPVDj3Pwix/CHH+YC2YdM5lCo9BGnF2dGIxRpKHEDE7Sf/pBNp68myW1RqveIFMJQ2cYmg6na8MaLTZCTt8njHTOUKWs2cAwpFSqTakyStVCt+aEZRkCPqadJwRUaLJXRnbb9Pg4VRRN9Y1fp4dR1TDVEFZcZFEYLQy759pzzgKcCURN9MVErL4BVyb23F8jTCJBAWIoqewzmew2Gl/SAAOi2yPgaWSGjNkTkR2DPI8EKI7hUk27iE9CH/cBxuwvEFCi9lA5RR3Bigao8DHcfAxEjRkqEViLfSwE4hOqEWxu2CuyCUAQhbi96Cc5L5tvQCjV3KeEHI2fuUrabkAyBDb7NCCfxCRPKl4h7EZjtGR6rQrW11ZptdrMzM6iTBxrxyxOIuNLzuWsI0kVSSph1cLaDJhU3rtgCTGToTSQyCSKABQqYWQV64XisT3PcuzEMv2iIo3MS61TVMhQCOBrlMI4Afg9GhuCgIBeAGKVJhTOYYOhrhW2PkOCaVwOTY1Oh6YVZclH/uHDAOzetRvvRQOv3W7h/IQdbUwi4zmio6e1YWVlleXVNekjEdwdz4GmmKxyLQqtDcYkY5AbJSLYdVXRabXZunWJrUuLEIJkf20Y3EmKdRIC6WMYpHPSLgAJuYvPDG1kztf07YYJ5bxknhURd0cZNZWKqmZU1hRVRVGMouaV5qxdOzBaU1cV3sOoqDh6/BRr60OCSsci8dYFfJTo9F7uU9rapm3apn012iaotGmb9jVgKjpwxEm+TPjAqKiJ4wPexph7opaNtyQadLDghDpulAQnNZOq8ayrsWZCMP3deDo2/a6ZoCqZpKrIgBqDVbLKOZmUyirs408+yfLqGqOyoraWYlRg6xpbi7NbliXWik6AtZZOt0ttHSZN+djHPs6HP/RhcYyt6CroIJo4EwdDE9IMnWWoxMiqtRUWQzAJh06t8VNv/3X+xc/8e57Yf4r5hbNJkjYmOHqp5Xm7Z7n8eYtsmzfY0TKrqyewtiZNE5RSDAdDNjY2cNExd95ha8twMGRtbY3Tp0+zurYqYX6jIWVR0O/3GQ2HVFWFrS3Oe7Zv28aLXvQirr/uehYWFshyEeLuRM2kBkxqAKUmo1ur3SJv5VGEOxPtpCQlTRKSxJAkBqMFTGpADWVSVJKBydBpG0fCxrBm37MneMtPvJ1hYfjt3/0Dnty7hyuuvITXftPtBLvB/EzC5RefR7G2wr1338XDDz3Ihz/0AeqqoNPK2L51iZfc8mKuvvIKvKtRNMDBhJUgTVUJbT86GFonKJOgYghP7TzKGPm70iJU7jxaJ2hlRPvHg/cKmecL2OF9eM4EVtgNTQrlLE0xSrN7xw5+6zd+hRuuv5oQKqyv2PPUU5w4tcz9X3iYOz/5WTZW1shUQhI02gcIFqjwusYrL05CDBNrAB9ttABekTUUgji74hALmCvAkVyrSZIzgKA0TSPQIWK5Xuh/EmoBlGWJUorRcChgU3QykkTaotYRWItgVGiyI3oBBZrP1trx8ZtzeO+pqkqKLTolTUibALeyQq2i1pPcuwDGzTGIelFNJjrnPbauOX7yNF4l4hCHIKzIYDG+4sLdW/m+N76en/rRH+THfvBNfMfrX83Lb76OKy46j7O3L7HQ65ApBU6EaSvvcAqcBouwMXEO7QLKBYxJxX3VClIj7M3YJM7AL+IHyVbX6KTATJqggqK0Cq9TEh1I/IiOqWknwiRQKgWvUc4RnAdXYjdO8PBn/54dySk6w31ko4Nkfg2NpbZDjHFoV6HskI7dwB16kvrJ+zgnq8nCSBgaKmMj73KsyllxswxCj5HPqGhR+YRaJZQYCtVhFDoEleJJSFJhqglrLLLcwmRwnh65z7Rmp+ntOf9GoDbE/tVoK7mpOv+fWePsKqXRxqC0tI/mnNPXJ+NDA8I0z7apHRpT8o+AvlKfzdECcujxsZAxZ1wsXoCy5tyTO4/fxN80Xzb9V8YvAYuaEDIX26WLIW7NzxqgoOljzV3KtUxuSI4X94taTLV1MbNYAxY1gFIM44tlKQDWhAVGHIu+3EYDbI1f5RrDWAstIUsSbFUzHAwpipLZ2Rm2b9smZSwXHstFPoeQon1GQkKKh1ChE6iCwyUGr4VlnCaB2gxxKIJvE2wX7zJMnmN1wshrDp8Y8Z1v+le86c0/wi/+4q9y4vgJAsLeDM4QXBtci+BSEf2mFqAqRDZebPdKpQSf88zTp/iRf/6TfOqTdyPDaRNWNmlf03UTkAoejQruu+9+5rZsQWsjQKSCVqcVW4cnSQ3tTmus16WNoT8YsLy6FllnUkQCZsqr0oYQRPPPhwjWB7DWoXWC0RpbWwiKXqfD7l07cbYmzzLOPfdcWRSMYbfWOVn+GwOKEn44DVh55NkpoHlklsV27/wkdM5aj7Wy4CZtT5hQtbMkaYb3sH3nTmFeOwcmwQU4dvIUK2trWC8C3k4aZdQSi2LikRG7qam0aZv21WuboNKmbdrXgDWTX6YjA2JsfRP8JQwKj1Ye60rAY1QQRyxYCE5AnumQBZk9njmpn5p0y/s4zCiBCmTS2gBJInbdfK9ieIL8SSawKjq6SZpR1o6nnn6G/qiUCZZCnGYnjBXnPGVVEoBWu8NgOAJtGI1GVHXFe977Xu774n0xZCVGPyiEIYBGKQHRvLeyIqwMBSnH1kve9YFP8HXf/J18+r4nOVUaKpWilEOHksVeyuUX7OC8bV3Sag1VrOKKddpZQkAyefU3+qCEEVJVolvR7/dZXVuVbXVVrrOsxq/D4ZDhaMhwOIyMD8XVV13FLbfcwllnnc3s3Cxzc3PMb9lCu91mdnaW3swMvZke3Z5kc+t2OvS6vSjK3aHT7tBuScaqLMvIcskCmCQpiUlIjIhHG2NIkhRtUtAJ6AynMk6tjvj27/weHt9zgEue/0L+w2//AYePHGVhfgata77zO76Z887aSq48vSShY1Jwlo21FTp5yjVXXcH83Aw33nBd1DIK5GmKUgibJ7ap6RZkTCKAkfN4FNYHTi6vMCpq0BL+oXSKD4okzdEmobaOp595ho9/4pOsrKwRvMaYDFsHlJLsdV/iTCmF9aJ/EWRWjwmO5513Fr/5a7/Ii1/8QpyvWB8OuP/BRzl06Dj33fcAd991F+try3hboTzChglGFtsjc6LRoxGnQdq0iZnUmlA1HbOh+RjGprRcR9MHdNS98N5T2xqllGSHm0JAujH7Upqm1HVNq92OjoKUaQM6eS+6ZLauoemPyGAQAGO0aH9Ev1BpTZqm4kxE1pT4jpPjqimAqbnmgKyqy4EkjM+HOG7EewUJqynLkrX1Pl5pAXtCIHiHcjWJcizOtnnpjddw/eUXcuGuLczPd2h1E0yqMEZhlCExCUanmAgqai8Aea1q6lDFhANBwhFjCJMMjJEVN25706iSOFgCujmUljHUlRUmBIyvycOIrDhOtvEMreEh8npZhMGtR5lURIedJTjL8rEDqNFJcruMqVegWqcuh9i6phUCuhwABbnvUx16gpWHP8MOtcqMGpJ4j9MdTjPDkdBmJZ1nkMxT6S6jkDCsDCtrjlFlGDlNSU5Jm1FtaHW3SNY5Y/BB2KWT3jbh13ypNQ72mdvUn6fexyOOnwfP3Xliz+1/qskqGMGY5tUkyT92mDMsNI8aiCzWeAkq9sXpPSNo4GO9h6jzEoKEFXnfiAlPnnk+CLPmuaDDGICJ3zfmvR9n3qqnsqvJb5qzyrlEN+fL32QQOCQylZxkqotAj4/C/fUUyCSp3oUJ6+Pxm2tu2nYc8sZlL7ppAgpOri+W0dR9RnScUTFiZWWZohixfft28lYrjp2xjTTsqxBQicWqktqXDMuK1X7N+z50J//xv72LP/4f7+eRJw+zMbCUVlGSY0MqY4OqCXrEoByyUdU8tOcAP/DDP8kjTz7Dy1/xdbz9l97KeReeQ2VrnPMobWIGv1j2oaYOFkeFxwro5aUeK+sYFSV/8c7/wctffjuf+eydQoiaYo/5MRDT6BE1paI4fPgQ1jq2bt3OYDAgSzOsdbTyFiF4tFbs2LENk0Red4BhVXH4+HHQBrSWOo0jj+hqSTtoWGjeEd97QgCtE+pa5gJpajh7907SyKZ2XjKJLm3dClpHICmGQ54BJslnCanzgMbFpAQoA00795K8pQmv9AFcULigZJHGhQhWysLPth07aXe6VFYApcoFjpw4ybFTyyiT4FGi4eREqL6sKionoJRrsiA+t+Fv2qZt2leNbYJKm7ZpXwvmGwdJWCAEYSYFJywEhch+GBzK9lF2iAkVdV3IhF5rceadTCwahpE4Ds2R46aIk9ZGt6hxWBXE8LuxKTnWBHCaXKNCAAcQB9laizYp/VHBY0/uZWMwYjgcQVAURUldiy6N94HRqMA6R6fbQxlNmqVUVYUxCe9+17t58IEH8M6e4UQGNCpoklCj0XjdYrUyfOAzD/LaN/8ov/6H76Q1v4vaG8qyBrvGQnfE88+f54Kds7QoKdeWscMhygW6rTZGa8qqZH1jfexkj0YjRqMR62vrrK6usrKywvr6OqNiRFVVVHXNYDBgMBxSFAXOCjvl/PPO4/bbb+fiiy+m0+2wMD8vmdxmenS7HbbMzTI7N8vMTI+ZmR69Xpdur0u326HdbtFqx9TmrZwsz8nyTAS5k0REkI0Zh74ZoyNlP0GblKASVteHDAtLe2YLr/6m1/H5L9zL8y+9gFe/6uu4/4t3c+P113DpRecT6goVAhur64z6BZ20y9fd9jLO3r2D2156K9dffy1XXXEZtirEYTSSQt0gTBca0DM2kGYy3rSdlbU19u57mrs+fw9fvP8BNjaGKJNKiJsS9k9/OOLhRx/h4KHDmCRlVFSkqWQ8bITFXdQtmVhswVHYRCuFrSrwlkRb5re0+JVf/nle8arbccFhQ+DhJ/Zw6NhJ7nvoIe742Ec5vXxS+oPPUFHHg4iphLEvFtlAMdTKOgGxXEwpDqJL0ziMKjrZSjX9TQpHmCZRoD4ygzhDm2hACIGqLOX76CDpCGAZYwggWeFi2JzWOuokKeraopWwjqQ9CIMLJPxFRRCYGBbXgEza6MjIkHbbOJcNaOViGGOAcehdiMBZwwRqxiRxmKMof/DkiaaTJ7QzTa+V084yAYhNQpK1UDpBm4ygDLUVJEGjUCHggxtrlYggcgDrSLxC2wCVRTs3CW1CxVC4WO4RTG+Eza2zBMDYAT17mm7/KVYe+TAH7n43h7/wt2wpD7Cg1kjtGoYCpQekfoOwepjTex9gh3HkZYEfVRhSjDJoV9AtR1x3zm7S0WnKo09w4rE72WrWaakNLI4y67GWLHLEzbGazDNMZtjwmo3aMazh2Okh9z7wFIcPb1DbhNI6RnXNyGe055bwKhnXqVLPZQXK7f7j9qU7NSMoY5BQgFIBBYWVN/WEmNqmjxB/H9luDeNNa2lPX3rWr2zxsSHvYQz4NPUZvI9haw1QEgFMpM2JLo88HYTNQdx/cqzxf7HgwlTfnL63EPumdS5mBBQtGx8kvDREloqL+jUSghhBnKZkp47f9AkXM4s556ishCANi4JBUTIsS4ZFxbAoKcqKqrYCKjUM42gCJkl/1tN9euram6vwjYLVmCklLN7jx46Ac7z2ta+V8VqwunHY4LjMvENr0Sla3/C85Sfezo/+y7fys2/9Fd76c7/G937/v+QDH7qTUaUQVSBheypfoXzAuYS/ed/H+Kdv+hGOnFjhx97yI7zlJ/8lndkZglKYJJEEIDiUFt2loFUEb1JhEQUZE4IXfjI68PiTj9AfrHLf/Xdz+6tfig3FpI6b8o5105RHY5/5zGdx1tHpdKhqS5KmFMWIrJURVGBufk40u2xNZR39YcGzBw7GEDKLHQM1EbgKEIKiqiQboPcIQBhZSUppaltLYKbSbN+2HZRoSgY81lbUdUWWZ2zdvo0syyPjKIZbBjlmcz7nvYCQNrZJH+s36mC5mPB3wlKa2iLLSMb3wPzCIu12l7Jy2KAIOuHYqdMcX16hRlFY0fOqvaeoagajgqKuqZ2l9h7bhGn+rw1Cm7Zpm/a/oW2CSpu2aV8TFlfkZdaMQjRYjNYC3HhH8JbF2Q6vesn1fMPLX8xsO8WIF4wNGq8SiIyRaec/4kBTk3hxU8K0LkmcvMqlTJy2+OvxPo2mQGPN9EJFjSXnAybNGYxKDhw8LCl2fQA0o6KQ1bz4+7IsCU0qdcAkKcPhiLKo+NM/fgePPfooTUa7oDQegwuGQErlDHsPnOQ/veOv+dc//1uM9CxVaKFUSssotqSKy86e56oLtjCXDEncOqP1UwRnydIcrRLJrjMcRl0PYXKMRiOGwyGDwZC19TX6/T51XUsoQ20pihHDwYCyqnBOwpU63S633Horl19xBbNzc7RaLdqtNmmakLcyOp023V6XvJVNAKRWi1Yrp5Vn5HlGmknWtjRNooZS3CKQ1DCTxJkT/YZm1RqlWVvb4Gd+9mf5/f/8h3zggx/miSf2csP11/HOP/tDdmyb5Xve/EZuuekGTAisr65zz91f4IH7H+aOOz7BkWPHCd7zgmuuptPKyFJDkiiy1JAmSsKbGqYLMqkOsb1KGIoAHLVzHDl2nE/f+Vkee+JJlrZux6RpzCqosc4DisFgxAMPPMDq2hpzc3O87LaXcfZZ50Rdj8CRI0c5evTocxzoceeQjDnBCxtHKVRwBF9htGfLXIef+7mf4eYX34QNnlLB3gNHOHB0mUeffJq7Pv95hqOC4DUqZGifoQMiWtuQYpiErKEgMQnOWeq6xkXNIj+lW9SEW3k3FXoBJKmkrW6c0DRNZWXeCcDT6XQiQGgICIigtQj/WidCsSGItpo2MQQOMIkIgSeJAQS08lPZmtIkwWgTBWDlO9mnYZbI/TVggI6hdg3opYiedJB+ba2AM9Y5tNIkWkfJ/lgzQX41DtFIUmrrpPhKT6YSTMxUpLQAZZ4ARgkDxTuU8yROkgaI8yaOsQqBUFuMC6RBoWLojoDmTYU145dckXdSN8aI0HfHb6BOPsrhu97FaO/HmRvshWP38+zn30e3v48t9jjd8jBz9WGytT2EYw8zMzrMWT2FH/ZJVIJxmnxUMbuxztdfciFXbemQHXuK4w98jNn6KB23jKsHbOiE09k8R5J5jpkF1phlqFtUOsXqnKFNMa0Frrn+pZxcqVldcwQSgkkoXEpny1ZIMnxkXDWMLYKaDMGT4Xd6UI+v4zdnbGpqn7H+no+MNa3HwtNjmz5eCGecVGk9znDVALD6K2aP+woWr3MMCkaTLhUd13jKBvANNCCK3JGPIUDyt0ZTaWqbBnriZ8bfx2NHkKVx1htHXMLSZL/QsIim2CTTRdL0eCkq2W8CdDjqKL49KkoGo5L+qGAwKhmMCoZFKZo3ZY21MftaiAs9NHWuIvQzpi3F8mvKIrK8xvcaQaXIdD5y+DCEwAuuvXYMXIcIxsn7eCMOXO2obODz9z3Gu97zAS665FL+5u/ew/d973dx4MAxPvjhj1PaCF8FES5XBLQK7Nu3j1/9ld9gNKqZ6c1z4vhJ3v/+j3LwyCqjShhZOhXQZW19g8NHTnDg4AmW10rqkFA7qU8a4EspKue46NJL+bc//VP825/5Ka554ZV4PQEwm9fm3TTwGEJgZWWVEKDd7tDv90nSjKquSdKEPM9Jc0kSUVvLen/AsRMnGVUWF4ShLW2qAXwi6BOZSmNWkY+MokZ0G7mH7du30+60CVFDqSiK+OwSbcEsy5hfWAAtGpoCFjXnmLR5530EHWX8F/CsCZ9sxkoBt6yT8LfaWlnEi+2p0+kx05ujto7KOmrnOXr8BEeOHad2wpbyRMF46/BBtDs9kUU1BpQE8Nq0Tdu0r04zb3vb29723C83bdM27f8s+50//8B4gtjYODuLdyhELPcN3/KNnD7wOHmacMOLbub+Bx/GBgM6wY9nWhIGF7zDOUvETPDeigZMMymIEzAQZ+5Maz7HCa2S2b1CoZRQOwSQmjpOnPCGKGZbDAcM+322zM+jogZQbWsBSBJhSPgokqmCsEGSJMPVlhAcB559hnPPOYeFhUU8Bq8zLDnHVwr+8E/fzW/9wTt4fP8xdHsO7zUJgdlUcd62GS7ZvcT2jkOXp6n6q8JmMYYszynKklFVoZMEtIQnbaxv4JyjrmrW1tfp9/tYW8vE0VmsdZGpVMcVbUur1eay5z+fK668koWFBTrttoSvdbt0ul26nQ7dXnesl9RudyKQJGFteS6MpDRtwtoknE0AJSPiwohoaF1VJGmKUipq7oi+QgjiFHZ7s1x2xRX8+m/8FtddfyOXPP9Srnj+83jzG76ZxS0zaAKJ1hw6cIiPf+wTLC1uRSnDJc+/lIWti+StBBBgRYkXK5pWSsU1bXFutBFwICBAkYqi28eOH+fxJ57gyb17Ofucc9FGc8EFF3D+eRcwMzNLVVXUVcUTTzzBqVMnqaqaa665lvPOOy8CZIphf8A999zDyvIKnU6HLVvmxIk+w6UFSags4ZDikooQvdLiFKZZzi23vJT+aMS9Dz2A8ykrK0OyvE1RDimLIVu3bqfT6cXVfxudWfHYw5RiWHMBDQijYvhP47SoGLbWABpaadEuin1CIavETZicDz4KbsfQmHhslKKsa4xJKKtKMsBFUVYBbGN/VOLUhyCi1M333jlsLeF2KgIFWkWnlDPDl4hAV5ok4/vQWkLpkpi5TkegK4SA0VrSbFtLf9Dn45/7IiUJymSxbAw6SQnA2Tu3ct2Vzyc1wqhoofF1DNFTMdwpREYEjiRRcp21Iw2aqiw5fGqNz+/Zx0baxgfFQnC86uYbmDGgo9PelJmUfTM8CSBntAEF3tX4ap3VJz7L6qMfYbb/JFvUKh0/JPNDKDc4efwAM7lmcHgP9dNfZHToUfzpPWxRq/TYwKSOghYn6w6HNhK+/qaXcMs52+ge28Pq3R9h0R1h1q+gqj5OZ5xuL7A/zPCs7bGRzFOZljjTJqPfdyxuO4+rX3gT7d4WjMl4+qmnyfOUoBUq2cIlV94I2QxVEGac0QYTNca01tS+PgOIUVP/NH0lNmaYYt81/xhjZMFhCoRrfqNUbKux3TcgiRrre00Ja4fYDmNdhBDpflN25qfnWGTchMg4lK+igHRsryGew/nAytoaKI1JEhJtJENcFKEXEAiGZUVRSea0srbR4ZexK0TAoQF8mjZvTMMAkmdRWVX0B33W19cpigKTpGRZPm5rzjnK0ZBhfyOGPAtwq5QmzzM63S7tThdjEqqqpj/oU1UVSZLS7XbJ8paAJbWlqmvqCAQ456hKy6ioJHtobePzXOqiSQhA7JPeTwAlbaKgdhwLdBRhh4AbrPH+v/lr8izjJ/71T9But8diz6KTJkxLhULZREKVtea//dm7eHLvs/zAP/tOXv0NL+aKyy/mzk/fw6ge8OrXfB29Vob2iQh0h0DWSnj28LMMioLzzn8emowPf+AOPvoPn+bDH/kYu3Zv55JLzkOrwOrKOt/yzW/kv/zXv+Av3/U+3vf+D1FYy7VXXYsPFqViHekUrxJW1wesr5cok9DutkVXL0yDkVISTRlprSXcXine+973cu+993PppZdTW0+3N0uat7jk0kvI2y0C8swoipLDR09QW3m2NG0Lon5lkCQoLm7Bi4i7tTJWKhWTUihwtmbrtiW6M92YVVHAQh9EU0oAPwGmTJKSt3KGwyGuSeCAVHsD/hoTv4tjnVF6DGBZJ09DF6CqZQGv9o6qtjK/cp5WO2d+fl4WrEx8YnrPkaPHREQ+9qGGqTbT6wljdDq0GmnjTRj42VsXY9lv2qZt2leT/b9c/tm0Tdu0r1ZrJomTyaJMeLWOXhOB48eP8bwLL+Ccs89CR+AoeIdWAYLDuQqtPAqLQlYqfRTYHYeHTDmYMrXX0GjHKBXdgZh1iDivFbdNHBUlbCVxUGVFUYAqmdRO7sVwenmNfU8/y2gkE2Xn/ThkTJwYS1kMxQmOk8HmUKdOneSP/+SPOXzsGF6nrPUrPnH3Q3znj/88f/w3H2VEmyTNaWtPJ/TZ1Q1ctnuGc+Y0M24Vt7FCuTYiV0lkoziW105R+hKdacq6oChGDIYDnHdsDPqsrK0yKkaUdUlRVYzKgrWNDdbW1yjrmqquCAQR4r7xRs4//3zmZmfpdbv0ej26MbNbryuhbb3ejIS5dTsi1N3pSJhbZCvleS5bqyUhb1kU504zkjShleckSUKr3WY0HAKijeAiGyNJdMzuV3PeObv5w9//Xb54z2f4hle+nIsvPJdOnjPqD3CV5ZEHH+HB+x/kBddcy46d27j5JTdy1nnbMW1QRtKQKx2d9FjdohEiWg4hplX2aJROsS4wKkqOHj/BZz93F+1Ohy1zc5TFkGuuvorFpSWUNvT7fQ4cOMAnPvlJnnfR83DOc9NNL2JpcYEQPMNBn0cffZjP3fUZUIEXXnctZ599Fq1WK7a/6bYlE3353hOUZFjTWpMmGa28Bc6xuKXHv/03b+GbXvNKbOVwteGpPUc4fmKNhx59lLvuuZPBaJkQCoKTMDI4Uxc8IGERAXEe5JyT8LUkSaDJdoc44A2rR76T9OdBdPYJShzAEH1+kySx/4jDmxjR98rSVIRqI/to3NeisGvdMJicHTMSQbLAqcgskmx7Ir7d9NMkSeKNyTEbh5vIcmhC+sYAQsNqiUCW9FFDJ0/R3qKClL1kZJTwDBsUpBlOJVQOajy1cvgkEKjQoaaVgFaeNE0oaosNgaAMVRUwISElgVpCfwMhil5DpcBqhU5iaGQMEQteAA0J+ZP2IlmXCh6+93Pse/BOFk2fOdbIwgjlS9pJILfLtNae4vSDH0Q9/Vk6Rx9mZm0/s+4kbd1HJRWVCfgkRdvA111xNa885zy2bxxh8Nin2e5O0O4fQZUbVCZhtbXAM3aWZ+oup5JZTmc5615RkrIx8GzbfhE33foNzCztYvGsc9hx/sWcddG17DsyoDYLWN2FrEsVQJsEY4yMkQQJc/QRyHnOONt8FNBHgB4BHse7iUOIhJVJ95nuU2IhAlfE/WQciOFR8WAhTAFKoTlPAyg953hnfHquyV9FH+hL92y+CQ37ZGqTULVGWLsR2ZZXcdiFCdIArs3vnvv+uSbHtfLasDOcx1pLbS2VrUUTyUXB6anDNKUZGiZLBLCcFYZjUZb0RyPWBwPW+0P6o4L+sKQ/HDEYDhkMR1TVhF3SOPDaiBaZVsJibNQFG8C32XwIoBUuCDBma2Hdrq2tUpclN9xwHZ12WxJJOI+1E1aMi/czCJ7lyvLYs0fZc/g0dTrD6UHNwCqOraxxajCiHwwbtWTGrGuHVxlBdxiVhhe+8AZ++d//LL/+a/+a//pffo5Pf+q/87pvfyXHl1d599/8PYORwwYNWrE+XGVmvkNnrsuJlRV+7ud/hTs+fjfOJ5RViaNmrT/iP/7+n/Jd3/0vuf32b+NN3/kjvPe9H2cwmrBIpXfEj80YoGNqDwVHjx1DKcXi4iJlWQGKrUvbyPIWPkBR1hSl5djxU5RVTVXJApKLoW3OBWztZGvCyuoo6G5rIFBXFVVdEghUVcXi0hLdXoe6qmIG37g19RW1mYhswU67xfz8FrSJC3jBoWM20eC9JA/wjhATQ1gnC1sNwCWblXEvNH1AFizSPGNmZkbA2ai156M2Xl1V4wWy6X5lYximgLBBnhXE8G8r+2/apm3aV6dtMpU2bdO+Buy3//sHZJIUnUwBXCQ3roqrVd45ntr7BOeccxZJq8tHP/4p1jf6JIkCbwm+QoUa5SUVOnGioJRo4oh/GITF1Eyuoz/QhP+MZ8rRRxAnTTxteVGijTPGuyN7KfI8GocnINevtaE/GFLVFXNzcwARABMGRJoYcR6DI0kzjEnxPqAV+JhCe/+zhzCtWX79t/+AP/urv2XdJrTbLRLloe4zmwUuPnuRs7d2mck8drCKqwdAIM87uBAYlSWjsiRvS9r2/sYGdV1TlSXFaMTa2jpFUVJWFWVVUpYVVUzDW5YVKqbf3bFzJ9de8wIuvuQSet0us7OzzMzMyAp1uy0Z3Xo9YSx1OnQ6wlLK8xatCB4lSUKaJqRTrKRkKsTNGGHuKCWrgmmSkGYCGKytrTE7t2UqBXgQnSUl5bp1aYGX3vpi0gQSDYcPHeTpp5/m3HPO5dDBg7RbObt372Tnju04XxOCIyAi6lLLX86av2pxakyKNgnLq2t86tN3EoDhaEQIgSuvvJKzzjoL5x3FqODpfU9z6NAhntq7h+dfeglLiwucddZZJCbBO8ex48dZXVlh3759bN26xGWXPZ+Zbne80u5DIwsa2XQKYWfF76S/BEDSUTsXyLMMgiczcNstN+PLkgfvu5fEwMb6GgsL82z0N9jYWGNpcYFOuyPHkbPElizAqfQYSBIjE3prx5n3nHcR9BGdoiYcyBipGxd1ZtQ0iBu1kFCKsqwIgNGyyq21rI4niYTJNfs3YYfCTAsS3qVlkq+U6AepKaFvE4W2tdbCVGxC25SMIU2Nhlieisj4EfrH5FhKCagTQTRb1wyHQ77w4OOc3hih0paA0Uh5EDw75me49bqryJVD4wlaUeGFPuE92gdUkjIKsOoDhwYjhmmO6s5QRef4+Mo6dz30OEWrQ0gNPe25/abrmEkUJiiC9WNdKNWw56wlidn3QnTo66pg36P3UR17knNmBHh23pOmHerKkhiFwdJSFuNGBEqCr9C+IPEO5TNGaoZlt4V82yVcdv0ttOpVjt3/ERZGh+nZdQgVw6TNyWyRPWGBPXaWNbOFIukyUiII74cVOxe28fKbb6XdaqGNJk1zEpNikozSep7af5CLLrqMs86/GKuSGHrj0QF0MOPwN68aDt2ZvVUxBfQoNX5thmxhOTQPFmnr8rfJcaTHNceKHaIZz8fAkVjDxjNjXaW4//iE/5iFMQgwzXKKT54z9kNraudYXlkloFAxBFjAUnlcNTovw1FBUVuKshKx7TABXBvmSeNwE29dK2HKKSXMnaqu6Q+GrK3L80AnZgzWBoTNVBUFo0GfYjQaA1hKQZbndHoztDsdYepWJYPBgLqq0MbQ6fXIWy20kfoUtmIEnyL7papqykrAKx/ZN/IcmADXPkS9plhuShu0kWdFiJpnaZJA8Dz4+c+w/8nHeOlLX8orXvlKQgikaYJ1ouEki05SfjZp84u/9jv81u/8Ec88ewJjeux/5iCf+ezn+Zu//RAr645R5ZntztGyKRuDiv6oYFTX1IHInlUYFcgSRbeTcdULb+Tdf/t3jEZDXvXKV9LO2/jgef23vZ7v+f7v4Z9853dw7fUv4sN3fJzHHn6M17zmlbRaBm1y/ts73s1v/vbvc/Ell/Hab/pGDh4+yl+/7wOce+4FXPa83SRNSO94viTtUWslzNi64s/+7M84cOAg113/IqwLdGfmuOCii5hfmMc6T1XVHD12gsGgQOtEepbSEcSbALNNU2rmTdZGpmlDDw+B2tYsLMyzsDA/fjZBDJV7DrDZZHEjyMJBmqbkWYvBoC99FWGbyXNdjhNbgLCfIrPOx7A150XKvqxEG8p6efbMzs2SpIZWlsYEH5Fp6wPra+sCHAVQShiMWsHMTG8MQqu4YBMvIY6tgfN3bZf73rRN27SvKttkKm3apn0NWMNemJ5Yy6p09Ce0wgfHi1/6cnxrgQ/c8WkOHD6KwpMrR9c4eqmnkwQ6uUGrKLCsNc42Ar9eGBkqUv61MJSayaDMzmRyqsaTbfleHBSZvfkxsylOeKcmW9OmtMEjAuLHT5zi2PGTsioWQ8qcrbF1NQa8qrpEG02e5RCdgKq2PHPwIL//h/+VPfsO0Or0yBNPpmpaquScrT0uP28ri+0A5Sorpw5jfYnJDE4r1ssRq4MBKslod3pUhaO/PiQ4xWhQsL62wfrqGlVViw5BJeEHRVEIo8q5CO4Frrr6Km644QYWFxfJ84wtW7bEkIZcwtpaLfKWgEet+JrnOXmWkWVp1E0SQClJkqiVJJNXHfWzxhO4WPZJkkRHKJBnOXNzWzh27CRaS0pioxR4hw6OVHtSbenkUPSXefKJR1ncvp0Dhw/xqU9/krktM1x/wwuZn5/DuUpSt6MwyCT6uc6gD9H5im2k0cRZ2xhwz733cf8DD7Jz11mcPr3MOeecywtf+EJmZ2fJ0pSqLHj8sUdZWV7h1MlT3HjDjVxy0cXj8LC11RUOHHiWshhx7NhRzj57N1dffSVbtsyCCgQ8VV3FHiEgpEzqOeM6g5IU0R6Fd6CCoS5KlK/JtWdrK+Gt//oH+LZvfjGuPkVVljz66D6WTw/Yv/8g93zhXorSAtLXpk0pRZImssocwRgdwTwX+1Kjc+WdsILCWMxXHAeeCzKFQJalOOvodjuxfwmDyXtxzn2Q8KTGidVTv5cu2vAGpY0EkGuJOlB1XUdnRRzoJuSiWZFunGofWU4CQgRxIab6cIjOTfANICGOTrfbnYTRhijW72U13VYjlLfoYNHBAwkhGFwdUMFASBjUgVM28Nd3fZ5fe9/f8Zv/8DE+sP9pjiSejdSg0pw8zUgixOcR4e7gIXFawj+sk4yDSPiqAGdyXyJwLem9t+86i5V+SelTnG6Tpj0ICWnawXuN8gFTjzChwBtHoi0ZDoPB6x59vUTV3s3F17wI6gGHHryD3vAgXbuKdhUj0+JEa5F96TYecfMcTnawohfYqEUjpiwcc905Xnbzzczlno4e0U0CLZ3Qa8+xbfsuzrnwUq67+TYWtu/GK9Egi9D/uO03Y2zjiJ75pJg4vA3YJG2x6SpT/aVhp42PMFXfsc3LflPHj4wWeT/5vmk3ck3NNcQf/KMWGWVNG2w+nGHN3Ucmjo9pzb0whawTAePaiQaMhAJJOJD0v+jIT2UJ+3LPqGnWlw9BzhdvptnfBY/1kRU1JYI9LpMIPMv9x3N7EUpujiHOuzjkPqapb5hCwgYVTZzpc0joVCyF+NuGkdUcN8RrluNPhdMGAcye2ruXEDw7tm8f132juePH6egtzjqOnTjFpz/5OVQN3/9Pv503f/s3YnzN/r376K+vcvbuBXLj+b3f+j2+5Zu/m9d925t5/Xd8N9/9Qz/Gj/6rn+Nf/cTb+YV/9x/47V//I/7yz97LRz7wab7whftZHwwYFo7TpwesrVcMR4FOZxbrwWQp5z/vQrYsLfHE3r0MBgVK5fT7nre99Ze45PmX8Qu/9FZ+4qe+i7f85I/iSXjrW38Z37DxpBIJSIKBcY0oWF5e5uTJk3Euo5npzaKNYWZmjrK0DEcFp06tMByWOK8knD9qBHofcHYSpua9gPnNhoptJ06balszM9NjdnaGgMwZ/FTGtEbwW9oYglIhrGDpYI5WnrG4sABIqJ1WkMSxbHpRMMRECT54fASZfGTJylUJoDwz0xu3cMmYKgsOIQJFWmt5/quGShuZsV7ajtGRkY6MB42uZF1vMpU2bdO+Wm2TqbRpm/Y1YP/hz98/Nb0VE+dPWEpVVZIkhuOnVrj3wScYFAXFqM+lzzuPW190A9ddewXXX3sV173gGq655iq2bVvi0cceI/g4OVBTDkNcdmscAJkMC1tFTFaSm/fyu2YCpWL4W/zY7NcAEON/4nSkmW1rWFtbITGavCVAiwoB7yxGQdBB1uKCJk0zcQIIeAVFZWn3Fsg6c6ytrtM2FbsWOpy/c54d823saJVisEpZDsnbOSZNGVnLsC6pvSVvtaitZTSsKEcV5ahkbXWNYX9AXVZCC49CmsPRiLquJESgrhkNR1x55ZVcf8MN7NyxkyRJ6M3M0O10x+FrnW6XTqdLu92i22nT6XTpdDuSva0BkSKQ1DCUTGQnJSZmxkoSmeSNxbgFJPAxBXHzdwExUo4fO8biokxAIZAYFTWzaowGoxWD4QinNFdedRnbd2xlx45thEitTxLRgSA02xm+J0TnJAQBklAGYxIefuQxjhw7SfCBsqxITMILXngtu3fvot1q4bxj31N7eWrvU3Q7XZaWtvH8Sy9l69YlYdxpw5N7nuCZZ/YzGAyYn1/gqiuvZNu2JUwyyaLmfXStm1DLqesKQUUFemkjxHZjVEpwskqe6ECGJbcj+qtPs2UWUuN5+ukj1Dbn5Ok1ur0ZymLE6soa8wvzotcxzVRSIogu4EsgzbKxJo1umBUN2NWUmZGy9NHZbsDbxsEFEf1FifC1916EwK0lzdKxrpH/slo1cmVEJ0lFhoW8l+rzYdyxxw6/ic5XFoXC5RDClNBRI8N7j4l6So2odwMkNc5rVVWUZcl9j+3l4PFldKtLGOuYKFID823D1918LbmqaaUJhja2tCgHyiuMyVhXCZ/b/wx/de8XOTkzxwEUjxzcz2OP3MeN11zLaH3IvQ8/TpG1sUYzozyvuPEG5k1Cx4kum05iWu3I2mpAeefdWL/K2hqlPCf3P85cUjPfhmBrEowwD3SCShotFKlP4yRkuFYZa2oLz/o5dl11Ky5t89RDdzO//DgLYY2kKghWc6K9hcfULI/YGY4lO1kzC5QhkeZZFix2Zrn9xhexo5Ow/OxDjFaPMD87j7cJKmQkmaE3N8vi1u3s2LaDpNUFk+CCRwWPQaGCsME8gG4Ypg3gP7Ex4DT1Or3PpD9PvvuS8br5/jnMIR9ZSYEJS2l8vOfs27RRsS/5S3w36T+NptLk71N9SonW1+mVVTwSFkgQgLUBe+tagKWirqlqS1lbqgjoNNaEoApYI98L2NCweCfhPaPhiH5ftJDSNCXL0jFzBaWoq5LRcEOEl5vjKeKzoDfWVCrLiuFgQFXVJEnKzOwM3U6PNGuJjmBkSglILPVsraOsG6ZVw+ASgFAADrlvH4FrYkiqNg2bJEiot6QE4+F7P8dofYU3velNnHf++RC1lIj33BwnAM8cPMyf/8mf8y9+8Hv5kR/8Nl5265V846tfwitfcTPf9q23833f9a287OZruerSS7j2qhu54JILmd+6nVEJjz1ygLs++yD33v0Qd37iLu748Kd533s+xt9+6GP4JKEalXzy4x/jjo/8A3d99h6e2vsszxw4wcEjpzhw5Bif+/xdDDc2ePltL2H3WefwwAN7+B/v/TBXXnsF3/nm12B0xcEjR/nbv/8oeM2P/bM3ijadteNxqgHZG4bvwYMH+N3f+V2cD1x19QvAJLS7Pc469xxUYlhdXWNtbYM0ydBGFmmI47NvsveFKCHg3ARUikBciGCnrWsWFrawe/euCEl6vLcEPMTFGKbnVEpQMOcc+AnQG3ygnedkWUpZFhA8JsofNAwsYr9w3lM7CXN2EcCsY3IH5zzdXo80TQEBpIzRotlotMw5gLX1NVxMpOKcPNOMVszNzcl8QzVabhPWoo9JJy46Z1e8mU3btE37ajIVpp+Mm7Zpm/Z/pJ3zyh9Ce4UOGhWU6JQoR1ASnpT4gPFAkMxns1nFjddcxNWXXUA57FMOBhIChyPrdfF5Dirnj/7LnzEqAippUduSEGQiolykT3tJ440vUXF11HtZaQvORd53XDUNUUcigkwhrqA3LoV3NgrxymR54lDIxFgRSAycd+7Z7Nq+RLedkpqAIZC1ewRkgpxkCcTQPZnwKqyDXm+O9fUNZjpt8lYG3lOWBWUxwmgRStVa0+/3CSGQtXKsc5RFifeesigpy5L19XVxqJWiKCQDXVlGIMnFLCs+sLR1iRe+8IXMzc2hlSbLUpIkpdMWFlKWZaR5Rprn9GZ6JMaQpwlZlpKlKcZI2ERLa0I7x5iMtm6T6gSbViSmJsdQ6m0YVaK1TJAngIE4HIwny1KWShnKouTIkcOcd965+ODJsyyubMvKfxNitWfPXi67/LJxVi0TQYQzTY3DiSSzmBxDABWp56Iouffe+7jwoou44x8+wdVXX4U2igufdz7GaFJjGA6GPPLoYxiV0On2uOCCC+l0u1RVxcrKabrdLnsef4JTp05w7tlnc801V0eWiYRtTNtzH3phfMnC4QBHkso1ewupaRFckJBI2yfRFbo6xelHP8Wpg08R6ppadfn4Qyf4tf/xWarWIlobrr/8Aha39LjwovO48aYbWNq6HedA65QkyygrCatCxVXl4HE2oIhAjhLAlrEjHifoUVPJewk3adpyEllHzWqvMQIu+hBwVkLVmgM650jTFNeEeWmpV9HaafrgxH/3kVHUOPoKUFEkvHGYdAQqQ3Qk1ThczpOkCXUtoFJzDDmn6HCMigHLp0/zF+//KH/3iXvIF3dTO0UWQ4SM1py7bY63/8T/xdaOJsFBmqOUwpUl1JZSBR4a9Pm9D36EgyHBpTOYdgvjCxbsgLd/6+vpHzzC7/7pX3K0NUOd5OzWnl/98R/m7FaCrrwA4M6S+oBRmtJoBhoGwTEY9lmc7ZK6mrq/RjVY4ZH3/Wcu4BDPXyrJjEU5DVYYViEL1DjQBm0yhkMYhTYbzHM6LHHui19J1ss4vvd+0qOPs12NUKMNnE5YzrfwcLLEA1WXo8kcVd7DBk1qA3kxYquB73rlN7BkBvhjD7P60CfoJinbr3opfse1rIYlKquoEo3JDG0lIIoACXFsVUqYA02YWcwCOAaNpOoJEexx3o/BaBWZCNO9XXxDAYQaAHK6zTRtonltPoy1k6b2h/h9PJdiAmTKuSQ71mTcYgpskkOryK4DYegppeJzRnSkrIdRbXniqf04JCGFSTSoyLpFnHHnA/3BkKK2jMqashIR6qC8ALtN+JsTxkUIUk4C6gt7siyFnXrq9GmOHDnK2voGrXabdrdL3mphtMF5z2iwwdrycdZOr+CqUkABpejOzrK4bRsLS1vJ8zaDwZDTp04wHA5Isoyzdp/Njl276PVmaOctFB6jNEkiDr+2UNS1hGpX5TiNO83Y34AZ3uNcwOkEZZoFCy0hTEGhgyf1NUnV5x3/6bcYrp3mT9/5F1x6+ZUoY0hjuLSNIaNV7UjyNvfd/yBve9vP8/affxsveOFVoCS0L0lM1BeKjEiTolUmotpagNzaWooSlleWOXH8MMePHOD0McuJ06cZ1RXr6yVfvP8L9Pvr1JUjeENlHaPSUdqSpV09bJXRme2w46ztbPSHnDi8Qp63+N7vfzPPu2Q3f/RHf8SjDzzJW/6vf8ZP/dDrBL6JjC9h30gocSvPGA76fPgjH+LNb/4ezr/wEq6/4UUkWYutO3ZxzbUvZGMwZGV1Da01SSLP6YZR2jROmbFM2nLjiSlABZk3KQVzc7MCKEXWmDyjxBowECaMQxXkOs/smZCkBoInSzPWVldZXV0R0NNIYg45tohyhxiCV8cQOOs8lXOUtSVNM1BKstyZlEQntPOMXrdNr9MizxMUgWefPcBwWBKCwgXh6mZ5yvbt2+h1unjvBNSSjj01D4RX3nrdGde+aZu2aV8dtslU2rRN+xqw3/zzD0g+qyAxrxL0ISldg9L4kBBIUEFRDdd5yY1XcNnzdlMWGxw5eoLPfP4+nnxqP6OyZna2B77GW8clF1/Kk0/tlxS5kT4tk5vJ6hNqoj1BnD8QJz9n/OGMSVCkRoyt2W/sjkz9OX5WsuK6vr7GTK9Lagx5loo4N5LtTJwmK05KszLnAxqFszVbZrpkCZTDIcNhH1tXAvCkKVVZMRwOSdIUrTXD4Qhb19R1zXA4oN/vMyqG1JVo2dTWYm0d9ZNqrLPUVU2r3ea6F76QK664ktmZWdI0pTczIyFtnTatuR69Tpdup0233abd7ZC3ctIsIctFaNvkOUme0mrlZFmLJIc0UWRGWD82gxDDEw0pWkdhXC0rrVoQixiCKGU3XomNWZxarRaHDh9maWlJJpwxDADkOFoptm3bKlNiL8LSxogz+dwJrUccvjAVtoXSlEVJmuU8/fR+Dh85zOFDR7j8iss459xzOPvsszHKELzi8cee5LFHHyfPc3bs3M7ZZ59Fu91Cm4SyKLjvvi9y7NhRTp0+xeWXPZ+zzz4LBQJieQnrCioIeKRE/FmAHD9NhwPAxLYZYhplCccEpSpSPyC1y/QPPMrxR+7EH3+UVqjQzlHUivmzLuaUa/P404cJQbG+copur8dwOOD06VP0Zuf4yEfu4PwLLozhVTKBb9h+4oiLA+8ji6x2AuA1deciQNaErQlTQZhmwfvxSnpzbNFYibfYODNhsl8I4hhbJ8wirSdCvU3YYggSrigMqon3o5kCmeLfGmdSwhsEvNKJxjqL0VHMuznA1LHqumY4GrD3mcM8sf8gptXDBUUa2XXBe2baOa+47WZm8gQdXMxUJKEcyiiO9df48098gkdOr1G2t4guU3BkCtrOcfvzn0+5scFdDz3ERtrCq4xZDa980Q3MZSq21LiZgPUWZwwrznPn3j383f1fYG73TsmqWNa4leOsPfsw5y0Y2nadtOlLGowGTEqddumnSzy11uGJExX7N1oUcxew45qbmJ3pcPqxL6KP72FRb5BWq5TKcLq9xONqkfvrHseSOTbSDiNtBHwuanZnbd5w68s4J3fYow9z7MGPsVSdZsYOGQ1WWNyxjdCeowotslYW+38E85oQpulqILJWptYYA9JnJ/vF9/F1PGY0+zZAVASfmjHmjN80h2peG5ZCAxYpOdq4PTWo5tR1yQ8V0CSZkGvwkfFGZCfJYUNkI8rvG4afUQgby2hqFzi1vILzShIFNAsOkTVircNaR1HV4mg7YV9MGI3xmoI8S+RSBezSkQmilMLHELrhaMTGxoYwMdOUNMtIkiQCa2DrkmI0oBiNCDYuvCglmkqdHu1uB5OkVHXNaDigiuGZszOz9HozccHBjMtBK41RSrKJOSsJIWwds9rFMTFImFOTmMOHgFcatIRQm6lFAI3CBMvayaM8/MW76bZbfM/3/QBpuy3jk3NIpk+F9V7mFx7mZhZ5wxv+CTt2bqN5BGilsbVDBdH2S7QBH1A6EPwIfB0zPXryVs7sbI/du7dz8cXnc9211/GiG1/Ay152Ay+99Sa+5XWv4du+7Zt43etezatedTu3vPhGbrzxWm655Tq+7Vu/gU6rzeFDB9mzdy/D/gav/YZXcvjAPj7+0Y/wwQ98gCMHD/CiF17N//2TP0Y3i4BNfOb52D8kol+04/7yne/krrvv4SW3vRwfAt2ZGXozs8xumef06dOEmKU2EAX/Y/ts2qnzUQQ+hhA77/BOvo+8MPIsY/eunWRpKm0qjsv4SZIU7+PDKow74qQ+pzbnarJEkjRkWYZSmlHUKiSG8/qogeRdwLkgYYxeEmnU1tLt9kizjLrJ/uYDWotuY5pKyH3DeFpdW6e2sl/TV4xRdLod0iQRBqfMQOMW9dxU4MJzdsdOtWmbtmlfTTY1s9i0Tdu0/3NNJqxeFETkAR5ABQXBAAaHxgXLXFfxshdfSy8PzHRbfOpzd/PMqT5HNzz3PvI0jz2+j8Q6kuBZ2DJHO0vxzkIImCSJk2jR0TFaYuqFhh81kmI6chVDd+Rz/JtS42HpTGBCJuZaC4MDkScAcX/HTjSAs47HHnuC4bBgbX2A81oy1jjRBDBaY6saFSBNhMLtomZNUZQy4a9KkiSh3e6gTZx8EWh3OlRVKWwlHxiNRqyurrC+vk5VllE0U7KfDIcDBv0BVVXhnMVowzXXXMPtt9/Orl276LTbGGNot0VsuxuFubuzM3RnenR7Xdq9Du1em7wtItytrEWetUWIN03RRgmbCUtKidEWbwxeZzjTxuucTJcYFVf7o7PWgELiBMZyj3/zQUKV2u02O3fu5ODBg2PhUNlX6itJJKxK9FHiZFeqJL6fOIImOiQx4hJnPRvrG3zxi1/ks5/5HKB50Y038bLbbuPKK6+g1+syGo04cOAQf//3H6LfLzjnnPN54QteyIUXXkCn0yLguPcL9/C3f/c+FJ52K+dVr3wF551/LnkrI+CxdSUT6uDwEUwKyoNyKBzETeEE/IwpyINXeK8wOkXrQPB9srCGGR3k6AMf5ZnPv59sZT+tegNnLSOfslonHF+vOH5yBdC4AOuDggcffZLl1Q2efHIfH/7QP7B//7OEAFmao5Uiy9IxMEPMsgaKJEklO9wUM8g6YZslJhlnaUuigLSYhJ0pLaBUQDSQGh2W4CXEQClhm/iYYcs6R5ZlBCaaSFJnsg9qcl1aCSCrYrY4ERGfCHHrKOTtYthnkoo2UYgr7Y02SePwN3oixHvptjtkJhHnMsg44J0495Wt5L4jqJGpRHSLjGZQjHhkzx72HThCuzePMjlFVVLbgmArEqdiZEjAqyA6WeLGyP8a0AIomczgM8VQ1SzXBQ8eOsR77rmXx2vHH97xMQ556OuU0ytrnN4YsTJylC6lGFS42lK7GmsMg9DlwEaLO/cVPLKxRO/yV3Ld6/85l3/d65nbeTbH996HOvYY89Up/HCZ2pWcbvV4OPS4a9hmH/Msmx6lTnFBE8rAUtLiO15+Oxd2O2Snn2Ll0U+zS28w60a0ijWS1Wc5+vAnMOUJslyhQkWmGs0uYSo1ddz0Wd+8Todvxb+HCETxZV7H+8Yxpdm/caLFwZQ+pSLQM20hppz3DbMtDu4hOt9yGmHmTY/xNDpIEfgJEYg18XnS/FZF0DREcGByDHlVY70/AU2tdTjrCDb2FduEJElmLB9Dw4iOuFyLfGzKonmVPzUO/nPv/CuZlEOIF/ylvztznJ36WgABJyF2ztrxtTd6T+N7iBpHtZVMdE0mR/mbAGY+imtPtwUVy1drWYApixFVVdFud5iZmZ26GHkGh0YvKARA8YlPfIb9+w+jdBbZRx5nE4LLqWvJ2lpXjrKwUaTcYuuaYlRRjCzFqIifS1ztKIohzg2pq3WMHjE/12LrQofzzlnkmqvO4VWveDFv+o5v5J//4Bu4/dYb+aW3/gR3/sN7eeK+u3nknk/zG7/wE7z3nX/I23/mx/k3P/LP+M23/xx/8vu/xUJPGGONVlxTRi5mjq1ri7WW97znrwkhsHPnLmSU0tTWcurUSUIcy1RMXtBocVkndVPHxShZeIp6XfHVWWE/29qytLgUcVYRudYqoGPoKt6Bs4QYpib1WuOspaoraltjXY3zFh8cKsjzIwQBi/JWi05vBusDRVnhosZkUZTU1jEqCgmJjG1hdnaOLG9RW0dQIuDufMARqL2jtJbC1hRVTVELaGl9GGuUBeLCTjMLHWetc3iiILoRoHfTNm3Tvjpts/du2qZ9DZhqVrNwBCSMTQUJeTM+YLwj8RYTSrZv7THaOIl2Qzp5wtzCIqo1i8vnUO05jh0/TUsbtHMYINGGNElRxuACUYchblFTQpwCmfArWcIFbVAqbmPAQ9Jcy+pydFYakEkJBX+yyj5hnEzYJs1+mn1PP4N1UFlZPa4qybjmnYQFuLrGVTWZScgS0bVo9Afa7Q4Ao+GQoijI8gxbW9bWVqnKirqqWVtfY3V1ldGooKpqqrpmMBgwGhUMBn1JvR4CRTFi565d3HLLLVx00UV0Ox26vS6dTofZuVlmZ2eZi68zvR5zWZtOu0XayTGdDNPOyFoZ7TynnbZom5y2aZGpFEMg9RVtOyL0VzDBEUyKIsfQQqmcVDUT0gj2RdBPNWBfMyWO7yVcSYCMXq/H3OwsR44cJs1S6roeM2y0VrRabbRWY32FMxyqKafHWichXSg2NgY88fiTPL1vP1onFEVFt9tj167dzM1toapq3v/+D7Jv337uuecLnL17N1dcfjmXXHop7XYHpTSDwYADBw4QgmPH9iWuufZqbr7pRWSpMGSMVoQQhacja6AJtSQ4lPeoIBnEdBMKFP3E2nu8NvigUD7Q0Y5uvcz6vrt44lN/yfCZu9nKabLiNN7B0Hd48ljBvfuWWalzji336c7Oo0yG1xnDyrFn37OUlaOuPXnWhqCoypIQmTxKKeqqHjuFSokDkESWjvPi0AiUE0N5GpaQFoe+rmqIq//eCbBkjLBbxHkXJpGObCeTCGhkawE8nbXoJiuRF1ZDAx6FCBJB9DCjk45W1NbJq3MELQANCoJS5K1WdM7ib8X7lkNEMVjp7xHYUZp2ntPKMoj1oYlgldZY5+kPBthYZs6LfpdzlsFowKFDh6mHBanXJDGE0Kma0hYS0uNc1AaLDrcNeBv1ZILDa4tXXhwxPDZPuGv/U7z783exNreF02mHQzX8xSfvZHlmhnTnucydfxV3P3GctboNuiXOp0pY9x0eOWV4JpzFeS9+Iy953Q9x6c2vJd95EUl7huOPPYg/9BhznMK4ZayzrIUOD9RtPj1qsdds50S6jTXdofSKpPLMlZpvufklnN02uOW9HHvwDra7U8wWK8xqRydx5LZPtXyY9ZOHcFQYM5noCVgx0RkKETgIIYronlE3sV9E8DAANMBQfBVWG2PWhGBCDfgvIWFN+5GfxfZBbEfxXE3YZnMt0hbiOSL7ZRrwas4tTCCp54DUo4Dc0tbG7yMCI6CStLumnTIFCoVYNok2spn4qqcyZiL30JRl89pc/xn30fST+O9zLZaq/Ds5jJRp8+90HTW/myoHufGGXRJTwFsrwFKTCKJB84Nor4mA9plp4xshb+d8ZGLJJlUqz4YQAQ1bl6wsn2YwGHL2OediTIKNYIuLzz0b9YhCUAyLkh/50Z/kP/3+H4PJKZ3DOk1VGd71rg/wq7/y2xRlxVNPH+Q973k/a2sD6trhLBjVxugWRVFQVSUaRV1VeD9C4QkuEJylHpXoAN6WEApcPUK7El/0ybwisQMSO6JFQTtYGK5z/vZZvu+N38yP/9Cb+aev/0ZmM49xI2wsD+sFDHLOi7C28zhrKcqCI0eO0Ol06HW7cdyMY20I5Hk+BllloS0ylRqwarrsm2x7Y+aS6HVt27YNpUTXzdlatAqBVAUSFeIr6BBQzuHqGltVVGVJVVVYK2HFSkOSCBPWOcewKCiqmlFVY7IWQWuKyjIsK0bFBFxyERASkfAZZmZmaFb0AmC9xyslYFJtGdUVw6JkMCoYFSVl1CKrakttJeOgCOBbKivfVXUt710t5UIA/eX7yqZt2qb972+boNKmbdrXgKkgLAEfs8F44gQ2gPGexDuSUGMUnDi9xurqBsqDqiv+6bd+C264hnYFOlgW5mdlohUUy2sbVM6jkoygEoIyBJ0QtIGpLSiNakCkMZjUhFtpGYq0Aa1FFDc6JzCtd9OEbzXeQPMl42l444Y6ByurGzz40KNsDIooohqoq1rAHmfRaJmQWk87axGcp5236PV6cVLu6HQ7EGBjYwMfPHVVs76xztraGhvrGzjnJBsWjDUzitEoZngr6Xa7vOxlL+fmm17E9h3baHda9Hod5ue30JvpMj+/hW6vQ7fbodvrMNPpMN/u0u12ybsd8l6HbrtNL2/Tzdq08jZpq0OSdciyjLmWoTt4lqc/+3fs/9zfMTM6wKxfZs5v0HMjWsHhlZSrOHsTQEmNAQBhKTWOnFZgjIrFH5ifn2d2do79+/ejtaauKhKTAo0IcWS9NFT8M0w++5jdCKV44IEHOXnyFI89+hh1WXPzzTezY/sOyZBXOR647zF63S088fgTbNu6xKhYp9uTEJ6yKnjgvgd54tG9PPbIE2gduP32l7O4MI9zNdpI6ISLoVxKBZREr2FCwHgftcUafTHJGKbiRjDU1DhVYXRFy28Qjj7Gvjv+kiOffg+d03to2XVqb1mhzZNrPe54dJW7nq04VMzw0DOnWa80pj2LS3KsTimt5/jJZe67/1GeffYYT+7ZR229hL1EQFO0RRJQkMQU42mSUFYi9C5tXpq3MCUmoUNunDlOHBcXw1fSJJXeoBVJIgLgBNE6MVpEs4MPUUB7EmLXnM8YMw4BAkTw28tvQmSKMMWwanpkiIwXEPHt5sIbcIAmJC7q3aioDxW8aPFkiaGVpJNQ3biP0kZSopcVPngqZ3HGU7masq4xwPO2b2c7itHT++gOB+RIGI/PMoZ4qhCZKLVF1Y5Qe4KVUKcQ2VzeBbRpsTpy3Hf4OO+994scTwwbAVStCT5l3/Ia//XTn+TU1p0sXvcKdt/wLXzugOWZqsWGWeS0W+LRUzMMtr+IS7/++9h2yU1s3b6LvD1DT1vW9nye8NTdbA8baFewoQ3H0wW+yNnc2V/kKbWDZdVhhKGqPGnhWCxKvvvrXs7FW3JYe4rjT36Qrj9Gx43oJCkFno0kZ80scqqcpQgtLA4bNHUdp3oNajFVZwIcTDSHvBfA0kQwkrGgt6QdV9HvUwF8rM+GhSqHjwCkHFwAGDm5nLs5MRHkaQCYCHpIOxagitiWTARXp9lQzjlhzUXwUdYWJERIN6drWFXRGjCm+c5HZmmIiSDkbwqjDEYpjDYRpNYkJsEYg9FSFgEPXoSrm7Dv5hzNeeSeJsX+JRbBrC+xBpAaHya+icUkX4VxWtcGsMAHghOGlegWynd4AWfHz854jcLEaYAkAZNcZCdKkUx6tVZSvpqA8p7+2irOWb7+Fa+Q0NiomydZ6cC5EMOeNAcOHkVns3zys/dxzxcfQacdgm7x7r/5CD/z1l/m6Mk10vYM7/izd/Hzb/9NjhxboawVqC5v/8X/wG0v+0ZM2mbv/md53/s/yKmVVWyoKG2grHPW1gPeJdg6IUvmsFajSHBW4SsNdYqrPVUxJNEWV/fJE0OoLeVgQFWsUxVr+LqkKipJNjkdluY9dS3AB2iOHD6KUob5+UXB65QI/He7PdIkg9BkPJXxVzWaec2cJrIDbZw/2Ia9ZOX9/OKiaM/5Sb2qIHVolCbVmjxJSI20UyJLraosZVlh61rGdDyJ0RJaaAy2tlSVpT8a0R+NWO8PyNs9dJZTVrWAQFVNUZWECGh2u11mZmbGwGITpuk9uBBk/LXym1FZMixLRoWI2jfC9mVtKSoBrYZFzXBUMRiVDEcVo5HsX5Q1ZWkpqzP1Dzdt0zbtq8c2QaVN27SvAdPBolwFvqIuBthRn3q0jnIlKsRwFJPgTc6wggce2UNZeuqixNRD3vJDb+K1t7+IV7zsRq67/loqDD5p8dBjexhVARs06BQfNAFDUAaVpHg0OsnQWrKBNWyj8avWoIVKLcPRc0EjWRWT1WHRdoHIgjJaqNLPybpDAB8UKMNwVLFn734Gg9F48mwrKzoOKAl/C4HaVqRpQlXJKp9JxIEY9AeUVYm1lvW1dVbXVimKgsFwQG1rRkXBcDhkbW2N0XBEURSUVUme51x22WXccsst7N69m7yV0261ZMVvdlZWOHs92u02MzMzdLtd2q0W7U6bvJWTpAmddptu0mZGd2ibNlmnh5vp0m+nHBysUlLiRyc49ux9rKydYGOwykMPfR6lS5TyMaSrJmRSxgKyyKq+TBCnRLsbBy86K80KZ4gprBfm51lYWOTEieOkWYaL5e1imnWiDhNImIVqwl1CkPAVJav+e5/cw8bGBlu3LvGKV7yCG2+8kXZLshWdPr3MvV+8lzTJcLXjmquu4YYbrueaa65mMOjz1FN7+OQnPs6jjzwMwA3XX881V12JtxYi46W5dm0mbDmIzmZo2pPGY3AqwZFgvUJpESuFQK5KeqzTrY9y+vFP8NSdf40+/gQLfkjmoHBtTrlZHjjmuPPpIc+Mupx0PYpkhi3bzmZYQ0UCaQeSNhjR7hlWni/c9yB7n34WtMYkKUorqrpCKwmd0NqMw9qsdZLJr1nljqFpTdk6ayUbXHSOVQzjkbsUkKAJ4ZB00I0uU8zGpsVRl/ISpogcf7oNxP4YRDAXJAOdOEri66oGPGjClpwbazw1oUg6ggHSBifXABIe4n2Trlwx2+vSbeeoIMFpxMPXtaU/GLLRHxBQlGVJ7Uq8CiSZ6Itdcu7ZvO7Wm7h8YZby4DO0g0c5jSfBJ8LTdBFc89HpKqsC7xwGg3aQ6IyVyvOJPU/zjk9/juV2jzJrY3RCajRJO6fMMh4/tcxf3XM360s7aV9xM/rim/n0QcveaitPDBaYufTrueCG19BaPA/T3oLXKcpXHHv8C6zu+TxbzBq27FPYhPVkO48nO/l4vcAzyS7W1SyDALUtyWtLe2PIt7/4Ji6YDajlJzl6/4dZ6O8nrVZw9ZDS1RSJYTWf5xm7ROf8W+luuwRjUkLQ6KQVG4aMpwIoCsjb+LpK/onjQGSpqKYtydjaMH/GY+3UmBF8E0zYAB1RKDuyIOUnQfCSqD10xnEER5kcJ7Y9pUWjScZ42VdFENVHYJMg19+McaEBmprzxtPEk8VjNG14ktZ9+r51w1QyAixpDcLLksyRiQKjJKSykYaRISbqMjXXGwsjNN0klk1gwsgSO5ORNOElnVnO08/QveriAAD/9ElEQVQ6+a3ct4TtCitJI9fWCCE32jUSvicC2dPHs86OgSWpyxh+GM8jTFdItBwzeMfyqRMorbj0sssIUUdL6fg8js8FYb04Dh85RntmC63eFt7ztx+iqDWPPrmfP/gvf8rc4k5mFraj0g7PHjqJUzmtXo/CetYGFZ+7535sMCStHu//4Mf52bf9Cqt9RxUMVqV88I5P8cP/4ifYKIYcOHyMX/il3+TRPU/jE41TitMraxw/fozKBnTWpqwDXhmGZU1RO+oAlYNh5RjVnqAl7LiOC0vOB1ysk0Yb8ZlnnsU7T7fTlfYUBOBrtVpxzJNyVHFMdc/NFtiAemMgWxg8gCwo5TkhSPl5HxszMo5KxsCMNElJTYKOYWi1FUCvtg4bAbGm7oyRBaUAMmcZFfSHBaPasj4sSLKcNG8LO8t5bNR2yrOM+S3zJEbLMxbJqOt9DFdTAMLsrOuaupLw5Kqq8aEpLxdBM09ZOgb9grKoKQrLqKgZjWqKkXwuS0dVTgDeTdu0Tfvqsk1QadM27WvAUjego0uuvHA3/+Q1X8f3v/G1vPn1r+TKC3eS+gJjAg5NjSFtz7B330FOLW9gK0s9WMNUa1ywc45zdi6A1pzYGPGRT36OLz70BHVIUDoV+rfWMZRGVrx0kgkDKTKUiJN+InOJCDSNJ/rN38SrkMCkMJlUi030mSYzm/j3GLZhEjm2STPWNvocOnKUjcGQqnaUlaTFlcmeUPSLYkRVlaRZSvCBYiR6EYFAVVZsbGywuiqhb1VZiVPv3Hi/siio6pqiKDj77HN4xSu+nssvv5xOp0O73abT7tBqt2m1WnQ6HTod0VFqt1t0Om3yPKPVapGkKSZP6XS6pDqjm/XIdQvSNkUr5+nBKv/9ox/kX/y7n+aRJx7m9NFnWN04xbrOybfuZmM4oCjWCYBOUzCasnEe1cTRUlKMsTRj+Yb4YTxZjE6dkvLeMjdHp9Nl37590DBeYqawLMsiI0bagTBSJAQCiOEKjosuuohbb7mFSy+9lG63Oy7DZ5/Zz6c++Qlaec7Kyile8Yrbuezy57Mwv8CWuQWefHIvn/3MZ5mdmeHqa67kpptvYOvWBRKjJbytydo2doSiWxYn8gHwSuGUwimN1RorcQGoROGChEwoN6BbLVMffZQ9d76H4w9/hE55mC2tQJb3GLHA4dEsd+0b8uAxOFS0OD5UtOe2gcnY6PcxaYZKMjozc+SdWVTWwZsWKu3gTSrizY0gq1IYIywyoxPR9hoLJk9cy6a9KSSEzTmHMQneSZaqRr/DORe9+QkbyHkvIYtTGZnG4uWxfJxt9FYE6GkArInTL3XYhMmFQOx/YpPrRcTFrTipTTidaLSI09mEVhIdria0KkkE2Jqb7dFpZQRXQQMwxPFiNCqlH1eShUgF0YYTUCowN9Pm8vN3c+Ol5+OXT2DXN8hVRqJTkrTJciROuA8eGyrQnqoqhLlWa1YKy30HDvPXn/8CR9MWazqjwpAoRQg1wYBu5/i8w771Pu++5wuYSy5n+82vpHfZy/niiYzeJbex+9qX01rYjQ/CKKirPqeeeYgjD93JrF1B+QGh3aKfL3Ew2cHnhjM8kmzjdLKF0otmVlIMmClGvPG227hi+zbU8n6OPngHC/URltwGOTVJCoUtodXmdGiz7crb2Hn17ZR6Ae0MiTLjfihNStCPcdVGFmPz9wYUAtG8moAb4pQ2hwEkHEreyHfNMD0erps95avp9jT+DRNWklJx8Jke05uFhulnQHwvu03+Jpc9OWdjSjX3/iV/gcbxbzSGxuGazTXJ2GKipo0BjIJEQWoMSQR0xoeLxddoGU3KfPoCGgRq8rMzLvvL3AMg7JFmXGvG81huDbDUAElGK1KjBQiNIcFaywgyuR6pE4l8jNpTIUJQYyBscg9aQZpoWlnCQw/cz9atW9mysDAu2hCkHzZsSWs9SiUcPHyYVjvn29/wBj70kY/y4MNP8BM/+dPsPuc8dJ6xuH0Hg8Jx9OQqWadH1skZljVHTpxiz9PPcNOtL6WoYe/TR+j0ttPubceFDoVLuO/hxymdJu3kPLHvad75rvdx8Php1kYVn/3Cvdxw84t503e9idVhwV+99/287Zd+i0Mn1ii9ovQBqxJKn7O8blnuVxReGESi9xP1pbw8y5ox+PDhw4QQyLI8tk8dQ8NFDD8E0Wlsym9cls3WNJdm8SU2hizP6c3MSrY1G0PwnMeFIK8+xBrXDQEN5z11FJC33svm5JqbulNRdzIAdcziVlpHUVuGVcWoqglKk2R5PEcgSzMWFhak3cQ2LwDl5NmgkXZmYlskBELDbm3KYBzyF3A2UJYWa2OGQeex1mNryXrafN60Tdu0r07bBJU2bdO+Buxbv/4GfvS7Xs9rX3odV+ye54Ithst3dXjjN9zED3/XN3Pp+TvROMnYFALOKwajihAdXVePOHXiCE8++Tif/MxdfOiTd/P04VOYvEfQKZITJsb664AOjlaWyUpcpMCPAaQGYEKNNZWav6OUhMMp0QAgruSOp9hKssyNgxyUzHRUo3URJ2reyzTNeQjacOjocQ4dPkZZWhHo9YGyLKnqGu+dhAfhKKoRdaSiV3XFxvoGq2urDPrCTBLKumU4GLKxsTEW2BwVBUtLi7zk1lu58YYb6PVmyPOMuchKmpmdZXZ2htmZGWZmevR6PXrdLp1Ol05bgKdWu02r3aLVbmGUIU/b6KSFb3c5ReD9997D5595ipP1gFe/7rUoBbO9WXZechWHbQ/X28U1V7+ArrJkOAgKRwK6BUrKW4po8to4eWriRzb/TPlwE0rK4sISc7NbOHTo8BhUMIk4rd4L2NFMlOva8sADD7C+vsFwOGTPnj0kxtDrdQneY4ymrivuvfdeHn74IZ534QXs3LGdW19yI5LsxnP02Ak+9tFPcerEChec9zwWF5d4/mWXUFZ9tHETp2pqE89o4jeFOPn2CpzWsimN1xCURauSJIgQd25PcfLBT3PwrvejTzzGPCvkumSkUg6UbT5/JPDZ/TX7B3OcrHqo9hxzWxYphhuUg1WOHTlAnqcCkCiNSXPaMwtkvXl82kbnHZJ2RwSioyPim0xZIWC0gHQuAoENQ4TIxAhEB0/FbGwxBXyjn9EIoisiG8R78iyXEItaAKUQz2OtHfcvYTxFseXotI6BnyAr6VmWExqgoUnPHi9mDBbE34Wxvo587aezE53pT090vSIA1Wu3mO21CV7E/0MMXQ1KY33gyNFj2CgCnAaNshLugzEkrZTeTJud2xaY77VIgiexCm0VtipRQZGlOT4EklRjjGM0Wsf5GuehtIZ7nj7An37846y0O6xgqI0wLfEO50tcsFjnQaVUaZe9gz7v/NyncbvP4aIXv4YXfcsPsPPqW7HdWUlD7mvCaI1jT9/Ps5//exbDSUy5gg2a06rLE2oLn1xP2Wt2st5eokhTgnLkzjPbH/CGm1/MVTu2Uy2f4o6/+hM6w6N0i2VUXZGEgNaWJJPxbNe5l7LjoqsYJj1MaxblNMpa0mTcmb+8hegQNjUTK286LOwrmlTe+MMZ40h8bepbanrSAJo20rR3PcW2+/+/NVchr81VSfsSNoUAB1YYPSEK+quA0ZBnhlaW0M4T2pkhTyW7aJamY+2zM/rC/wub/sl0X/qfmYpOfuP0J4kmTQ1pltDKEzqtjG4rp9tukecZeZaRxuylscrHDOEQYjSdQj5H0DlElhiR6VSOhgz664wGG1xyycVsmV8QLcWY8MLFpA7C1hIGzb6nn2HLlg633/4SgrO8/Rd+iYXFJd7wxm/j9Mpxduzezup6n8GoYsviIjrTeKU5cfo0pa05+7xzWF0fsrpWkqSz/M7v/hf++E/+mvf9/Uf54sNPsPOc88k6LR589AmC6bG060L+/N1/x4//5M/wnd/9PfzpX/w5+dwsn733Yd7795/gvX/7caxOqLWi9IZP3/Uw3/FdP8If//m70HmOC8JOEoBRtiQRLUFjDAcOPAsK0izl5MmTwmpLUpIkHfclEJauhH43mdUEdJPHaWR2ek9Qinanw+zsLD54au+w3lHZmrKuKMqaYhxGVlNWNWUtOkiDomRUVpRlTVk7Suupo0h28/xohuIQWXkCKImuUu09o6rGhkDWkoyqeZYxP7+FLEvJ04TMaBKtSLS0M2l38pppTcsk5Eay94kG3qSPCaDWiMXLQp5rNO0cYxDKR+BJ2tqmbdqmfTXaJqi0aZv2NWAXnDWPcSPKQZ+Tx09yenmZ1ZWTjDZO0E0GvOGbbuWmy89ihg0St871L7ics845izoYhiHjnX/zEf74r/6Oj9z5BfY8e5J+qfE6x6vk/2HvP+Msua7zXvi/Q1Wd0GlCTw7AICcSJDJBMBMSc5ZEUVSgbFOSLdm6kq4VLIu6liUrWcGirJxIUcwKzGACE0gABIgMDGYwA0wOnbtPqKod3g9r1+kekH59f7/3y0uzF1BTp+vUqbRD7fXsZz1LnAEC2tcUyrNt4zi33HANKlSYlFlLjzK9ScpZrVLI2xqwaXURYEmlLGMjRlJaGrdDXGeDIoXRJfCpAUgiiqjEefcBjp04xamzMwyHNbUPIhBZlwQCUUVMbnCupqpKvPcsLy+zuLRIXdUj8cyyHDIYDKjqSrK61I6iKHjOc57Dc597C7t37x6JW4+PTzA2Nkan02Z8TICkbgKS2g1zqSgoWgV5XpBn4qC0bE4rb4HNcZ0O95w6zjs/8D58VpDV8JbvejU//cP/ihfc+FwefPQQB84skU1uph72efDzH+Wp2z+APXIn7aWnaKuARrJvcc7TS6Efoxoi2xtHaxVQks+iuyOO3/T0NHmRc+TIEQGPqhpjpNwa5yPGQJZlbNy4kd/7vd/jfe9/L73eiuiQRNF5OHP6FHfdfSfLy0s8+9nP4sorr2Dbtq0oBf1BjwcffIAvf+kLdDotbrrxBm79rpdyySUXEYJD6VU9l/+dNfeookpLROPJYo2tl+m6edr1GcKJB3jiix/izINfIF8+g60qfGwz66e49zTcfrjPw0s5Z1yHxcoyvkGEVAe9JaKvsJlmw/S0AA4xkGko8gzbGsN2xtGtDqY9hmm18UoRVIpNIIlsRxElLstS9IxSaI+ELTTOwWromFKSFU2evYBLMYWYeR8w1hCB/qCPsWYE/oljIaF1DXDU/C41nNGDizHNdKvVMD05j1SZqMBHD1rjYxCGgxIh/sq7ETNJnKnkZLAKKmgtHsooDE9ritywcWoi9RuREIU1EHxAYdj/2AGImroOoKxoIKEl1Mtm1Dajrwyu1UZ3O9K28RRGk2ciyJ+h6aCYBApX0y5ylmLk4fkF/vLTt3FGKXq1JwugqopY1ZT9Ab3ZJdQwUESLCQqtc+os59DSEp+4/wGKvRcyvucCso0bUS2NMZKVsXfmEE/c+UnGBmdw/XkGynCWSR7T2/jssMM9TDJvu0RXQz0gdyUTvRXe9qIX86w9e8h8YP+jj/PYg49x5vgMzmt6UeEChNqLLp5z5K6imwWsqXHRgc2kjHxiKj3NdKpLIWVYI9UFMdFaWtNJfLOl+iJ99irjqCnj2OyDMGtGh1oLYicRdhJjaLTxm5b/30yOIA790y34IKLBtWTL8jFlzFJSR43R5JmlXRR02i3GOm3G2i3aRUGRFxKm2jyDb3H8/71984++ecu3sgiNbpxRZJmlVWR02wVj3Q5j3Q7dbpt2p3m/5ORZLunf0zMfHUk1iNJq5x8T8zcET0hahEYrzpw6CTGyY/sOumNd0RtKYU6iQRSpa0dZVfQGA/Y//jhXXrGP7dPj/PBbv5/+4gr/+Zd+kfm541hbsn3rRpYWl6ldxcTEGNFr6lLz1OHjKDT7LtjL0uIivd4Kwdd8/nO38Xd/+zf87u/+IcdPzjC9dSs+KI4cPQ26wz/+y2f5zV9/Jz/yoz/B//0LP093bIL+0DG72CNvT/L5L3wVjyEqS+Ujf/jOP2FmbpnKa4Z1EtIOAsw0oZd1JQL/WmuOHTsGETrtzkhfqdsZS/qQMhkgAMoaIXRX45w8o4a9E5EXrLWWDVNT8syJRIWASnVNfzhkud+nNxiwPBiyMixZHlYsD0pW+kPRRxoOR4yj0rmUVc4Tvbz3dOPqJYDeeQGe6hAFEGwm+pSh2x1jbHyczFoyncAkIyw9nZJeGC0Mpdxo2pmhk2d0ioJWln6jtIRfpvlEYc7JMRQRRUDrKBqIShhwWsW0jKrfuq3bun2b2TqotG7r9h1gK4MBDx94kvf886f5+499ib/68Gf58v0HOLW4zLDqszJ7nBffcCVvec2LedOrX8xlF+0khpqFlQGfv/N+zgw0cWwbqrMVVWwA3QGdC1U6giFiYk0nUzzn2qu57KLzuO5ZV0KosbpJKd2ARo1Yd9rWAE6J4UITcsWaz+egHGs/NFnm5PckFhJI1pWQUi1rnaG05ckjRzh2/Dj9fj+FZAVqX1PXJc478iIn+MDS8hJlWRJjpHY1ZVnSbzSThiV1XaONYfeePdx8883s3btHwKOJcUnV2+3S7XZG2kmd9LndkZC3dqug1copWjl5npFlliyz2MwSjMIUBbEoeGp+lt/5y78AU3DJ9vN5w00v5YrJ7WS9krbSXHzJJcxUNWfKwPSFVzK97wp6/QF3fuafOXPw6+RxmSwMMGkwmB6pPMK1s6UpbGoVdEo7JAuJmaKVwnnP9m3bGR8f5/jxYymlfRMqsuogRiIXXngRv/CLv8C//tf/mmc840p6K8ucOHkCYzU7d+3g0ksu4frrr2Xv3j3keY73niefPMZXvvw1jhw9yvbtW7niiouZmGpT1X20EWFp3TDcvsmSY5ScIwEeFQaFjYyWPARyX9J2fdzZpzjy1dvY/4V/Ip54kEmWiMMVQiw4Nme58/E+D5+CM/UYs7XGZzndiQmWlpYki05ZUjpHMDlLAwdZjjFaNFc0aJthizZ5p4ttt9FZRgDKqiIqRV1XwhxIWibW2BGghFJ4J+CZzPh+s4PdzOyqhsm0xi8MIWCNhKN650fhGVqvsqRcAhyacM+QhJrlGuS4IQYR6k5Z5bTWSdxarqa5MmAUAiP/y7cCTqy97qQp0gjRJmFwY4T9sWFqHFdLyGTze6U0WdHijq9+DaUMxmQ4rcmKAqMM0QEqYxgsJxb7+LEJlqPHZeCVOHU+BHKb0zYZbRfZrC3/8Sd+nPGxLodmzvCnH/sIK62CfkR01byjE8EvrlDOLWNKGMyt4JaHtKImR3SwBrrggbOLvP9rX6fXGaOPIRhDHYb05o/z+L13UPghQVsGqsVZNcah1hY+u9jioWoji8VmBjGgtWcczcTQ8daXvohn7NtFYaHyjvbkJPuuuo4HDp1hodSIwo8iRoXymswHFk4cRg/mySipqRkSqFCJqfjN1oQiShmn8mk6h8a+pZOX6mHTLzeMCL2WpbC6p/zTHGj1gM0+DUMpETzOWTef/9fW7PC/2bE5FqktjXYV4MAlNl9di+hw7VIGrQQwxeDRKpJbQ5ELeFOkiQBrRCdQALlU67/lc/t/Z2uBvf9vtvpaTHo7VpNlljxfXawR514rjTEGm1lh1WSZiC6nc8gp0wETSymMmEqeYSnaY+VwyJnTp8isYceOHcJQTSyvhjEJogkHCucC119/A8977rNx5SIvu/WF/Mov/hLTG6Z48P47yW3F1GSbbrvF5g1THNz/OB9630f5xt2P8oF/+Ce2bJrmogvOZ9Bf4czp47zudS/jH//p7/mH9/wVP/4TP0av12fb9k1451hYXKTT7fLJT32Gjdv20h2foHJDQnSsrAw4ceIUl19xGWdnzvDlL91Bv1/xq7/6a5w4fpwQPbt27aaqJdxMwt6EsRaiZCZzXpJ1LC8uQ4RW0RYdo6qm0+mMgH1S/xZHwJKTJCF1jXc+aViJrpnNMrZMTwvwn7TtmvZYJd3GlV6PlcGA3mBIbyBAUvO5NxjSH5YjQKmqPbWX8LImBE6hkk5W6psVxDSh5yMC8yTAKctzcmtGIZTEQAye4J3oIxKxWpNZQ24t7Tyj22rRbRW0sozMSkio1XqkSWaNEQZdpsmMwtqmrmqyTJFlCpuW/y2rct3Wbd3+/9bWQaV1W7fvAPv0HQ/xz5+7kxNLnkVfsOgLvnL/4/zzJ75Ab+Bw5RDfW2DjeM7mzVMEpTh07AQf/cwXePjQMVRnAy4bo1QtPBlgk1MfUfiUgjuyccMkG8ZzcjXgmmdcwpWXXECo6sRGEiZRVMIgGml5rAGSxCEWB7IJh1sdOTfe8uqgQ6Cnhs0k3ZlOAsF1VWGMwqTU4+KAaY4eP8H8wpKwlWpHVUn2ttikYk6sJGsNdV0zGAxHs7AxQlXXjI9PcPPNN3PNNdcwNTXFxPgE7VabdltApLFuV5hK4+OMjY0nIKlFqyiEnVQU5HlOnmUivJlZskzo86bVotYZXuecPjPPjdfdwCteeivPvvRy2l5RLQx58vBJzi4PeHJ+kTN0WAwZ/WwjV7zwjVx5861kBUy0KgqWaRswOkh6pNFzSw6YUvRrx+nZBVb6VcpaAxAIpLTbaSZfa4UnYDKDj5FNmzbjfeTIU0dS6FtAKSNaWtqiEOCiyAuMMZw+fYZ3//3f841vfIPHHz+AVoYL9l3Ali1biDFSDofs37+fT992G3NzM1z9zKu44YZrmZoaI880SsnglggGI5n71gBHRL060z5it5G8SXHBDR5LTcuv0KpmGR59kCe++inKo4+wMa4wTklQGaWd4OCs5xsnSg4t5cyUXQaxgy06+ODoD5cZ1n16/RWCgjpovGrx1IkZ8qJLZgt00ptSSq5TmQxlMrTJUNoQFQyrYdL/agSwtTgkSTy7AYAUwkqS5iFZuXQKEV11ZMRcXaNQVJUwixrAdrUchRWU5zkq6WHFGMmLHBqHJol0NyCT1nqUBUknnZ2GfSQaWrKP7C+OTJ7nIy0fpSTcRoBLcZVjcrwaEFIcKkWW5Yx12vhygHfC4FI6wZ3asNAvOT03T6vTQZkcFyPBKMhz+iHn5LJj/+k56laHYQxUrhJRc2UxGOHtlX2qMyf5qTd/L1ddcCH92vOXH/kIjy4s0rcWr4QBpEqPWxpQLfXRdUR7RRjW9OaXCIMSVddkKTFA32Y8NDfDFw48Tj0xwUqEoCP7H72fsj+PsYYFCmaLaU50d/G1QYv76i4L+SZqCgiOerCCmp3jB17wIp572UV0jWR7MlnBxq072HHpsznetxxf8MRoIUKmLThPGA5gsIhbPoNxK2Q6YGyGzgqUzUQjSEFESx+cSkHCpxp6Z6pHDSj7TUBzstU4qQQoPg38+BZ/xjUhldL1SE1ovqMBvpHraOqL7N4c8GkHbux/sfn/ncl9+iCMuNp5CSUqU5hRJY56VXuca0LB5N2jjRIBb81Ie6l5puc+NXlTKUTYW9gjoGMS+k5Y8Ll7n1skzT5rF3nnyaSKUU2WOtFWUum+GmZKRNqR7GPItPBXFHKSUTk354kSxk4MormkrLSj6Jk/e4baOTZv2cqwqglRUdfCUAohMhymcNKqxljLW97y/dx4w3V4P2R8rOCCC3Yz6C3yfd/zev74j36PTmHR1PyHn/rXtAv4wz/4Q37hP/48Tz11iJ/6qZ9g49Q487OnGazMcdkl5zHeydiyZRJf98htZOfOaQbDiuFggHMDfvZnfoqpiS4f/9jHiViC0szP9zhx/CSvfc2rOf/8vbz7Pe/nve//Zz728du49daXEGPNxg0bKIfVaDIqJqDFB0Rw2tecPnOKubkZjM7YMr0Fay2Vq2h3O2ibwgrTZFvz+xAkxNOn7HghaQ1l1rJ54wZya8mtAIB5ZtPrS8DOyknI27CsGVaOQSWhcP3KMag9Ze2pXKBygdrHxK5KgGCDyjYAId88USf1w+OcJxDxoemzFZVzVGvEvxvA0ChFZhSF1bSthIO2MkNuJTuibhYl4y+jNbnR5EaRGbBGCaBkNcZoTJbWRmPsulu6buv27WrrrXfd1u07wO47PKDOtxCzDsZApiKTYxvYs/tivGvjnaUsK/YfeIL3/tOneN/HvsAn7niA2VoTshal9yhjJEuUIumLeIIOoEqCUdQ6Y6WqcNUCmZ/F909z47Ov4qLzLwKlqIMnKlAmObrGjDK4CVtJgCatM5lZVwbhQIkOkwh+J/FuhNItM3qiB6GUQhtDaNgWWhG8QyfBVYEVNHVQHHzqKDMLywwqT4ga7wLRRUkvHiQsbnFxMYFlEhoxrIbYPOOaa6/jpufczMZNm2m1WmzYsIGxsTEmJieZmJgQHaVuh263m3ST2nTbSTup1aaVtyiygsIWWJNJ6I6yZCYT8WWVUamCz33ua/zF7/0Zb7zlRdzzpc9w6Njj9AvF8dLxT1/8Op+8/wAzY9t4dKXLmbkhy2XB/3z/F2ntuJzxLdMcPvwQw+VT5GYsDdYiOoFshoiKIup54OhJfueP/pR/+dinIVqUD/jocUS8eBdoFYnR46Ojio6gIgHYtWs3ShtOnjyJtRbnHFrbxBZjBC5pbVlcWCbPWhw7epy68sI2QkLSjh89xv7H9vPUk0/ykpfewitfdSvbt28mRjcCHyRyTlJ4B+/QRkLIIglQEmWRUTroSATlQTmC8ngcMQzQahm3+DjH7vowR+/4AMX8E3SrOTJXUtPiaL2ZO08qvn42cqhqMxNb+LyLVhlxWNFbWmJm/iyLKwuUwx7Ly0vMLKxwz32PsbhUooMmBIWLlmBb+FiKoxczyTCmDVVdEQkCXPqaGFfDI5q6PHIyYyR6T2Yt0Yt+ik7bvfMS+jbSOCKBteKYOidC9E17UErhvGSNa0SJq6oCoCormc1uAKXkzWojrCSFtNEQwmr2LiVZ4ZoMXQkJGDnpNJmgYiSzGS6JhzeZhEy6DqkLGqNztLFsmBrHhiHaO2nzMWJ0JBhLa9MW9h85irYa4zVV9CzGklk8B5cqvnZ0hoMrFStaslXRr1AlUBnaqqCba87fNs5/fPubuW7vTsregHd99FM8vDjATUzjs0wAEKewpaW/UIG3In4bhTkVasfC7AJVz2N8pKUiRtWsaMfnDzzCu77wWZYUPPDoIxw7c5KhjiwoWGpNcbSzk6+Vk3yjmmC5NUmlINQltqqJiyt8/wufx3P27SSv+9hosCEj0wXtsUk27LqIHRdfy9cfO0HPZWgPoRxgqGibSBYqFs48xbipaJV9stIRnWdYD4mhRgI/DVFneCJKi8Mp6cpTPWogi6ikz2wApLSsppqX+tT4raTPUgmb+juCfFcXJeBGkxEujpzf5rgyMdAAjqLrpBLE0rSKBNokQIYEvsTwLQAuZJ8GeNEoVEigTRTAk6QHNCxLer0Bg37N4uKAmbkVZuZ6zC30WFgZsrAyYGllyEqvpNcf0h/2GZR9qmpIcBUEh/IeHSJG3lBJSN8Iq0lpTFSYoGQdFToqdAKa5A4VNspvUZqYsnYRJfzIKoVNYtwRg1IZWudYlWHQqKDAQz109HslK/2KXukpXY0LoqNmdUpLbwyZ0lg0NmVojVEAJRMDJt2PDwavW4QQMb5i5exJiqLDhuntDOpI7RHBZQfOgcdSeShdYKXfozfosdQr8crglENlNaVbYfP0JnZs24lVCl8tcuG+jbzrXX/Au979J/zJX/4Wf//eP+b5L7yW6Gu0K3nzG17JRXu348saE+HooUeJ1QJbpzewtDRkdn6O591yPS9/yXP5ybd/Lw/dex//8J6P4m2HJ4+cJjjFpqmN3HjTTTy8/zDv/eBH+c+/+hsS/jgcsHnTBmFm+cTsCYHgIXhF8BHwzC+c5cCBAxANxuZYq/HBkbUyXGJWkt5XOmo0KdvtqC4qCMICmhwfI9caQyDXUFgwOBSiSadNk9DEyCSYD5Q+yhICw/R3FRSlC5SJpVQlUe9AxOOpfSUheSATLpFV9lHwEmIcHc7XuCAi4SuDkqXBkIX+kPkUdjdM7ycTA22tGM8Mk+2cyW7BWDuj1bJoE6n9EHQgBAfBY2IkI5IDKgSyxHSKxDT+M4SIgFf1uqbSuq3bt6utg0rrtm7fAaZ0IDOOQg2x1Rwb8iFvfPktPOe6K2l3CnpB88SZFW6/62FOnlliZrGmpotXY2jToVCW3Dts1YfhMi3tybSSAZPOiBGsNrjKY1WLTHeJLqJCyctefD3L82dQ0aHSzKcyibmgUxjTKAROWBnNTFrjfEjYXBqWJfZSE14g7saIezNiRTWO+Wi2TqkkzB1ZXlriiUOHWFxapt/rAwrnPFXlGAwGAjJFGAxKYoiUVcX55+/jBS94ARdccAFTU1N0OwIcdbtdOt1uyurWoTsm27rpbxHiFkCp3WpTtFaZStZYrLES0qU1SlmC6vCxT36G//4Hv8dbfuj72bp9C695w/dw2xfvwLU6fP2xR5jpzfHlex7mwQPLzJ/q8epbns933XQdN13/LD7wqU9x1hVkG8+nM7GNoIbJIWxB7EDoEMnQ1lAUGZ0i59577uG6m27EWcOCKyjVFGXoMKg1IaRZ6xAxXmE9ZL7ExooYIzt2bKfX63P27NkR+8CYpM+DPHfnaq644nKuuPJKXvjCF3LJJRdTVkP6/ZVRuWqteM5NN3LF5VfQKgrZlhy+hsmw1iIQVRDtHTw2OmysyY24ztHXRBdQQeHrCuNW6JYnKQ/eyWOf/SDzj99LPlyA4OmFjDnGObxsue+JRY7MBuYGFqfbdCY2MixrVlZWWFnq01upcJVm2PesLC8zNzvHfffez+OPH6TfLzFZDsoQUbgQsNpioqdlPYWJZMqTZ2Z0O1lWEJXCWEPlyhFTDkTzhlS3RUNKZq+VFifFZlZAosReathMIqydY4yhLEthQSVwxjsBe0Yg1FpHPl1UGIUzCuNBJ82sEfshhuTsJ2HuhoWSmFOqSVsfpS40YR0kAEGlTHUhBIy1o/OKI6WYnBhnw+QEdTUc6XfE4CEEjLY89dQx6hCIxrHsHZ9/4GH++CMf51f//l28/2tf5nTVpw4RG6DQGhs8JjpWQh9l4Yff8laeefnVLGrLX37yk3zx0UcImSXXoLzDAKp0LM/M4wZ9lK/oZopWXZFXDutB6YzZpWV6vZJQRVQNeKh84ODxY3zya1/lzgOPs5xlzNgWJ9obOV5s59F6ggcWIsvFGJCjvSV3hjC7wvddfzM3XHolRgurSifWSJbn2DxncvNmdl10MWd6Q+YqT7CamBlCZsFqcjNkePpR7OxD7DYnmQ7HmQqn6MYlMq0wKjHFUnilsGbE0Y0xopVZBYa+hTVldy4Q1LTNNT9MB2lAo9Hm1T2+NfiDdOgCNCp88KneplDMBlZKP23OOno3NAd4mv0vzjSqx801xhgp64qlXo+FpSXm5heYnZtndm6BublF5ueXWFhcZnFphaWVHis90boZlNUoW9do4qSZPGlCu5uJFKvRthH2boC2pP/3La9+1RQNszdtiEEYaASUbkIZIUZP7SrKcki/32dlZYW6KvG1iN9bo8kzCeMTlqyRcKQkyKxT3yPvYjll9A6lYGlxkWFZMjk1xcaNm0ZZ0UR8Oa1DYDgcjkBtgIWFZQ4ceIK77vw6Tz11jDxr451KuoiWGDR1HcmLFhs3TbB7zw66YwUx1tS+5OLLLuRfv/1tTE6N4fyQlcEiP/mTb+ddf/tn7Ny+kf7KLLt2bOTFL7yRhbmT3HLzdVzz7Mt599/9GSeOPcGjD99Fu+XYuCHnlpufRX/5LDff+Cy+68XPZ3l+hlxHNox1yBKT0z9taYD2hYVF5ufnUCa5TykxiNHSxzkvCRGsFTBRFjtirmZGo41iy+Zp2q02RDBKkVvJEllkliKTsLLVJaed5xRWRLMNESX0J/Cgwmpb1lHCvYXspFBRo0mhmSFKnUmfYwgjhnZVVQyHJf3hkJVBycpgyEpfwNNev2RYeepa9KFIOotZliWxeos1qxkGYwrlDkFOGSL4qAiJGyeThxajRfzc147gPK6uGfR7qXKv27qt27ebmXe84x3vePrGdVu3dfs/y/74Xe+DeoULdm/hBTc9i+de/0w6hYgBn55d4PN3fJ27HnqMnpNsKJ4cFy1RGRFixqFdn7EscukFe9B+yOLigsTPI2LBOjhMVfKsSy6hqjyPPv4E3YlxIhVXX30tR44cSRopaYa6CW9DvI9zBtNpcCyD6GZb2j3KtnP3X7NKv9VpgzhCMuCLIUioQhr8LczNMT4xDihslgGKsqxZ6fVx3tPv99m0eTPPetaz2LdvH51OhzzPGR8bo9Vu0W63RSspfW63WrQ7HVqtlgBHRb4KIGWiY5E1mhZJQ8ZYI8CSFYDu0JHT/Op//Q1e9vKX84bXv44HH7iPMwvzLFWOg0ePs7Qy4PYvfJ43v/ENFMpz6b5dvPbmm1HDim27z+Ov3/d+9uy6gKue9Xw6U3txusCnZyEzoAL0KG2JwNhYhzd+z/eibZu/+fsP8id/9mf84z99gqqM7Nt7PoXxiMyBJpJByvQXYwQtej1bpqeZnZ2lHJZMTk6KnkZy1IwRACTEyPZt25ie3sxXv3YHjz7yCPsf38/k5CR79+5hy5YtdLodnK8hZShryu/psx9N2es0eBaPUwTXVfLEtRHtLucjLV1Sn36Uo3f8M2ceu5N2OUfhBxgUPdXh2IrioRM9Hp9xzAza9FUH2pPUOqdf1pTlgH6vR13V9AYlg6FjMCx56qlDHHziGHXM6ExNSzZEk6GMESaOhuBr/HCRq6+4kNe/5uUsz89w843X08qtgHVrmERyb1LRRe8kMYFILLyQhLuTDpHUdfldSEwhrYUBGBGnPxJxtbCT5LkkZzaBA1oLICUhZgIgRUS7ai14EBOYRGIvNd+v3c8oTQgxOQ2pZBJrzTmHMbaBAaQQG5Cp0ffRGudq+oMBp87M8sSRkxSdcVAGrTSV86jo6eaGFz33RiKOz9z9df70w//CSSwzxhDGugRriUqjopa66Eo6seTl11/DxswyMT5Jz+T85cc+xRf2S7hayDJJGa+AytOfX0Z5RqLubV+R9wcYF1Amo9KagMaXNRmalsnIjMUoYdL1ektoPLWrGWgrLCXX5ZHFwKC7hZ7KUcrQDpAtLfG6G27kFddfi4lQu5pceYyyoo1CxIVKfMFhj5kjB9jSVWwZz5LYuTwfrSJuuMzcsUOsHHuC4dmjWLdCUeTU2eSI0aeUQuuIilHChxt9JqRv+CYURkl9UWt1u9L2NatUpsKWiwlw5FsAP6kGjNbn9Pfp7xglxDOk0CydRN+lbaS2kqrRSBuq0XRK55LV6sWOrkAuSJir3nPy9GnKWgAR5yOV81RNmvaU1t0FYX/45CSHyCh9u/cSIhVQRKWlDabEFKP7TmBZfzhkeXmZsqwwmSUrcowVfaMQI66uqPo9hoP+KNxIa0VRtOiMSaIHk0lo6aDXp6pKiswyNTnB5MQYrXYhoL5qYDtZmybcHBFHbpqgUgIgGb363pQJjhRGl+L7sixH1QN8f4kH772b7vgUr3r9G7B5QVWJ/mAIouVT1Y6IQhnLgQMHueOOO1AYYlTkWc7c7BztTpe5mVmMtjx+4CA7duwiRRaiMwk9b7QS+/0+nXaLsipH2eWE8Rjpdjs4X1LkLb7r1peybcsWQqioypLrr72GZz/7ajZtGAc8l12yjwsv2EO3m/P8593MC593C4bIP37og8ycPsmP/PAPYCTdwAhslEUJU9dVfP3uu7jtU5/i4osvZ2rDRpZ6PZQ1XHCRMLKV0sI61jolKGnqpSSoCCGwadNGup0uWimyzBCDx2hFZg1aRRlXKSXgn5WwsswY2W40KukghqSdRJB2nGktwJS1tDJLuxAgymjJnFnWNYNhybCuhckUUphfytwafbrnFEInIXuiuydhzQEVITOGVqtFt50z3i7I80z0AVPo6LCsqGpHfyATWjFp5oFCa0u700Gl9uBrB0HAXVeW9HsrXPvMK5qWum7rtm7fRvb0sfq6rdu6/R9o7bjMy15wPa992YvYvWML2hr6leMbDz/OBz/6KQ6fnMXZLj7rELOcaIz4HwRiqMGXbNs0yZte93Je8JyrecOrX8hb3/gydm/soOsexg/pWMiQtLBRt7jngf08evBJVvp9cqt4/s03Ug/7BOck3EUb0FbC2tK6mdkV5CdpJSXtGBkQJ0daNqS/5R5VYnQoJIa/2V/0BWT21FiZiY+AMZbaB06cOD3SLKhdYFBW1M7THwwIIXLhhReyefNm8jwXXaRWTpZntBqNpFZBq9WmKFq0Wi3a7Vb6O2V1KySNc5ZZMrvKTDLWCNhkMxEFNgajNReffx5ve+sP8ulPfIqDj+7nqkuu4J1/8E4Gw5Iv3XkXB546gnfwzEsv4l+96VW89vk3Yx04l/Plrz3M3fcd5m/e+xmGaprabKRM2i4oh9IlmIqgwUWFQtPOLNObNvF373k/v/8//4qLL7uc7Tv28Fu/+ft8+IP/QqZzYsLyglIELIGMgIAJKok+79i5g6WlJc6enUnFtSYkSkldspkBFSWLT/R4V3PkyJP44KhdRV2VEn4QI87LLLdkKRq5g6RaCVFhgugoBQVeg9eR0tUMXU0J9LRmUSseeeTr3H/7P8KpB5ksz2KqPugWS6HNgRnP14/0OLCUc7RfMMgmsBPTLJWB3rBicWmRhcV5htWApZUlBuWQs3Nz3P/gwxw7MYPDkrXHyFsdnFAz8HWJwRGrPtQ9fvxH38Iv/exP8OJbruM//sxP0bKa3JiR2LUyyWHWST9ISehabBgUDYiX2kEzex6jsJOISZMoDdRDkNTeSimpe3k2+lucMRgMBvIsQxAgKYE/DUupYRmsTaVttIQshBCo61qKNs1MN4BDSOFxNCFHxhBDAz4lbRclgJK1Eio5us+Uunt8rMO+vTuxymOIBOfEIVGa2gVOnp7l5Nl5Fld6HDhygtK0GNo2vtWmHzzBGrTNCWgh6fmS/txpTFmR2xYDZfiXr36Nj95zD732GAOdUbqAjpEwqBku9IlVELHa6MirAe2VRabrEjs/R9fXFApsUGTR0p/v4XoVYejxVQST0QuwiGUlH2NGj3HMTXDfQsViayN93cXqroi59xZ46VWX87qbbqSl4PEjT/GxL3yBEkXpatCKYVWSFwVZ3qY9toGxjdtYHITUDnMCOZGMLHjG/QpTgxO0zz5MOHwnp+7+OEe/cTu5TgkViMTgUSMCp2QLjFEc4gYMPseevulpf8dmSdt9yswYggAaDU4V1/CTnn7Ipm9fe6CmXjSfddLWasJrm75cJzAphDWA1+gw33ymxrRuAKDEJtFJb0pphAOpCEoTtQGTEbUVbSFl8RhcIou4qAhRExJoF6KEDYoeTwpFipLVCwVRCVA4eq998+tsBOI1oFTiDaVtsk+TTZMULqWSuLK1GptZstySFzmtVi7vG2tp5RntImesXTDWaTHeaTHWLui2CzqtjHYrl6yV1o7CWp2rGQ76DPs9lpcWWVxcZGx8khARXcLaSRp7JwBcRFHXjsWFRd73vvfxyCOPsHHjJtrtDgsLS5w5M8PM2VkOHDjEiROnOHNmlrvuvofhsMS5yFe+/FWCh97KgLrynDp1luGwhmhQyhKjZTCoR4BKkQnjZzgYphBpja89RV5w4b59aGW45lnP4JWvuJVuJ0Pj2Xf+bjILCscPvvXN/Mp//iUyo3Cuwvs1LCWftJBqyah22223gdJc/cxnEkJgMBhgbSagZ2JeaiP6VqItJGVSZAIKTU1OMDE+Lq0hirbScDhAIQyyzBpaRtOympY1tDNDO7e0rKGwInSdaU2mhfVUWGE3tXIjZZvnkoXNWnTqU51ziaEk5xstsemrE3Np1JJX6+Co5qXJHa1JYJecW1hKRgDI2Ai7h6QllfSd0rrRsSzLisGgYtAfMhyUVGXFsN+n3+sx7PdH51+3dVu3by9bZyqt27p9B1ioB0xvnKSqSxZXSh547DCfv+Mb7D9yipCPofIukUwG0spjdCTWA6r+IpdcsJfMBpYWZtgw1WFyPEPFHhOF5fIL93HZxfvYvWM77UzRX5zlvL078VmLQ6dnOfDUUbLcMtkdZ3x8nO3bd3Lk+EmC0oSokkZSssaBaLyQ9I24qs1eoyF3+qb5d/Ur3cyqJ0ckxojJMiBloUtOu7CmYDAYEmOk3W6DAh8jw2FJOSzp9/u0W22279hJJzGQut0uY2OildTpdBjrNtnd2rQ7bRHezgtx5m1GluXkmYBGtgGPrDjoxhhJWZ2YHVopdAxcceUzKGyLd/zyO9gxvZWf+pmf5sHH9zO+aRP9XsXyqQW+7xXfTcv3wbf5+Ce+wof++XP8t9/6A5579VVctmcn111/LS43eDNEa5+4CIqoDEG48RADGoPJOvzjxz/Nwwef4Pf++2/zipe/gqcOHeXok4d55Xe9GGOC6Chpmd1XyZGT6DRhBmit2Tw9zdzcLFppikIEuoW1Io6Q9wJsbNu2NT2/NldddZWAHUoYDiExHLRS1M4lRyoV+5ohrwx15V6CkgWlCNrgbUEvy7jv5Cn+/GMf4cxDX+JiO88WPwtBUeopjixb7j/e45F5zam6y4oew3QmqYksLC8zqEpW+ivUZR9XlwyHfRaXlzhy4gRHThyn9BGbj6PyLq2xjaisjcnaEu6gPP3FGZ5x2fn80s/9B6575kXkqkT5isIaMmtRqTwahkJUUVK/y40k/TKFS5pFIWlkWJvhk4ZSbJzoVOcFxNE4L5neUMIUakTABcRKzzfNoDdhcQ37o2EpmcRgao7RsJRMYlDpBNwGLywro1dD+rQRYW/Sfs3xgxdglxEDoNHNkdlxYy3g8b5maWmFxw4+STAFPoVNoDTBeaphn2uvfgZjrZxvHHiSg2fnCZ0xyA0xgIoalJXzUtOqVvjhl76AZ2zbQx3g43d/nb/59GdRG7Yy1AaHPDdbOgazK8Qyktkc7x2tWDPuhvzE61/DM3fuYPbUKWYXFzCdNkrlKC+hoeVgKAwPhAGEDwLYKMOSsxyaKRkUHWqVEz20lcb053nJ5efzvc9/DuNa8ejZM/z5hz7Eph1beOYlF2JiRFsrYu8xUFeeemWZmScPwsJJLtzSSmLKoENERU9uPNQD2gq092gDsbOBzt5rRStGWwJgjJJsTsok9mfDbpF6+XRrQMM1Pqf0vUo+rTUJ2zx3q1obJkkcdfey69PAknRY6d/TWuvRlqZ/by5mhLeOTrb6oTk+a+8qvWO0sfgQOXnmLLUXp7d2ntKFFIaqUFq0BLWy6X0lTNsQBdwO8VzHeQTOqfR8YtNFinPfH/RZWlyiPxxis4w8MZXQkvHL1xVlr8dwOBgxlZRSFEUxYirZLKd2jv7KMnU9JM8zNmyYZHJinE6nRVHkaG1G7zp59kHSwGcS8pbnObkVYe8shWhZYzCpEIJidF/RB3KbUa3Mszx3hvvv/Tqvef2b2HvBhWR5gasb7TZ5HihJRHD02FEuvuQSbrnlFqY3T3PyxInRezMECZfbvXsXRmseeuhhbr75Zr761a+BypgYm+TBBx7mrrvuod3qMhiU3Hffg5w8dYZWq0tZOg4/eYTJySnOnJ7lE5+4jYBh//6DPPzIfqY3beXhhx5hOKiYmtqEj6KX2DApQQDMGCM7d+xk796daC1C1UqZFBrZ1BeF944QHb/8n36RUHte9t2vZG5+kcXlFbbu2MGOXbsJCfg0zfiDpO2XxiWtVovx8fGU+EPCgwf9Hq6u2bxpw4itJAxCAYC1Fg0shTD3jFKp8q1m59RJ/LrIzAi8yq2IY0tbjAQUVe0YlBVlXeNGdbUBMKVPyKyhsFnKEijvAasVBrA6YjXkRtEuLJ0ip50LM9d5z7AqGQzLkbh9f1jK3acJwphA5izP8c5RV6Lp5GtHORjg6gqt4MZrn9W01HVbt3X7NrJ1UGnd1u07wO6+5z4WlvucOLPA579yLw8fOsGAFjUtMB2UymRmNUaUBl0PmbCRN77qZdx84/V8+Y47qQKcmZllx/YtjHczcm1YWVjAOYctWmyZ3sgzrroYHwZUxvLY4SMEZTly+AibNm6gqh2PPX6Qlf5wlMY2Khls6eSIiKO6ChswGv+nadhmJlem2EeaM6Nt6acximukE+3ae7/KoohJADMNtK3NmF9YwNqMsbFxVpZXGAwGLC/3mJmdY+euXUTvmd68mYmJCTqdDkVe0O2OjULdWq0WeZZjjKXdbmOtJc+zUdjbiKGU0gY3GjeNU9+EHikF1kYq53jmM57Bzu3b+e3/9hv0q4qYtbDFGKeOnaEdLN2ixYbp7Xzktq/x5+/6AI89tp833PpCfuKVz+Oi7ePs3rsdlxlU8ChauFqjdYFSBTprE7QlRi0p7LVBF23ufehRPvGpL3Lw8JN87nOf4off+r0844qLU+rjHB8CRnlMKMmNIia9EJ1CnSAyMTHJyZMnyfKcLIFpITgJg9OKuq7J85zNmzezdetWARlGJqFQUvICtn0ToNSEuWhAJ/ZCBLA4nbOick5GxXvv+Cp/8dnP8URdsyWssNdUdDTMu3EePB245+iA036cU1VByMdxHlxVMhws0+stiQZJ5SkHJctLy8zOznP4yFHmV/qorCDoDJVPovMOJu/QHhsnBIdVnrI3z7//sR/hh9/8OjaP5+SqRIeKGILcUxRNIR8UIQapo0FSTBstzJ6IAC0qsYUaYGY4GJJlGYAw74IIGQvrR1heiiTInTK1SXuQWWRjkoaREiCoYQ81bafRZxoVhPjxaV9hXjRAVKOFphNgIMUjYFcTuiIz4qvfEVch4qZtyukFzArB4X3NYDDgwKEjLA2csEK8iMRKuIZnvNPmWVdeyh0PPMCTc3Po8XFqQJsWIYqqSMtX5CtzPGfPDt5w440Y3eJLj+7nnR/4MHV3nKgtSlkyY1GVx88uY4IheoUOgbYK5P1lfvL7v4dr9u1ic7dgYmKM0yePszQ/h22NSb9ChEwzrCussSOBZh9hxQWOzCzTp0XQFgUUypP3F3n25gl+5LteQtcYDszO8tvv/zB9Y9i9fTvP2reXzDchRQ5rwLtItbLMcPYkfv4oF26ssLGPjg6NR+mIN5pgc7zKCVmLymjK9ga6518PyuKjsHEE9JPrDMk5JYFXwi6TctPGEBIYHFO/q1If2/THak0jXdNc5fs1ffQIwGy688Q6lf4jAU1NXUnHbYARWK2jcfReSKdp6mr6W65ZMlbGsCaDYsPMUMKw8yFSh8iZmRkBlWpHlYSOmxArbWxzI/KKGYW/CQhcu5QdK7EOQ9pJxUhIbTpx+CS0sz9gaXmJcjiUPrLIhVXStK9vEf6mlKLIczpjXbrdsRGoVA4G+LoizzM2bdjAxg1TdLsd8jzDJOavPFLpE7KsYS4VtAvRXLOZIc9lAiTPM4o8lzqBaFm5JJZvNIThEvsfuJfjR57iDd/3A2yc3oIylrp2OO9BaZwP+BiJASanptiwcQNFkePqmo0bN7Bh4wa2bdvK1i2b2bVrB+12i7IccNHFFxIJ3HvvvWzbuo0t01u46667KMsS7z1nz84wOTXFEwefwBjD/Q88yMMPP8yu3XuYmV3g0ccfZ9P0Fu6//wF27drLwtISZVXx6KOPsWfvXowu6PVrjC04dOgpvIczZ+fpdMeJMdLv97CZMDFFoF4Yn/LOkeQC8/MzvOfv34U1Gc9+1nWcPjtLb1iya88eNmzaJH1ThOgTKyh6FBFPoFUUTIxPEEOkToBSr9djOJREDmNjHbLMoDXgfZoca0IRpXJL1Qopw5uMaZSWLGqZNRijUCpiDWgVhdMbRYh7WEsWuf6wZDisCRGZ5NIJOLJaxOQzQzsXUCpLgJJWAlhnWtGyhlZm6RY5rULC+CMist0ASv1hSe0Cy8srqXE27VsyzeUpGUJd19RVRVWVEGTiK/rATTc8Wxryuq3bun1bWeMJrNu6rdv/wXbg2BxfvuthPvOlr7PQc2StSaIqsHkHH5RoQriAUYZQRYxzXHvlpeyenmLm5HFmZ5fQxSR9V/CVux+mVyqqqGmPT/K1u+5m//79zMzNsbCygjcKZSDPM6qyplWM8/VvPMQXvvI1njp6gtqJM6MSLqBkhJ8yvqUtjd5SQ/9Pa9lXwhNGHsXI1xCQSub45LtmPXJKlBYGSMMTSTPV2lhOnDrD4nKPld6AuflFlpZXZB+lqWrHkaNHUQo6nQ5TU5MS5lYUtIqCoshl5jeJIwsDSXQ1hAKfxFrPAZIaAdd0b4k54vB0uxnalLzi1S/ij//sD1icn+Pkk8fZPLaR+ZkZ9u7ayqmTJ/jV//IbfPQjH+Pqa67i3/7k23jDq1/MEw/fRww1JregDHkswBUEnxOCYXG5z6du+xJ/89cf5PYvfoOFFU/lNLt27OXSCy7myKEjVINl3vlHv8lrXvtitIU6Wh4/dJKBs0SbozNDEKWmNfP/jeMX2Xf++SwtLTEYDPHejUJsQgI1Gge1GSx/a1sLEo4+Nt8AgRAr0JEazcC0mM+7fO7JY/zGBz7MB+7+BnO2y0B3WdJTzOfbeXSpwx1PDnlkBk67LvO+RSjGqQLUZclgaYmVpQVcVVIPKlYWe8ycWeDIkdMceuoU/QpU1sGrjGhaqLyFLdqSIa0eMlye4YLd0/y3X/0FXvzca2mrmoIS7SvJ3KSB4IUhkupGjOLIWy3sNZXAlsb5NU/TNmqAJK01rnbJuZZwORE4lnqVZRkqAX5NGQkmIO0oxkjtamIUwKhhNoV0bc2xpPwaEEIckeZ6lEog0QgI+NZlqZUiJPFlAb2aNpmuT0u4iEoOcKfVYrLbYfv0Jlw1xGrRF1FJX8bmLd71D++jrIeoWEM9wIZasmkpjQGyuqTVW+DlV17GW1/yEjKnufuR/fz5B/4J357AYQUkdY5i6PAzy4ShQwUwwdNyNePlgJ/8vu/huosvYLyVUXQs+/Zs4yXXXc3FYwV+7gS575NpR+UqHJG5pWV6ZU2NYcUrjsz36OuMWilqF7EosmGfS6bavP2V380kijMzi/z1P3+S3tgUruhiTIYNBhsVNoVmGWswVmMKS7AQDagY0MGPFkIkRo0PkvMyeifPJUiGP3GQpUyEnJTKQ6nU3oTN2YjxjurBiG2W9NFCEJwlHXNt2zzXGh5parFJNEfC7FZbfsMabfrp1Vq0pl497SSrez59SSDKmndHUz/PsUgCEBrmnrD5TAJJm9+PriUKszOGQPCyiJbSuWFSq2FFaR/n8M6lCY10P0mvSNSs5F2oUjtZvfenWfP+G/0pv5Pto9flqF3F2KSzb/Rx1jCPEtDVyi3dVktC39oCNBV5hhm9XtNzDwEVPN1Wi8ceeZiiKJic2jhiGku9kpDBiE7aU0mfJ8r5tIqolFghhprga2J01PWQGD1TU5MsLy+yYcMk3g/xoeS883fx+je8mue94GZuuvl6Nk9v4CUvfRHKRC68aB833nQ9E5PjLC0vMr1lMwuLc5w6c5JHHn2EDRunOH32JNt3bmV8Ypz7HniEr3zl6zzw0OMcO36ao8dO85U77uTur99Lf1hy6vQZAqBNAudTiFgIUco2Bk6fPg0KprdMk7cKer0+Ve3IC8mM1wCN3jtCyqpWVUMJe5uaoqpryroSVs9QMg02TDd5P3qC9zjv8GmCoK4dw7KirGQZljVlJZpFlXM4L4CenLdOQGcti3dU3lE6yQrn1wD6TW0yKZtgblbZTRJml8AqoyRboDHY1D6EWS11LZLCPBP7qk51XQTkZWJE2o1PIFsSzkptPQRpI845aidh8Ou2buv27WnrTKV1W7fvAPuxX/zvLFeRaNvJmRKAI3iPURGrIoaQUglrWqrmWZddyNRYm8NPHuXY2UW8bhMw9Hs95mZn2LZ9OzbL2bNnD5/53BfYf/AJnjp+nLzVZmZ+mWMnzgLCAnBoXNSYvMAYSS1uGsHgZoZ6NGAW5gVpsKrW+hNq1WFAiBLNxHbzdaPjPRqAqzRzHVO2Kp2ytDRAVUigUowwMzPLwvwCrnZUtQhGb9++nYnJcQaDAadPn+biiy6iVeS0222yXES481xmm42R0CaTQt10ApdG4W1pkZCwVcBJlhSuYC2+rrGZxhQKnSluvPEWtm/bw9LCCh/5l39kz/QEy7NnuPYZV+Prms994ePcd/eX+Pu//BOu2LePl73ptSxHcDonCxplRKz7gYcf4ud+4Re5/Yt3sNJ3/Mmf/i1fuuNuQrT87M/8HAszs/z2r/9X3vbWN3LJhdtRYYA1GadnV3jxy17H0tBz/U03AB7TaF6lp9w4NErJfbVbbY4fP06n0yUmQecGgLBWgKXVUluzrE3rlz6srR7i6yggElRgGDVVa5xD/ZI/+8SneP9Xv8qsNqjOGAZDy0c2VRXdqNn/+FFmyw4zQ40d20AZIzUQqgHLszPgPYOqpBw6Fhd6nD27wJNPHWNlWKHzNmQFOmuhTQtlcmofKTJLpkHHmh/43tfzb//1j7B5qk2uagormehUCldDabxHwE5jCImd08zYZjZLIueS2U0r0SYJSWuocUqNtdRVPQKOGlehOZZKIJM2EvLWOJ8hBKwRjaQYmnKQNoUCVzvyXESA8zzHOz9iQJEAqdVrSJpajTe7BjSgcW4b4CBKyINzDpOOFxMLpnHeQUKcnHOo4KkGA2YXetz/6EGiKVBaMuppY0Uk2Q256brLWe73ePTA4+TtNiGxPYroyVYWed6F5/HWW1/MlC04fOwMv/OXf8uKzvF5C5VnhODInSIs9NH9CrRoqrRwtIc9fvQ1r+DmKy5mQzsjxgqbW9E8UTBRFBybOcOg7GPzHK8NQVvQmmFZEVEs9oeUQeGjhMS42qF7fXa1LD//1u9lq4kM+0M++eW7uPPIKerNW/F1zSXT09x0/vm0kiRZUIHcamGEDJeZPbqfMHuYi6Y0WUhAWPLuQwRXe6yykvVJa+rWJloX3IxHtIBEG03qi3OezGbJ6atHIOaIaZZAxqaMzgVspHxjA4ikNhpShkLZN/XFqU7opAmmEpAOqV6FBnBZBZx10v9qDhybXmL0zzfb6DrTtY4YsIkvJPVY9gsSpciZs7PUIY4EuUMUeESA3nTvDUCSwqJi2i8k0eTmPRRTmLVWQJRMiDplNYwxUlUVveUVyrKSd0dRrOo5JabSsLdCORwkFp8wFFv5qlB3lufUtWPQ7+OqkjzP2Di1gcnJKTrtdhL1D9QuJEdfmDExiiaOUVIf14JYAm4IEFbXNcNafl/XDoDxTpswWOaLn7mNC84/nxd/96tRxmKsgLMxyss3pGPJf/LOBWHOKCBGAU8EhJBMaXnK9mmzjF27drJ5eiMQ2b17pwRuGSm9yalJilbO9JbNbNwwxdZt08To2bJlK5dcejHbd2zh2muv4cILL6LfX+YZV13GBfv2ktmcX/u132T7jh30Bz02bdrIE4cOccEFF/Le972Piy++kPHxMTrtFkpJNrKIlC0NO83XHDjwGLd96pNs3bKVq59xDfsPPEG/rLjsiiso2i0pP+ewRgS1Y5Rw382bNwmQrxRVVbPSHzI3vyCsT21QCsa6bbQSgNV7YUj5NeLag7JiWNcMqorhsGJYifaj9x7XAFFr1qILlbSMQqQOiAB9Jew6EKZqE/6YWyXsJCPJL2JsMrgJu08lVqNKou7WGkx6j9feMyxr+oNh0qQUDbxBfyj7KyVAZaoL3U57xHyV7HM1IQroFKPnlufckGrluq3bun072TqotG7r9h1gv//e24mmRRUUURsZLKuIwaN9ySXn7+ayC/dy+OBBtMpoG8/VV15InhsOHj7M3HKFC5aAMG2Wl5dRRrNxapLxds6uvedz8KnjVMFy5NgZDh0+jo9WBEtROJODFs0m530KWYqi85OckzhyUpJjmnhGI7ZRcp1lGJzYDiM3Qz4r+ZAcj8bx0SibwI+Yjts4sQhzKfkDEOU3MsAXj2737l20W20yaxgO+lTDkgsvupDu2Bg2s+RZLim/jcEYTZZCDxrx7bWaSTLL1zCYGnBJJVZTCiUyBquELu5VZGxynI/908f48Hs/xAf+4b1cccl5/O5v/DLPu/Ya5o6dZPv0Zl7/uu/i1hc/jze98Xu55jkv5K7HH6U0ivHJcWKoqUNF7Wv+6I//jAsuvpT/9Cu/xHe/4mVs3bmX93/oNh579AD/6od/gF/75f+Lqy7eTSdXKF+jY0TrjIqcr9zzEHfe9wiVCzz76meOUk/LM28cyoZ5E7GZZXxigl6vR57nhOAFYDMizjzScZHCT0dKs+6j4zYFk2yNE+S1oTQtlrM2n3roEf7805/hnrNnqcbHUcaQ1xUbypLNwyHZ4gJzJ0/TGwQqNUbW6lLVJc4NKMshw+VFoqsZDD3L/QFz88scPXaKuYUlPAqVZTggGEvEkmUtrMnIjKLq97j0wr381I//KNc+4zJaNtBtG4ySAXIYgaTSFkJM4r/p3l1do7VkDNKJqaQbphJqFXxtQnlSCJE2sg4NYIWwjITJtMo+sdbivYhx2zQL772nKAq894QY5RypKYW0r6vF4XPejX6nkxjt2gxyDYNJqRSGuAZQYg37QiVnU6sGJEz7JIddJdAril45riqZWVjm8SdPUnqFUjahAaK7ZTPDWEexY/M0Z48eJ/SHLC/OkbkhreESN194Hm+59VamTM7Bo6f4/Xe/l6VgoOjgAWUiVinUSgVLFVmIVNRksaZTD/mJ73k9L3jGpYxnEWsDdfApw5KhU7RoFxnjYx3mzp5hfm6BdneCoAwuaUNVzoPKCFGjYyQPNWowYE+r4Ke/942c3ylQZY/jZ2e4e/8TPLk0oJyYwATPRdMbuW7PHozzRAWBQKYjriypewucfeJBOr1T7BlT2BBQUaGDgpTC29gcozLQLUpdUI3voDj/egGVlCGgCCnMeLXVBVACPhgtAGYIKTRzDVtJ6uIqYNSU/Sq6v9pG1zZf1YSPIRkhVzvdhqmT9o5J32v14KPj6Eb3K9Wj/5XJPaTQ2YYdl0JBWQMquZTN7czMLD6qlNmtmXyQlPDGyHEU6X6jXGNsgJOUFWt09wqMknu0Wkn2rizHZAajNHVVsbyyzHAgWkhNiLTR8nxcVTHorYw0lZp7LYoW3e4YnW4Xmwv4XPb7uBT+tnHDRqYmJ2m3WpD0c8qyoixrSQUfIyF6JEddArpSw4wRnPdUdS0TKmXF0AVht6QwwnZuOX30EA9+424uvvAinvvilzGsK9FPa0L/Ehgi190s8nykXBoR50AICICemMd17dBJm8f7Gm20gBMqUtUVMSUP8CFQVZXs64bE4PAu4kMFeKzRtPI27XaBtaCCZ35mnrHxcW553nO4/PKL6feX2bN3D66ueeZVV7G0uMjePbtQCCgk99GAiJHgI1pHvn73nXz1y19i+/Yd7Ny+h6PHT1J5z+VXXjFiOMUYsUYRnENpxY6d2ynaRZJBivR6Q2bnFynLCqXSWADodkXTMYSUbdAHykqAmt6gZKXfH33uDysGZU1V1ZSVo1yzrqqawbCmrB1l5SlrWYaVbKtrYdhpJfU7yyxZqqtGRVQUMMr5BpRcm+EwLTE1IoTV6LxnWMvxnW8AK0tVVim0zpJZMFbacLvTxQqCBjHifC3JA5C68rybbzynPa/buq3bt4etg0rrtm7fAfa77/ok2ma45KgqrSSGPVa88ObruO6Zl7Jv1zS51Rw6cpxOEbni8gvIcsW999/PoPK4NIhWOmIzzdHDT7Bj8yRtGylabcY3bOPRA8fJ8g342MKR47TBaQg6J2pxThSR4EoRpGyG4k3YGwI2oQTgIQ3SiTGBRo0j0fwtA+LRYD8dL42V054iEJ2ljDYyABYRXYUMiJVSGCPMkIb9pBLAtHnTRooiw1ihfA8HfZaXl7jgwgtptzsURSGgkrUYk8Qtzbmhbw2opJKgcaPppFMo3IixpCSzS0GOUaJ5BIrnPPtannvddbzy1pfwb3/sR9k80aaVGS694jIuvPRCdu6Y4oK9u9m+ZRd/9e4P8Qu/8p95+9vfTqfdoQQMogvyite+kpueewMRxUc//kn+06/8P9z0vOfwp3/6uzzn+kvpFjXRRL7ylbt56MEn0KaLMpaYZdx13zd4xatfze2f/jSbx7tceN4ejEnPOz3s0ToBCEpBnhcMB0NarTZa6xHDRoCTZu81tsZZla+e9n0CJQY646na8Psf+DAf/vo3mMta9FWOcYFuv8/WUDHZn8fPHGGsXMQMe4x1xqgqhYqOYW+RlZUFhq5m0FuhHDqWejVHTp7gyLHjVM6LALiJ1DiCkSxtrXaHGCK5Nfiyx7/7sR/lzW96HVs3TjDetnRaklZeaYha4ZVCK5s0y+SLiMYnZoA4qQK+uMqPMrE1Tr0Ao+CdfNdqtyjLcgTC5FkmYRKVOGLeebLMUjtHluUj59do0W1ST2OIkEIsjNFkNktOok9AoDig0sbkN1rrEZDlQyDLM4ji8K1luawWl7Qjl2bwG3BKKSVtT4vuEslpnJ2bR8eAxtMfOM4uDnnqxGmKTkdAsyzHR8iLnIX5GV7xvBdy3QUXc/V557N5rIVfPMPNl13AW259CVsnNnD07CK/8Sd/ycGFJSi6xCzDWIVxNX6hTz1wAvAZjXUlLTfkLa+8lZdc90ymxyzGBnz0WJOTh5xMGTCamMGmomCqPcaZU3MsLA3I22MErYmN+HWI5DrDhoApe2wdlvzS236IfRsnKQi45RUWV1b4xqEDPDkYQGcKgmPflg1cu3sXxjmCgqg8uY74YUXsLXJ2//1MxyW2FX0MVerlFF5BqRSVLlgJOUtmkifLjPliC9MXXYtXGW7EVBIKhjUmZeQEraMAn0FATK0SiNiwdRIYMwKXEoAvAFOqV6NwutX+IL11INUf70R8vqknEm7XZHpktHdMoCQJdJL2IP1pHHX851pzfSodV8Clb81U8lHYIGdn59Ln1X5LnGEJ+ZGgv/R+Ss+NKNncpPnK+bTSaAXWSKa1PMtoFTmtIsdaYeVVVcXy0jKDwYA8E6ZSlrKHkcDU/soqqCT3hIBKazWVakc56OOqmjzL2TA1xdTkJEXRJoZAVTnKBDxISJKwq1RiUhklgLVK/amASg5X15RlSekiLoV0Ga1QwXH4sYc49NgjPPOZz+TKa26iSuXmgyckIAIEHGueEaTMYgkwlqqjU5+iBRwrq9TPK7zzEBVV5YhBEdISgwI0zgWUMpRljY5goiIGI9cYwbsA3kIIiXWjUEFz/r7dFC2N80M2bpxgYnyMzZs2snnTJvbs2okKkt2sqoaAiLDHBiALkSwzfOJjH+GxRx7iyiuvZNArWekNCSguuexSUKLZJc9WgKLp6U10xtr44DAmZzCsmJ2bl0x2WjLRGmtQKjLWbWMSU6l0EvK20u/LMhjSGwzolxWDxFKqnBMgqZT12vKWtTDUqjplXKuEQSQsKIU1kiEutxajZcqDIGF7pfMJlBJgqnaNiH2g9g4XfALJAtF5XJPhMERiYivbLKMuK7TWSRheY4yMc9rttoRWB08InroqJetecIToeeFzn7O2Sa/buq3bt4mtg0rrtm7fAfZ77/kECo+JNdENaOVWRESJzM/OsHvbJrq6Zs+2TawsL9IxgfN2bUMT2LF9moluiyw6suioBz1CcjqPHjvO1KYteN3i4FMnmJ1fFmaHMUQtjosAWBJaF0PAKLBWHNFIcrLjqgcSSQOThoeUcl/LWgbFAjxJBrnmp83MqG5QIUTzWwFZZmi32gTvqet69FxiYmko5CARAQK0bYSTPdu3bKHb6WC1osgyjNHMzM4yHA7Zd8GFtFstiqLApqxWDaC0loW0NvxNqQQkJSq5Gol0N7Pz4gSF5P1Yo4l1xcRYm107ptGqRoWSqDw1jhgdxoguVtEe56///n1cf9MtTE5t5c/+/O94/wf/ifsffpLuhmkmN2/i3nse4Ld/4/f5ype+yk/927fzU//uR9g4VeD9gNm5s/R6JfNLA37uF3+Fz37pqzxy6EkeePRxjh47xlWXX8xLb7mRD73nb7j0ogvYvHk6CeJqIAogl2YfdcoOpo3BZBJ+qBVkWkt9IKXYTn6kUol2jx85lCiNtkk8VRschmUsZ6PiYw88zJ9/+nM8NjeHGp/A+UDHezYOSqYHPcYXZmivzDAWBuTOUeicalhTVVXKmlRRplndlZUBc/NLHDt5hsXlZULUKG1QNkNrAQuNtpKFJ0YINXt2bOHf/Mibuf6aZ9BtWTrtHGPEUWvKTiJ65G7EEVegTAq7ESfLJIab/GTVSTZWNI6UWmX9gDyYBihqGERNPdJa47wb6XU575BHJxnmSCEvITb6OMkRSpnmQpTwF50YSQ0QoJRks2oupLkmvSbcbnR5UQAJHwUwIgHFmRZBaJ9+52NA65RF0GhckMxbX/7yl9m5fSeZyanqil5Z8sRTR4m6hdM5IbWT6AK9xUVuuObZXHbxBUx1c/bt2sZznvVMrrvqSjqdMQ6dnOOP/ua9nFgYoNtdVFHIvTtP6FeEQUDrnOg9BTVdt8L33Po8XvPCm5lsZxAcZS2itg2bLirAaEyW087atFsdJrptZk8dpzc/S6fTwWtNyHNhZsVAp+xxXiz5ie99I5ds20juSwyK6Dyziws8euw4BxdXoDuF9iUXb9nIs8/bhVXyQE1ykKOB4dwpjt7zRS7qDNmQLWHxqBCw1Cij6ZkpHp03PDCfc3DYIm69hD1Xv4BsYjsuCkNOwrsSU0UKNGV+I9XXtGnN11KNBXBpQBSpB6uZA1OFTZVgdQpAjpWAoqexjEZMufSZBEKueSUka8Ikm+v8ph1kU9qj6X9IIFOkua7VfWPi7ZydmU1OsejOhAR4ZNoK8JWyHDbtWKqDvINWgRK5Hq0lo1qeWYrcUuQZmdW0co2KgWG/z+LiIv1GqDvPMZlFGWlzrq4Y9HoM+gO8d6nf0BR5wdjYGN2xccmeVXv6/R5VXVK0CjZu3MDU5CRZJqHclaup6jpp6QhIgpLJEq01xsrkBklXq3YCRA0qv8pSSmCRNQbtKw7vf5CjTx7ihS9+CVt370sAeWwSkcEo7C0C8hxJIZnynOQbCY87d1sDoseUUU9YnQJUNOzGECSET6UkHAr5PpCEq2M6IYBKDJiYwtsRvSsSUORqYSQ1OkYhNNpEArx7H1J5GlxVoULgs7fdxqGDh7j8iquYmV3AK0PeGWPv+ecj1UuAqcxotkxvYtPUpDDCYyT6SFULaO5CxIUAWu7DKMXYWBuloPaOYeXoD0p6g4p+WTOoPIPSUbpA5SPOC+BXexG+bo537hpcjNTeUzmPCx4fpA40YW/GSF1t2rRL+w5Kz7ByDMtagEYn7NZmzCjPuAlZlbA+Uhu3xiSNJk1VDjDEUZZBjYwPxtptrNEE5wjeUyYAVaHRyvCC566Hv63bun072up04rqt27r9H2sCkFRYKq654gJ++sd+iG0bOhgCK4Mhn7v9i1RliaXkNd91I9c/42ImWhluOCTPLHt3bua13/083vbm1/CmV72UG699JiHC0hBu//qj/NOnvshD+w+irCJqR6AG5TBaACCdBGWtllmsqDRBGZnRTyBK46RELaLdMQEzKoWLNVo9JMehrj1oQ5YXAkIZncJyJIOdNTKjPTE+zsapDawsLdJfWR7R/o1WSWxS9k8JonFESleDUhLGUtfEEPC1w9WOOunOPPzII3z0ox8V3SQjM+E2E20McfBl8K6Sk7R2WXVs0oe1fyuF04FowBgwMWIMoB3O94iuj6+HBD9EqwqjSoxWBDReG2YW5vjG/Q/zPd/3Q6wMPC943q18+kt382/+/c/zX37993nda76fzRu28jd/+qf88Pe+nk1tiw2esqz5H3/yl9z2mS/y7Otu4Bf+8y/T845bXvLd7Nq7TwbW9YCXvOAm/sf/+F0uvewSYrQobVPZNKLOTZhIE/IAWiVtksQg0Folp6xZ5BEoJW8lm0kYGDFSR0+lNH1tGbTHeGxlyK++5wP81Re+zJN1SVXk+LpkvB6yww3Z2l9kfPYM48uLFMvLFIMSSpn1HgwG9FcW8cHTG1T0+jW95QEnTp7lwKGn6A17xKjI8kIcpgCuDiivKJQllhV+2ON1r34ZP/vTP87F5+/EUGFNQCkRNxbsYQ14CDJTn/5rsvZoLWGXNpM6Jg9AwtqakCOlZEYZJUCNUkpYSqkdNALHDUvIOUee5SOn3VoruktagxZnqvaikaK0TsBPAqBSuIbzbqRv47xoYzTAVUhgYUhhHjEEVETEpLURoElL2EqWS7ZACf8D7xxaKazNKFOoSwRqVxGix8fA4aPHmFtYoN0dxxZtJie67Nu1mempDsF7MBm1k3A8rQzatPjYZz5PPjHOhi0b2b1lIxft3Ek77zK74vjdP/tbjs6uoPIOmc4JLmAC+EFNGEaMKgguYKPDVivcesPVvOYFNzGRIYCS86As2uQEQHo2eWaFbdHqSnarS/bt4GU3XsUe64mnjlMMB4SyREdHVwfa/SX+/Rtew6W7tqLrPoUO+LrGAx4R6cWB9w4dHIaII+KUOKlWGbS2lK4ilMuU8yfZ1FYogfAFHPQVw9ox7zosdS+kc9XLuPyVb+PiF7yJ9tbLqGKGQwAlrRBwNDn1WqeMcLJJLAEEJIczxoA2Uj9U2g4CAkmFGnVi525TShzP1L/L5gYkCFhjJCU9iizphnnnUEpABBBndc3BBTxozv80i4kNFRvGY4P4KAFylZb6zAjQT1fX7NdkGExL6pJkMqM5R0zAR0jxhincq5n0MEayaeWZJc+MgEpGkeuIVo3OUGI6jfqM5nE14FkDusjFRySET2uDUUZYtQk4k/NJ9q+mT40pK2FIwJmPEQ+4qHABPEpSLSg5thCDpQ5UiO6gJkoon1ZkRnHi+HGU0Uxs2ERVV4Qo4XFNXxCRzIwh+JGAuQAcEjK1Cnp4au/WsF7kGCE2v0l6QGmb8wL8xOBF9Nk7ondyrChMwua3IUZ8rAhRkhi4EKhDncSko4TK1RLSFrwjeBGHdkEYNzGx85zzOBcB0Z50VcnK0jJEzfTmbfSHJVFrprdvX2WAp3DmTrtFp12gYsDEiA0BC+iYJteIEiOZwt1iAtI8IbGUHIOyFmCnDrK4SOUVdVDUUdYuRhzgEG1A+axwSuOAygdKH0YhcA1TabUuS4ZCnzLK1SFSeagdwk5KmlzeO6qqpKxK6qqmrhzDQclgUFFWCXRyctzcKFqZoZUZOpmhsIrcgEH6HBUCRkUyIxpORSYsM6sN1liszVMrW7d1W7dvN1sHldZt3b4DTAanirFul2dccj526Rg/9saXcMXOCaj6LPRK7n70MPNlTVnNs33HJJGKmfl5Dhw+yemFmqNnFjhy8gR5W7H3vGme/4Jb2LFrD73eAO8D1uZpNlhmvhpHoJmhJrGPZHZT/m6cb0az0KCQMAFh8siCNihlQAmIgbYUrRZKRYKvR/oZAjrJADfPcyYmxnBVyenTp4gxYDM7SpstDrkM7lcXWZkUlqGt5djJk/SHQ5nxq50M8pNP88TBg9x226dGGc3U2uxuadFKtJLWgkp6tN/TASdABcmSowKkJeDFPdDCOtFGkytN2wdaqiZXgczmoGFusYdta/7m3e/kd37nl/mBN7+Gt/zg6/F4njx0iv/5zj/nHb/yc0xvLqiHK9x39yMcf2qeubM9PvvZz7Nz9/nULvD85z2Xl7zgufy3X/0ltk61+fN3/gGveNl3sdzrUUfNgcNHuPe++3jwoUdGITPGigj0080EJanaMTitqbSi1kpCe9I+UYmGlM8MdUqPTnSEGBlmOYeGFX9426f59Q9/mIcHA3qdDiFAK0QmygEb+ot050/S6p2hyxAbPLnuEKuCYc8xOzfHsKypnWduYZGllR4nTp7hwMHDnDk7i7ZWwtN0coCNxmYGazVZbqjqIVdeeRn/10//e5733JsoMkvepN9OLIfG6Xy6iUOYyljL/j54jDGUZYnRoiWilISekWa9vffUrib4QFmWSXerARFSCKdWGGuoygprreyfQtDqWrIApYsQACH9JqxhlPkgGkshCYI319qIg69l04UQRmFKWgtTQRgNkhEsBI81Nt1X444LM8rHQIgeYxQhiAC5TiEwy8s9PvvZ29mxcw9Fp01WGMbGOmydnmbX9q24aoXoypSqPUhoYpZz730PcvSpY3SLnLFuTt9VnJjv8Tt//G6OnO5RBnAxUHmP9oHQH+L6NcFrXIhoKqzv8bLnXc+bX/NqOrmEDDb3B6IV04AOCgnvUUChYGyszdTmDVxw0T5ecvNNbC9y9OxZpvyQ8arP1LDPD7/qVezdvYfM2lQbQGf23PyJUdJpN061CwoVPUTRwymjIiOyfPoIe6fHMNoTVEEZM2pVUKo2PTtFNbadi69/CRc9+3ls3XMJxdhmgsrkmtcCP4JjQAInBYRZbZCyWu0b1RrwMpIYicnk0TQt+X9l4jivXWuj8Um3KaYQLKUEnBewS64nJHCnQVnkM2vu4FxTqc6x5qpiTO+HBHyOQKQRA2aVteKdw9UVddIYCt6nd1paVESriCagdcBI9CRWgzWQWUVmNHlmZMmFjah1k+FQdIVgFUSS466dcFi1Bmxq3qaj9mkMWUoOYc2qjl+zb0TafPOfPAx5hjGuRRBXH1RMYU1EAbEkLBzKcsBwOGRicgNbt20ngIhBJ3ZP87lh+/gkIu2dLJKlTESiRVjaU49Eps/9LCLTjQi1gFACNDXnW824F3zKcOeFMeUb/R8n2kEhfR5dV1oaQezVbZK1zXlP7VZ1hZyXttHr9XjqqcMYoxkbG6fT6dJpt9kyvXk0gUKEdqdNt9tFp3B/7z0x1ZvRez9NHIzCPaMwsCREMaYscXXSSJKJrNVns/Yezi3AqCAomUT0SbvKe48PzbOVbHYBYWRHBGht7tM12e5cIPooEgCpQko9EMCtdp66lrDF4XDIYDikKktcXUuCCK1S3ZfEBsZoATubK40BY6AoLGPdFt1OQaed0S4M7SIlUlm3dVu3bztbB5XWbd2+AyyPNVYrFheXePjhR+gtzVMuzfLal7+Udsvitebuhx7hyeMzrKw4tM6o68BX7/wGd997gPf/8+28+0Of5Mt3P8jDjz3Jvfc8zGc/+0Vm5xbJiy7oDJIIs1Ja2EdNuuQ1g+Ukk5QG0fJdbCazU3YRyUpjVgElZUZAktJZ+pxJ9qpmFjkGrFbE4LHasGV6mlaRc3ZmhuXlZVgze00KOXq6gyVXALpxOrRoxswvLfH4E08wqGuqlFmlLsXRH5YlX/vq1/jsZz6TKPRJf2QU+pbEt0cg2Sqg1DyTkVMxWsThUirKjGJi8siMtha1S5OBMUQFmgITLbmK2OD4jf/yc7zn3X/GrS99IS54fvv3f5/f/o3/ytve8ib+4k9/h9e+6kXkRpOZHGMK/vhP/oLf+t13cvjIAmdnA/3KM78wjyHwMz/5Y/zE236AlZmTZLEiU5Fef8C73/sB7rz3Pg4fOcK2nTtxEapEnY+JDj8qa6JouCQtIdDoqDBBnrUUfUzaMeArJyKlwAqGedPmi0+e4Bf/+t18+IGHOeo9y9GjvGN8OGRjr8fWfo/xmdOMLc3QrXuE4RJ1NWDQH7K00GcwrBmUJcs90bCZnV9g/4EnOHriBIOqJmphzZmk9aSNZLiBQJ5pYnC8+fvexI/80Fu59OILmBzvYq2iaLWwWSbMoJi8v29psn017CeKGGyUEDZSm4g0wrACtugUdqOUIs9yhmUJEWpXU7QKnHdoJRpMxooTY0yT3RCyLCOzFu/cSMeqrCqMsfikh1KWpbCHqgqFhH00IFFTn2MUsVyd6mxImeNCyhxG0gaJSSDZewEfQsNwIhKNaP6s8jSkHYIiBjhzZpYvf+WrbNy8lRAjNjeMjXXptlucv2sbYbiAjUMyo/C+lvTUxmIzy6OPPITRkUFds1RF/vw9H+bxE3PE1gRVYmYED6r21IMSlfRlWlbRjSW3PPNi3vKa72aisBKiMXK4Vx3zptxUAvxI2cGKPKfdKti4YZJL9+3lxddezXYd6MycZuPyAm+79UW86OqraGc5RmnRuUrhgSE5giBsNpwnOHH+fHIwQxLsVxrcwkmWDj/IRVvaWDWECDrI7H9QlqEZo719H5O7L6I1uUmyb+pMQPJ03UqJuK7cTdqWnNvV+xRb/VOeg2jSpYxkT6/r5/70m0wh2llKpfUa9KRhDJGakHcCLjVO8yhkM51TikZ9y5Oq5CirFJqmUtsisQMbtl1zr806BGl3I2fcOZyTFO3BS0iuVgprkvi2tQk8gtxEisS6KKwm02B1xOgo4U9q7fNaddRX+/y14NJqH7F6fwIGj0Dl9C6RMKaUeGNNmLVK7VR+mYSVm1CzEaDU3P/qfmkLClJIk5Z+MAZWlpao6pqsaFF0xohIyKrzwmhpNHeav6uUda5yAhhVdfqctp3zvROgotm2drtzHlc36eqlbdTej4Cic4GpVfCl2V57T51AlebYTz/Xudchx69DoHY13jkgMjM7w+nTZ4gIOGmMIS9yxsbGhL3pHVlumZqcGpUeSpjWMQpbrClNpWTc0owJYqqHI3AsdQfCMmsYW2uXlHkw8UBHy5pQwhil74jpOx8FXPJJiLs5loTRpWfrZJ8YJZmKyAbkdNoFnVZBUeTSZ8cEXPlAXTmqYUVZllRlha8dxIjVmsxqjJKELDEGYScTiNFjtKLTLpgY7zA53mZyrMVEt8VEZ52ptG7r9u1q65pK67Zu3wH2R+/6KN452q2c2dMnGcsVWzZvxMXABZdezqMHD+GBY8dPMj01TaYVnW6X7sQmnjo5j25PEY1lcWWF4ydOM78wRNkWdUhEamVktjdlnTrHYXj60P9pvsjTTQbfq87D2iOpBFiAElp+mjFWSaej027RbhesLC+xvLy8Rt9IjnAOYyQN8lcH+3IOoyTzlU7MCmsty8vLxBjYsGEKg5ZQHq1FD8MYDh48SKvd5rzzzpNMbmuYVrphJDUMpgQo6eToNc+rcS6abaM1YI0VwWyliRh8yqon8Xt5AmsiPtRs37kd7+GTn/wM//mX38HS8jK/8+u/xhte9TK6BWTGMzs7x8//0jvoTEzzglu/iw/800d4/PAJFpZqysEs37j3Lj7/mduo+iu8/jWv5MLzz6OqSqqy5KkjRxmbmGTbtu3cdJNkaTl06Anm5+aY3rz5nLJfNWGsyKcGLGvgBTG5dQFnXJbTywqOOvir2z7P+++4ixkMVZZhvGPM1WyuKrbWQ+zMWcZ6y0z6mparIc3M9vsDBsMhvnYM65LBcMjS8gqnTp/l1OkzDKsaHyXzkLYZyhhC0oUiRoTMELj0kot5wxteyzOuupxuql9FntFpt8mzjDwJwI+0s8xquY/uOYVChthk0ZE7bpxDVLr3VB+bGeaGAReRtiV6KaJx4p0ASKEJO0l6Xo0IMikbEwj7SpgRAgbFICFcIQSyLMMHL/URkjaYlIk1ialEI+4toUdai8PfMO28lzAsknOutcE7N2KuCVNJnq/zHmstBC/hEEqz0hvy0COP86F//Ag/8Na3MjHRRcUKgse5QFXXHDz8BP1hDVqywGkVwVXs2jzOW970KlqZYnal5Df/6K958MnTDHRBUEac5KhQUeOqUp6f1hQ60nZDrrt4Dz/2/W9kQyEZMWNYFXcWDZHG+Us6U6O+QwC/Oghgl1tLbixFlrNxfAzfW+aWq6/i+ddeTUFABwE7iLWE8miDq2sWlpd49KmjPLUwILTGIFZcsG2aq/fspRAXEWKNqZfoHboHd/gb7CiG5PRQQe4lEhiGQL+9hU1XPp96cg+hmEBHCc9SSkDyBkAZ9X1SzFJGzXff9E1qm6mcxakUZ3XUZ43q7rm/PbdvFVBGnmfjSIsgdlPftBKdFtMIvjdMjrXHTpMQMdWdp1tzxnPW6Xyk/j8225TCh8jp02epvYQIucSsCQl4a9qxQhh7OoWa5ZkdhfFkKdStyC1Flgm4lAtLScSipX3WtWOl12dhaYnBoCQrCvKiEHZgKh9X1fRXVuj3eyMAT2tNq1UwNj7O2NgYWZYloe4BrqpoFQUbNkwxNTFBZjMiiso5qtpRpwx3AmKIfk9mEoskE/HkGBswSMAfF4KAGgl8CnVJ1V/mrq99lV27dnPNDc8BW6yCEw0YntY+6RuGmBhgCQiR6pgEndd8bgCOZls8JwSxAUkabaa0b9pHzpmEtWMcXffqNaW/RyF2zd9rzpv0n1b3Y7S/1qIB+PAD9/PlL32RHTu2s3fvPnqDIbYo2Llzlwiz55axrmSENUaTpcyvOvWzLiDhqUuLOKmAqKQjaJWm2+mAkuy4wzpQ106AuiAaSk2dXV0EjJXBTTPmWlPrlbxfZC3fCkPKip6Wbqb8hJnWhCuGxAQUQKmg22nR7bTIUphaMy2gGhkBJey7kNhaWstiM8uwP6Aqh8L+a4CuEGi3CjrtlrB9jfTLVkNuNa3ccNVVV6X7WLd1W7dvJ/vmN/K6rdu6/R9ndVVhFfiqZDgsOTO/xMqwYtDvMVFoXnnrC3CuZug09zx4mPleTb+s2LJtC/suOJ+oQRcFTmcE28GpDlVI7CGTC9gRJQRqrVvSCGXL32uH+c1ncTwaaEGclORoJ8dOHIcGkJGMbbIdVMpk02m3GO92UcCZ06cYVuVo9t1YSWFfN6FrzfmTY3juIuyJPJNwEZsG6Hm7zckzZzh2/CRlWaOUHNMmdkin0+H22z/PI488PLoPGcw199Sck9EgTy5hdYAop1drAJjV6/QBfNBElRFUgaeFU11qNUatciqgCpFBWXPw4BF+49d/hx9/+7/lVS9/FX/+P/+YW657Fm083bwgUrNhy0b2XX4Vb/03P0WpDb/8X3+Fex+6nxOnZvj5n/sZfvnn/yM/+9P/nuc+5yaC9zz44AN8/a67+OLtn6fbbnHBeXu54vLLmF9Y4CMf+Qgzs7Ps2bP33Od7jkVkrrbRc2iWkEAmue+IZqgylrI295xd4D/97Xv4zKGjzJkCpw1jCjYOB+wpS7YvL9A5eZTtbkinv4Lu96n7JXVZs7y8QuVrqlDRq1boDXrMLy5x5NgJTp0+S+WjiHDbHLRNQrMiKh6CRxtFjJ5XvuK7+cEffAuXXHwBY50WeSaD3twqFAI4ZlmGtdkqQ+jp975KChCwyQjQ4b1LzoywksRxkpA30eZS1E7CCUjsuphCU5QSB7QJW2vAJWCUtU2nVM6jrGtJhFslJ8JaAT+rRmg7ka28F30S0n7NuYKX8DaUOF/NdqnSiizL5O/EGGwVrTXsPUPlROOkKAqck3MabRikNNlfu/seis44ne4EtfdEpcjzgk6rxeYN4zz7qotxvXmy6FCuwirHVK74qR97GxOTY/S94qOf/RpPnFgg2LaEgvgKqxQ2KkJZ411Eo8iVZ0xVXL5zIz/x/d/DpiLDRo/NJOQxplCvkMDqxuFv2nLzrKPStIo2OmoynVG0WmzdsomrL72It73+tbzi5pvoak90Q3QCrJtn5YOnkb1VJL2RKCFw+IAOIQEvEe366IUjLOy/i11d0MNFiBXGNnpZiqAt3Y1bGJ/ehmq1cRECGmMzqlpCDZs62tTQc/rdEbD09LYr+0WitI8Unil92pqQqtHR1n5+2t/NodNaWG1+BD467wXMT2Fwcj3N/ul8SHv61uC17KFTWKZKuzTHacCqZr32OTQhcMQELKvmG1BJo0grEWEuMksrz5jodpgY6zA53mVyvMPkeIfxsTatVk6RW3IrjrjWwoxrzqlT3W+eu7j3DTCQNObS+UevjvS+W/1+dHOjR5x4Kqv3rWRbTL9ZtdHWcy3KP1rr1TB1IjHUuHLIcNBn34UX4aJiWPskAt6kmW90kFLoWEo/36x9QDSVEqi+dvva7+VzOtbTP6dzhfQ5yVmlbZK9r9lv7d8hSPmuHu/py9rtzTU31yWg/Vfu+AoxBq6++lkMqyFZAgO1AmMUU1NTGK2pq2rEiBNdJhHSlmNJWFpMgNW5RSIF3WQkbNYhgXQkgGgEEp0zpmgOIn8obWRpxkxp3ZRpaEL7EogUomhdNeczJpJninbb0u0WjI21GB9r0e3mtNs5ecuSFcISpQGIg7wvGqZY8IEY5J0TvB+9BJv3nFYSMqqiRxMwKmBNJFuPflu3dfu2tXVQad3W7TvAinaL3EQu3bebN772VVx7w43UPlD2l1GDOfZsGuf6Zz2TOkaOzM5x78OPMLe8yKmzJ1hcmsH7IS6UqEwTc4MzBmXtiH0gDrlNzsFo6Jts7dBJWBerf6qU8UNmgEmCsag0zNarotdqjcC20TLjmtuMbltEfOfm51hYWCAvijQoFmDKx4AyhqwoMDYHbSQbjngfAl4ZgzIWbSxlKbo7IcrAK6KonSeiOfjEYQ4/dYSykpS/i4tLkoK3LBkMhvzt3/4d+/c/BgpxUNK9j2ZO0wCs+SyKuQiLQEnIgcKgsLIog1YWHxRZ3iFQ8Nnbv8bP/vw7+KVf/l3uvvcpnGlBu83p5QHv/KsP8oNv+xkOP3WGf/zgh/ihN7+OVhyCW+LuO+/mD3//r5lf8vRCzabd29h+3gX8l//2OxQdy2/95q+wbbrLof0P0W1lbN+6lXa7zf0PPsyTR48RleKyyy5j5/ZpJrsFjz/2EHfffRc33nQD119/Ha12seoESuGuOmXBk2lQKhBMwCGAioqgoyIGjVeWKm+xf3nI7/3zx3nH37+PJzCstDpooxivh0yvLLJnuMLkmVOMzZxhsx+SD5bJfI2ra4ZVzeJyj7ryDFYGLCzMc3r2NAcPH+LxA0+wuLSMshmxEYlXGmMtNs8wWmaXs8xy2aWX8DP/10/zvOfdwuREl/Gxzmh21RpNlpgKegQwiKNqrIBBkDIZJYdkBMwkrRJxmoWh4Z2X0LImdCWxiiTjnJGQAyugkDZNGJM4zkopyqpMIJEdHdskp7p2NVku4tbBS5a3RpC7qqo1zvsqgOSTYy+ZkYKAWqMSTfXZr95zSBpLw+FQWDNBwqmqWsLpGg0kbUV83bkaiDgnoaQozakzM+w/cBiPZX55hYACYwho2p0OmzZMcvnF+9i1ZQNZqLCxZrg8xxtuvYXtm6bol46/+Id/5IOf/CL9YKl9RIUaG2tiNcSXQ5QP6GgwPtAKFVfsnuZn3/6DTBQaqxSZLRKDTsCHLJVvjIIKCitgFejw3ouoceVRyhKVJWu1GJ8YZ/v2LWyd3kiWgUdAwuA9kvVQUrBbYwUIiCLUHWPEaINGEeoKS3JIqwFh8TQz93+esaUnadcLZEq0lmo0JQpvc4ZBkXW6KGtw0aW1powKXRQChiV9mJicu+SCjrI4NWy1xgFU6bOUuoSt6TXMIp6GKa1iQFJJ5Vk1YIl832BRWkl4MUrhXI10x0lgOzHtVAJFmpONjr8GUGmuEZrrFCCg2RzW9EkhSMr3pt43VtcVdV2N9GC0QlgU1iZNNUueW/IEJnXbbabGx5iaGGPDxBiTE2OMj3Xpttt02gVjnQ6toiU6R1r0c0RcXtp2cElTKT0QnZJKaLn8xAZZBQ5UyoQmT1PuX436Hnk3rmqhiWZb89xUEvRu+qCmTJrPUvea8pPfCHAoLK4YPa3c8tCD90GELdu2E5QZCXA3IEKjy9OEsjXhZn4N0CBhnaLh06wlRC1pHq3V93GO2jkJnWtEvV0t25yjcqI11IRtNWvnRe9n9He6ntrJeeRcq5nSJGzv3O8kHE6OXQ5Lqrrm9ts/j1Kwe/duYpQMahPj47SKjK3T02RGWF9NGVdrdZCChA/HBExrnbKIRmGgjvSnfJR3vjZp2kWjlMHYHNl9lb1FasMNQ7yp5VKtpUAjzf6rbUAm5FYz1DZjLp/0lhSKVmHpdnMmxgrGu7loHbUsrVZGnmtJHJJmDI0xaGPJ8hybZVLPgryHnHOiAak1WstEHM3EiRHGrM2M6C5pyDPJSrdu67Zu35623nrXbd2+A+zHvu/lfN/Lb+H5111Jp5Vxaq7HZ75yD1/46j0M+gMYLvHiG6/mvB3TUBQcOn6WL37tQT72qa9w8vQKxBwdc1SwxKgJutFHWh2sNH9FmpHvamabZrtKIFIz49Z0QUqJtop8JjGQEDFUBdYorIHCalqZxiihUHe7XeYX5pmdmRGnzAhQEBFgSsLF5HOI4sSEmNKpawHFUEa0ipRwZ5prE4cYSGE+BLnOg4cPc+rsWQbDEu89VVXTHwxkYG8MH/rghzhz5oyEwSWKuTYmORYiWnlu2Maqc7P69+oiigQaFxSfv/0OfubnfokvfOkuPvulO3nD9/8oH/3Endx++0P8+Nt/jv/+O7/LW77/dfzxO3+TK6/ch/cV/X6fii6z/cBv/48/5h8+9Ane8/6P899+67f5lV/9GTaMZ/zmO97B1Zfs5r1/99s85/priMGhNNzxtTs58MQT+ADPevY17Ni+nccefpjPfuoTnDhymJufcz27d+0gtxIS880mHqTHUYaKWgdc9HJfNdhY4FWbJVtwwmZ8+NFH+L//7t3cduAJenkL72taw2U2rsyxbWWOLcuzZGdPMxY8JqVLLr2jjI7F/hK9wTKxrhksLdNbXGZpqc+TR09xZmaesq4llCBEopLyNzaTrDMqkulINezxQz/wFn7wB97Cnt072Tg5Trdd0GkXtFoZRZGRFzl5nieNooaNRsp6JzV9NLBPf5MG940jnec5dV1hjKFoicMvToXM6DZOoEpMIlIoWvCBdqstdd0adArVbLK1RUhaSwIsZTZLoEGgaBUwCn8TZzIvipFjHqM4k8bIcYuiIBIl21cK+0EJoKSNOP8yq51YH8lpza2VNqMTAJYEfcUpUhBEd8kaTVVV1LVncbnP4sqAmLU4OzMnbTJmDCqHD4HNGzdx3s7dnL9zG8b3Mb7PD33fG3nR867DZjmf+tydfOoL97JUS51QwWNdRLuACjVQo5SjoyIbjGL3ZJeffvvbmJrqMreyTKUURWcME5I/n2bzG4F9EPCvcYjECY8I5wyGzotmmFdkNqdot4m5pTaagJZMlWtaRMPgzI04UdK/yLF11BAiVkditUIxmKV86n7qQ19nqx2ShyHBO0Cjg0NFR3Ql3UzTP30Uf/YwG+Ii2XCGtgmo6NA6FXByaGNs0KBvthgb4CiBgSl8p6mXoQkJWrOWm5LnFBPbQSctOdaAPOJwr4a1SR3nnD5Q2ol8LyGWApKstWZvrUXoW44nbUu6IXG8YxQ26VoQpgGUVLpm7z3DoUwKNG1J9Ika4WuN1pClssqsSZp0hlaroN1q0cpziizHWgGCm4kQawzW2hQeK9eg5QU3ug8B4KQiCQDW3OvadWLMseY5k3R1mvCyJLLcHKNJrCk/X2XZiYOv5RlHKe9VsGKVySj1PBCcI9Pw0P33AZHJDZsoXSSgRPuudlS1H62rBPiU9Zp10lOS79auk5ZR830DBnkR4faJUeN9EKAofb+qx+SoXU3lJCFB5WqqlJxg7Xb5LIk2mt9XtTvneGu/K73H+UhVO4ZVydLivGT2U5qxsTGcqwkxMD4+xsYNU4x12qnfVOR5zmAwZGFhgeGwTCzpWtiwDTAUhKHatCtjzAhoU0kLbO0YoPm3+a/5NvG2RW8r1S2l1gy41iwC6KyCtVpJPy/1JB05HaMoCvJM3nGZsamPSlxiJXVH9L1WJ+V0ZrF5js0LtLY4F6Xca4/kfpP7R60VyZfx4GhcmMZK67Zu6/btaeuaSuu2bt8Bds9Xv0Smao4eOcJd9z3EV+/fz+JA0ta6umJiYpyqdmzfcz5ff/AARVbQH3pMPkkVc6LKJKtblCFNVDrN6q8ZtayOlaEZEif2jQBQzUhaffP+Kg2dknMuX0RUDGgCKjisBoJDx0BmFb3lZWZnZgjBUxQtAElTngYuDeNpBCohjAy0QRsRLVbaJF2i1ZAzGS6vuZM4EnNAa9EkODs7S1FktIoMAJOcbGssg+GQxx59jJ27djI9vQWFCCYnX0CuU6UB2aqPMBrUodQqQKFk8BVQ1F7xPW/+Ac674FLe+/4P88bvezOHjjzF+9/7QT7xLx/ju1/yIn7rN36Fl7z4BohDjJH07e9+93v4nT/4S171uu/hGc++ir/8q3cxc3aBX/+1/4cbrrmMyy88n2OHDnPTtc9k33lb8T5y6PBT3PuN+9m9dy/nnXc+1193PU8ePsSZUydot3Iuvfgi9uzdxfjkmOiF+Fq0IYxJFLBkCplxNQqTZ0SQgSwGZVsMVMYMmgdm5/mTj32cf7nnHpbzLirLaROZdI6NZY8t1YCxlQVaK8t0FSJm7GqGwyEr/T7zy4s47xkOhyzML7C4uMzxk6c5duIUg8qjlJS11hatLTGJ+WqlCN7h64obbriWN3/vm7jk4ouYGB+j226JVkphJbuStVibYY2VTDjapFlYAQ8bNl0Tmkkqz8aZVWk22GY5ZeWwWU7t6pGjkWUZdQoLa+pfiIHMZmilR9nfhLGQhL5TqEoDfKAQLSNjcK5hpcgstk/Z4kKjn6SEbWMzi3eeLJe6rBMQ6lw9OrdKbJa1gIQxFgU451FrhI+99yjTOEapVelGNFlCgZSQ8/Des7DU47GDT3L3/Q8TTIuxdsZN119H8FFYWlpSeltjGRsb48SJ47zuta/lhuuuI/iaD3/0s/zDhz+O7kwRjIRjqAA6NG1XWD02elquZOeGLj//H/4dUxvGOfDkk/zZX/wVN9/8XDpFjo4iZNuE4AoTJJVpiomSNip3ppPgduL+kKXnUAdHtOIgaTSZzsWBV6DwKCIk8GhpZZnHnjzK4YU+rj1GrGsu2baVZ+7Zjlo6zfLjdzN4/A52xhmyagmrpP+IhAROefLMgPP4OnJmZp5N01spOhNARmz6uAY8lGJZBVbW9nVpu/Tdcq9xtK98lnMnz7TZb81vGyAuvRXEgRVUS36f6vCozqZfq7SvSsw5qTfyWae1Sc93BHYlYfjQhJWlPlVqmhyvAaSaazHGjDLXGZNROc/BQ4cpazeaVGiccyVFPjqW1girLU0QKJWyZ9Wesiopy4q6kpBVEeIPUu7yUkqaSj0Wl1YYlhVZlpMXBcaKI+2coyqH9Hsr9Pt9vEuMTi2Ofnd8nG6nKyGNZUm/38N5R6vVYtOmjYyPj5FnmZzLC0tH7n9V289o0X9qMnNpLZqDfo3gtoA9wibUwaHqAZ/71MfpTEzxkpe9iioa6pjYlwmQGukdhQTopeYXR3pHUgjSL0h5rv082kY6TgphWwW80mt4dFypT6Nm3mxPLCzhUq5eQ3Ps9ConNuyv5jfpuzA6VoQYiL5mfuYMn/7EJxjrdnnhC1/EkWPH8SjOP/88zj//PKlbWiamBoMBvd4KLk0QdDrt1C4sIcJyrwcJmDHaYrWwPQflUBilwLB0UpecG4FrIYQEeDcPtQED5SZjSIykIG1BkcDrmJpEarvGGLLEghUgStpMTG3SGLMqIo4mJtH6clAy6A9Z6Q3pDyuqSgTUa1fjGz2mIFn1qrJiaXGJfn+ItXkCO1OfECJ5njExNi4TH5nF144QvDBzWy0uuuiS1Ytet3Vbt28bWweV1m3dvgPsjttvI88zPvQvH2O27witKcpoCCbnyLGTjE9tZGGpx2du/zL9YAheoW2Hfh2JWS6OQ5QsQ+KHiPhoGralJQ3AR05H2tp4Mgk4GjkPzXfpe3HWFKjkyBHRKmnuRI9RkW47x9VDTjx5iBAjRdESHQNXk+W5OIIxeayJ5YNKi5YQN2NsEmZOmeoa4EmuCJRQwCEJNkQo8py6riWMJQ14l5bmGe+2abVa5HmemCaOVtGi1++z/7H9XPPsZ9PudCCxo3QKoWkG4hIq1dx7Or1CYKQRsIToN+Rt5pZ6fP6Ld6BswcnTJ/nsZz7B5RddwJ//zz/kZbfewqaNLaz5/7D3nwGzJVd5L/6rqh06vOnkM1mT80iTpFEYJSwRhcAyQRKSwMSL7704cB3vxbIx/mMw2ET7AiYYXUAiCRBIBgWE0oxyGM1ocjhzcnpTd+9UVf8Pa9XuPkcD5utY75rp02/v3r137dpVtWs99axnCROo6wJt47n++uv5sZ/8L3zui/fzv/3g97K6tMKf/OEfcd2Vz+HGay7j4N5dfM2rXsVAQbI/etf/4Oz6Fmu7d3HjjTdS5Dl//j/ezdnTp3juLTfxnMsupSwLlpeWhNFEYDQo+9Ae9RAWbjJ4BR9tNEQPsy7SDIZsDIf8wSc/xc/+/h9yNBgm+QBjHWXdsFZXXBRa9lRTOHGM1RgZeGkPVVvTdi1b65s0bQfWsTWZsLk1YXta8dTTR1jf3MZmBQEjIW5ZLg6F6pkIoCShHW98w7fzd175MnavrbI8GjMcCIOnKMTxyjRVt7MKJml2QmFBJEBpzi5KDvPiZ+9FW6jzgRANW9vblIMBbduS56Ipk+eSzj5q+JwwQURg1VrpcSKeLeFu3kv2tdTfANqu69kSvvNUdcVgMKCqK/Isp2s7CVNQRyI5E2g3TaDU4jET4Ctl0P1jxJEAM0vXtVgrYWM+sZl6x07YH3ISHUNiZHsyZVI1PPDw4zzw6FOQD3noi5/j7he9iAMHLsBqti1DZHm0xGBQ8IIX3MlVV17J0tIav/Sbv8P7PvxxstEqLQ6siowHdQgD+GhwMbBSwMhX/N//5Ic4eHAfrXX8u5/4aU4cP8nXvfqrWRrk1M1Uxjoj7JYUBmSsOOMJxJPxClQGGGeEaZQ5Sxc8NtPxQwXCQye6WRiwCiqZKCGGm1tbPPCkgEp+tEwW4Dl7d3H71ZdSH76fRz7we1yZb7LWnaXIbR8qk+WZOI0aqljajBzRtnvi6aPsv/hqWjOkIaeJAnh13kudatuxCTVZMLsAglpl1jkrYrwi8C4AY2oDAjKl8Xze/51NQJyyvlI2wyBC88lMGvO0LFFD40CYO84KU2kORkl/iAvMP6dgkrB0+sKAZqyTbUaYN97LgoKRums7z8OPzkElcd4FsED7oQ+eGLxmrUs5LKUNt11H1TTMZhWzqqaua9pWQjtD0qwJkRgCdd2wtT1hY2uLqm4pBirUrWFDIQSaumayvSVC3Rp6agwU5YDxaMxgNMQ6R1XVTKdTOs0EuXvXLpaXxqJtFlDmTYdXUEmea4hQdyasqywXFhaI1lFi63Qh4E0mwLIJTM6e5OMf/RAXXnIZL7z7FUzbiFeWcYii/SVgt7wnsCbBrXJfFKyMCNCtKE+Uf+bvmllM8JFUd/P7GXUfaSt6LgWt0liTmsF82+JLypT267fpj9JvQhCNM0LH4UNP8tG/+kv27N7Ny172Uh585BGyvOT6665nz+5d+nzIqOuazc1NjDUMBgNCCCwtjXHOYYyE3W9Npv2zAj2Ps46mbanrmq3tCdNZzdb2NtPpjKqWzGp1VdM0DU3d0NQ1bdPQNK18buSzbGvo2o62aWlbeXVtK+HOXSvjR9fRtQ11VVPNKmazKdPJlKqqaJqGelLTVHLO2WTK9uY26+ubnD27xZmzm6xvbLO5NWNre8Jkss1kOmUy2WY6mbCt5SbKczb4qHqbci+D9telpSWMkXEilRMjGVWvuupquYE7tmM79qyyHVBpx3bsK8A+8ZnPUEfLVTc8ly89/jTbdQeuIJiCzg147PAJHnn6OB0Z1lgyV9DGiM8M3gWMbbGhw8VOQB4bFfyJz/xaYGAnW1jP1n3SSrmCOMb0S2smrR0qU6nMHG094/TJE2ysn2Y4GlAozTpGI+nUNRU0Vn+dwCQAY3HWkWc5zkkKeHH2laG0UFBJgJ6KIhNL33U4a1UcVFKBEwNnT51Qqrgc07mMoBm1ZrMpn//857nqyqtYXV3F6ARS2A/zcARI9aB1YyPGBH1J/Xhj8NHy3Fvv5NOfu58/+dN3c/LIYb725S/in/9f38uBAznYhroNPPHkGV7/hr/P8aPHeckL72RpmPG8O17I29/+B6yMlvnWb/p6VgaGk4ef4kXPfyFFljOrJpw8eZpPfvqLTOqWG268keuuvZb1M2c49OTj7F5b4Y7bb2V1ZVkBjRwfWqCjzAuiptyOQcWcxVVMfgCEQBYNWXR4H5kNBvzV44/wE+/8Pf7ki/dRjVdpzAC6jKXYcDB4DsxmLJ0+RXb2DEvWQtPRtR11VTGtJkwn22TB0FQN29tT1je3OXF6nScPH6UN4MoCnLSpGKS9OevI8gKDiFi/8hUv4w3f/m1ceflljIcF4+GAIiuwxoogaZ5RDkrVPFFgSbW35loRyUGYA0jzV6oLYVsQYWs6w4dIUQwAQ16IKDzG0NQNkXn4TVAnXlgPwlho21YYR1HZT8Frl5PzZMrW850Xhhyi3ZVlKWtacmYkA1xc0EYyWkfJIXZO/pbyy3V2XadjhGYBSxnREotEnX1hSEipEivQGAGIRLRYVre3pjWfv/8hHj10lDpYRpnnUx//OLfcfCsHDuwh+FrOEQ3DYUFeZDzxxJP80q/8d97/iYfIlpZpAR8hkkMwAijhCSYSyTFdy94SfvgHv5vLL7uAw6dO8m/+43/moUefZtdwiW/5hq9naZARMhGWTUCJDmUY9HpUpDwNEA0NGZBHQ2YcTWiJmfwwjxbnwXdBgE3VLnFRmUpYQtOxub3FA089zWMbE7rRMs5HrjpwgOdedgFbD9+De+pTXF7MWIozgpXQ2TwX1l+MmYzZroAOBjanjpbKjli56DrM0oXU+RIxLzGhxSmYkwDLfthZsEjEGWUWKTszRrl2q4LyiRGUgM55M5d2b5N+jzTrORtC+0ECMrXbLJhs09Odw1Sa7zFv6/PjzffXZQt5nCywzdK+/b1FhJDrtuXhRx6jblsRVO6CCKajQsNBFgt81xKVfSTPJhGEbtpWAJ7ZjOl0Dix1qqnjO9EC8l3XZ6Bc39hkWtUYK2HRKGtPwIMZ1WzKbDrVvif9Ps9yRqMRw9EQay1VVTOZbFPXNXmesWtlhfFoJP1X2SJV3dK2kvodk+6tkbDLTEKaYpRrbBpPXbdUTUPdNDSdJBPwzYyTR57gvs9/lquvu4Frb3we27Wn9RCjgG1Jf+2cVwwS5qWMGgn3EtFpYa7M31NYujwf5ZoXgR75TvaX8qbfCDOm3x7TPZNX2jeNNc/03Ze9YhDR8LaVRZ3Y8cSjD/Hpe+/l4ksu5Jprr+Wpw0fAFVxzzTWMhiUxBKpqxqnTp6WsqjkHkfFoqGw66HxgY3MTj4yTaRHGKIuNXg9LNY4Q0W2MtGtrLc5ZnLESeq3ZRtNzyOk8Zz6/mfdHq5noXMpCC3pueW73IapYTLQ4DY8jGIKPEqLYeurG03ZRM9ACCCMr6nGiMmIFWI0EHQNFC6uVJA3AaDCQjk6krgXcCiFSFCXXXnON9tAd27EdezbZDqi0Yzv2FWBve8fvM1pewWQFg9ESjz36GHmm6bZBmBc2A+NEdDai0foSRmKDUKGxjtCHkjmIrl+3NVHFtc0CfGR0STetGCYnwhhaFQxOckrWgjUeGxoKE3GhwXYzVsqMp594jOnWJt535MWAYjgmupzOWKK1YISlYFwm2ibIhMspO6gYLGmmL2GWROMADZGzklpaRLH1WtTxFqcn4mNHNDK5F4ceQnA4N+Tsxhara6tYZ8gyQ144yWhiDPWs5snHnuSuF76QoHo2ydkxOtFbBJSSAybEHmFEhABdF8nyAZ//whf55V/+FX70R3+Uf/oPv5+/86KbGQwswWR85vMP86/e+pP83W99I66w/Oef+2luve15XHTRZSyv7ebxxx/BxJYXvfAObr31Zu6441YigUcff4TtyYR7Pv4JvA+84I7buODAPo4eOcQXPv9pLr7wINdceyVFIZluBJSIGv6VS4qdBCw4hzeiI2OcgdjhrKfDULuSTVdyrFjil9/3V/zXP30vRzqDKUdY31E0U1aaLW5spqxsniHbXqcIDcY3mNDRNRVtU7E93daV2o6t7SnbsxnHTp3msScPsbU9w7oCmxfEIJP4GCCzGbnNsKpjs7o85vu++zu5/Xk3s7a6xHhUUhYFmcsoBkPJ6Jbn5HmBy3LyLGV408m7TuhjYpolZ1pdWpm8i0h8BLpY0HQ5weZ89nP3gbGs7dpF1dby6xTCYyUleQqDi0FCKn0QgCh4FeZAWEguk1Aeo45CjIFZVfWAVJ5nlIOBgmqyKtx5T57LynrXtgwGAxHNVhApqB5Tz0jRa3RO2E9EcYDR0CLrHFgJm/Ah4DKHsVbD7VQjw0S60AqwhCV6AY2n0y02tre5/+FHefzwCTwD/GCJSXC880//nCZkHLzoKtxgNxu15fOPHeNXf+/P+JXffRfHpx12sKR9V+sdT+4gho7cQBZbrK/YPYR/9L1v4uorLsUS+MX/95f41OcewA7XKDL4hq9+GculofOqnaTH7AeyCN53fYhLYlqUeS66bS4jZjlYLUdixQDGZUDAmpZIJOj4Z0ykbWdstS0PHD7KI8dPEwfLEAOX71vlRVdcwPoTjxBOPcn+IQxNIDa1OJNO9E18bDGhwfoWQmRCySm7h/zyOygvv4NusErbzDBtJYC3F3DcYITMqWwNo6wPg8E5YUNZ58gyR9d25EUhIIoKfc/rR8f63oHth7JUbaAQWhpTk0U5PUT5Lmp4W9Csd+lg6fgyPso9UaxBxmvVg8EY0BAbg4SlGnWeBeCcl0FADgjRUHeBT372c0ybjoCj7jpaH6k70QmqG3Gmq0a2dwEaH6naQOMD07plMqvYnsyYTmcKKjU966duPXXTUVcC8mxubrG+uSlsDq2DrtMU8m1HNZ2yvbFOW4mQvjUCJA4GI4pygLE5XTDMpg3bW9vUVYWzGcPRGJcVdAGmdcu0qqnqpnfk267tmVYhRLrW03WRuu2Y1p5JVTOZVdR1y2xSEXxN6GqmG+ucPnyYxx64nxtvvYM9l1zJJGTYoJm9egZKehQoAyi9R11MSWFc6TfP8DkdK4E/PSiVzpGyv+kxU5a0EPXc/buw2tJLfmPw0cjCkII66RUTqyrKAkTTVMQE6vvApz/6IR578AFuuO56gsnZbsENxlx48SU0bcvm9pRjJ06xNZnStp3qOnnqusHaDB8NjY9Mq5qTp09TNy113UpoW4zS5kKk8YHWRyZV3QuX+64j+E57kS6QRNWoE37Xl5kw1ASoi6SMeR0xSBbIEANd8HTB0wZPq6LqddvKuN7VxOjpYqDuPNOmZdp28l43zJpWfpt0q3zSpOqo2o4uiNZW1bTMmoZZU7FVV0ybhqrtaH3QrJSembKzJpOZaFrVHbfdesv5l7RjO7ZjzwLbAZV2bMe+Auxf//ufYs++C8iHy6zu3sfWdsXGpsT2y7Q9EfoNpkd+dMKv/8k2YQGlv+Xb5B0kB0BPurAibNQRwcwZRDLplzA6RwDfYkOL9TWOQG4izWzK0aefxmUZZTlgOF4mKwcE4whRypyck0iaVArgIavAGXlZiiZUAouM0ZC45IxIWeU7ZTb1lyHObwgSvpKcH9luJTsOcPLkCXbtWhXNDRVQNtFQFiWbm5scevpprr7maoqiwGnWk/6cera5z6UC4egKvDGqA2Q4duwk737P/yDPc+5+0e3krsPkFlsM+auPfpLf+u0/YFa1fOd3vZkQPL/4C/8V50o+ds89fP7zn+VN3/EGLjh4AN+1ZJnj9JnTPPHkE2xubXLTTTdz1ZVXsL25zr0f+xhdW/PCu17A/v17tYrkzvemH6wPKhZjFdCTkJPQdTJ5NYatrOSszfnoI4/xc7//Tj5w3wN0w2Wiycjqhl3es9s37G5mLK2fxs2mZKHD+I7YNdRVRVXNmM1m+CiT9emsYmt7xpFjxzl+6rQAnhiihqYlBo6s4IpYdZ5n3Pa85/Kt3/I6Ljh4gEGZUxa5hLnlOc5lZLnobblMRNWdlWw81kgYVGLsqJ8rQFIPKAm4gqaGjhh8gLqFT37mPj716c+wtLzCcy5/jgAQ2ke891hlJzVNQ55JZjDrLJ3vxAn2gSzPJNwtquD2oqixMpcyJ1mgrJNVb++9cu+EoYI65d53WOtoGmGwJEaKXdBdkhVwudGJvWSdrI4DfRhH50X7JYFZIURJN40Ie/uoOksYbNRQKu+ZVVNmTcuDjz7Bk4dP4E2JLUcYV5IVAz73hQf4zd/+Xf7wXe/hbb/7+7z7Ax/i2NltTDkmZiVeBWBNFGg7IkLdIE5UFlvGWeAN3/R13PW8GxgPCo4dPcr7PvgRTm7WhGKZ3Hi+7Zu+lpVShIfNgihyVBAmc6I7I0wXzUDpLCbpmkhXgBixMQpBTkdHYyR02FkjgrXGYaLI0vq248zWlC8++hRPnFgnFGNyIlfvX+OFl1/I5tOPwplHuGDckccWXMEkZszMgCoOaCkIeszOZGy6FaYrl3HZ87+W6XAfjcmUVepl/FNtJQkfA5T9IONb+juqRpwAA4nFFlRQuGcuKXMujV39WLpgZuGf+Vi38H3aFIVlFNJzgjkAJD//8t+KaR9SQKz/zQJ4JH1VQFIJq5JQvKSlN6kqPv2Zz7E9q6lbr2LPzZyxU0tIUV3XNE0roEEjIW9V3QhDaTZjNquompqmFqZS07Y0TUutoXFVVYmA8+Ym6+sbbG9P9LqkzgVYamnqmk7DmYL3GAXyjXVkmTw/QoSqqphOt2mqiogwmSIi7F9VNZPplFk10+xlWqZaQ6Tqmmo2Y1ZVTCYzJtMZW5MJW6rl1NQtVTWhbWtCU/OZe+9h/eRxnvv8F7G8/yJmwYEuCvVaRimcTG5nDyjNt8sGAWTT53Pf07NVgBM5jvxMelj/3m+fv/r99OSpDPI70SVcLCOqCZXKmPYDCbHEOGEE+Y7P3PNhDj/1ODfdfBNHj5+iWFojy0tG4zHbkymHjx1nY2ubWVVTNY2CkA2TWYWPkapu2ZpMmEymnD5zRrLXtdKGplXFdFYzq4TlVtU1TdfRadhaYrm1rWh1pVcKa+vD3JqGppX764OEeXrfSThc19E1DaHr8P1LQuI6fa9S4pG6wTeVtF8VKp/Vci3TWcV0NqOqBTit2/SS62majrrW39UNs7pmWtfMqppJXTOtG7YVePUhsD2ZyDGn0jems4rJrOJlL7lLbtyO7diOPats7kHt2I7t2P+yVoeS93/oExw5scHbf/9dPPL4IQIZEWEbJRfoy7yCv8HEHU6hXPLTaAR0mqtOKPMH29OqNV8J1lh82+JiII+BkkAWWpYHObGpePKxxzh29DjFYMzS6i6K0TLRFQRXYLMBLis0g4mACCAMGYwwaAbDJcrREtFkmkJX3o2+W6thTEbEm43NlO2UY7Jc3p1851wmDtli/URJh2udpfWeL33pYZraM5u1tG0ADFU1YzAsefSxR3nHO96OMeKMCmV9fqxFQGn+Pp8RWyPw2W233sIP/e8/yObZUzIBxeFtyda0wbqM3bt38/a3v513vOP3+D//j3/Iv/m3P8ZnPnMf08mU//gTP87znnszTdOANXz6s5/l7e/4Xa6++mruuusFHNi3h7/64Ad48EsP8IIX3MmLX/RCEQAm6PnnTp4BZWIIld3IzRdgg0BbTQkRZjg23YBjpuBX/+J9/Oiv/Tr3nzoJS0tApKwr9ncdB6qK/dsTls6eIfcddC1tNWO6vcVsNmNre4umbfERticzNrYmnDqzwYMPP8rpsxtYl4GxZHlOWRZkmaUockLwmBho24q9e9f4+3//LXzTN72GPXvWWF5eYjgUTaxBOaAsS/1tRpZJWIqEbSmIdF6YmzUCMMiWKGGbBmEbNC0Rh48ZWT7iZ3/uF3n4kUf51m/7du67/362p1NhfyggJGFmAh71+jAKWLRtS+YyycYWIk3TEEKgU72VoOFvydlvW8lM1DSNsI2QFfit7W1clsm9AtpG7l1M4Z1OmItd1wk7SlkpXSf6PVkmoZ2SBU0yxSXnXVhROSEKaCUMKmVHaTY5o6EZ6bpEc0mud1AUZNbgTCAzlhgMdRsgL1ndfxA3XqZc3c3Srr24cggmw7liDnAnANtYEWR3jtxZbGj4nu/4Vl754uezMippqwlnzpxW3Ri0j+f4KFpsXlkdMbQQvUg0xU5DPQPeNwTfElUXyftA9JHoxYlL4VHabUHDZ4kQgiEEYUN1XtiHMToIjtzmuABFNNi2wbQ1vm3p2gpDCzbS2JxNt8IJu4ePH2748OMVD54dsu4OcDouc4oRj2wGDt54F91oD5W3BOsIeUbQ0MeYADAdWuTuaaY2a/HKUvOdhLOapMPkVGNKnW+rbVRswdFHDnrOfv0Xf40ZBfq1NP/zH8zN2rn+E+eEdCqAqu3bapY3CSsVRl8KbSNG8qIg1wxtRZ6TZZLmPHMabuREPy3TDF9GOg7eC/PDGEOWSx8dDoeMRiMGgwF5kbLHKRDrBNiTsCUNCXUCAM/DmOSz7Hc+UJaYO8I2Edak9NtWNXnqqmY2m9E2bR82S4TMOpwVcL1T4Gw2nTKdTZnNptR1Rdc2hNCR55LZLnMWYyLTyYRyMKQsh1R1gw9exhgFOtpOQv0E7FDQo/Ma8pTCnnS/ztP5/8l7erXnff6fbU/H8OdvFyCl6zxet7WL3y3u7wMhIABc2+K9Z3trC2sMS8srVE2DtZbBoGQym3Hk5Cm2ZhV1F2giTJuOugvMGmH4bM8atquG6aymbluRe1MgS7qJAs89iC8s10y1/PI8F8ZpWTA471UWpfxdyOJImeciwO6cJJfoQ+IsK8tLrKwss7K8zPLSEkvjJYbDAUbBNqsi7hIqmITb53WFsk6zLCcvCoqyIC8E/HfFAFeU2LzA5qUs+n3ZKxP2l3F0QRiC06Zje1YzrTtmrX6umsUuvmM7tmPPIjMxQfQ7tmM79r+sXf/yN8iKWRtwxVCZPuqMJS8jqnO8MKl/puGh35Yyv0V6EnaM4hv0K3+6MdMJvkJQmCihKhkdNjbkSJYZ3804dfII29tTXFYwGIxxeYnNSnwEHyNez2VjEtIWOntymCQNtDB7fEi6ROIEyURO0i1L6fR3+pLPAWKA0IFvMaHDtzUksVZN4WyVDRODBwImBtZWVrju2mvYs3tFGQ+wvLQMygB48UtezGu/8bVkeY5LqdhZ8KcUnIEU5iRCwJgMbE7jxdmuu8Av/9p/58nDR7jrhc/n1ltv4+yZTf7BD/4QP/IjP8KP/D//nH/2z36Yb//Wb6WtPYXzFLnlSw89xJNPPIUxkZMnT3L3i1/M6sqYw08f4ulDT3HXXc/HGst4PCZzlhDFwSDpP/T33xBMINjAoHPYaAlEWhvAQvTQuSGnyXjffV/kHR/+GA+fPo0bDvGZIccwajv2Rdhd1wy2NhhUU0o8nRFmQKsr69F7ZQhIOMrWZMrho0c5c3YD78FlwizCis6QtQtaIT5QFhmvePlLuf22W1lZWWE0GjAajVgeLxFjIM+chLs5h9H2g7I2kpOXwmgSW8Vo9h5t4FgroFI0RrPcZGALPvLRT9K1cNV11/G2/+9tLC8tsXffbl7+8peytrZK21TCLNLm2HXdHJCR1kieCViTdEsSUJNMwt60XSfnWrPGpTA1a62EYgGd78gzyfSWgKMeVAge2zsZC6y9c5x2+TtpL1l1fn3n+zA87z0RKY81irxZA1GyoRED3tdsbq6zOan44L2f4Z3v+SDbjaPNxgSbi4MT5PhZplkdVQcnJjbcgl5O6kPRN7jQsFzA677ulbz8hXdwcPcK1reEruXzDzzEz//623lyPcDSHpZNzW/+/I9zcCyZ7Hyo5H6iYVNGwBUZX+b17GxG2whYhvYLYwxRQ1+jls0o8ysahMlnLZZIHgNtU/P4kRO8+6Of4AOffxCz9wKin/Gq517Ld7/s+Tz5oT+ieOz93LwHmtrz4NnI49uW0cHLceWYU088Qdw6xt5Vx649uzhw4wu57I6vphrsp3EjYcNZCF1DqeGRidETFc8BCdXrQ8WiiGJHBSNsYjIpY4nE/tE6kUPo6NC/p5vSn6RvQ+ebYEryHJJziUhzD6aknXpLzjjKjpLsgFZDE1P5Utsw2pe7IEAZ6T4aaDWM7S8//DFmbQDVXJN95FzpOqI+RXr2mUnXOW8XaJtJwKL8XI7hLLSd59TpMxw7doz1jU1cnlMOhgL2GksXAtVki62zZ9ja3KSuZ/31DEZjlldWGS+tUAwGElI32aZra4bDIfv27WPP7j0sLS9ptlFl2+k14+RzygaWio81RDT0LAZCBIvDOTh75gxbp0/xW//tV7Am8trv+C7KfZdQmQLbNDIWngO2S/1Y5m2hv486nPSfn+k9gfRRF6qegX12/vZki/tJceRC5/tpyXTe0u+vTzbJZKvnt8JCzq3B1Nv8zI/9CFunT/DGN7+FRw4dY9eBizl48cUUwzH1ArhuTBKxn48HKyurjMdjXBQA8+Sp02AkTE/KKnICc9NMbtpupG0tfK37iMm1yvifns3z/YNqpw0GJSvLY1x6lilYGbxnMplIZlEnSQ4MwrYUFmoK95VzpVDCNDYEA9qr1GQ8kHFG25f+KwsOBkIgs5Y9u9eEpW4tvmvo2gYLFFnOv/jf37xwzB3bsR17ttgOqLRjO/YVYBe+6PWSmakoicZRNa2yFnTCmTIynWfPNDykbcaooKaGaaXgqP4X6nDEGLExYKNASpaAiZ7YNeQ24ugoHJw6cZzjTz9FsTSiHIxwubCRIo6YdIxikFTaeiKTnA91KIyxuCyj6TqZcKX00ToJEldBRRgWrifGOcMAIiF6SUWuoFLoamLXEbtWnZ5AluvKvnP4Lkj4TQwsj8c895brGY8GDMqcLBfhc6MsjeffeSdveOMbcC5brC01o5luhO8VowcTyfOCECBgibYgy0v+6D0f5F/865/gqisv49iRp5lsb3H61Ak+9MH389jjD3H69An+3t/7u9RVgwuRY0eOsLSywjv/+E+47LLncMstt7C1uc7nPvMpYtfwja/5evJcMpzFGHAKKqU7m9hIMmk1BGsIzjCIlkwnwQ2ezjpmruSp7Zaf+O+/zacPHydb2UUXAya25GHGrgzWQsdwsk2+PWXVOrrJFAdMq7Oi1VBLNrF6VrM9mTKtak6dXefQ4aPYTPS/rMuxCm7IfFX1gqyB4Lnsssv4tm/7VvbuWWVpaUiRS4bAPMspiwIUnMizrBc3dVnWT7ptmoAj3k7/OYW7hQysJ9pOQoysoe0C1o342Z/7Zfbtv5Rv+IbX8YEPvp+vf83X8FM/9R+58YbreelL7wYCZZ7TNJXo3JznPBHVKdBMVyChZEVR4IMncxmd76QfGPXGIpSDUsIdNJtO13a4PKPrOoqi6J2UrpWMiYmdEjVcMHoBHiICLGVZJiF5uWSZ813S1ZFMdBjo2o5yUKqIuIh9RyRkT5x9aenO5aKP0jUYE5lsb7E1rfn0F77Er/32H7DdQDdYg3wgvl8XeicYDCZzeCPODEQKoCOjM44IZLFhJfcU3YQf/N63cPUVl2NtxvbmBhcf2E1opjz82JP8p1/6TQ5tRtzyXsJ0nZ/59/8Pt1x9CU3T0jUzGauMZtJzwkYUhpWEJJrEfHEFTjq+sOKspfVBgI4QEZafOG9eKkBW+60lB3zbst14/vyj9/KnH/k4s3yEzVr+zu3X85YX3cETH/xDiif+iqt2F9z/5Gm6A7dw0W0voStGTCYTmu1NZmePc+rIU1x66cXc/rJXw/J+KjOgi5bSFeAlnI3Y9qONTSFj2rYTWGitw3fdvM3p9fb3UUes2ANPemf68LfUhmV77KPZEggQeyeTBcdefy3tRJ3jvj8sHlCvIJ3XmrnAvGxfOKaZiy+l7V41hRLA0XqofeSz993PpO4wTlgYtj/f3M5/FqY6ON9iFAbb+WN7jBLedvLkSQ4fPcrZs+tELGVZ4vJcQCXvmW5vsXH6JBsbG9SVgEoAS0tLLK2ssryyynA0pu0CTT0l+o7RaMz+ffvYs3cvqysrFGUpYK+CmwkoZKH2zUL9+4WU8GAkWYEznDhymOOHD/EzP/kf2LP3AK95w3cRRrugHGFDJ8LMCWRMr/nd7Mclo+BHusmpvSx+3++nZet//ze8y9Hk83ybgDqL+/TtZ+FcqAC8nDGe0x7TsyAj0Gye4t//qx8mN5E3//3v4cykoVha4/IrrhLtvqS9ZAxex9i2k7qxzrG6ssLS0hJOxdiPHz+OMaLjaDUjZgRM0oI0yKLWeZban7xp/eg4HVVvSuYx6fKE1TYYDNi9ezeDQjJ+yjxJXjFGJpMJGxsbEFUfT1lL87MgLHDVB4Q0D0igUoSeASkLdqms6Q6Y1Pf02jKXsWttFWcieeZo6oqmEo2xPMv4oe98nf5yx3Zsx55NtgMq7diOfQXYwbvfInR7mUrqJCZN3iKmB5WS2KkOC/3bwjDR/ymAQzTpN/JCNUmi1xTMxmCQLG65DVjfYENNZiKGwPbmBsdPHKftOgbDEYPhGJflYHOipshuu071TCIQCL7TEDvR+DBWsnGh4FNEcCO5TiNsIp2MxZhqQCZBUVeaZWIk7yExlUKHiR2haYi+FVDJt8ToCdFLOuZoZAU0pDCLjgP7d3PF5ZeytrZMUTgMjsFgoOFVOV/1Va/k7rvvpiwHMim24qQaY2U+aRLQJ9cr4VGRLC/xGIxxbNY5v/wbf8gH3v/n/MP/8x8w2T7LJ+79CD/8T36I0bDA2kjVVMymUx74wv0cOXyM62+8kbXde+m6ji/cdx/WRJ5zycVcefklDAsBVqJOtkP04oz2cKGcN+qqqHEZPkKZZ2RGtIMaLMenDe/93Bf588/dx6NbEyYuJ1YNY2sofcUaNWuxwZ89ybCrKaMhNJ7QBQk56LZETyRAXbdMJjM2tyecOH2WM+uboCFp2IwYrdSP3Agya2iamtXlJZ5/5x3c/ZIXs2vXLkajnLLIsNaK+LaVlOJ5LuLcmWrFGCOZBGXirWFvCw6LS2wIooRdBgs2EK2AnYFINI5IweHDp3j72/+Iqva8/BV3s7w6osgzBoMB+/ftk/I6CyFofQsTyVpLDMIeMgm8yKTvBs2oZIz0UYNmPuy8hgJJu06AkNFsbS4T0CWodk7UkLs+S9GCkyEgSCDTjIpoGJPXMDjxakSfJjGmhLmnjkYCk5XNlPqXAHLCiAq+g+BFlHhW88jjT/Orb3s7h06coRvtJmQDoo+4aLFI6BVGwoe8UWYikSJG2mDxxohQfjfhotWCt3zbN3HbLTfSxYx3vPPP+OjH7uG73/zt3HnzNTz++JP8p1/6DZ482+DGu7G+5sCuJQ7uWSOQsuuJflZq+XJBSatN7gPGELqW3BoyJ/cpgITomkyhbwHRpVNHyDSDoBE2R/QBWww4tT3l+LSiK0cMXcOrb72WN73oVh79wNspDt/L5ftXCXuuI7viJcTVAwQMfrbNpJpC8OTWsmfXLkYrK/gspwkGTEaOw3lhdMZMHE+n4VfSUGRkT85mAjCkfemlG9FWIgEG+l1qKzGBVAvv6f7LcZMjr0BWOoaCWrKjuvaKQiWgIlV9Dwokx7q/JfN2m/Zf/DuxrFAGkWxW9hnQRpg1Hfd88tNsTmtcMRDwLATQ50ey9AxMTn2Moq31tzIjGmZt23Hm7FmOHz/BxuYGIcoY5DJhFnXeU89mbK2fZXt7qweVjJEU9eOlZZaWhakkoVwNlshwOGLPnt3s3r1HAAwNVxSTsqbxJAEmxoj+HzquCGgqoAQRxqMRp44d4eEH7uNX/8svctOdL+bWl3wVjHbRYAldo8k+5H6aXldufj/7NqN1sLjvM/2ddptvky1/7Wf0di6ASKY/YWp3C20otcV07v6YMpam76NqoOWx5fThx/m5H38rF15wkFd97WuI5RjvSi695FJaH/oxwqsOnYR+CqBjjGE8XmJleVlYo8DJkyd1zqKvVOCFgpvzuEtiX75FnsUqyK0MoqjzF6NtdTwes3v3bkxiPy/Ud4yRpq5ZX1+XsOdM9Pj6ca+3vhIXXtInQpTrIvU9fdcd+voOUUClEANFnrOytIRB6rltKtqmAdVt+5Ef+u7+mDu2Yzv27LEdUGnHduwrwC54xffoX/PubgwKXIjDY9IEIIpGw+LI8MzDRIfkTJEVtvlkQ+GlGITtE6NkLIodxleUtGS0dNWUw08fompaxqu7sXlBPhgRyBSkkmADSKCQh9hpeQPGlGBlhZfkKOlqb9QJVT856gGaZAIeyXWmCZA4qjIxE0CM6CEIqEQQ0ejYie5EiJ06i7YXaSZF+YSWXWvLPPe5N1IOCnKXkWtY0+raGk3T8Pzn38m3/L1v6RljCVAICioZBFgSrR6pB4MInRssnV3CDgb8m3/94/zGr/03PvrRv+SqKy5ia3ODPHO0bcvnvvA57rn3Y1x/zQ1ce+317Nm3n8l0xmc/91mqquKu5z+f1eUxoa0o8oy2qcmyXNuJUsF6ACLO7wfCqMpchilyXF7SBMehY+t85z/55xyzlkvvuJV134AxjGYTluqKfWVOtnkGf/oEK7mBrqZpGzofmVUNbdMRY03btsxmNdWs4fjJU5w8fRZcLk5/8Jpm2eJsTtfU5EWGIdI1NTdcfx1/95u/iQP791HkAhjlhSXPjLKSRDfJWmG1OSMC2dY5Wc3vwzQWQSVLnmWib6RMJhCHOBrwPmCznPe9/y/ZvXc/N938PMBy/PhJ/sW//Ffc/dIXs3fvbr7u676OPMupq4qyLJlMJr2Wiw8dRsEag4Aa8/ML2JFCzlKIXLbAQPJdR4xQlAVN3RBiwFlH27XixKgzVjd1r8+U5epEBNFSss6SZzmz2QxrhUXhFZA1Bqx14nyoCHfXO1LK4tEscCFlb0q/Q+rPx4D3niIXIfd6WrE9mXJmc8L7P/RR3vmn76Yb7iXmI81GmWFwtJ0XvTZjKMuczncE7xlmGSFGyiKjqbY4sFLyL//xP+Cqyy8lRMMv/cbv8OcfvAdsxo3XXcmP/KPv4/HHHuUnfvb/5emNFjdcEQdOkFw8Fh+1jyWHV52wEANZlvfgXSRQ0hJ9TQyewWBAdDmtLaiDJZgkIu5xRkYzMhF9l4YjLCzjMmJWUFtHKEqWzIzXPP8Gvv2O63jqQ2+nOP4pLr3wAJe88FvY3n0TE5/jCLh6m63WY8shZTkQ/R/TSRe1GZEM4wN56LBEGgV90vVYZQ+k+yXjtLSTNCZKyFsKR5s/PoyGx1nVTErgkNGMgSyAFwkIFbaXMGaMkTpM7Jl0/NQWI/I3OuJghHGTmFURFXNOyReewfryQT9ueS/PrN5/txlnt7b59bf9Nme3JkTryFyGQ9h1zC9ZAFatl7Qtud/nl+H8zyDjRAyR6WzGxsYmk9mUGKKMQZmwSDrvCT7QNQ11PaNtanG0rWi8DUZDysFIsmx2Ht/WWCNp2JeWlhiPx8JGTM+0BRDFWiv3JIFLKRTKsMDSlbLneS7jom/55L0f4X3/4z28+Ku/ictvvJ1QjGmjoe1qTSiwwFTSs/X3rgeVjAjGf9l3Ru+FlnLhni/u99e9p/Ol38tX8pw657jJzvtstM2df74YIHeQ0/DZj/0lf/zbv8arXv1q9lxwKUt7DjJtI11dgzXKSjvXEriDgSIvWF5eomqE9bi+vjE/rxFNrHNBHAmb/9tYOk9/vghRtd6sgpSj0YjRaARB2LwsXGuMAn5tb2/TdR3GGGGvLjC5k82ngPPCRXSOdN78cKH59YuU0t6kD5SDgtFwiAFi9LStitIjuk6//rP/v3OOt2M7tmPPDtsBlXZsx74C7MJXfq/+FaGfwsT56hUgOj4GE8VhjDJDkb+fYZgwkpg3QUg6hRAwKTMRoscESYUbCDg8ufH4aouN08fZOHsG5xyj5VXccJnocoLJ8VHD8tDwNj0XIRBDhzUR5wzYgWZ1Exq2FFFSBmvp57YwaU7XIiBTukbdP4qzF1XINUYPMRDa9lxQyXcQWmLsiJpFxvYOTiT4BmMCF110kMsvu4yVpaFmjHKU5YA8E8bK13zt1/CCF7xAmDMaTmKNOJ1SPgWV6GfA6khZPI6OjNlkxn/9L7/IN33j13PLzTdSNzWPP/YURw4fp24arrz6Svbv30sInoceepgTp07yghfcJayZMpfJJmCNiArP620OKmGEMSYCzhFR3TAULmfiLCe3Gn7vj/+C33/XX3Jou8Yc2MVF119GVrSU7ZS1epulpsZsTylmDYMYiG1L51sm1ZSmk+xKYKjblu3plFOnz3DyxBlmdQtWQiAxFps50aeJAmpFL8DfBfv3cdutz+VFL7qLtZUVyiJXAMgyHBRkTuo/y0SIV5wsFXZWBo0xBuOk9cmkXyb+Wgl6CySDFs4Q8EBGU4PLx3zxiw/zUz/10/zAD3wfz3/BrVjnefyJh1k/u8Gtt94OKdNT62maRjO4SV3HuCB2HWXlO3MZUXtXAnSMOupOQyeMkVXkRdaRNaKP5NT5dJqRMGksgYTyYYRNFIKy5DS8TUAzFGAIfabGFI7XA0YKEMTEeNH2n1w3Y9Sh0IxvciHixFoMvu6oqpr1zS2eOHyYP/vzv+Cjn36Eweo+gs1ojCO4Ah81VCQGMiAzEFoBy7JQMXAtt1z3HN7yxm9j7759rG9X/OrbfpePf/YB8sESwVh8V/E7/+U/8MSjj/CLv/o2vnToFMOV3TIKan8KOFyIuPNCelBBaKsCyzFGom/YVUy4+OAelpdGnDl7lsePnsBnS/hijLclURmaLlhcKIguherKPcg07X10jjYGyDOMmfF1L7iB73rRDTzx3t9geOqzXHbZpVz04teztXo9jSskdNi3YEd0LqfyLdYFBsZDiAQcHTnGRmyY4WIgIqGf4nzKwOqSrps66DGxh9L9W3wOLAAU4jBL3Qi7MYrGkraPcwbfVIf6O5PahZ5XD637zofk9BtpNwuhbAvt68uYSrpfrwuljL8YI9ZmApAFDem1lg44fuoM//Rf/t/UAbCOQTE4bxw81yLzAscFQCGV93xb3O6cgMJ109Dpb20vtj3PThe9hFPK82ceUmQzAb8xon9DDFgrx03spGcqh9zROdCCEa0tYa3JtxYdPqyCiW3ggl0rfOgDf8EjjzzM17z+u1k5cAXBDojW0AZl9EW5gzYBNgvvsiwk41MCFaQ8si21O9ldtyHX1d//Z3jvf6/PQjmWvJLJ/osMtnPvhQXVUUrlWniPBounjDV/8Fu/yoOf/Sjf/obvIBuvMVrdz6mNLR5/5BHy3Ano/gyW2uUcnAfnMqazGVEZObGfiywW/LzPfwtLfVTG4QT2RtquI89ziqI4Z5YGcn+Szaaz/jqyLBO9zb+FSUbYZwLVvvz3aaHOAEVRUBR5X9+ha2UxRceTD/7JO87/+Y7t2I49C2wHVNqxHfsKsItfsQgqpfc0odFJSZqsi2CJ7JUm8s8wTCTmTxToQ7bFgDGewkaMb8C3ZBbwDcNByelTJzl86CmyPGM0GotIaVFKuIiR7G0hipC3QUAOA6LzYS1WWSLRGMCJ3pJqRgh1X3UBlEOVTIQj546CYCURYxIjS7+JwiyISicXBz8QfAtedKCiCv4SBGjqOpn8y6TdSKif1exYRA4ePMBVl1/McFDKanNZUg4k7C3GyOvf8Hqef+fzCbpqmFnVWjIyQUwTY5kQC8iRJuBykBwfIi4zbG1v8NBDj7B5tiLPB7zgBXdhbOCJJx/n2PGjOGu4+aabGA5LrIZkOJvyumkFpHvdn19AiqjAkrzA2oJoSz7xpYf5lz/6k2xOI7gxNYY2b7nk8n3s25Wz4jr8iaOUXUtpM2LV0lYt1lhm1ZTN7U3aroUYmM1mbNcdTx8+wsbGJsblytxyYMBquEUkkmeZMLaamhfe9Xy+6hUvY++eNZbHY/JMQuRS1rLCCRvIWtEIsimLUw8szR2VrBBQNdW5MZau6yjLgTisQSbrRVlycn2d7UnNW9/67/kHP/gP2bvnAL/0y7/Erl3LfN3XfhU3XH8FbTslzzRULxpsVtC1klXH6/GMsQhmJsBXqxpGbduChriZPvwtCLvBChvNey8aOBre47JM/k5OtRMhY3H2DE2r+kgp05yyQFDQKGV+S2WR0DoFQqQ5YIzBuYy2a/s2ktpQD7qoKHQClZy1BCRrlXMSLurrTlK2tx2nN9Z58JGH+KuPfo77H3qCmBXEckiDgyzH+yjhZiKDTm4Mk60t9q0N+K43vo7bbrmO4WjI0yfX+blf+U2eOLZBZ0pcPiQGz/qpw/zJf/95zp45xX/8+V/mkaMb5MMxIFpl3mRELA4vum/9/Zf2HplrEBlr6Kop/9vf+ztceekFED1n19f5q098jk996SnicBetKyXczASsj9iYESxEG3tmpdwnDXOMHSazRFPz2pfewRvuvJ6jH/o9zNHPcvXV13DBnd9MvXY5jXXUTUWe59AZ0XSxAv7RNarP5YRxZRHNL+/JovYdBYREN02ZajrOok5dCmG0Gj4WF/5OYY5R+0ja36Xvta2k/kQPEmkDOcdkYwKmtHn1x+736IGj+S9jROg/2n4TKBxjxIdA5iR801kJSTKIQHxiKtnM0XSB46dP88a3fBemGBCiYVgOF3S81IxoS0U9b//1lzFg9UITyDXfKMxAp2GoPghzKWrf1zEoHdtYhzXCWDF6Ugm5TnKAAk6aKFp+SQPLey9hV/osWjS5b1KHUaMOpb4ljFFAFr131pCRc/kF+/nAX/wZx06d4HXf84/oil14clxm6fA9u7nvK3qtgkmfC9bE/xlQtLCv4vr953T8futCvzzn930Z5Itzj6vJFhaqJf2ZmEFyDgPR4mJD1k34xZ/+MWZnj/Jd3/09+GxMvrSHQ0dP8PAD96lG3fkmGTNTv4iqIRS1D3nvdcyWxBBfZv01/G1M6xZpIxJ6l9qLMJZSFrnzzchNAWNo6lrHbJk/LV7T/FZ8eakMgpF/mfWgktanbMT7DmMgz1WuAOlDskghZ7XW8MBH36e/2bEd27Fnkz3TcLBjO7Zj/4uZiWAj2GiQRFVGg7Ys9O9OQ84WftdPyr7chEtj0pofQA8EESTko8wMgwz89gaHHv4SJw4fZjReYXltP4PlvdjBGt4O8GREUvYROY5deOVZhssLbFYSswHeDfA2F6DDSuYvSc8sjB+sODv6p6ySLrJRrMFo2mZrrWqlSKYvZyX1uXX6biU8wWW5pMx1GTbLsS7HGFkdFodIBGBDDLSa7t3YjKPHTnDy5ClhpjhZ2ayqiqYV4dx3v/s9PPzIIzgNT1io4HPqOTkBvTMQg3Ir5A5YYzhx6iR11+LKgtuf/wI2t7e47/77+MIXv8iu3bu5/fbbWRoPcUTRiwpeM8KIc2adTj7TRFXvRtDMZEEdNozl6JkNfuqXf5N//qM/xfrM0JkBMcKS8VxcWi6iZW81wZ04xnLbUtYtzdYWVTWh9jUbkw0JATGGxgfOTmYcOXOWRx5/io3tGUHbhM0LjHO4LNewI80Y4zv27t7Fq1/1VXz9130NB/fvZZBnOBuxFvLM4qyEvGVZRuZysizH2Qxr5J5nTia3AjBJSIhMbuUlE21ZvU33GAyDwZCq7vjs5x8hK5b5ru/+fv7br/8an/rsJymHGd/6rd/MrrVl0WbxARsjuY0UuSG34NsG37UYJBzAWgkhDSHQNi0maXMYAXZSeJqAPeK89yu7GtoGYFT7CO27UlfChkktq8iLvhFFRGSbxFLRMLvkhPhOdLWi1kVQxl/wErIA6hjLCaWO1EHIMnGkBOwyRE1vblRQPepqfZ5J5r3RoOTyyy7h5S+6jZe/4Gb2DKFoNimbTdzkLNlsg6zawFbrjEzFnrHhm77qhfyL/+P7eNHtt5DbyKOPPsp/+pmf5fEnD0FW0JHhTYHNCkxosaGjrSsM4JW5YIzRcUb4PTEK2JfEi7sQCKrjFIBoDT5Ebrr5Jl798pdy7aUXc/VFF3Dp/r1cc9lllC4jalry4IEoOm+SZSsSjbyCNZBZojOqyeUhNmS+Yil3dG1gEgq23QqHJ4b1UNJEg+9aiizDBwi2xdiW2NVYDFk+kgx70VPGBtu1xM6CKfs2YZXRkrIOpvsuA72G0ailv9N+VplFaVsar9L2HnxMUIvubPTvxPqLCkYkCyoCLG32mUzb2Lxrzn+9wHiS/qq6YFH1w/Tzohn9nBg+MQrgkzJALr5AzhdC0q1J2kMLDI0FANIsHH9uMmZZMw9DddaSOafPG4MzhswaMmUPpWMYY3BunomyfxmBbEH6nNSDPOsSK8gYZR5ZaeMm1ZHq74QgIFTQMHWiPGliDBRFzmg4YGP9LOVwgMlymtbTdYG2aei8p/WezntJDNB1+rnTVPSy4NJ16bOnbXW/tP/Ce9vO35t2foy28/p54TidX/itHPecY3RSLvl7fh4pz3kv/+Xb2q7Dd56trS1m0wnWwEUXXyzMnyKnqio9d/tlv+06yaQYSLqOVkW5pe3nOraaVN8L9d7Pn/7Wpv01gTLphfSLXvOrX3RbeAVPiHLvjTUS+mqN9LU0LvbtGnmWBU1goq8YZYz0IeB9oNOXj7HP1tvpC5tkCjKisXReMsl1EYIxRP0+9MzgHduxHXu2mXvrW9/61vM37tiO7dj/Wvaff/1d0E+UdaJhZNWdfiIvD3MjM35ZbNJX1InGM5sc0caAxWN9g/E1w8zg6ynHDz/JiaNHyfOC8eoaw6U1TDagixnRCjgTArLavDCRTpNzYwzD8RKYjC5aumgISDiPTJ4VQFJwKJVVfr+oT6BXb2QFXd7nzkD6zskPZf++quYTHXFejPwVA8HL5Eom9JqSXqnoGIt1OSdPHKUsJLOQOPmSKSaxUj5+771cd9117Nq1S8up5e2LoWVdqBOICH9F0q130bO0vMTK6iqXX3ElJ0+c4D3/48+46orncOedd3LBwYNAIEXgZE7YIwYRV45GVrrnt1lPDuJYRwuuwBZjPn//I/yzf/Mf+NBnHoJiTDQ5hXM4X3HxrgE3XLKPkZ9iJhuMncNvT7DqyMyamrpt8MEzmU6ZVTWbkxmHjhzl2NHjRJsTMSKineUCoqgDV+Q5xkSC77jo4EG+97u/i1ufdzNLwwF55hgMCgaDkuFwSJ7nDIdDsizDWUvuRCQ502xe1lnyPMdaq06bOGPpXFLrEspjnWTEC9EQjeOxx5+kHK7yR3/6Aa657gauueYagm957i3X8/f+7mtYXRmxujLGxEhZlITgEU1uSd0NMqkG0eRweY5zsoqdmHbJooZQRHXeu7YjV2HfqCvLjTKbxPnVMC0FnxIgppckx9I+nsIujZWMeLKfsGfk5CkcQtgPyRK7Qhz2lClMnftF1kpypoJcqxwyjTZyT4wxDIZD6T/Osro05IL9e7jisks4uHcP+9ZWuGT/XvavjbniogM89/qrefndL+CrX3k3r7jrTi48uAeDp2oqTpw+w6HDxzhy4jSuHIEtISsgdlSbJ3nNq+7Gty2f/vwXOHpynawYqlsuKKoNXtOOO4xxYOUVjcPYXBMDSAKBgwcO8K2vegmhnmCI1G3L5tTz+YefpLElwRWYaMg1VXfUTEnBRKIg3aoHLSUIocWaSF5v88rbn8ue8ZBDh57i8cNPc+E1N7PvmluJmTAcc+sI0dHGSktvILpeuN7GDhtbCfkiJ0SLswI8uMTWs1aBEQEjdHTRMSbdaHmLCTDS8SfdzfS3NcJ6SPss/jjtJ21PgUcNT1vc1+jO/anTs0A+wHmcIIFU5oyqmIB9MweHrQJ5xgi4jDrh0lwjWVEwmc74wz/6Y1xWYFwmwv0aEjtfdFD9tTR2WNFhk0dIWqxIoVjyXJVyzLcbI8dMNj+mHk/fBfQTVpVBwlSdlcUIOY4iRXqd4vhLFUl/E2ZKAszSS64nJTmYX5uA7jl5XuirZDxeYjxegq7mvvs+x4WXPIeDV95A1WlfCZ5gLJ0PBC9jWhrbvDKH5XMSkVbecALmtf5j1Pa/+B4jwfv5sfTYUY8p2wTESO0htan0t57qnPdOyxl7vTcBVFK55++R1gds8EzWT/L5T30MQss3vPabOXL8NKu79/LEU4eYTieSwVXvxeLLOZmHRB0TszyXewBkeU7XdfMFL6f3cFFDb/Hvv+GV2pr0kjRHk7Z+/n5FnvdtOMuyPiFFqiBpq9LX5u123rb6tpQttCkNxZR2leZkFucyXajTBT9jyTIBb10mCzlSN/PzyDmlnf7vf/879M7u2I7t2LPJdsLfdmzHvgLskpd/3/yDOXc1Om1LkwujDlAEonDvZQIQdbKsq8TRiAND8GRRFH6sryltwPiKMyePcfb0SZw12LULMXlJludYdSQTamWM5DqRCWMkKmPHOhVQtk7D0NSxkNkpUXIgqcuDOh1pPVb2sQRs9HQ9Qja3Zx74RBNqPkkN6hBHYvD4rqPzLaGbg2eha/FtQ6ehcZkyAaKKu0YfyV3AmchVV17Bwf37WF4aSShGjLIKbB0XXXwJ3/Edb+Tiiy5UNooXh17BmPPN9ALe4tjQO1qW9733vayurnH1NVezsrwqN3Xh8nXaLWUwsa/HiMG7DBMNsenIjCWEjjZGvCv5/EOH+O+/82fc++kHqaMjK0sy05HHhl2jjAv3rrBrKaeZbmLpcCZSVTN8U2NipK5r2iAO+Kyqmc5qTpw4yZlTZ4Wh4zKCy9VRFUaLsxomEALOGvbs3cuL7rqL2297LrtWh+SZaEbkRUGWOYq8UNbR3CEsMnHaYIEFoA6YTMal7oyBzrQQLZktIGT4LpAVGTZzPHboEFm+zBe/9ChPHjpG3cH2xhm+/qtfydq4oJ6e5bprr8bYiMszTpw6zefv+yLPv/1WRoOSGAzBGKZVS9sFinJE1LAVo85ICJLOPmVOBLkWAQCM1ElilKkzkBw4AaYE4PQ+UA5K2qbFWkPT1gwGA6yG84WooUrK2IEEhErTSHXXeREQT+LgQbNpxShC38FLLjarjKmgYS7GJHFlOUeM8xA758QBQXwYAUW7TtpHXTObzeg6YfR1vtOMbJZBKYLEo/GILMsZjZdE2y10bG9ucubsOp+7/2H+8mOf4rGjpwnFCiEbgM2Ybq3zg295Lbdecxm/+/bf5YMf+zz57kupXIk3TkLqOi99XkNsg7UEKyBTQDIzJod989QJfvKfvJlbrr+MyXSDje0p7/mrz/Lee+5janLIMnIDA3U6GyNZAoU2ajBYnMmFqWYina8xxnNx0fDPvvfNLA0HnDl5jJXxkIP797E0XpLAPyOM0gBkRsO5FgEXZZSl+gVhsMU+HFGHAq13p0BH0BTo/eigIZRyH4U1J+C5HEs0uRTQVx2lcwHZebtK4+HfZPMyJUdZSmK0rRkN55T2pOCEjvbp+Gnf+RNh8QROADcjR4+AyQqOnzrDd37v9wsI6TJhCgUB23pgQtt3Om46g0XCcs81GUfOt1T2xf6ennNBr89aS/Qe07OIpN6NnjsoiGudlWdm05JpmKpBjmWdsByjAjDpWRatgh9pwQPJDDYej1ldW2XP7j2srq0yLkeM8gHBVLznXb/HX7z73dxyx93sv/o2vMvknkdDYCSZGK2AmtbIu4ylMqamujBotkwUCDHztkHfThbqTY8l38lx5PjntqmFAzzjd+e/I08A9H/9J91LYY8ZZ5mFlnHjOf7wffzZO3+TvfuX+L4f/GEOH1tnZdcePnTPhzh5dpuiyGWOkUJAnaNrWwnNVoAdwFpHkWUEDS/GQFPXfZhpUPDJal+MZgGES/OyZ2pUWCTGdd4mkZqUbf3vI87lCvRIPwqqcZS+nx9DMvrO75GMAVY2zJu79tV0WtlThzdrBYzH4KPHh4CJnjxzku3QWQV258+4+eUZPvrHb0sfdmzHduxZZDug0o7t2FeAXfLy7ztnAtV3e4PqTIhFoqJKMjExMnPQ/c0cZJJERuAbXAwMLcS2Ylg4Nk6f4unDh/AxUpQl46VlstGa0GN0ShLSBFtBoqirVigNWgQ4dfJnkhNBH6sfo4SjIEdIM09YkI0UPaaIIagOxd/GFGhBnHrxKgRwi8HjvYQgBe8xvsH4htA1dE1N6Bqi70SgXFffpJwQu1oYUKHjphtvZO/uVUbDkqLI8SEwGAwFRMsy3vrWf814PNLV6SB0+WeaT4Jc/8LEDwwhyIR1OByqM2bxUbJCzeukvyy5rxjAikQJNURDlpfMak+wOS0Ff/iuP+fHf/rnyUdr2GIs6ahDi/ENB3Yvc9WlF+CrTVyoyU2gqae0rWRyq6czwND5jsmsFlbH9oRDhw4zqxqiFwfOGEkPPxwNZTVZgSRrDbPJhBe+8C6+6hWv4MILL2RQZgxLWTHNs1xWUDVsMa2YWisgUpZC3HRiLI7N/AUygTZEPKKPlWUFXRexVoSis3LEY08c4pd/9df5wf/j/+QjH/sYFsMVl13KeJBzwzVXErsaooBQXQi8973vZ3llhdEw49bn3kwIAt9VdYuxOZ2XLmEwsnptRasoOe9BgSXvO7Is7wGlTlluaAhP57ueMSTXBG3bUZYls2pGkWd0XkRb27alLEuaujlHwDtqyFpKjS2hEDpWKGCQ6rfXWdJ6m2ekE1Hv2DMS5o55URTUdUWW53gvIuSdprGORIKf6+J4Pw+dSYDZYDAgxqAMNg0hcRmGIOGEbcP29pTDx07ymS8+xPs+8nFObNTYwRLBik7UdZfu5R9//3fy8Y9+mF9/2zuwy/up7Ag3GEOM5DHQ+LlThYkqRqur6hrqG6OEAI4Hltd87Vexe9eYL973eT587+ewozW8Kwm6cp9hMUQ6AtYEjFHQ0DhisMLGix02NnTVFq996e288Ru/GmcgtDWZgUEpGSTFSZNgPZdlmNDirNS/0boLKoYbScOifJLv5gLWRoEYcfDkJoWk+6OfY9JYSY5tOm5//DnLQupF7rmAoDo26TiY+tlfZ1LUBHqc991CP/Xek+WZhHkuJDFYLJtXtl5Up12AMGFKpfHdWIsrBhw/fYYf+bf/jiZYohVWI9ofID3t5NhpG/p3ytx5rv31oBIg46Fq2GS5JBNAGYTGGHzb0jU1jYp5p5q3mYTrFmWJdY627fBtK2HQzjEcDhmNRjhlFqZwr6AsoWklIWuj0ZALL7yIiy66kH379jMajRgMBuR5JuyfLuAizGZn+JX/8p/59Cc+yXPvuJuVS28SkXgDMvIM8ERiDyrJOCb/zwEgfYz3Y1mqn9Q2FtnJ6V3wr3kl2tSudVP6zqb2t3Bc0n1KAMjCceaglwGULafzG6OgvnGGJnpWA9z3sQ9wzwf/lNvvvImbb30Jg/Fu8sGIWVcxbTRZAdA2DW3bsr6+jgFJOqGNMbXdMs+0jgVQ7LqO2WzWly0owFOWJXXbzq9jofTnmzDVzmW2om0b0FA3pBWrqL0xclzR0Vus9/nvBRST41hd5Fssiuw7B4ql9nXtKt3vxH6yhtZ7hkUuMgaJKdULy2toaQI/Y+S3fuHH5yfbsR3bsWeN7YBKO7ZjXwF2SS/ULTbv9rGfNss0S0AlYSUh2eD6/SNRV8ajgSw2OF/jYmCQQTPd5vixo0y2p2TDEeVoBVeOyMqhTjh1MpOOa2WinwCfni7tRNBY9hWHtp9PxajT1aihSHINaVIjpRTrxbjTMf5WFmU6pM5RjAoyRUQoNQigFEIA34KCSr6tCa0wlXxbY3TCm2ZYhkD0QnnPneOG665m19oKeZ6JiDORwUBCcW6++Sbe9KY3sbS8BCywV57xIqRyjFEAUCd/iVmQJuzBiGaGcHUWqzPBbukbKG1H3XU0ZIR8zGfvf4xf+OW38enPPUAxXMIVDpcZrK9ZKSwX7t/LMDeEZsrSwNFV27T1FO9bdWw6msZT1y1t55lWFcdPnebEqVO6yuoEZFSdo2iiZD0Cocx7z4UXHuSlL72bW5/3PAaFhLUVuaPMZOXVKavNWPOMTCVrrLRBK3UkoJ/cnsh5Dg2SOS0QMS7j+Il1PvHpL3D/lx7hG1/7Oj700Q8zrSbc/ZIXYXzLrbfcgrOGrhXNrJPHjzObVRx6+hDTacX1113PZZcexJiW4EVYeTKrwTjaTu6plFPunZRF6mN+3xfKp6wT6ZPpsxwnxkhe5CLMrey/FOKUZQ7vA957irKQLG8L151+nxqHXWAeRRX8lq4kbImgKd6jsicSOyaqgyY9VcW+ve9/FxPrJAFg6YRGQn06r3pk0t37P4wCXVkKD1TxeJ/A3OBp6ppJ1XL05Fnu+fTnuecz93Hs9Aa2XMJjGcSOf/KD38P+XUu87wPv4z0f+AhNHEA2VNAs4N0QbzLRWTIixGyiMvlCunYBW7x1dE2FxZNnYLNCZL6tZLLESMhL76AJ30nqx+g1BE9uI7GecNmF+/lH3/cmLt2/RuYMvqkpnLBXijzXMc/K7zBkRoDXnr0jDUiOv8BWSowIY+cZ2kKQMc45YduEMN8nAQC2ZxhpW1vIPBjOF+Xub5q0kTnAoB3tf2IGrajYf1po+fJdEuSO/bUqqKRtOJVV2q0CaGnYjKbfP53LFSXr21N+5/f+kEnd0njJKClNLso919+n7FiR1DAXC/c3mwGCAjybm5usr6/TtC3D4ZDBYCDMPSvaZXVVMdncYjLZpmk7pBRQlgOGoyHjpSWsy6iqirausQZGwxFru3exNF4iy4Ul03YdUYGroigYL6+xtLzE8tIyRVmcB0LLhYQgzNxBnvH0Uw/z//7MT/LYw49wx4v/Dm7f1dSuJBqDIwC5VKlWqO2fQ4CJX8YIsufoRMn42w83Zj4GoWBJqrj+fvX3bX7/5Fmmx9W2tjj2pG0YqcR5+YwCxXpc/U7Cog1t9Cx3no/9+R/x8Bc/wate/TJitsINN98OLueaG6/FlWNhDHppC8YYTp86zamTJ/rnjlcdOdHOigwGBUtLyzomw2w2Y2Nzk6auRatQEzc0rbA/U18iQue7eVtWi6qNpK2y/z4BVLJN+orvGc+pTcf+OWI1A2HSFyychFcL0CnPpmSL9ykSwYpep2G+aEUCrrQH52XB8nhM5gQ4zbKMXEMCQVi1IYiAeQiRf/uPz52v7tiO7dizw3ZApR3bsa8A++tApYisxMu2NIGLAuosTLgkdMLrK2AI5KGiMB2ZhUNPPc7Z06cYjMcMRytkwxWCHeCKJUkHHoXBQVTnyuiKP+oCKLMEIzH4aSKUJkFp0pTKTJSgj9BPZBN4pK/0C3U0RJT8b2MR1IEkKlvJyERbqOLCmiB6ou8EROpaQqtMpa6ha2Z9+AQ6QRZmiaxC55nFRM9zb76J3btWyZwlLwoMMBgOsM7xnOc8hx/4gR9goGwjmdydV9K+btQx14m5MTKZ9d6T5zld26F+o7zOO1BEhYS1howPhKzA5yN+8/fexX/8+V/FlWu4fKSsjRm+3eTKC/fwnL2rzCZbDHKLCS1NNYHQ4buGyWRC07WEEKjrSNMFNrcmHD9xkvWtLVxW4CNYKxpU6fx5JmyCEDxN03DDDdfxutd9M3v37GYwKBgNBxChLAoKdcaslZAQayTjm0yIRQTXWKPMG2kDKaQnXX0vuqUOh405gUg5GrI52ea33/6HXHH1jZw+u8Wjjz7Ba7/5G8hzeOLRB7n7ztvIi1KdcMuZs+vc+7F7GQ5HPOey59C2LavLK1xwcBeYDmMyGu/pfOTM2U2WV9YwxtJ1kp47auiAlE/aj4A3ljzLFByYZ4GT+z0Ho5KzkmUZdd2IqOysohwUouGVKRjQ62VIGnOpfVk17jqv6Z4lTE7AIGG5GHW8jIbDSWidOMNWRcKNOnjEeV1HFSMPCmhI+IXoPQUv4JS1cr7kaKBt3HdegDIFFLq203MYFXUNDIoMEzxd0zCZ1WxNKx5+/BBfeOBh7v3UZzh8egs7WGVgHGePHeJX/uvPQKy59+Of4IN/dS8PPvw45aCgKA2NGeGNpLsWAEiuO3dORG0XmBPRQogCdAmIWisD02JMATaT8VXHNhuF5SEgu3zwbUUz2+a2m67ne77zu7j+6svw3RQbI2Xm6NqGIstkLLKi9RRUiytTEWYBluahTUbHPWnm87aUnO5O24LcI+kXnQJXSQBe6l/uQ59BTYEAYS5oWnR1UhNjKSqLyzp1+dWxn4/gz2xS1DlTaV4GLfvC5wRUzplKegwFShJwlp5pKLssRmHY2aTT5nKqNvCRez/B5rSm6YIsbGhhF6fHXQKVFralZ+f/1CI4DG3bcOLESY4dP8asmlGWJaPRSEOCHD4GZpMJ66fPCNjQNNqeYDAYsrS8zOraGlkmoNJkextnHSurK+zZs4fVtTUJBc5zykHJYDikLEuyTHTAUjid02OiAC9IGxIWbsewyHn6yYf5+Z/8MU4ePc7Nd9xN3Hs1tRsSDDi8JKlI9zc9e+RJJO1uAeSBRekh+VL+1ufaOWCPVlg6jn5OYZpyHr3ngivK78y8rSWmzrnHlM9GCqagkpavZypZjAUfPWt0fPBP/4BH7v80X/8NX8usddz1kleQlQMuueI5dKqzJlG9KfOhYWN9g7NnzpDnC7p31hJ8g3OG4XDI7t27ZWyNkoF1Y2OTra1NLaWVzKoL4A9xDmqeY1FmQf3HNPdZeE9/e9VvC7qKZzS7qyxAye9T3TrNFLlYd8+Yrc4EolHtL7ROlREYgqfrWlZWVxkvL8kCl3YXq1peTo8pQt8CKsUQ+Uff9brzz7RjO7ZjzwLbAZV2bMe+AuyZQaXkJCxMkqPBRtHr8FZEZTFB9HFiRx48eehEQ8k3bG+d5fCxI3QxsLS6iitK8uEyzg2JFFgzIOKIcSox/DFiSJN6Oad1kmENhLV0bqja+eXU1a8IsV+ZFhOhcHmRQCfjCMZi4l8HKp2/NYLxelrxbiKhz64SoxeAKYqOS/AdoevwbUVUUMk3FdG3wp5QYexorOoKRJyN+K5lZXnMVVdeztrSEoNhSe5k1X+8vALGcNONN/Idb3oT4/G4BwvOKWkC+9KkXd+tEaZNTNoGMeIiacoHRuouzcijiRoSEonRUodlHnzsaf7Df/5FPnP/owzXDmCzIaHrsKFi97Lhgv1LjG2DnW1QFBmha2lmM2L01NWMSrMDNW1LVTVsTxpOnVrn7MaGhKbkZa+5YLBz/SxjMKEhhI7LLruEV7zi5Vx33TWURc6gLDAWyrLAOktmHaXTv1WEOzmMRldZE9Akc3N1PJJzk1qTeDdgREeHIOK9v/lbv8Ub3vxmjM35tV9/G9/wmtfyC7/wc3zXW97IVVdexiCD3LccOX6c7cmME6fOcGZ9i4MHD3DNNdfy6U98gle98pU4C00zxWVGNJWsZTqrwWS0nTgcVtlHCbhhIVwkOSap3cu1iXuUWCNdJ6FuVVVhFkSJ595CpG0airLAKIPJq+PvnIStxSgO5+I5YkyOiOjxoE5hAqVS2J3RCvVeNLBAAKXg5RpS2Z2Tle8QPDGFMjkRjU5lCiGQFyIabq0AUIlNk8oeY8Q4R3QZRC+Z20zEBE/bdNSt5+TpdZ46fIRHn3iKD338czx5YptBMcQRiF3FD3zvW7jh6ss5dvgIRw4/TV3NmMw2k1ssYto40VaKUfSUrKGpK5wF39bkcUrbGaIpiMZic48lkhlHZkR83boIzhGzETZYLMKas8YTYsOuXStceeWVXHrxJYyGK7iyFGBdxxdiUNBK2GfCNxTw2CIhQf29A+3HypRUk3sgg4bcK2n9IUjII+pc9nUehZmWQrZSm4yJZaUgodPQuMSEWgyV68/F4jA7L5PYwrNH29dcO+/cc2NUlyj11ZD04PRr7ScJ2DrnTMYIgC0joJzViuh+1Xju+eSn2JjUdFHCXueXIAcK6AJD2qYm92fxKfQ3WIy0TcvxE8c5euQoVTUjzwuG4xHloFSgLFBNJ2yePcvZ9XXazguD1xiKQcny8jJru3aRFyV109DUNaPRiN27d7O2tsbKygqD4ZBMAY1+DLSWrkPCXfV4UqT0jJO/QxAm8iB3PPbgF/mvP/0fOH7oaW68/cWY/ddRZWOCtWRIeJY1KawYbZNyXKugTnrqGoM8ZxLoo/dQ2Lzze5/e9ed6XG0H2jNlu+nZUBIqn9qJlEW6Qzq3vuttSsc0KXSuP6YkCnBWMiyuUPGu3/l1Nk4e4Y1vfhPbdeSW2+7EFQP2X3QhWTkWEFIBU+dcny1z4+w629vbhJQogUjbNhIyDuR5werqCkUhbS0ET1M3VHUlWdQ6mYOkPislPtf0DmJ6RtB8J2t1wU4GcCIR6zKZX6VFBB0G5J6n0+hJo1TiYlhaf3+SaT1GBGjX2QU2ShKQoixYWhrjclnIEGakHL6/z9pGQy+UHggx8I/f/Nr5eXZsx3bsWWM7oNKO7dhXgJ0LKgkocr5FIiZaYWqYSOtrovEY68lix8AGShMooidUMx559FGazjMYjxgurZCVQ4zLsa4kRqsijuIAdTQYJ1lsYtTJj1KrZbYyX8WSdS8pUXrJMJWWJbW0IaWOlolxbmHz7CmuvOxitja3mNYtweUEW8jqfkxOySIbBD2/zJFkciagVCpojCrW3afilW0hCFMp+I7oO0LXYEJH11QQGtpqSmgbAQBU0wOi8KuihNWMBgU33XAdS+Mho9EQ5xy5rjQ757jt9tt4/be/nq7rKMqid7ClnHNmSn8dJKcnvcQswgZyzkAMdL7FZg4fIybL8Ri6CNlgiR/7z2/jXe9+P84NaVutKzpcrLj84r3sWynY3jjFuIgUtDRtg4mwvb1N10mIW920TGc1s7pmc3Obo0dP4DsBAkKEaFVoWLOYWWvJXE70nma2yVe98uW88pWvYGVlGZcZhsMBWebInCXLxJnNs5zM5D0wkkAl069az1+QHCm5d8bQZ98zWU5QQDMrSh594iiPP/k01uY89MgjfN/3fz+PPfowP/qj/5r/51/9My4+eIDcWmwM0LU0refD99zL6fUNysGQ5ZUlLrroAq69+ioyC6FrUWwPa3N8hFndEqIhxPmkWsqVHKTE2pGQwEXwpq4rsiyjLAc0jTgqXed1dTituAvQVBSFhPIFEWUV9oi0kd6JR7LARdU1Eodt7kBEhf6S1pIAWcL8EidKwibQzHNJ0DsJfFtlMs2dybm+jEkr+S6F+kmzTYCGMQvC5OqEoGUJMUKWE6OncI7YtRADvmtx1jGtak6fWefw0WPc//BT/MlffIjWR6ItJK11iNx8wzW87pu+nv17VumaCpfl2NgwLDLVR4vCXAy+Z+ckXTUw1L6B4HAmw8QW6zcpqVkqMnJvILbkhSE6R+sG2C6Sa5hvyAricIQdr+LKMS4bQLDE6IUBE0XAm1QvUmN4BXRilEhh9aD124U9dWyUr6Ttp/6QQt1AwL+4wD4iOdrKfLOKwvbDZRLkjuJIp/MIAKjhaf3YMy9RX4yFbXPgaGF7lPYfE+MqMT0S01VBStln7iCLLdaAbtFjSwtMY7r4zT4apnXLe973AbZnDV00uKxclBnsyyxA/RyAQdsCC2wQ6VfyHpO4tzryDkPbtKxvbHD27FlmVUVR5AwGA8rBAKsha01dM9naZDqdUjcNKCswywuWl5fZtXs3y8vL5EVBWQ4oylI1kXKKMiUsEKDW9WHBcyAyjS+pvIvv8rdkqjz65BP8xi/+DA9+4XNce8sd2H1X05WrRJdDbMFIqKA+irSdoH1+DlzJuaMsTilgCXIfpa3Nn7/JUriVHFL0mlKTkjYs+8tv0zHm7Ta19f48pNCs+WeUgQdyL0kZzowB3zIOm/zOf/sFCgJv+s7vplzexZ6DFzAcL7P34AVUXcDq8ytdC1HD/qAPczRaLq9sVhlRIc9zlpeWVPtQ27WK7M9DfPuiErxoIMlmGeOJkehT/5+HFy+ymvp7nF4L9zrVU1qkSAsbiaae+k7qc323ls1EnZuZvn6FqZQYfEZD033w+IXjkmohal/R/iL9Cv7xG79m4UQ7tmM79myxHVBpx3bsK8AEVFqcOKZZ87kTDFlbzGWlMDbE0JBZjw0tgwxCPWX91ElOHj2KHY7JBmMGwyUG5QjnSs2wI6ESOuUgEPEGAZkMOE3bHFX34tzpJLreBbCgC7BA8U5lzi2ErgMj07g9a0u87jVfy+njh7n0kkv4+Kc/x4c/8RmCG4rWiZdjCANDHIvFCWb6sx8S9RpQIOkcUIlI8C3Bt8SQQuE6CB1dM4OuIbTVXO9l8Tx6TGsimTXs2bXGVVdcRlkUjMYjFZy2DIdDMIav/Zqv4dVf/ep+Auaco+3aPnPZ+SblP2+7U3FkI+Ab0QvTy5VUwUGxxPs/fA+/+rZ38IkvPc2u1X1k0ZEj2kl7VjIO7BniwgSaKcMyp2tmeF/Ttb7P1tV1nqppmVUNk1nFyZOnWd/YBARQ7LzHZpJJLdWJ7wR8MMZw8MABvvHrXsVVV13BoBxQlgVlmWOd6jBkDmvFycpdjtUUxHPnSYEkPV7vuCiYaYxm90PBuSghlB4j6cSLAb/7zj/lE5/8LK9//Zt4+KFHiLFla/MUN1x3Bbc99wZcBIeFEHHGYZzjyUNPM6kqVnftohwWrK0uY0RdB2eF5QKS8r2LopmRNJWshujFIFmhrOrU5Fkugq9AnkvmoBCiZrFTAMc5dQbmIUFG9XG8l+yB1lp86GTiv6BllICdBMQl7SQ5fuoj2v+UAcKCU0+Ucvmg/eM8h03Cj+bhFcbI7wUQ6OkE/f5OwTVjVZQ3gRT9dSWND7m/IUo4mPcdzhoIygoMgeA90+kUHwKTyZSnDh/nE5+9nw/f+wnOTDtGqweJdoT3Hdtbp7jt1hvZv28veT7CGU+ZGQ7sXuVFdzyX/WtLWN/gjPT/1nvaLtD5QOUDA2vJ2ymDbpPuzGPUpw+xksMABFTKDeQ5XVZSRHEIvRswy5c5xTLLl1zL0r6L8N7gEAwpOeIxiNoZCoQAAiopuyxxNXvnT+sy3SsRrFanW3YhqgZW1N/FBUDJ9E6/jMs2oaG6RZhmwkDrUvtKma+ssDH70KpnMC1mP+an9pXKn/bqGUnapmKUNiTfzttMei6c+/svN2mzRsfz+fV0GDYnM37zt3+HjUlN3QWyrFT9pfOPAkHvQ19HieHXb5P3oJn2kDsn59Q+UtU1s6rCd52wLLOcLBembtd1tE1DU81omoYYoSxLyuGQ1dVVBsMho/GYshQdpiwvKIpSFyIyCX0ri579J4CvjJlSHr2nWiepvIvvEDEmcOrocd75//0GH/vge1nbu5/Ln/dSprGEfCDtKKWF75NqJABfwSvp9BpeB8ZKsovUj+VMqTksLAL0n+W+ptB1GdulhHIWbQsL7eRveucZQCWpF3rGr3OOzBhs1+A3nuTP3vHfccbyba//Ti658ipsWbL3wEFWdu2jUYxkXqZ5ywzKMt3a2mJjfR1ixAf5drFvGAxZnrE0HjMcDvuwvZ6phdSFvCno1AuW63gaFdBDQumigr30bU+OhfZ13XqOSTITBXdiFLBQ95J7rGP+l5mwe4WElsAl8EF08UhAfAzCRu/vRX/0+d8Lz5sffsOr0gl2bMd27Flk7q1vfetbz9+4Yzu2Y/9r2X/6jT8+bzqzaAvbDYCXNPHGk/kZRWhZKTNOHTvCE48/znQ2Y7S8zHDXPorlXZTlElk2xJJDtKpxoC8XCc7QBbAuJ88lra3Mw40weNRt6n80n/P1ZZMJW/pPw5uIeN8SEebDdVdfyXVXX847f/e3qaspt91xJx/62Mex5QhjJCzDGE2Nro5AD0LoZFjO/+XvMsFdLJ9F0lMvFFWPE6PHqAaENaJ9ko6uO2KMEYFPA7NqxmR7wu7du7HOki84GIOy5LHHHmN5eYVLL71URIyNiFGzSHvvTZgJ6ZrkbyQ1ugRxSJkNdMFg8zFbteMnfva/8fO/8jts1JZ8tAw+kBEZOM/Vl+xl77Ih6zYobUVuOrpqRte2zKqKyXRK07Z0PrA9ramajs3tKU88+TSzqgEjAKK8wOUyuey6hrLM8Z1kO3rFy1/KN37j13PFZRczKHLKomBpPMIaKIuSIpf241xGnhfkWY41AlYJMCOCokYdmfm7ChVbo6CUTLqFHSTMuI/d8wne/T/+ghtuvoXh0gpHjhzjr/7yg7z85S/jZXe/kBuuvYIrn3MRZWHp6oa2bvmLP38veVYwHI8ZLy2xurbKyvIyo1FJ8C0GAQ4NKYOWVHxQYEDYawKgWGtVSFsynhW5aGqgk3rUURFHMSNG0T5KjANpdwIgRGV2iC6SrEIHzZgVvIRjdJp1LWjmqLggtu0VlLHKQkkOamLoWXVYgobExQVWhnWWthWdJWmLKbRPQK4Ypc0nRpRRcMgqEBFjFEfNSkY6m8l96sEk1f/xGiphEttABbSTQ5TnuQouS+a/0WDA2soyo9GA4ydPs75VUYx24W2BG405uTXlyWNnefTQKR4+coovPv40DzzyJO99/wfYu2cft916G8F7irIkywe0PpDlBaOyZBxn7IrruBMPsP6FD7A2OcTS9iHKradw60/iNp7GbD5Nvn2UePpx4uZRutkGx06exi7tYe3gpbhyhCVSmI4YohIjAyYqeNaDeYao41bvJCP/yP0TYEh2Ss6mjDwG6QdJHykBSTbVddIg0gMaGdL6EcaoU5rao4Q96Zinn8UBXRzsFgfIhS3JuUzbzvnRIniZxl2x1JYSqEYajlOZz398LJj2Jlg4U8Qyqyv+/L3v5+zGFpPpjK4VtlBVVzR1Td3UAgTNZlTVjKqqqKopVVXRVA1NVct+tbxXVcVsNqOpG5q2oa5qZtMZVVNTVfJ92zQCriqAjAJzwoCDYVmyurbGnr17Wd21i9FoTF7kor2UZ/I8gz65hfRVGRuE0WhlgchqrK/W6aKl+7j4t7xL3xwOljh+5DBfuv8+qq2zLO3aLWNG5zExqsbUfIFG3mUs8CHgowAVQYG3rmsWwKTUXyXcKabQp6Srg4YbBnmPUViUaWyKXsOlIj275m9+lwx4QUM1gww2ctwgItaK+cniUV1z4ukHOfb0E1x44CB5sczh48dZ27OLfQcP4vIBXQ+Wy89MTKzA+Xg8Ho2IIWpYshW0SIH2xJJqu070sSaTnj2byrwYFhZV11H6hoyHUU5GRIFM7R9Rgc10P84Bl/qeEOVvHfNTeCdIYoIYOnzXEXyL7xrVgQsQ568E4KNM2HQfUxk7bQOZJhnwSvoWAAtdaJzPDeQeGV5yyxWpsDu2Yzv2LLIdUGnHduwrwP7Tb/zR+Zue0UzsKGKN6SqKWDHKIu1kQ4S4z5ylHC0zWtnNcHk32XAFmxXKAhHnJ0TJDBeN4i5WBBLyYohVHSVhJ81XN1Mmo+QhGNVeiDIz0ZdTLvzCS511bI51ju2tdU6fOMaLX3AHN910E8dPnuFz9z+ILZeIKEtDJ5agK6j98dNndcLSRDyVSYGgxW0ybU8r6nqMfg91uFCmRky6AzoR1PN7L6uOdd3Q+Y7l5WUFPaQcPnjyLOexxx5jOBxw2aWXLYThzAV1n9nSNE2cMQGxDF3MaGLJtM15zwc+zr/5iV/g4599iGK8B+8tWagpTcsFu4dceeEqRdzGNBvkpgUN/Wm7jqaRULemkRCw7cmMs+sbHD5ynOPHT9B2nhCNhi5JuJvJNMtRDOS5w3cNl1x8AW964+t5yYvuYnVlxGhQUhYFw4GEvBWavUhSyec463q2Wy/EvQAopTCxBCxZYwlEXCahVLmmtHdZhs0yXFZSjpb4/T/4Y5546mkeefBhrr/mal73za/h9Imnec4lBykyacpf+uIDrKzs4iMfuYfNrW0OXLCfQ08fYu/e3RSFiDXnmQCeuYZYifBvcuAzojF0XsIBrAI2CUzKMkkx3rYi3C33Wu6m0QxKMF/Rle3ye5DU8gIatRLGoMLbdoFxIudRtlsKM1KmFEhok4SpipOSgJ8YIlazfpFC5nSfpKMUQiBzAlYlJ8ZYo/dMGHgoUJXarjEJIOk9MulfC6EyqMObxoyoxxeISfaJ0IdXBB+I0ZC5XNqGgSyPLI1H7Nm9h42z65w6cZLBcCihcGR4HCYvwIhGl/Rb+NCHP8oDDzzIZZddxv59+4i+pbQwymFYbTLYOsTGAx9i9tBH2NedZKVdZ9isU/htijAjDzVF6DBdRYieypQc2oo0yxdyyU13U65eQOOFuRd8izHCPlsccyKig2Z0/JJ2ESQcUMcntJ/3Fa91P/8sAs0h1aOOXTEJbvdMpTT8zc9hEoioQHk/7uhbujd92dIZ/5rxSTbPvzvnswJKi3v0913/jsoEQZ8ceoD0ptd8/rnT5zkUb13GtGp47/veT+ODhugoaKnJDrrO03nJ+pkSIKS/kyPtvZeQTM32FXSb0TKLKPN8e4wRmzlGoxHD4ZDRcMhoNGIwGjEejhgNRrgsE1DWObIsB6yMF712nMEYhzOJpSl6SdaKgLZcstHrTnU7bxvn/516UdR+ZUzBdHubzfWTnDr2BNuzCStLy+RWtIOCmeuNBQUvgoIbMUIkEEh/RwxeMpVFWUZqmpqubRWI8ITQ6XskelkoSqCKXwiNRfGRGJWRmYAhLYcARPrefy/7yjETuJSAGwVt9PfEgPMdj33pk2yeOsZ111zPpVdcx7U33sjG9hbPufxyjMtVNF8KMq9v6YsxgatRNACNMUwnMxkHlYFpeqaUSUgLbdsy2d5mOpkymUyYbk+ZbE+YTCZMtidsbW6xtblFXdUYDYGL0ffAnLS5VFHp1kqlGSOMonkFKjCU+riyy0yMTDfP0NYzmmpKW8/6v+vZea9qSlNXtNVM2HXVjKau6NqaWTWjriu8l8yjWiMLzW6xjNJGovzBS265sv9ux3Zsx549tgMq7diOfQWYMJXEFh7lMonUTwYoYkdRb7E6zHCh5v4vfoaTJ4+SFRnj1TVGy7vIimUGo12Y6DA61wsEgvEEG/EugFWWgnFkxoEVp8no5EVYSvMJb3KeMEK97wuUypZ+ixGmEsLA8CHI5BYIbcP66RO88Pm346zlj/7sPbRktKbAmEjXtfjQ4azFZQpq6by795GMEbZVOr9WjlWGRPonAsZE3OLvmGfSsSBhcUGEi0NX93BSXw+aASWqhsLm5ibBe1aWRvjOUw5KrAIGRZHz4IMPcvHFF7N//36ZmC3Uz5ebzr7VsgiZcUQKGoYc3+j44R/5D7zjT97LZg3lYCTslNCwt4zccOUF7B5DmJ0iizNCO6OtG4xxbG7P2J7NqOqaajalqmomkxknT53m8OEjVLMaZ52ACz6QOQF1jK6mRwLWQlnmvPpVX8XXf+3XcPFFF7B71ypL4yHWGg3lyBkMhhhjKIqiB5OsEZ2hBFIIaKBA0jO8MIaqrjDWkLm5OGsIkRAtmIxytMTdL3sFDz30CH//LW9h355VDuxb4eILdkFX46yhrlrWNybc/9AjXPqcK7jlebewZ88qF110kKJwGBMp8oyuaTSFdIb3AWdzvSNy00KUFMoCrCYtoSjXZhUwEThSgZx5H0nOe0wi7Ead7Chha0FDMzOX9aFJCZyRqjDkeU7bdgwHQ9FqSow6ddQHgwE+COgWQqBu6j68Ion+JrDHZaKpklbFQZyYPMuIumJuNFzKd+L8GM2clgCtoFpPRq/ZKivK9tniJOsai2CDviceTghSt1IXymiysgJurCUrMrLCMR4us7a0zJ61ZXy9zeOPPsioLMF7CB0mVHT1FBMDTdvh7QCfDTlyapPffeefcu8nPsVL734JZe4w9RbuyXt56mPvZHD2IfZ2J1nxU8rQSrIAZ+hioGkDIVpabzkTx3z6aMvgyru48oWvId91CU3INOulI1gLUdtoGnAU/F4Ec6zTkJM0cKlbu8hSUo+3/94aAR0T6DNvF/PP6fs09hkdc0GyT9nEitH7LOOg/l7boe3Pm65h0eYbFr/rrxUBwrwCobEXQJZ2Sg+IybXOf6alVEJO7BlXyUx//IjuABjrmExnfPDDH6EL4NOwqfpgCWiIQXkdMQoAo8ycJMYWg/wdg2QrlH7vCD4QOgFSwJDnJeOlJXbv2cPBgxewurbGeLREUZai56X1m+pS+pTef2VjmgQA6Ht/T6yAhlb3SddtjDK/zgOjz7f+uwjRB2w2YGVpxPbGSU6fOszm6VOcObPOaDjGupzO5nhlFrJw7MVnU39/NJPidLLNZHubtut0PFLmUrofeq3e6wJVFKYRiXGkQv7BKxiU2FHpHv0N72nfoONq2hZi0PMJoGFChLbh0Qc/RTPZ4Pprb+DgBc/hwEUXMloas3vvXlpvsAr0SYNK9WwwUcZngwC0RLnvAmgFuq6Tdqqgl0lNToEzY2W5KgnWS62k9iDnCiEymUyYVRVZkWGcxWaOLBdR8NRm+rmGkfFC6llfCgSCMN5QMfGmmmHaGhMDiUfu+kW0818BE73sqy8TJSxUFicsRS4JC6Q86U3GKNGOk+efSQwoIi+55SppQDu2Yzv2rLIdUGnHduwrwH7mN96pEzxx3DAyeTfR40JHFlqK2DF0noH1nDhxjEcffxSb54xWd1GO1yjGq5hsgHUlwtLXSaiVTEnRQDAG4xwYh7EZxiSWysIEqafnM599StEwCKiU4KP0m0UGUTRWs5cFnBVR0MxlGOv45td9C4dPnubP3vt+zmxs4buO3AQuWBtz+cV7ufjgblbGDj+b4Osai1DSo0VXU9P5dJKbJkD6d++MaLHTVLivU2SlD9WoCTFinIQMpGuNcU72lsl/JCCZiM6sb1CWOaPhSL7T83RNCzHypS99iX379rFr126sFacfuQVE1TOReyyF60PvjCPagu3G8Ifv+SD/6kd/mkefPo3Jl4RF09UUpuGS/ctccWAJmk1is0VOR1dPyZylbTsm0xlN29G0LXXb0rQd6xtbHD52gtNnN8BmBBw2E8aHSZmYrNyv4DuciVx0wQFe982v5dbn3cJoOGA4LLBWHNMiG5BnOU5BoDxTAMllMvlNbdca0TRSpzuFeohTrBNpvVkuc1TVrA8BM1bCqkRzyGBMZFDmXH/tVdz3mU9x7TVXEDrRyzp8+AhlMeSRRx/nyNFjXHzRRezetcKutWWMkVVeayTEzDlLrkBL17WiB9T5nk3V+SBr9hGiTtkFNFLn2UvWvuQIiuOfWtq8r8Qo4tb0GdUEjDLGUuSFAEG9ALi00hAkXC4EYaTUtYB/4lDoqrc6PVYdYmOMsCSUXRRCEMdJnZxUlqhhVFZD4BIoZK2V8AhlHqFMGymvMJ9AGTKI02SUUSN6QHPgI4EqMWrGIwXj0rggYbXzMkmbUQH3zIITwKPIDWUO+/euUGRw8sQJnLVk1pIZg3O5sCvzXAAeNyC6AlcWnF4/zUfv+STbp46wvPk4zWfexb7uJKv+LCO/LSHDLscYYT/hcshyqmKZ43YfD5yB/be8nMuf/2rC6gVUODzCWBDR80LHCgE10Ax5sR9TxBmUoUiuPQENiQkgzFH9ToE7GW00bAyx2I8/UoVRdcZA+6xBxul+n/n4hYJQLAJbaUxPwJ4MbT1Q0J9Y+6U0axk3UdBLrkuZmoqnyb200k4WipKuSn+u2xPrTSz2xTbznVJdIqGv06rmQx/9GCEawOGyTJ4r/firdZ7qMiTnnj58J8jJNZOkJctLjHMUgwF79u7jwosu5tLnXM6FF13M3n37GI+XNAQ3aTLJtYQ+DGkOfBg9rlOGklPA2GXyzLMpc6YVVpN1wuRNY6S0g3T5CrSm9/kX8/sTocgzwDAsc4rcsbS0zNNHj1JvbLJx9gxNPcXFBhsastiRI8/ZzARsAhn6zHxy35yv+e63fAff8fpv4Xk3X8dF+3czKgyDHGxsiF1F18xoaxEoD76TUHIrddN2LSF4WUjSNh2il7oCrJEx3RhHSPpFCwwYUSAzBAV9BA+UOpcdpcw2trRbx3n0i5+BEHnxi++m87C6Zxc4y9ruPfKMc45OGaVSs3NL24K2NWss5XBARELhYuo/RvY1VrSVBFBUTbL+gPI8Nwoi0mfAhC50TGcziJGylEUo0+uBzcFHUFDNSDvt+xHKto6Btq2EddTUOGVWpz5pSVMiuRfyQZ5gmc6RBCjSvm4tLsspB0NcXmqXS8CbNLSFlidzJvT4EV7y3Kv1847t2I49m2xHqHvHduwrwJ7z0jeDteLMGgkDymzERY/zNSUdw8yxsX6GRx9/jLwckA2GlEvLDJdWaIOEClgjbBPSym0CMECmJ8ZgnWgCyZQyTbjSip5OAf+aUSfJJqcpRzRynB6GSZNgAy52sjpmJFWusY4ueDyBzHQ022e4+/Zb+KoX38XKIOP0xilcmZEXOfv2Xsz73n8Pf/Rn7ydf3UNNkNAjl9HUki45FdLopBRdhUvljzHK6qlmhxJevadrG2IQEe/QeaL3hHpG7Gp8VxN8C7HDWGF+APgo7C0LOF9x4/XXsWf3Lso8YzQsCcEzGJSMx0tkecF3f8/3culllxJCwNkEKklIXDEc4r3Q/7u2E+HvwRKf+cJD/MAP/VMaM8ZnY4rBstDfmyl7xo4rL95LYRq66UmWx0Nm04kc13um0wlt56nqRrKXVTVN5zl58jRHT5wgBAHFrJVMagloQVlYwTcYAqPRiJe85EXc9YI7GY+HjAYlLnMURUaRZzibUWZjnJXMVs6Kw+1yydhljOuXTY0xOJ1kJ8dR5rQKSPYTZyOhGCGwtbXF2toqTllTXdfRti2j0YgQpKxRGhM+wJGjJ3j08SfYu2cvm5sbDAcFN990g2T9C6L5A3PHVbFIBXBSeIIwaToFc6J1TKuGEAVUCpphK8syYkobr86Oy8TJMAY67zG90K58L46uaG+UZdk7qRI+J9n1mqYmz3OCZg5cNAkHLPrfRQWHooJWwUsZfOclTEIBCwEx5vpcRlkwAFkm/V88IeknAk5IWBFR6iExZhKwELwwlpyR8BBxfjR1vDpSzglbI4UZmRS2Z1I4npQ7qtBzRAXLi4xoI201pZ5NaOua6WTGoSMneODhw3zgI5/m5NmKwdIu2myAzxw+tpSmwPsMMkcTJhS2IbaRS/wJ/q8XrfIC9zhLYUJmWnyoiNaQ2RLfWqwbUjnHJIfH6pL76wPccffXcNG1d1BlS7RZSbDKBohgo8PEDGNFbyzLcnzwZC4TBpGOFf3YaaTuerBuQXsqRAGT0z01xmCdCqCrQ+v1njtlxmAS8KOwQ2rTerqgIB/qaEr7m2epSnumY/oggKuMl3KP0j2PeqxUVrn3GhokR9GzLpqWRAEF/aD9W6tD34MyplIbkIYoe0QTab0HZ+kirG9O+bf/7sdpPUSTaeYtYRtlWS7PFd/1unwxqiaYs9i8wCsQG4KMb3v37uXgwQs5cOAAZVnStS0hRuq6pm1b6rqiriu6ppGwua4V7ZrgZV/vBQhJoJK1GGVmGufIsqwHILKsFKHuPCdzTkS6NXNoCjlN7MJU34svCXNLdzhVaSR2HdZJGK+JgaeeeJxHHnqA+z//aT5z78cgdFgTCaYAN5BQsLxgdc9eyqUVllZ3E12OzUqiFaBuYD0njh2hrqZccfmlPP/O27n99lvZf/Ag5XBIUQ6Z1S1Hjp7g6PHTHDt+gieeeoqnDh3i1OmzTGcVg8GI4WjMoByS5TkgTM7gkbYYHW0XKLICTBQhd5OAJwVMmTclgMwafFPjTCR3hjzMiGcf5Z6/+hD4yA//kx/mqacPc8V117Oybz97D15IdAVg+zDl8y0+g1sVlJnUtS0nT52a6ydpfzSqFWcV+P/rTA6dvhfAela0gQAA//RJREFUTp4VGWtra6LjpJeY2KcxRrxQG7ERTJA5i4kRoqeaTqibGmN0kWJRB1Jx3whEI/MfUagCGyNyBbpQYizBZGAz8qIkKwdgZCwwi2Dy+daHHkpv/edv2sn+tmM79my0HVBpx3bsK8Aueun3Y4hY47Gxw5pGQZmOQW7o6glHDh9iY32LcrDCaLxEPhxh8lInh5muV6XZha726izBGNF7MFbS1M8nbzKZT862/Fw/nD/ypBnMl32RtifnRcwrAbvIHL7TTFjGQ5iRtRNe/dIX8PIX3slkY52t7Q1mTcVwPJKJdrSsrh3gvoee4u3vei91zPAhXUc6Q4LF0sq0AEtppU0ApUCMqhURAkRxEoz3hK7Fe3E2TFsRvQhS+67C+1rkppw4cmkVFSCPHQTPlVdcziUXXUiRWQaDAqtizllWMBqPeeMb38C111yDzUTbxhkRSY/R43G0MSNkA06c3eI3fuuP+PP3f5j1rQm2KMnyDBM9hQlctG+FA6slrp3i6Gi7WsEqQ1NV1FXFrKoIUYCRtvOsb25x/MQpNje3iapx5QNkKjCdKQNFIJ+INYFrrr6KV73qVezdu5vRcMDS0khC3TJh92S5aCRlWU6GI7e5ZIxxBpzAis5YLE6ZV4ZoE3th7gQn5g/JzdWPxsh93NhYZ3l5hTyXEK3klEuTFmDPh8j2ZMZ4aYUvPvAlqqrmqquuZFgWOCtgiiGKzs2CU2E0bEbOJ9mXjGoSNZ0ny3M6LE3bEbE0nToRyQmWrgOawafrOnGHVL/IKcAQgqcoSrwXVlGMgbYVrSSrTrCECabwOmV3qaOBnsam1N8KCiQ2k5Q/sYkkHMV7r6DUnGEUEW2jyAL7KK2OJw9CgSXp2alvK+iYCpKGBP291WOl72OQMBUBQGyf3j0BYEQBs8T5T6wrcYCcdapdZgTMxVPPZtRVzdnNbY6d2uDhx4/woXs+xdETZ/D5GFMOwVqsG9DFkjZCR4OJMwbWcbk/yj98nuMlg6fJuxkus0RkXM1igJhRmzFH7RqP1I6z4wNc8aKvYd+FV+OGe+jMAOMKYmhwBPCe3BV0bcTmGd4oqGg1c1cKXbMSChhjEn+Xejd9+5UKE9aa1G9qUkmAWeo5sQf1AxJ2098TdSTP6UB6f2RTYh3Mv1vsB6lc525XINAkACuBJgkETk7nvMSLJseZs4RYaHNo/4+aPbDfNv+xMDIl+AmMoYvQxcjmpOJf/9sfo+nAOhlnbc/ykf6T+kxUbTTnpJ8NxiNG4zH79u3nwgsvZHV1lSyTrJQ+eNqmETCp62iahq5tqeuaqp7hW3k+dG0ClTq6tsP7Tp4JCvolUCnLsmcAlQryXJIYuEwWTPKi0PJpVkwV3HeJ5amhdIA8M1IdqUVlTcYogJLvWorMcerEMR576AGOHznEg/ffx+b6WeqtTdrZjO3pVPSorCUaBwFMUZCXJcPhGGyGGa1hMwlrthbJouhbgrXs2neQiy+9nN179rG2OuLifQMuvOBCVsYrFHnJcLhEFw3HTp3mycNHefr4CU6dPUM9a6mmEn4dg8HaAq9sJYBohI+GCdio4KsJBBNl7mIka2RmLBZL7AJlmHHigQ9y+JFHueGmW7jy8iupO8/FV13Ndbc8l937L6AJqS2QZjrnWD92nbNNKtdax6yacfr0abpW2KwsgLZRQ3n/Ols8dhpVbRofnOh0jUYjYcxqqLFzTvStjABBBA9dR/AdbV3TtZJlVMbqQFLlMnKS/u+AdPnY90NZaBOQOhKNw+UlWTmUe25FdyvKgZ+xrtBriunaYuSfv/lrz99lx3Zsx54FtgMq7diOfQXYxa/437CxI4sNmWmI9RbjYYYl8Oijj7C5fpbBeJmyXKIsV8gHQ4zL8MZiMs02E8VZSbN6ofxbWdlyrgedAjLzSCwjg0zczreIMpYWVrlBVsPSHvTTKwkJWNiLJjqMKyiV5eAyRwwNfnaWVz7/er76pXdhQ8fmVsU7/uzdHDpyjNtvv41bb7qBldJBhJU9F/Dbf/x+7n/kCFUbhS2UL07otAxR/ha9m7RZwKRIVFBJgKUQBBTybUvwHT54TNdKNpW2pmtn+LaClD1OnWI5RSQT2hEEzy0338Dq0pjxaEiWJXFWy2g0YteuVb7/+7+PPfsOAiKI7YzBdx2NtzRuxCe/+Aj/14/8O2Z1gbE5hg5rWjLTcGD3mAv3rWDaiYgJE+maimgLOi/OTwiBtm2Zzma0nWcyrdna3ubosRN0EYwtNDwnCJvIWAWRdLIdA4Oy4O9+82u5+aYbyPOc4WCAs5bBoMQ5uaY8yxUQMcQykEdLbgpxEjJLtLLOnEfIUsiiUYpWch9TO1LnNDUWg6HzHWWZi4PoPadPn2bfvv0AFEVB17UaGibwXoywsbnNZFpx8SWX0rbCJMgzS/Btn/L5/Mm/qmn125MTHZR5E43l8ScP4fIByyur5MWgdxKstcJs02xoKCvJWkvnJSuYdaIf1TQ15WBAUzeSkSk5Dip0a4yhbVsGgwF1XYtDqk5U5iT7W1wA1KRtzx1OowwSpzo7knFOypkAC3GCxMmORMkwl+VEBBhK12+tpdN+cq4J+CNlt9RVTTkotavPNZVSWB9SfKnd5CxZi/cLrBcdZxLYJOCAxQRLbnOaplJwUVghk2rGxvaE02e3ePrIcb74wIN88J7P4IZL5MMx3o5oY0G0OcFaGj9j4OCq7hD/9LacO/OnKP30/8/ef0dLll3nneDvmHvDPJ/eV5b3KJRHASQBAiRIkCJBgk6iEcmRWpoWRZk16tFq9XQLs1pqOUpsSWt6ute0SDXV3ZRESaRIiRI9gQLAAlBAoYBymZXlTbqXz78w995zzvyx97kRLytBgNMzs1apYldFvogb1x4XZ3/n29+mLDyRQEOgtiWxu4/Xdz1nBh0O3P0+Dt/9AP7AUaCLMX1CtHR8gWlGmNQI2yJqf0pR27U6WsrUylkrjTLxpoEjWlB1Lxssa+wANEEYmAIwCCNIgKrJPiBlP2nVel4dn5zWidNQzZapNNldRnwFe/L9yb3KtbMDKc8x5SQbBYTzWHiVybmmQCVpsPLd1D4piRcs/qm28ZT3EqZSI4VNk2BzZ8jH/9u/RRUNJofY5oQSCa0LQ1VJfzp+/DiHjxxheWWFlZUV2aVli0lbjcoabepaRPlDoK7razCVBFQSNlMg1JJxS/qT/taoWLdzXnRzvAh3W+9wThIYlGWJdw5flhSlMJXsFKiU6zjXTQby2r/TBW5ELyiD197J71FhDN4mXn3peb78pS8y3N2l3/GMBzvyO9HUXLxwgddefY3Lly7lCpBidw6aia4ORsrVes/cwiJLy/vp9uaxrgTn8L2SbrdLxDAcV4ybhqWlZW644Sbuvvtd3HD9DRzYfwA/t8Qrb17k//E//D8ZDWs5HmFkk3uQhmqVGioXDQQrbTCmhLdWQF0MNiZ8s8sTv/m/46zng9/8Ic49/wJFt8+Bkyf42J/4EZb2H2RUB2HOSgedKjy97lVulXyW326gzXJ36fJlmrpux8Gox8nvyNdj8mwxs0yVCei9p1OWLCwuyu9DCEQC1go7LTU11WhIU1eYKHOrFKOwp60jBgl/Aym+yXggzyKLiTJfQplSIUFRduj05rBFR7TH82KZzgv2lJUUST7pHqbSfzkDlWY2s7elzUClmc3sHWCnv/nHcSngqSlNg08161cusbq6Sh0iRXeObn+Bbm8e57pKY5ZgtKRioDHKj77N6auNTBasExHulCfieVW4dXh04vX1jDTqNIrldzJxml7lMiYRjDBWunof0VjqaoCvN/m//fkfY6FMWOP4j7/7GX7/y89RU1APR9x982k++q2P4E3DuIFL25b/8Z/+K4ruAmW3T8hC4VNmkImPTFN1skyCJCCAZAESLYks0B2bCagUqkr2DTWxkewoKYfBTQNuSVggKQRiqOn3Sm656QZWlhbp9zoSIqZskW63w3Wnr+OP//CPceDgYZwvCQGScWwOG/75L/9Hfv6f/zK16+FNlxQCJo2YKxsO7+txcLlDM9qkoMGlRGxqiLA7rEkkAafqiroJDIYjtncGXLh0me2dXZwvaKIBK2nrEd9HfWEJ6Sm85cTxY3zP93yUk8ePUjpHp9vFGWFcFWUp2iVONLGcdRhniL6hAArjMc5Tew/W4rGUETyAS0RjSChY0jrVE+d6+r047QKCSBhC5OLFCxw9egzIAIaAENYZQiOhPS+//CrHjp3AFxqCZMEgIIhzlqaW9NdSBnKx1GohaYiawFSMxxWvvv4Go6rhxKnTWFfoqroAOTFGCuckRC5GmkYy1U2DOXINaSM5xA4FGCRcRzVz9B9xJgUAyNeo65qiEF2WlARYyA67MJemnOOcYQwBqcpSRL7l+aQ8MwMKzVaYAZ62u6qDL75Fvl8BaCXUQ0I3omoHOXV+JYRLnBZZvdcwEQW8MmgRp0Alo+FOVlf8pa+Cw+JNIeCGFUZWE2qaKPpg2zu7XF5dZX19nTMvvcljjz/JxtYuY9sD18WX8wQKaif6L7ekN/i/3lvybv8y/TSWccEXDFyXi02XV4cFo4UTHH3XN7Dvhjsolg9SGYezHWKwpJDwKVHaIGOAM9QRjO+0Dp11VgEGaVQSwjh51qCgmoCIkzY33Z6knKUcRG9NqiS3qdx3p8tWRJGnGEntHlKluQ/ZFoia3iO30Kmt7TkUTNLrJvJ1jIQsprzIsPd82cw0e02fwbRAslzUToX1te1B+00GfGMSgDcATTSsbmzxN/7232PcQEgGXxSSVc05Ot0Oi0tLLC0uc/LUKebn5yVpgPcS0tOGocq1oopINyoknZTl9NVApaapJYGEgtah0TTumm0xfQ2mknMlZdGhUFCpyKCSl6ySTsPgRNNNAfcpfTKjACVX1VfSUD80vMqSaKoxTTViffUib7z2Cq+/+govv3iOjfUrHDpwgE5ZMj/XJ8XA8uIiMQY21tZZvXyJpq4ZDEaEJlDXFbu7W4xGQ6kfDTcmSuh80e1j+3MUZYey16Ps9im6PfrzC6JVlsC5grm5efr7DlIbx8bmFilZEcRvIqYNwc9kuohrajAQsQQd00yKOJOwoaJMDTZWvPjcl9l65Snm55f44Ac/xO994lE6cwvcfu+9/PBP/imSL0nGywIUEh5+tV3dTsntV397pP0LuLS+scFgMGj7rMtzra/LtI1on2lZqEbChr33zM3P0+l06JaOECqq0VjmIzEo5CN9PSqo5LyjrhsBG1FQ6SqgV/ouJKvzxBhxvqDsdHFFpwWTkiZlkbKSrXICGQvI40VmKkVpc//lj3/H1NVmNrOZvV1sBirNbGbvALvl/R/FpMh8r0s12OGF588wGo7pzy/QnVvCFn2KrkzkYoySoSrJCqN1nhB0JcsgAsrWgiuJrWikTFBpU5PnFSpkYqqOzZ6ZybVMqdV7bWqLrnZnt8WRhKlkPNGXVOMB+3uRv/Bj38V8kXC+w+NPv8y//sTniLaPCwl21/jBP/YIJ48tg/XUfj9/5b/6Oxw8cgpblCSrmjBvsdSG+4iXHOWVgjoAmuUnBmIQarm8ItV4hMn7NmNCqIj1iFhXWF1BzedNxgpAhYBWvW7JXbffyny/x9LCvGRTi4GYEp1eh9tuv50/82f/PMZ3KeeW+Y+/92n+27/z31OlguS64EpcU+HimMU5z9EDc6TxJh0XKKxoQIFhXNXUVYNJ0NSiNbSzu8vucMzaxgZr6xvgnJDOjGRNC3hKLxlnYqgpvKxqj0e7/Ikf+kHuffc9zM/PUTpL6SW8rdvtgmZ0Q0Owsv6HaA4lChUAtd5SFx6SxyVLmQzORIILEv6WRFDWtO1CrHU08yeTHW8BTYbDEcYYLl68yOnTp1sNouxISciIE20qBS0AYmyUdSEZ1khTOl9qTSPMHsn+k0MDAk899TSLS8sMxhX7Dhyk7PSwviAGAY8Gu7v0usJcMio8LYCPhCbl7EBM6Qs1TcB7cULEKQnilCe57xziByiDIrOOBIQqiqJlaaUkTog4NKL/Iddo8F4AjXytDGwmTUk9PYvIAEGug6gsraiAkWyT8USALV0Kly6NSRMgox0ztG5yCI/0N0lxn5/PO0fTiPZQDDkcVvYtnCM1ogSSrMF7T4iJuh4TQoOzsLW5yc7ONpfWdriytsXzz7/E5555jtUrm/R6S7hykaH1FKXhdPMGP313yYPzF3D1gCZZ6mKOpy+PuFwe4vj9H2T/rfdRLh2k7M1LdrdkaZpEp9ulHo+xKWARIeKQEskVVNFQWhnXkgJCTrP45XbYhr/ZrC8ldd6GLGXWW1TlE81w5abCQnMB57Y2ARi0D7T1N92n9vaxxPTXUxWY95tmKk33kHbXjDZq+54CiSbw08TyYdmSMjNoTzc539421brHukHL2xiS8axubPF//5t/h7XtAb35Ra677noOHjzEoUOHWFhcoCg7bdhpLi/R5zaEphZ2iIJHRkm58jMQqOuGphFNpazfVuXwt6qmbiQkLmsq/dFBpQ6FV6aS9/iyoNBQuDymZh0y0aGTBSGThdFz6OFUaYugszBIUxINoNDUXLl8iVdeeoFXX36R1YtvsrG+xmB7i+H2dstAaaoKaxBwKURCaOiWJUuLi5w8eZrDhw8RQsPuYItet8NoOODSpYucO3eO7a0t0MxmkcxCUwa08diySzQOW3ZZ3Lef+aUluvOL2KLE4Cg6PYzxRAxNnoMoeCkDNSQc0fj2d0Pk9GtKRvRMxSvnnub8S2chVnzbt32EN944zxsXLrFbB/7rv/E3OXb6BoZ1wPhSwGzk9+5qy32oba8ZNJliYIKwEI217OzssHblCuTQxKmw0q9mKQnAC1lvT86fQ6mzWV1YWJwvMUnmJiYlvBGGWtPUwprOjMYUlFmkY3Eej/Vh8lMlIBhLo79VvX4fX5TUTaCJqZVDSLqIYJHFpuk+3No0UynBX/uJGag0s5m9HW0GKs1sZu8Au/+D305TNZy/cJH1jU2wBf35ZYpOn6IzJxk6yKnfUaaRzEITygJABZitMA5i8sSUwx+EqTSZ9k9PisRZaEIjos0xTTm3V4FNkjhEQ26UYeFcy+hAJ8IJA6mhMAYXG/AdajwxNvTSNv+Xn/weFgrVyFg4zN/8R/8T48phqkgnjfiR7/8AB/Z1GTWRtVHB3/tH/5SFfYexugoZQ8QXEiZk9bpTM0R91kZAIhIoiysTvmVCLZoZxERoakiBGCpiFusONbEe0ozHpNBMVgzbSX5S4fLIXKfDbbfexNLiPKUXUWtJIVzQKQvuvud+HvnAh/kXv/pb/OrvPIYp5ynKHik0+BRY6jXsWyjpdyxxtEPHyAptaGpiioyqhlFV0zSBZjSkaRpGo4r1jU0uXVljOB6DEYAxRvDegS0IQqbHO4vVc95y841824e/hZMnjtPtlBSFo9BQHAnd8BKqZyWDkWj/yGq6MRZrPSYlisIRCUQr5emxdJwnEBmbCNZRtGEC06ykrxY68NafutFoxOqVVY4fO95O9o0RR44MlCJAqWi1ZAdCzmW13SekCYBkIUoYBS0qHn/8ce64/Q5effVVDh46wsbWFieuOy1sI51wJySNNynhvYiIZ/B0wiTS81vXOp1Ww9OMAmYxiti1wdA0Dc5NGFhFUTAeV235iNMooI+AO8KuIGeiU9FYazMrxtE09RTDSdKCOy+Z4gSokZTfhglryCBOuM3Z7VSAPOU+nR2VpP1fQTNxrvI+uZwU7EBZT1PjhoAMwq7yzolzrPVmVNdLxjR1dLCiSaVMjNg07O5us7U9ZDgYsb25yZsbm7xw9ixPPfkco6ZD3VvAFIZTZp2fvGue28s3qZvIhd3EpbrL/Ok7ueGB99M/dprQnSdE6HS6FFhM1RANquUCGGEHyrhmCXhwHhsDJgn7QYbUCfAzaecCDGWmkgCdmgFRj8kFk5uOEaKOmjjtRhkKKCgVo6Rvl0tMZVK8Zu8RSzGKVpi2N6vZq0JoKHyBsYbRcCTZysg/DXJTTkXVYwuk6u9Imgptm2r7X226mu8X3ccqe6LVV1IWU3a4Q5S2ELFsDcb82//wWyzuP0R/YQlrvTjEU+eEhGl1xKQwpM1Kn01JQNKEgJiSJEHApNA01E1Do68JU6mW34hGQ+CaWhmvUfpRK0avGd6mhbp9DoXr4F1JURQCLGno215QScdWl8F36dNZpDv3p/Y5jRHikIZjbW9ucvHCeV575WXefO1VLl86TzXcpapGhN0tTC1h0k0jbKzQSB8nKciRwfAgGj9Fp2Buvs/8Yh9XeHr9HvsO7KPb79E0jej4DQbsbG0zHgm7qWkadnZ2GQwG1E3Thj1jvABPRYdubw5flDhf0J9foChLrJPfmKIsSK5HwBPxWNfBYLEp4GJFvXuFjUuvcvn8yxBr3vXu+7nuuus5+/wL7AxGLB88wl/96x9n2AQNfRNhdHlOfb7cMLQNTrqavJ+0pCnLbQcY7O6yubkJxtDUwviUeYcCmV+l7dNeevL9tfa1VMx15L5JEZvkR0uGlalj0TEqIuN4Dn9Lmn1SAdVkDA2G6Ap6/Z5kB82/gzmDXTurAZN0oWzacjldFf72X/3Ed+7db2Yzm9nbwmag0sxm9g6wG+9+iDfevID1HXxnjs7CEq7oYn2J9b7NCJeSrDBNO8opmZZOb1U0NqUoKbPThNXz1UeSRFKR2KQOTDtJao9RoMYkrJlQupNOYkLdtBT+oHRz6xwGKJ0juZIKR4wNdrzOhx+4mQ89ci/dwjOOnsX9R/jN3/wE61c2uOv2Wzh9YpmqGbI5qvnNT3+JL515jTpZnC8xeJ1sy+1Jlhahu9OyWYCc9U1mz+LYkeRZgmgriVB3giCaSjHIqm+KFYRKttcV1WiESRHvrDgXWiYAhkisK1aWF7nrjtvwzjI/18cVQjcvLThfsttYzr6+zrizn+S7EAKm2uXE/nn2rZQ04226hcOGhvHuDqV3jHZ3aUJkVFWMq5oQI4PBkNFozPmLl9jc3CLpaqM4nrJi75yX1Wxf4J3BpMBcr8v3fPS7uPfdd1M4z/xcn7JTEJqG0ju8mzhHzuX2ZAVAmcpO5AtLVcs1LImSEV0zYmfzMt47ysVDjFyfJhUKKk0cZ74qqKRl2Tqewq6JqtnzxhtvcOONNykrRwWyE5RFIaFwCnBM8t7o+SRHs26Rv9YXVFXN2bPP08TI+vo6zbjivnvvY2FpiYBhOKo0/bgcIwCOZFtKSe4zg64CHDV6/wKakBJFUVJVY0DSUUtohWSPy2WQj09JAC5JRy7hDU61VgQoKmiCbEOvL+F1Ui/S5lN77qTsF5vBYi+sLaNAUnYmnQJgxghabFTHxylDybRZ33JmrSgr49lnzG9yVG0SMElYk9P1LPeWslOsY8cE3GowLgqYlBzGSOKBoDpoZVEQFWAaDcbEpmZzY5XNccV4e4srl9Z55sxrPPbUs4xi4Lr5xMfuPoJdPcd2kzhy6z2cvPMhDl13K35uEXwBqmOVIhAiHkOTIskZAe+N+nIhaQZLKw6ZTQoAyTPJc08DS5m5puWnztjkeykHqcvJWJrPGVPCZ9BQmU5J9ZJymedwFxmjpa1nQeGrLWr5JRKhkcUAAZikvycVtm5qCT/K/QVdpECvk5KIj8sYL/3BWAkBRK/fjr3XsHYMkGLTsKo8ik/KLimLrYkJXMmwiTzz/EtsjxsJP0wCDE9OJo5ubB3gKNv0XvK9p6SaOAlCEOH8lJLqJimoVNeMqzHj0VAYQEGYSXVd6e+CgMVfC1RyXrYVvov3Jd5PQCXvBVSyU+Fv1lmp/xz6ZiXNvVVQSZ4rl61AronEeDTmwptv8tqrL/PqKy+xduki25trsiASaqrBFjSVHifPHfT5UVBJS4kiBkLIGlMRbKJR3SirCwyF9xTW0nWOpZUVTlx3HUv79jFqGuom0un2iCGyenmVF154kfXVS1iCSBDCpG0lYU1jpcys91hX0J9fpNubE9DQS5tcu3yJZrgL4wGYxOnrr+eOu9/Nysp+uv05Xj9/iYfe942cvuVWqhipQ8LgBJTR9iHvtPwy4IiU6TVbbLurvIkhSFsPgc3NTUZDEc4OmhFTxrJr27X6xLW2eSp6nYLCOlm6kkat/UJj3PTYYKYYSsjvnNSl/GYlHYPwBa7bwzkPym5NoAg2Ohbld3m5bMpmoNLMZvaflM1ApZnN7B1gbvkU/flFOv1Fiu48yZVYX4CuYiaigB4pycqfMQjt3AIWXxTizKITUwtER0qyeismf/eufOZvxLEUB3ISsqIzivxHJjYK1KQYKLyjrkaS4a0eUxaOXrdD4T11givrmxgsvrdAMAWucNiwy4rd4Ye+80Ncd+QAzlhGVaS/sAy2ZFxVhHrMxvYuv/fY43zlxTfZqREavTGkBmE7+EKADoxmtJvMuyOSGceotktesc7AA+rgRw2NI1QKKjXqPNSiqRRqYjUiVGMBgYjEkEGlXDaiYxXrin0rS9xy043M9bt0upJWea50lGVJdD2uDOH1jYpoC+a6JQfnSxZcTV3vUhSW2DSS0aeuGA12iSHQVA1VVTMcDhlVNavrm6xvbLE7HIGxuKIQ0c0o4VIxRspStJTq0NDtFNxy0418z3f9MY4cPoh3VrIRafhRt9vFW4tT0WQBMyTUTTR5FFBSwNI7aIyjidC1sBy22Hnjac6/8gwL+/dx/PaHGbr91GaO2AIQ6mzrKurVJptk0iufpzxQY9je2mZtbY2TJ0+qAy6Z9GIIwrZo3awJrIQ2V3SinfvMcDTm3LkXeOHFlzh2/DjOefavrHDD6dNUTUMdEuO6oVYWHgqExVbjQoC2lIRhFJVtY404HShDRbK9qXaI6sZICFtBVVWUZUkIohnU7XQlMxqG0WhEv98jajhZiEHCypB2DxIiY212NqW8BKjKIIW8z7pOAnRJmWRHySAgbGYPWQ2dC01DUZbCAszP1WqBIHpDLcNKAybUUctlkFmEWXA6X0/CvCbgR+vSmSSZIY3FaGpxcniihgV674W5FMASGVXbDGOi2tpitD1kbXPMm2tXOPPCS6y/+QI3LlpuPnGCm+65h6Vjp+gsH6TTmYMkYEkTGyBSGBW+NY7kEM02BW4IicJ6YpNwvpBxRnWl5bkzK1IAl/ycKHjWskDymGvk2iaDajp+SSVO6qUF+lrASUFIDX0UqEFPm6Rirt2vZL8Qp/W/hCVXeC/PoQCjhOrsPYeb0kBqw7G07Yk2kbSvlNIkVPIPsbZXp0yvmDYBVDKLJhpDwFMly1NnXmAYDXUCklWwWNpN0jY/+d2Sbeh1ZNgXUCl/DiHSNJL5M4QgoFJdX4Op1AjQUk2YSqRrg0rWOqy3Agxr+FvhuzgnIW9lWeI19M1Pg0rTTCUElLXKQs6gklTzpGydsdR1zdqVVV5+8UVef+1VtjfX2N64wnBnC0ItSSfGI4gCnqWUWsJuUgA4KdsppogJA1KKhCgi5NJ2NdtZlLtIQX73J6NtZjl65hYW6Pf79Hp9Ot0eKysr9LsS0pVSogmB9fV1rqyt0YRIExp2d3cZ7O5Ky0hR27O2DSkMSAnb6XH40CFuvvEmyk6f3tJ+br/tdgbDisWV/Vx3080EK7qNmoEEGxLJSEY1bQxt+UmXnS7Rq0y/S1PhcEkF8OumYWtzm5FmXM1941ptP1/n6s9GgZ/p7zwV/VKYSiZl1FjHgbZVa7u+qvOYZKRukXDvZAxlp0PR7bVyAUk6guwjR+09x1cpjfa4hC5WzkClmc3s7WozUGlmM3sH2MIND9HpzVF0+iJGnSStuQBEBmNUdFT8HKxxsnroPMZ6XaVVzaTsTGJFUwBkSqJDyWSbbAdZ1RLHQvRO9giz5omFTmxCaLAkTGroeEs92mWwtcZHvuWbefD+e1jod+mWBTWWnXHg537+f+X1S+t0F1dIzkGqmLcj3nXDUb7zA4/g6xGm02cYYJwMxvd45eXzfPJTj/PmlW1id47gLDE0dErPeDCS+01JtWTEOUtTczSZsEWd0CKaUfnLNiNc1ptJmFCR4sSJSKGBoNngxkNMEGHvUI9xqDhvW3pIuKABaxLLSwvcfeftdDpdut0O890Ck0RsvaJkY5yIxrM416PZ3aBnazplye5ggDGGwXAXa2F3d4fhYJcYoBpVDHZ2uXDhEmu7Y7CWEGUyj5WV75QSKQTKQnQ6Qmzo9kp+4Pu/nztuvZl+t6Tf70EUUeGyLHFFQUqGTuFbAMFkAElFsa2xGNX9MDk8qDdPBHy1S+/SC2w8+2mq7fNUznDs7vfTP3Q3Q+ZJ5URTCXl39VxWTB2JdgKtTKUJUALj8Zg333yT2++4k9FoLO1YGURyvEyLYxt1lTDKmJF7F9ZU3UQ++/nPc/7CRW668WZuv+MOSeOcJGTvxVde5cDBQ7iiIMRJyFkOS3CuENYgKPNjArDIvUtbKwpPUOcsO96yTRhGTSNZhTJAVdcSuuacpQkBa8TpbDITRB16ow79XrBu+q86kDHhnGQla+oGKS5x2IVVOAXaIE55yMyENnucsIWc88KyUn9PQqjk2MTUOKHb8jNLdQuYlp/TOem7KbO0omT8akGRhABPOqYZBcVCDBhr6JgSQ0OThjS+C8Mh9bBiUCWaZszG5jahHrLQNRxYOcbcgX003mK8o4gGUwsTKFkjek3K1KljEoH5zKZKUCDp1zHCXgqqbZIEd9J/5BmlGepYlB3H3P7yo2k7NW1aeKkTAXQEeDTK9hTAXOo0M2zk2tMgj7JZ8j5XmdHsiXVdt+Ofc45evydhziEwHA4pO522nU0fK2/kOVLLVJrohxlrJJxKM1rla3wta8tH/7a/Q0naVtM0YB1VNERb8pWzL7BTB5IriCHhkcUSDWiTk2YmR/4vt8kMqEyFv8Uo/S1pFrhaxbizUHc1HtPUkv0tNA11VcnvQswMymuBSpJl9erwN2czqNTZw1T6appKGbQD/e0nM9Ny2Rqs9YyGQ95843XOPvcsF8+/SaiGjAc7NOMBJlaEuhZGbpDf7NBItjgpG+nLk5EyEZJmtVN2W4qJGJIwYoL8tqQmSvJHB3Vd4TF4Ywl1RVOPRS+NhHEWHIRoMDg6nS7eW+YX5jl06DDLK8skEp2yw9LyEikmXn/1JV5//VXOXzivbGfDvv0HuPOuuzl46DBbO7ucO/cCS/sPctf972OuP8/hI8fYd+AwtuwQMqsWg4kJHxPJJqKZlFxrGVDSf9JUe5/eN7ebnKWxViDSWU9d12xsblKNx1Jxf0jbv7pfTIAiuRcyqNQp8bpgYrQebGaXTrWAPabjZFKukfWOTn8O6xxNjML61HFJzqW/A38ES7nvaF+agUozm9nb02ag0sxm9g6wAw9+J2ApihKLI2tKgziS5PA0IytR1jiZzFoPRvRJcnBX1EmjJTHhCUwmNi2oZNJkCpWsaq8EiqJkNBqJ08NeYCkZAbUKCzQjShN44F138E3vuY+uDVAPSfWAwhooSih7LCwf4skzr/Avf/U/MAzQpETHN3zsw9/E3acOUYy32DY9PvOlL7O6vc1Lr17g0oVdFhePEWyP6B0hVcRmgDOyRhdJzM8vMB5XqL81+WsQYfIUJ2BSjDJ5zJ81RAJdgSOMpkClQAqSfYXQkOoxzXhMqCtSqLFh2IZa5BVDmWgaSAFrEkcPH+LUyRMszPXplp6lhT5NXTO3uEIVDVUTCE1Nr3DQjAhjWckdVkOiSQyrIcPxiOFoxGB7yNbmDuurG1RVgE6H2GpqiUhsUtDDECFGOqXnnnvu4ju+81uZn5+nW3j6PWEklb5QYdmCouiIroVTBsVUBiKNXMMoC8ZaSzCW14aRP3j2acZhyCN33sB1uxcJL36JZvMCVVHgj9/Fgevfg+ks4/LseGoifS2Tr3L9TIMkmSUkzufa2hrbOwNOnjwlmiNECufbLFzS/qWfQMJEAWdQMVSM5bOf+zw33nQz43HNvv37qeoaby2hqrl85QpnX3iRu+5+F2W3S1InXMARKZLczmIIck7NZpaFmsVRlv5ipoAhmfpnB1rKVEIVpZ8VymCS84mzmVKiqmrJGjfFSGqPS/LUAv4IC0i0lETs2hiomxprxVHPx+c+nX0ho0CWszIOVFVFUZQqMq37GAGHLFb+5hAKfaQ8VrQggYInSUGsDDRl9pUcr2EVxkISp8eCgoEqautFPLwKDcZaeqZDiDV0ImPTwVVBdNGw+DRWbZFA0fF06DB2iVha6hjoBEMRDIUtGTeBcYp4J0LbJgUFlGRccOKeyv17S2MaYgE+WGzUcMs8fqj+kBRobs9SzBn8QQGk/F1UUC2XqwatkFDNIQVcpL5Sm01OD27LF6QiJ91r0s9CCBTeU1UVu7u7CjxJGJyxlv379tHVdl5rQoD2DBmsisLmnHZK24fO+6Fhj+3mqe9h0kj0b8tyy2FD+euUS0CcZHzJsIYnn3ueYTQkX0AEq4xG9LdALiF/hRWodaOlmjKopPX1FqZS0ygb6Wqm0l5NJVQrLSbJIpeuCSppeJu7lqZSiXNOmEw6Njgn4W/RplZHKYex26zdpoOOAAsWYzwbG5u8/NILvHD2LJvrVwjViFSPIIwxqRZQKSH6UZrpNLVJJ0RrKMXQshhNLQs0AQFiMIZIlAUq3dfoOBjrAGSWk7D36qpqdcFE0LzGRGHRAITYTLWLzNaRMXFpeYmjJ0+ysLjEfH+e1AgjsmkaLl66yOtvvMZwPKA316O7uMJ7P/wx3vPQe1jZd4AmQnKOJiGgUkzYmOgYSSpRa+DdxHQO0H66+s3EMoxj9Dc+Jk0Aoe0qNIHNrU2Gg8Gec07btbZP/xbm7z0V/W4p4ZDavnP/kK6h29qrT45PGKwvsM7jOx3wMsamZCUHngLCBoSBeq1Q2dT+M2VS4dJvJuX212bZ32Y2s7elzUClmc3sHWDHHv6YygxINpWkTofMIMTBNxidwJY6edcwCuR9Hija9Sx1IEwCI6qPOoXzEhYXG5ypcabGFwXDwS77Vpa59ZZb+YPHHif5DkYzyElqX8kWkxJ0bKTZWeeHv++7ue2GkzgCo9GQECNrG+vMLSzQddDviB5UKrpcWN/h5//ZL3LbLbfwyLvv5Mi+JWI9JiZ47vI2v/Srv05IDuu7hGApyz7GFlRBnD2sIYYaVw/5wCN38qH3fyOPfeEr/PJvPobr9rAp4mKDs47KCkDmk0zD88q6OIIq3ooKBQMxjFWoO0gGsRggNtDUxKaSdM21aCyZMKAaj6Uk3cSJh4nWirGG40cOceroERbm51iY60nImXWU3R6V6jINB0M5x3BIXVdUMVCFhp3hiOF4zGA85vybF9nc3MJZmcyGJGKnkHCqXxNjg7OGGCqWlhb5ge//Pm6++Qb6/S5lWVJ4R+G9sJNUM0lYMV7YMgpyuELSh7skYQSRRG0MQ+epyi5nX3uT3/nc57iyucp9d9yOuXSRH33oBHa0xaOf+QOuv/UO7rv1dsbdRSpT0vNdquRIpkTkusSBju2kOuKoSamgKLpEchsTx96qhpAKjoCRTDzbW1ucPHVSGQRBgAF10EMSUVpjEqWzeAVJjRUQLqpoLRrWVXZKLl+8zGAw4MzZc0QM9z/wENaLjkhS517E6zU0ASmnGFRsWLNLidC9hCEGdTpzP3XeUVcC8OR9MtAioWYKGKjTIQ7rBKRoGglhCprlKgtwoyymDL5FzQKXNPuQjCOTaUTMItvqrGbnPmVw1DmihkvlZxAgq4GUs8cpgKWheTFGcXc1nCu0QISZ0gLKrCcRAc/3kdBwvSSgRFE4mrrSTHRaDk4ZPDFSGBGKTzYRMDjVfWpiwllUP0SE0YmJcV3hOxIO6hDWBVGcc3GYpJxydjCrz+9yNj4vLL4mBUEVo3BAr3bCYoxt2KBzWjfadpwTFkWcYghkUDAqG072mTib+ZzOOWnXqlXnbAYTJcxZqnZyH0ZFkk1meIXAs08/zfLSkugzpURRFpASZVmwsLjA0WPH2djYVkFv0fCKGvIjJ5NL5PaYLbeNKURLx1axmLP8TbHVMMJ8kGedAsNiI+Lc2t4NEVzJbm144tkXGOMESE8J1x40udbE6Z0GDSQsCGXuJRW7D0GYb6EJhBAIMVCNK0LTMBqPFVSaMJVEX6mWZ8vhYZnlagXYd6qp5JyjyNnfbIn3JYVmfyvKQtlKHjMd/maMRLWT9ZRkzMhlBNOLO9A0ia3NTV449zwvv3SO3c0NaCpMbCRsOzWkIM8XlZEbm9ACbnFKazCPDTFIwoOQJs8mwISOY7l8tfyTlnOugcyGy+1GwCiB9ZKG2OU6ClPZ0KQlQ7JWZjEJTNT5j7EY6/G9Pt25eR565L08+Mh7OX7DLVjrRaspgbGeRrXHUpLQd6tll8PfJm3i2nb196kFPI0uTukXE4xPy1JChi9cuDBhDGfQXSUF0BDqzHTbM9briR1jet0CZ62WmzDicluQ8VHHTZdDkmURKGLp9uewviBZK2wy5PlFW2q6GeXFjb2WptpYay3T9CpQ6Sc+ctWOM5vZzN4O5j7+8Y9//OqNM5vZzP7Tsn/wP/+SzlZybL5MYhLCIrAa4mSc14wqWSNmYnn6OTUNlUmFzIvQdCHCX4qioeOoSc0uh/f1+O6PfAs/+H0f5YVz57h4eZVkC4J1YMWpwoiGTF2Pcanih7//u7njlusI9YDhuOKxLzzBL/7yr/Jbjz7GV868SIqJlcV5bKqIzZCVpXm+6ZGHuevmm5j3Tia8tsPzr6/yT37xVyh6K7iiTxMcRdnVSVPCqDCucQZS5Oj+ZX7qJz6Gq7Z44F13c2l1gwuXLlA6hzcGIlRRwpKmV/SkVBAmwtWTqr2+kkxs9U3rjGiZmiSsGJMdInX+jTLJkFtgPBrSKQq63Z4ANup4xBioq5q6aQghMhxXxFjThIbhqGJnMGJnMGJzZ8Cb5y+zOxpjnIBzkgVQRMl9obR21Xnqdjzf8N5H+KEf+j5OHD/G/FyfbrdLp1NS+AJflBSFgEo2i3J7zfpmJVzDOIs1AkRiLBRdhkWHS+OKp159jV//xCc5ceoE3//t38o33X0H77npei6f+RzrjeGx517lxpvvZPulL3NwqWBxrktRztMkR4OlSRBTEHxIy9ICVvWGGmUPGGwLrgqbRevKGDCRbqfHcDjk8qXLLCwsTJxudVZSlHAmawyj0YDPfe7z7Nu/nyZIumZrDUUhYWYpRVZXL/PMM8/grOPkyZPc/8ADUud63aIsBbjyWQRdQLgYJGwptxtrBBSRULGo2d6EJWCdYzQcTUKEDFSa6S0mAVfEgRSWUgYZ5OTS2kSDSYCFDBg4K8LJAlgo6OAcxqCgUKNsqkl7z6BLnAK0sgNrkHCmHFaakvR5UIZRCG1WJQmxFNAgxCCOSltV2SGW27fKpBLnSL7HSChS1liSsrNUdUVRFi0b0HkBUUKUa8s9FBJ6pyBwTEEyLjph7YmIuj6vtThjIYhAvxSnlp+RcTDGAHbv/aPsoyYIy4wE3mhZpskIq0dgVLTaGhWytnJ/ub0IG2kKyIsijGs0sxvq2Mm4ogNJmxVN+ogwV/JLHV8j9S/vZVzKzzGuxpw9+xxNXbO0tIh3nmo8Yntrk/m5OTplwXgs2jC+KKW/JXHonYYYGykQca6nfnNSbpn5ctp+p20yTiorZep4ptqJAUwGm3UfgwC/VTScX12nMdJu5Rz5OtdwhNu2rvWUcZMMDGQHWdt3zDpJQRYVQhMITSOLC0kWJGIMxJiU4aO/zUmfTp/BGhmHrFV9Ja2nDBxZawWwt8pqUr26lh1qtRyMgOf6YfI8uUkkaJrIaDhk9colNtfXqWtJJCEBUJMCyacwGJy2EwGthHkqYfQOYxzWy++Byfeof127+ODxXrT4rDI/rZMwPmsdhRfNqLLsUJZdyk631ZByhfz+5JfT3yOn711RSthfFic3gJVQrt78Ajfccisf+raP8PAj38iRY6fwnS5NCNR1Ayi43z61jK+5fUpHab/cY6n95+rPeaOeVT/KV8LYzrsZI0B7f35OdcYEfM/jl1UQuKmblnk2DeporWNTQ6FC+LnRpqTZOuVBWjQrg0YpgXHFBFAyVhJMyC9re/Zpe+sWtWuWkdbFlKWU+KZ7b967cWYzm9nbwmag0sxm9g6wv6+gUlKGUkqil+OcOErWeUnlbmzr7H4tm54WtRMDY4hRHERHwlJz/clD/MmPfRv7FrqMhiMe+/wTrG4OiK5DSA5cIQ6zOutNCBArjhxaYd/+RS6uXeEXf/nf8czLbxCKPkVvEVzBa6+9wcULF7jx+hN0bNRV1MRgWFFFy+XNIZ/43JN85slnwfawrsQYT1MHYrLC3PJWJpcmYmiI9RCqMe+771Z6Zkyzs8F9d9/Jpx79hDjivktVJ4pOIeK77WNnZ1Y36DZx8HWapXM2TGpXCkkyiZTDNBwlTujjk3XW9qRS7gZSiqyvXZGwB+/BCCOi0ymJMbKzu8u4qiAlhsMhg9GI7d0Bl9c2uHD5Mlvbu0QmYVvGWkJMFEVXV39FKB0SJ08e52Mf+x4eevB+FhbmxWHslHS6pWh5FAVlUUgaZ2MFUJp2dlR8GidOtneW6DxVp8sL61v8i1//97z46svcf/ftfMtDD3Bjr2RltM7gta9gti9yiT5Pvniee2++mf1cYef8OfrOs1V3oJwjuJLkC4xXB1kdHZssNlmiSRgvk2sJg5K2blGWiwVjAphAjIZer08IgZ2dHRYWFtrib0JDWZRaFYaicIQQ+cIXvsC5F16g3++zsrKS5+ycOXuWovAMBgNOn76ew4cOC7ilmknZWUfDBrxmUZO2oOyTkBkYGQQQJ7NpRAOo0PsBRMC6rrHG0lEdG69Z5MSfNqqtpOFu1khYmoKRRhG5DEJlFlAGjhICAqUkoU82s5CywLeGzoGAOXLdnEFOHAbnnDCRNGzPe80Qp9eJUUKnYhBQq1GmnuyjTnZmTilgJiCFgGX5nqYHqOyAhxAoy0IcMA25jJppzCuzJzQZhEM0v1T/S/q4lGMMohnjnTAWUaaK9FsBeKyWXUySPVBCwwSUk9BGS0LKQcpQWTnTt64DSv6+KArEkcyaVLmMTRt+ks9HBvassrGmnM38LPm9NQKAGgUw5HhhyWTL94IKxYcYuHDxAl964gnuffe96tQafumX/iW//du/zerqKnfceQfWOXZ2dlhZ2d+y2lISja2oTM48cJqWGSuFYKZArLYs8g2pU523T4NL7fO250XCsYyOAYAhkoyljlZAJR0L9ORT73WLltf039zO8vuk9xSVHSbMVAlrCvq+CZIJLgYJj5P9hO2DLvYI6KzXyoCQ0d8qOwFHcnazDP7KuKsaSlmI20y0s6Qg5JXBhlwamXmSkgC/g8GAK6uX2NzcEDATSRhBu6cA3c6KEHgOw7RW+oydBoesxeXFK+c0DFYExwvv8YWwqwovf53qOXonoJP3hdylglT55bxrj81Z8HwhGlNFKYscRaFMrqKk7HQoi5KylHBBY0Uz8MraGq+/8Sbn3zzP1vY2C0tLFE6u6Z0Izv9hNmmTe7fT8qzyd1OfdVvuVrk/JrRwp/dXHbiyLOn3etR1QxMERMrtzheSWEQWHyZXycfbFCi9ANC5DtExGyNhbAkBHEMyGOcoez26/TmcL9pFr/xqz/6WZ/6jmzyD/oUZqDSzmb1NbQYqzWxm7wD7mX/ySzqX1Mmp8RSlrOIZ4zE4UsyARZ5ufG0z+k+e+KNzI2ushBs0Ax6+7w5OLDgsEVf2+fTnn2QYHMF2NJuKTsaNhN95V+AtnD3zDOtbWzzx7PO8emWHxs8TbR9MgTdeQsVixU2njrLY7+B8wfr2kN/91ON8/ivn+I+Pfo7XLm9RmRLju0Rlq1gn2hQYQzKSWlscrkhTVaQm8E0P3Uk3DWG8Q5EiH/nO7+TJp55jexQwRZ8q1qDaJJOyUOennXLLbMsY0ZmSshJRVHF2ZHrW+mq6kkqSjEcCOEycP71I/gejE0IJB5zTlV9ZKR4Nh9RNQ13VjEZDtnZ22NodcGn1ChdW16hCIiVLE5OsQCYw1tEpO9iUMCZiSXgH99/3bj72sY9y443XMzffp9fVSXmnxHtNca0rz14zE01WoNWBcF5WrK3FWSS0oOhSdef5xf/wW5ii4MPv/wa+4e5bOWwdS9vrXHnmc8S150mb61zwyzzx4iW+60PfxvGDc2y98RKXXnmFYVVz7MR1VDgR2U0Jk4IKkU7+i85SqYC1MeLMeudQhSRhl6lYvTEejKXX77OxscF4PKbf709CsaZAwBgjS0vL3HTTTdx5150sLi6wu7vL+voGc3PzHDt2lPMXLnDnHXfS7/dJJMpOh3FV0TQS+hSiiiZPOda5fWTwJalwMghLJYTYMsmssmuKwgs7RR27uq5wzlFV4zYTnDEG7wsNOZFJ/DRDKV8fppkkEholQImwlIxq8aQUiZm5NaXFhIZl5LadWidfQBZxZARIjlPhfLL/hCU1KXNlCmj/ymWUtA6MEZAlO7hZl6ZduTcCgnkvoJsvvJzTaG81ue+C9yKgjmZSE4JRdr7FsTZJ9GkkW5XUjQiqa2a3qftrhwN1wrWQ9WwabqIaVVVVKRDQFpzuLieJqttDEsaZ/M3g1d4sUTGHtmFwXpIt6Fn3mDBYpoAng4xNkyEd3dLWgTWGqq554dzzXLhwntOnr6euagrv6fV63HrrrTz66KO86557KMsOKcH8wiJJNXKcE5ZDmmYqtc8pDDOpk8kdmD1DYYbbJ9/ncmid3KvOKSCSlGP+jHFUwXDh8jqiEqiHaqXt8ZeTfE5tvFNmKU2AMpIyj676m1SzKmR9paZRwEn6+DRTadrBlnuRZ2lZZNq/pa4yaKPMHwVuWpZS2xZpAcK8Lb+f/n2R55NQ2PFwyPraGjvbWy1DLpeewWARICn3D/l/AmTZKaBJgM18bbkXAZwyo0nGk3zfzinryivj1UkG2pz1TsZLOVbGdElIkMvD+QLnRANIXoVsy6CVK/YAUGXRxRpHXVVsbm5S6ZjklHGLjjlXW1tDWoZ72otuuApGekt5g8h15frO25L+k4+fHlvLjmgjNY3IBciigIyR0g71JFPmUhCmUvsc2maRkNCgfTMkMGWHbq9P0ekR9fcyaZPPLSDbW0tl8ix7TNvPtMkzZgBV1ctS4pvuveWqPWc2s5m9HWwGKs1sZu8A+3v/r39FFhPOkytjvc4SrAgz66RZfvnTV5kufBUzkIxmdkkGbxwuVpS25j0P3k3X1AQsV7bH/N5nPo8t+uJ0NRUuNXgTRYPJOWwSIKLo9Li4us2wBlwfg4cm4JqGIjZ84D33873f8a30+yW4kvVB4N//7h/w5effYG0QSUUPW3YlbMlasAlDoHCILgQiomuwpADelBS+ZDQe8eA9t7DYLzAxUTWG7VHNzbfdyX/4jd+h01sgWmQSG8XpbouqdWD2WusfTU222vlZ+0cd0ZxRTifLIbaq6lMnFocsyo5cvnSJ+YX5Nlwqxshgd8BoNGYwHHBlY4s3L1xiY3tARHQkjPMY42hqEYTOk1NLIKXA6etO8kM/8P089MB9zM/36fe79DolRSFhImVZ6EqwisKqY1PkEAYFuay14gxYhzFJhJhtSWVKHn/qOVYOHiaNhnzrww/hdnaZt57YVDz7/LO4XsmgcXxxs+LV3Zrbb7mTpeV9mPEumxde5MAcLO7bR3JdmuQgOVzMIN6kPddB1JVSMhgLzhmMjQIqTYlCGBWoF62XRK/fZTwesTvYZWFhgaRhO0mzdHlvCU0AYxgOhzz37HP8/id+n/PnLzAYDDhy9AjLy8ugDB3nPaurVwBZqSeHHCmYIannW0obKbMCWkHxrBUjzqoxlqZuWofbKBMpJeh0ujRNQ1lOwtTyPhmsohVWlXApqyFoScPSsnNgVSQ6X1NAq0bBgRzCmfWTNCOdtueo5/XeqxaVOJXiYgj7JrOeMsspPyMKzORwGtR5n3bwrLK5nBVBcmMmIAkIaJKSsKBCiJqtrBJnMUn4G0l0YIRdpW2BxGg0ZG5ujrIsmJ/r0+/16HU6zM/N0+v26Pf6zPX7kJI+2wRQyswkO8VSSlcxlUIUoesENEF0pqTqBbCYNgHfSg0NlGx5XkMhk7avaUBKyrvBWCOgQGZwTYNWyuJqw9+mgYc9QJPUhxwm16rGY1544Ryvv/Yad915JzFEer0uB/bvZ3FpkUuXLnH77XcoWOAoy44AAjl8TwEwGQd1BNS/+T7tpGG37UW+19vPIJr2j3zspN9ofZCkNxkjDw0CMiUNf7u8QTC5TSp4pNdp38slr7FdxmH5T8C9qBpoMYp+UFRmX1RQSVhLjYa+7WUqoUyl6XIQ5EZBFyOAi4BGOcxYQ+N03M3Mugzo5LKalMekrHNPyv1F2mKkqiu2NjfZ3t6mqStlKuWylB4yaaMKoKoJcDEBmtprGRljbQsmTQFfOmpbI3py0m4UnJoCyGThRLcraCS/N1OsaycLGPJXrid0VGXl6P05DWeVR5Ew87ppqIOMOWVZ0umIbmBbUolJe508spyn/Zzrb/L91JfyafpjLns9iZSwlqj+Y6cSm1hj8EVBr9cjxigi7whwOfmN2GsuBkrnJ9+ZCWs9M5SsL3BFh+7cvOiPIRMXad+yj5SD3u/XfMkz5EfNYX3ttgyaacgd2o/ePwOVZjazt6XNQKWZzewdYD/zc/9a9Q2EVm6cJ2rSsnaK2LIlZKKRJ4Rf27I+g0waQogUzpGqAYdX+rz7rpvwFrrzyzz59FnOnHuJFAI2ViyWhn1zBfvmO/RKi1E9oLKjoXG2BDwd6yliQyeMueP0cX7oo9/BraePEushDZbz67v89me+yFfOvQGdJXx3QcLqrME5I1oaKWBjTZFq7r/7Nha7BYOtDcaDXWySkA6LYTwecufNx9i3OEcd4LNfeo6DR08wv7DAffe8i8cf/wIpr/wnyZaHzjPb8jIygzKTL9Ai1a/lnWzL4Ic67uqEZOZSVB2ffKpswuyaOIFbW1vMzc3hC081rtkZ7LK5ucWVK2u8dv4iVUhYV2B9AdYTorAdrPPEECmLghQC3cLw3vc8zPd/3/dy8sQx5ub6dDslvW4H5yxl4eh2Ozjr8M7jvIRfuJzu2olIrIQNqfODgRQlfMJ4TGeRVy5t8Ld/9h/RKR3vf88DnPnSk9x48jTBRFarhq2iyzod0spRHr+0TlV2ObK8whuvneeum04Rdy4yXn+N7cqydOQ0DR0ShWYlzPWgDpkt+de//Ks8/oXHue2223BehUgNYIX2L+pgAorknMveO/q9HldWV2mamrn5OSl7rcu6Fj2jlCRU6Kmnn6bf7zPYHTC/sMDRY8fUYZL6e+XVV9jY2KDT7VKUHYx1BBVerqtaMv/oRB8FTIKKEWftpCxCHBXEEXBINLCCim0bA+NxJe9bJsqE0WM185uAEfI+azW1xaYAUwZ6Ykx4L4LUGcQQ8XAvzkPrJSmLSZ/ZaehbdnaMhnhBUtaYindrxivns6aSakwpWGQzaDQFGEmzEuAjaQicUSDKyABGymAXwiaqaymXlFKrY4VBwJ0UFWitee3VV7h44QKDwQ5XVle5eOECV1Yvs37lCquXL7O2tsba2jpnz5zhypUrHDhwIHtJoM5viJGIlC1TYFjuxl7LMJdnFlSXUXiyH4jAd/4+5ExtU0wldByY1IMAS6SrWCqTndv3GdjM+yS9V3HGxdmT+jKg+lej8YgL59/kueee475779XnEyba9vYOx44dZ2lpiZASvV6fBHTKUp5D+w1J+ll+0tbh1fprP1/DSQYdO7W8rdFepuy6ybl0X2XDylGisZSspU6WC6sbNJmBxN6CnwZLpHqzqyxtK0kjkzaurIuogH+M+koaCqf9acJUEhAgRQFyW2BJizxr6Em/0TAzK7pE8ns90dITEEXGA2E0adhcBmSUHQha90YAA6NXzE+ZUqIJiaoas7W5yc7WFk1VyZia0tRLj2zHKx0Dpq/B9ILLFIhkJdxqsk8GjXQOksP92m2yXcAoYS7l8H3nRFdJGE2S/MDkcFDd3zoHCsAJQJ1D6JTlpP3D6nhhXEfHB9EsLMqOgs/advY2kbbd7fn8Vd+1B7QfjZZ7+/VXaX/SruXIXJadbg/vXCtkLose7cGg/dalSKFgXW6fCQHmjC8oyg5lt0/R6RKMlay/Ou5LneaW0p5Ybbokssn3e545t4WrCkKaU+5T8u8HZqDSzGb2trQZqDSzmb0D7L//hV+dsDBEUlvAoHZCoKu8+sMOeQ4g38uEb+9LtsuET7xQmTTEkHAkfBhx240nuOWGYyKoWXT4n3/u5ymLkgfuuYNv+6aH+Y5vfoT33HMbD95zGx/6xof5pvc9RB1rXnjpJVzRJQRwCbphxHUH5vnYt7+f9957G/0ykRrRCPrsk8/yb3/rU1zYGGM6Cxjfk8xLiIixc0g2n6aiQ8OP//Hv4ZsfuZ8H7rqFD77vQY4fWqG0hvNvvk5MDSbW3HB8iaOHD2KLOf7xP/nn3HDzzSz0Slb6Ha47cYxHP/s5fKc7CYVoy0XL0OTZk3yf54vyRyb7eaJm9PgMKrVZ9PKkX8WOpyd04lw4nBcB0oSEVqyuXmZlZR/JwOXVK7x5/jxrG5sk48GKALdM7nVCjRGNI2uJoeGO227lJ//kn+DOO25jYX6OuX6PoizolAVe01l7DT8QrQthIDl1aPJk3rk24E8cAWMV7EkkV3JlCP/j//KL7D9yhD/3Z36cpV5Jt+zx9NmXOXDqCL/wG7/HJ555lc889zpfevMyF8cNRw8d4rs/8F7SuOHKpTc4emCJK2+8TLn/FP2Dp6noEpJBIgSyQyUOli+6lN0uL7/yCrffeTe+7GGsJ0RJid2KSwfRKcr/SdUYFpeW2NnZFebK/Jz0lBhxKjKdQyiPHz9GSnDjTTdx1113EUIjYYDW8Oprr0CC3eGQQ4eOiIPShrVIu4khZ1bL2kPKoHHiBGUARbRockY26c0t+yUEYkp0OiXjcSUgkrHUdYMxlqIQDTPnROjbWgE2QCb3kjVuIqDtfU4PLeUhzCO5B5u1eDQ8wyobxmg2MWknct/5+UwOndPWb62Eu+UQGNQJShq+JiCfgmGq+WQycDQFgDgNA0xZzyk7UzlkUQGSDKgZpEs5J1nccma9ajTi7NkzQKJTepwxjEdD3V+BZAULXnr5FcbjMbfddrvqmk36dowSziH9TI7NzrfJjre+z59lXw071O1JQ93Eyc2MwlwOOoIo4yiXRbb8WWpSLJ/X6HthUU0Lmk8AJTlXQjioeQQSIKipK7a2Njl75jkuXrzIbbfeyng8pmkaikK01pzq0SSg2+lRlCWkhG9DNSfjZr5teS/9LzF145M3E9M+ZPS+px17ptoJIAkHpkLcIIBxNMlxYXVdQKVcF5lBQfvQk7f6QPK9gFqpZVwI2BI1A5zUueh0hSAMpaaRjG8pBMkoljJLCX2PnlevYCYAUgsS5XJTTTzrNAmCgsxSphO2TwvWaJ8zU78t7YNlwExD9UajITvbW+xub9PUkpmODIJl0DYfaPTM03Woe8g1piq4LcdJwbb75bZpJcyrffb2+fNLgKA27I38vPLZZU0/XURzzmP190o+Z3ZXZj1pf0K0i6wvJZuqd/T6c/T789J2r2H5Wdq2Mdm69921QKf85qp2K6PlVd9pW0rtvkkWBlOiLErm5+dwzlM3Ai6Zllmq9a5JJExOauCEtY71+LLE+Q4Y0VVMJvcTHYNk5tCafJf0zVv75VvunanddLyRp9Tnyn/1/Qfuu3Vy3MxmNrO3jc1ApZnN7B1gf//nf22yUpkneW+ZJkwmK3lSmK2dfE6ZTFzRiYc4bHnq0XGWZrjJN7/vfo7s7xObhvFoxAtnz/DHP/bdPPTuO1mZKzD1kK5t8LGCapdQ7/Kue29nYaHHi+eex8aGhY7lfe++lY984CEOLpfEMGQ43uWpMy/wqcef4Ymzr9KU89iyR+FKbEp4Cyk2opOTGpZ7PfbN9aEesTLX5fTRfZRxgK02ObRc8q67buWOO27CUjPe2WKlD6dOnaCi4PFnXubpp5/i+IFlFjuOo4cPY3vznHvxFQFr2pIUvaTWdDG3nYDlMpMSJk3Ps/SfPIGLCaWaI6FWRhxTEaGepJkWtlkgxkCnLAlNYHt7m+FwzPkLFxlVDdZ6cAXGWDplVyaIGuLlrNxPv9vhm9//jXz/936Ug/uXmZvrMzfXpywLDIgIt7KQnIJLopM0YSTJewGUUpKwIwGXtC2lgDGBGs8/+9e/zmeeeIrv/YHvY99yh8e/+HnOvXGe0FtkXA144c01hpXlxutuYmwafNXw4fvu5bqFgiOLB/jys69xYXWXUydOc+DmBxj6JYLrEIk4o6v9xpJwon1jI5dXL3Hv/Q9Sdhd47vlX+cznvsz2bs38whJl4TE2YoyUV3bCchtPKbG4sMDlS5ep6pput9eyaGJMbapn7z2HDh1iYX6ere0tvvjFL7K+vs7Bg/s5sH8fTRO4+ZZbCEEAh6QOKIhDKc6NtIqoAJIxAspglJWBZB/LAE4+Vhw32ixATaOgjoIDIQTRu1LWk/cSFpfFslOKyh4R4AjV8BGTspCQuAnrSAAm0dzIwJw2ZDkqgwMqsm0V2EkpKQiWgTPVeEIc1DyuJAWDJJOWCrArKyVvzw5hVL20FlxRcDCqzlFCCWitVpKUS4qZbZEYj8e8cPYszkDZhsU1OC+sIDmfuFjnzp1jWFU8+NDDdDodAKyX9tD66lpOVtkBooWj/cPIDZkMHGXR9tzu9N5zmUk5hzYs0RgJGNLaacv7Wja9/Vr75LYuH/L5pB/lIc07j3WyXwgNhS8A0dT68pe/zPLSMqdOnWrBS+scWMNoPObixYvceMON1HUljLqgLMFrWh4j0UFU3l/rvq91ktahzmWkoK1NiZCSMBNTxJlExNEkEequJ019D6A0GdLzveh/GSScAmPythzWJm1bgOGgwtwZVJIQOGEooSGjqHZNJAOQ0k6SAixou28BP5MZOwqOZL2hKeDJmgzWTMAXaV3yn/Qz8fWTvg8hUI/H7O7usLOjoFKbnS5Koglj2zYyKZ+97aitHyNjk/TDqffa7mTbZDs63uR23X5u26neff6s43Ter13smEoYIZnl9PerEPFvAZkkGYWEHmsZekl+URQl3V6fufl5Or2u3ovekbaNSVuZ9JXW8ph2tSX5px2T8ua20tsN1zq6NXn+PPeSjJzzc3NYTVog4W15AQQJudZ+ibP4skPZ6WKtJ+f2I9cP6D3mDpi3aUeZdJG3mj7f5N+vYrl/te1P3s9ApZnN7O1pM1BpZjN7B9jf/6e/prOCqckbk00ys8kvmbJN27Un9GLtpMaKM5VComPBNAO+69vfT8dWuCQCyu956AEOHThACInhuGJ9a5dX37zAsKro9edIqaEebXPd8WMsz/c5uDTHt77/EW676RSFM4ybhosbOzz6+Ff47JPPc2WYqF2fxkgK8FJ1fJq6EcZKGPPA3bfyg9/zvezu7PDmhQu8fv481iROHDtItwRixXA8Ym5hgetvuIH3Pfwgxw4tUnZKgu3w3ItvsL65yaWLl7jl1jsYVJEnn3ueNy5cFl2qKZvMvSZTqTw5ni7T9p3RrUne5/1pRVAFqJJ0zRqviDrSeRU+aQYedRbGVc3W9kDo/r4UYMUVLRvNO0doAtZADDV33HoTP/bDf5yHHryXuV5Jt8xsJEPhPWVZiti2nYS5OSusN6caHi1bSZ2d1unRSX5ZZDHoAEXJm6tbfOmpM4zGFfffdw/jpib5glGEC6+f59L5NboR/s8/+H08cu8tfPD++zk2P08HMCywNnL84i/9G2696QYOnr6D2nZoYqRwBkMQ58gI60McoMjBQ4fozy/zv//LX+Hn/tm/4LXzq/z+Jz/NV77yFO9978OU3lC4vKo/VUcawtWEhpV9+9jc2KCqxqqlI3pBckB2eGTl+IUXXmR17Qqj0YjB7g7Hjx1jbm6eqm4YVxV1I+LYGRwScEScSZMBGAUfjLKTsoMIGYQSlo84R7K/OFDSLn1ejTc5K6A4uMZYCd1rQyWE+ZZULFXakzy7OOfiaOY6zefNjrRpmUnahjEisq2Mmva5cniJmVwvl1k26RHZw5h0qpzFTsCVrNmUBaonTIyk/aMNGVUgLDuzpmXP5f4j91NVY848+xyFN3Q7Bc5KCJvNOi56LzEZXn7pFYqyw4MPv4dOp0NRFJK1UvtvSokUJETN6md5ePljlc0UgqSVN+oUWw1lzIhC1qzKZSTnnmJbSYG29Sht6Bo2NabncqKt2+mWnr/P0ImUV7slRtGBKnI2rsSxY0d58IH7OXz4iIiNj8c0MeK858r6GudeOMf9DzxAv9cXRo2eT0C0PZeWc8qJ2zbTbr/qPnXr1RuEKTbVr9o2mhKp1RUDUgDN/nbh8jp1ymO0aePOpq+fHd4MwOR6iknE2uU6AvxnplLK+kohEppaNJVCILThb6KXNwGhJkBee+1pMMVYBfamQCUF8ltQSYFVTGY1TYFJuQxNrgV9tmlALMn9VtWY4WDIcLBLXVVEzXIo4BKaOTPJ71J7zqtqRCpTG5Fes32f26S0ffla3qR2w2QbuW3nz7lc9DdGznP1a3p3eWPbBRAroXMKhicFja2TTHLWSVa6br/P4uISc3PzLeiWhyepo0k7zQBMLoP8/bVs0rYmY11KgJkASXJ42xD078QS0lTzmJmivLz39HpdvC9oQtPubZ3BFh5fFpSdLq4sZfHFOFA2mMgZKFjY3v/kldBbaR/yrfeVH2jP48stXuP7/Lxtx5qBSjOb2dvUZqDSzGb2DrCf+ae/pjOrvLYtP/Iyd54ASsag2jKTicO1J/NqOplLVifzBlII9Lzj8L45Hrn/TgozbuP5R+Mxw3HN65fW+fTjX+a3P/V5Hv3cE3zl2bOsb25z6sRx5lykGuxw/fGjXHfsEI6G4XDI+vaAL595md949Au8cH6T2s3RmA6h6MoKI0ATAIP1nmY85PTRfXzsIx9gaXmFz3/xS1zZ3qVxHc6ce56jRw6ysrRAp3A8/qWvcOaFVwnJUDqLNQ2dfp+GgiefOcfW7pDVjR02diq++PRZvnzmLK7Tb4GavUUik9k9Dpv+zY5d3m+yTWdbU8CEQQWnk0zcLXnii2YJghQUUNAV+RCi6N44h/MdrC+ISSraWUcMEZIsVJaF533veZgf+oHv48C+JQoH3dK3IW5O9TmKnN1NQ5kyW8lpFr0c+mZbjQp9LmW2yEd1gh00CY6fvBFjO/ze73ySqqq49777OXj4EE8//Qzd7gqrly4zb+Ab33U3876mS8IZx/Yo8olPPcnP/2+/yFy/4F233sD+oydJ1uMAlyJWZuYta84QpT5wnL90hX/wj/8nfvBHfpwf+ZM/Sdnt8QePfYYTx45w0+nTJA0zTClpyI+8B5n81nXF0vIyFy9exBjolB2ctSKKHAJFWWIUACo7Hba2t4gxsm9lmaNHjlLXDTFBVTeTUFQFPwREkv5krWhp5e3ZaZ1uWwKuBGWMKIstO7UhUJYCwQmrCIbDUbv6XlUV3W5H2EzKiPNeNJWcU4FnI7pImXmWQ0tSShOHOYmmUr6GUY0kqwBXvv8YxdNyythpnS8RMRGRcqHnYaw8X7ao+kFJQ7RyCF2+ptX7TEmucXUYWEqSES9pH8m6KfKdtJLxeMS5c+cwCeZ6HZyBlERUfAKUQd0EXnrpFVIyPPDgg3Tn+hSlZIvLYYJSj9JejMCamMyUasNedXhtHd+JsHdSkAwFkfKzyhGyTZ5dQeep87XPpNtaax3Pt47nuc/uaV/kMCxdZNBjQgw888zTGGMZDgaERsKivBMR9KqqSAk2Nzf54hNf5KmnnuKDH/ogBw8dhqRtTIGYq+8jm8n/tE1A28o193/rtrY8tMylHmQckLAe/Z1LgWQsTXKcv7ym4W9STtPtL1vSOk2trz0NKEUJiUwa8qZAUlRQSbSUmjYD3DSolFpQSc+j45f0h0kbgKnwNwVH/nBQaSpMTsGXtry0nifPlp9L/oYQqasx4/GI4e6AajSS7JEpCVMJYfuBPO90NRgtq/b8Rq8nf8gtsb2v/EV7j/mgyfb2ZBqSOzl20gdkt1xW16g/6ZTavuQ8AixJuGA+xBgrYXPeU3Q6dHo9FpeWWVhcnDqZACA6krXt4eqrXv0ZckOafjsBlfTTBKfJ55Qm8dbWbmSsyeOBtI1JG3bO0ev1RJ8u1hSdkl6/T9npwFQCASFrWnIyF2KtrSXf2N4rJ6M3tLfqJ9+3b65ZAm15Tb/XIgUS33z/bXsPmNnMZva2sBmoNLOZvQPs7/8v/37PxEDeTSZ67YSM/GHq4D3WznaQvWXqQV5dxGBSpLCGu245za03nSKMdwh1RR0Su+PA5554hn/3O3/Aq6u77MQCN7dI0enzxvkLvP7ySzx81y1UgyGxqqirMbvDIedeOc9vPfp5njz3BttNl1AuU0eP9QVNAmsSvdJr+IAhGU9T7fLIvbdx05F5hhE+/YUvsRugch2ML3njjTe45eabKYuS0zfexm/93qf45Kce44WXXmFrd5vBOLCxW3HulfNsDWqi73FpfcD6zpjklP1zjVW6t27RktZ5qwHJQjaB76CdiMnkOKpmjhEBF3mpM5Q0BTUJvC9JmkEqNA0GK1n81KFKyESz9AVGU4s7zT71Ez/x43zLBz/IXK+kLCylt3hrKcsunU4H5yRjk+hS2Em4gPd4VyhDRxxlayQMThyN3JZkgm4ywGNNG8pnTcGtN9/O8vJ+fuXf/hovvfQSDz34EBfPX2S38bz08gscP7yfu266mX7HUifDV55/hZ/5H36Ozz32BO++6yQffORObr/xOubmF3DGYlPEivK8ZK4xRia/JmKwhGCpmsRv/t4nOXrqNHffex/GWz7x+7/LdSeO864778DGREx169ylKE5TDjvyhSOEhuXlJba2NvW5RbMHpG5yn+h0Ohw/cYLlpSVOnjxBDIE6NGAtw1FFVQmwZDJg4kRUOSTRmskNyVjJzpW1lrLzn52GfK/G5Exm2amTE+TviqKQNqHObxYAl8xw4owkdZQykCITfbkfAXOkAeeV/qzxhIJaNmuTTIXG0QJDcv9y4syiknYagmSww+TWog+vzxEVGIga7iahlTlTGwoUSCibVWZG3p7HJ2EB6UMxqdumqTl75gwQJYytqfHquMcgmf2kHAwvvPQKBw4e5KGHH6bT6ZJyhrzMRsp9XcGEzKBK2fvK/ULuBCGUyPlNDnczcp8C4Am4k8tRj9KxIX+U69kpPatc55NGpO1BHc58E2lK6DuRQwZzEeXSk21VPWZtbY3f/d3f5cTxE4zHY0ajIcPhkNXVK7z66ms8/vnH+eSjj/La669zyy238qFv/RYOHjxEaCTrXkxJdK/Ug8xtZ9rybWvVSnvWNjW1Vfd86/G5HvKzGQ13JElYsbGGFAUwTJmp1Ia/TcbpyQknfzNQne8p/5MUkEGd4xhTm7VT2F1RgKSrQKXcn+W4KaBiGmfIBZLBEw05FoBFw990HLFZK0izNcr++VhhFBsFYNoGlDtRvn8STQzUdc14NBZQaTxqAcT8WyT3Jn0pjx1GT5PPt7d6pb4mda71p31i+hmvOlC+1fmJ3P/kNTmNHqPjk5xmck6RZpuUSTtWWdEYpM3iJ4/gCgGVym6XhaUlVlb27Wlvk/A37d/TRal11n6e2nzVpsl2/WJSG5MNaXpMnLKURf6thOqGpmkZk5NxUJhL3V5XGIZWQCQpIGEmTbe3pIFwctV8F3Lt6XuXOcy1H0hL4+rNYtNtm6n+OnW1Gag0s5m9PW0GKs1sZu8A+9mf/9WWu5GnJuLcWywWkyRUiKm1qWnLjlOexCUmc4aIpJ5NyUBMOBspbGRlcY6jh4+Q8FzZGvHq5R1+6zNf5olzFxn7BWrbwRiDp8HWA2657ih/7Ns+QMcHxjGxMY584vNP8RufeoJHv3SW7VjSuB6NsWATzhhSAO8KXBiy1LUs9jyD8ZhU9hgPd3nfg3dzaC5R9Zb5nU9/Vqdmoo8yrmqef/klTt14PTHUPPLAPTzxxJe41Mzz2uqAp168wFPPv8bGzgjwKgoqz2+Nm5rgTk1WdeKLOokScjBhoGQHTcCWqYm4rrhaYwiQvU1AmBIhBrzqExWalltmZ+ocZQfNSqY7YyYCpEYZRiGh2Y4SxlnuuPNOTl53kk7h8M7Q63o6hafwPaxxeFfgrcMaR+FLAZeMfBbWisF5bUPqPMsdm6zZDkmFjdtvxBeyNmBtw403nuTgkQN88SvP8Huf+jzD2nHs+HFePvscJ44e4sy552l6B/mFX/4E//R//TVsVfPhe4/yfQ8eway9wvHjN7HQmyOFKJnUnKEiUqVAMIYQLXXjAUskMb9vH7Yzxy//u1/n2TNn+NQnH+XQviX+xPd9lH1zHbxtiEacQavtuTAeb4UJZ0gkF0k20JvrsbU1oNfvi/Aw6qA4CXmSeoZeV3SsrHckGwkkqhpichhX0MQK70UDbBqkIbOPjPbbDFwoozCv0LeOs5U7rCrJbtY0jYbTSNvLIEzOICasJE23rWniQ4iqk6OOo2r+xBSxxSRcLQQBjCaOmrTzzHQSZ1mewRiD01TWef/cfoxmN8xaPSlKJrbMPrJuwlDK54LsmExGqry9dbym+0QLngiYGkPAW0uKgWo05NzzZ4j1mF63IIUai6XwBc4VGBwJSxMSZ8+9yOLSMnff8256c3P4TtlKyrTaWk4cdxQIiwhry+TybjWk5JnRcRUE7JBDxeuTrfoMGvqY+1h+CXicdLxA6ksIBxqWlOtR7qllk6YoHdFMylEJa8qYSXoFuYcUA7s7u1y6eIEnnvgCX/nykzz9zFf48lPP8eWnn+Gpp5/lwqVLLK3s45577+XhRx7h5ltvpd+fI2EoNfRSHjeHZKm2lLIqvLGtBlWuz6RtlJYBlsEXGRflPuVltFCkL+gAJBdQsM5IucSAiRGMxRVdRk3g8toG4yYQrZckDxriNf1jKEkZ5JopKdCI3E9iAgzFJIL00ofkFlJMVKEhRGH5hRin2EnCDMpdLuo9Gx3PtTKlzKw+gxXGnXFFm4DDeodxEsbknAD+GIN1Fu88ISmIpeFqud6TNAgtSw2nslBXNcPhiMFgl6qqAGhCo8US5TwWAVYnLVKLXfbSmiEJz0p/e9F9BRADK1lojVw4GStt0Uhl5nMb2ajjitaFMrLkGpNXzuS55yUNQ8eEfL8K6FpZNElA08hvqvMF1nuM9ywsLtGbm8N6SQYAgZgCyU76oPYiwNDEKHMitDAzQ7xdhJpcmz0zM30GbeOT9pePm1hKCZsiPkVpzzpWWGvBCAs211MySLgnaXKdKOVidA5oDUhJRmogtPeSb0PLMUlfMEnmfC3EqHU1OWa6TpDyMPLKxyS5QxIQtB/FlPjQ/bdf/bgzm9nM3gY2A5VmNrN3gP3sL/x79V1kQmWMUcaLrs7JnFgmf5rF6+oXbahOXgHWSYbVFVAFE7yFFGounn8T5xydXp9Pf/EpPvPFp1ndqYi+T7Qe7xymGbPYsXzkg+/lGx98N73SMwwwDI7Hv3yGTz72JQbBY8s5khXHHSDUFdiELQwmVdx+3WE+9u3v59s+8B7OnH2a3dEupQ186L330w9DLmwHPvXY45SdHnUj2U2iMezuDBgPR9x6w/X0C8s3f+hb+MQTzzMa12As3pcYIw4jbfHppPXqFe1seXs7Kc77GXnXzg8z4DK1yZjWEbQkrEmYFOVlEt4aOmXB0uICo9FQNFkmZyNlPZw2HE0cjhBEhDnESLfXo9Pp8vrrr3PD9ac5euQwhTUU3lEUHuMdkizOYLzBOkOyiWQjySawiWQi2AkAkh0VUOfUqFOnL1lYT1gT9W/CWbDOcP0Np7nnnnczGo/4lV/+VW657T7OnT3HvuVFlhfm+e/+xt/i7LPPc/2xI/zUj/0AD1y/wujNs/RKz/E77qVJiWChBupoiaaL8fNcvLTLJx/9Al/44rPsVLB86Di+v0TZm+ezn32MlaV5vuPbvpnv/97v4MjBJVIaY2xkY9SA7xCU1WCdpVGwQ9xEDxQ4U7CwMMf6+hr9fh9ipCi86F4lnSpnjRTVIzFGmArgWrYaRlaWUwRrC6ICN0Xh25A2p85M1kpK6ngmzahmrQA9Ap5YBTdaiAXnHI1qOBllERVFPtd0G5TxwGmfJjM7EuptShszmlaemJ19beQGAW/2gGOTsUMYI3L/wsKRl1XAIx+TxydrhXmVH8SoAzd5Mrl+bBli8jlFBaSShCeJo2XEWbRWVvTrimefeRpDYmFxHu8l3bgz2XESRyjExJnnz3H02DHefd/99Pp9AQX0mQ3CiMt3JOWpbK8WCJS/bZGQgQ/Zbs2EZZWSsNaihhHKcQbjNIxQWRatGzt1DTmPhiSh7TeHt101zmQwx+g5jJWXHioAuPbflGA4HlJXNYsLiywvL3P82HFuuPEmbrvtdu69917uu+9+7r7rLk5ffz0rKysURSFhsl6E79uBKt+C/k2q85aiZh5UTSKTM/pp+CMtg1PreO/pptqbgFG2bSsCGqQpUCKSWUowrAPnL68xahLJijZfWwhTllAAaeqVHeKo7Ttq34xIVkmBaIV9GJpAikEEupWllMGupI3JGGEEpphvUk6QUpLFHwVkJRxZkhBYA95ZvDPysobCZ2A7i2rL84ICKib3B0ESc+vNgEbTqA5UHRiPKppaAO/QNAL8IezU9pSI9p+MZ6K/BhCT1EFCgIjp6wtIJvUoQ4s8m/Rn2Sfl/XP9GrRlikn73PtZXrrv1MvkuYz2BzMdOqfbMuAn/cxhfIEtCuYWl1jZvx/nJQOcc5JxT9i62sb02fO9tufPG/OAoSZ1PmVTAO/Xa8kkooGo4b2ZLZ7LyCQRqHfaBqw12o6y1p4CclNAj4Bhch8ylk0DgXr2XJd7nmhvH8zWPuf0V1MHGXlw3S4/Rh96YAYqzWxmb0ebgUozm9k7wP7uz/2KTN70vxBFdHfiyMmESCa6gajCofllrIqqtvM6YR1Ilpq8ehxlNUyzw2Dg1dde59lzL/L6lR2C7cjENiVMPWSpY3jPPbfxA9/1YU4eXsGbQBPh9Y2aT372Szz+5HMU/RWi6RCNJ0UITYO3BksgpYbEmMJG7rzpFDefOgT1Lg89cC9f/OIXWOg43nffu+ibwKX1XV584UWINTHWNHWNxVC6gssXLmFi4OiRwwyqhnL5OF956ulWYyZPBWUSNimvrzb9m54s7pk4tnMn+TdPiHUOODV5DjoZlSleXkG0BjqlOGpvvPEmVVO3q9iYiVh06zy03BqD80X7sk6yL1V1zXPPPsf111/PoUMHSQms8xgv57FOmQ0KrBhrMU6248SpmMziJ++t863DkF/WWJzekVOQSZwQKFzB6qVVYl3zZ/70f8bvfPJzvPHaK3zT+x6mVxjuu/duHrj3Hu646TS/+Wv/ikuvnOXA8jzX3XIHcyduJDhHdJ7oPMl1qBrL73/yc/x3f+cf8NzzL/Lya6/zH373U/zBE89w8fI6v/Qv/gWlS/yVv/jneODu2+j5hIkVKQVefuUV/upf/xlOnLqJlX0H1PGP2tY0N06yGBwGi3OGXq/H1vY2ZVlOKlmrfTKfVl0kZUiMxw15XVjwSSm3ELTGjKHRcBlxcsWRbhoRXTXq6Is4+oQ5lI9zbVpxYQnJvaijrlnNQogtu0hYHCqArZpQmEkd54l/UsZPbtfTToSx+j5JGBU6NmRGifQl+SzhdwHrRAA+hIDzqvml55U+p2BLdn6T3DNTzqOEJmZmhoxx1lpClOx3088l4YmiofTss89qn5IQ0hye5J3PUAQJePrZZzlx8iTvuufddHo9YhtqBqAOO8IciwomTrPIAGIICoxIuWCmGoeCRvm8GBU595LByVqroJX0QxJElNGjDqCzwpzMz/5Wy88j9ZpNwLyp/TX8h8lwJMcaQ1EUdMoO+/bv57rT13P69PUcOXKUgwcPsm/ffpaXl+j3+3gFkayGKIKKvFsVIZ+cdc9fFMTK4I20O6Y6kwKYOq5Otz32tEUFHbV9pAw86jiV0PAfa0m2IBjLhdU1moiAHcZMhXhNXinFllfR6q3pvbS/gfo5BAGP0HYfQiA2FSk2xNAQQgMxYoEUg7IUhUliMZAZW1oCRkFcM5UswVrRvvPOUjhNrqB6SvlYo/Ur7XPv4k8u79wujNy8Pq5kooshUI/GNFVNU1WkELDIPjGGVmMpZ4abBhCSyT9BuS50AYoJYadta7ktGgWnrAC8RkOqnRF9Pvk5EraWtWbyW6L9UEfUt9Rf+3z6tPnqeciS50hSN02QPmEtrigoOx0Wl5ZZWl7W9qz9Ta+b5zv5vAZhUednkpe0H+lfe9sVyLUnPU/r4euwaGRBJZrM9NKX1qMlYYVQNulXoKWx54paSvpOx8npVzYBlPIlkoaX5332PlO+UvvSr2RWkj8n0TuLWoYp8aEH7pi64sxmNrO3i81ApZnN7B1gP/sL/37PZ5NDo/JELr9UWPnq7THIRMtppqsYQpvmeDKXETaNXgBjHQ2Gxnhq1ycZQ0GCwQbvuuEYP/zRD/PuW6+jNDUmJeqY+PxTZ/lXv/kYb65ukfwc0XWJFARlSBXeYVLN7tYm973rdvodx+bWJq+//gqHD6xw7OB+bBN5+N772Vy9xA0nj5GaiqNHjvEN73mQRx68hztvu4HjRw7x6osvc/HNCzhbcv7CJQ4ePcabqxv8+m9/ShxSTdsusx+Z4MosXMpE5kPiBE/b3onaVdtMnk7tnam1Uy9jsFYmdXkCbYBevwsYVi+vsrm1iSsKsE6ztngFlTxYB7aQbfoy1mOMJ1nRn8I4qiYSk2E8rnj51de4++57mF9cwrpSJu/WyXFWwv4EKHK6wumxes0cfmCsU2DJSoYlDWPIn23K4YMS9pJBGWGAOVaWVvj8Y5/jH//Df8izZ1/ggXvv4E/9yR9kcc5BrPAOxqNdHnnvw9xz//3cePvdLB27kU89cYZDJ05RR9HRSsZzeW2bv/G3/i7f830f40/92T/NRz76YW6+6wF+9dd/l6ef+grf8NAD/Nmf/FFOHV7B1iNoJLNRiHD5yhb/7je+wONffIZT153m6JFDxFhBapRhpau9GgKI9xjn6XR6bGxu0evNyUp3knqOmizJGCnLqCEDdRVxhWjMGGUqpGSw1otzpABIDiWTpmOkpbRtUB01zcaW21QOsTIZHNJJvnwWB1dAp6zZo0BPzICROOHTDm2MGh7XCFCjjR/nFJSyE0ffOhEQl/Pl+9Tby+wR9XsK76WtO0td1y3DKN+rs04dFzl+GjCRc+Z+I9fPY1rKbKsWCDOEpsZZSzUeiYZSSvR7vdYZjJqtzhhPMobheMyzz53htttv5/Y77mw1mcxV4J5BHSMdE8SZUjZREiCxDd1RBtf0c1jnaJSFVtdyj234n5XykucSoWyrjCIUgLBZmFxZiiQBEGQfuWar06UlhpaR2VM5+bt2mNsz3sWU6HS6lGUH7yV7VLcrOi2F93iv7FPUkbYKCCKAlFyvfWyMjp/W2hZUrOsG0+plyeKHUxZTbgP5N0kA2skJpV+o02qEkWS0oSUM0Uibzro5GCvhaMnw2pvniQr4WiImBU2wPvUyk/e2/ay4SRJGqUUydJoUIGoAUYoQAzRjTIqk0EAQECmFCmcQvaIY8BZi02igkY43eVHBWWGu5noiyXlTUoBbBLvR3wyvGfrA4J3HJAGELJIJT54zYnP4lDJi5a/cY6jGVMMBTTUiNjWxGsv9xwZLwhlJjJBBlQyyxJg5WgJVJGX3tMwmA0bvxSLsZgN4ZV3l7yT4NOJIeCufHRFL0OeR61uTcHl8BlJq9tQdRFwbzCqsWcekbGU/CfNMUcKGY5I2WZYlS4sLHDiwn07hcQYKJ4skzsj9uFxH+b6NMIQIDSlUMvZoOGp7X7nctOzausmLF1qeX/WVgajMlFIQR2YTWr+ZK5ciIYlwvOymoE8S5rBkQpSwvlwWNtdpBpjM9P3KPvn8k/4xaQN77zUKawr0vfYL/Y78Wb/74IN3tv16ZjOb2dvHTGqXFmY2s5n9p2qH3/+ndTKe5xN5gp8n5bKyxfTkfMryKpc4L9mpUbcz5YmNTG5Sy+mAqqklHCaBN4Gl0vDIPbfx3vvupBkNiCEyDoGLa9v89ic/zaWtIZVfIATJCBVCwhqHc4YUGmI9YnG+x7d+yzdz3603s3nlCj/3z3+JcahZKBw/9N3fwUJR0u/NsbW5Trc00AzZjeB7XawzlL0O/blFOv1lzl/a4Itffpbf+v3fJ5CoQ6A3tyyTKPGU1W3QcpgaLnN5/GE2+V4ncyClk3J5S2lp+hWdEDYYZJU4NjWGRGjGbFy6KLPgqGywlvmAMGH0vc0sFX0GY0QvIjtNIQSq8RjnLKV3xKbi1PGj/KW/+NMsLfRxZtw6vlkfSEycOQEKdCVWv2Gq3YhDMbUdSFZSF1tSO/lMKWKcAEEhWUIwPP7FL1J2etxz9+2UPuEQ1pwvuiTjGVXizFsDf/Cpz/Lay+f5yZ/8UVJsQDNWVXXk1Tfe4NjJYzQEhtWAf/ZvfoPHv/QMP/Wf/QTvvfcOTLWLC2NCNWJre5e5xRWS9bz6+kV++r/4Ga677hTrV97gv/mv/zLXndiPY4xNQQTBTSEgkTGQGrzXcC9ge2ubfr8H2i2k3hOYLk0weC9p5L13NHWNKxzeO8ZVpbpDjtjUChxY6qqmLLNDLmFeGURQ71kvpECKs4xGY4qioCwLxuNxC7TUdU1RlKQpEMk5J0CGE28vZ33LoJIxynRIE/ZiURRtiJUrhCGUwaYMpMBEu8k5FTJPMv6EIGyPwheEUAsIpQwljIwqVkParBGAKrOj8rhlrBwjTIYpJhITkE6AOel3VkGqra0Nzpw5Q1kUdMpCWBDWtIxAAds8g+GY5547w113380tt4k2UA49wxhCIyBQDE07gkr9yHVjUkdPwY2UNauaIPdspR204FKuSj3G2om+UB5BjLIewhSLJbMGjAItuQzRMV6+k46adDzK+7bf53qWG9axXi/a7iHnZGpMkzYioZf52hkMymNAbqfG5nBP6Rj59LKfPAvtGCK/J7rr5LnyvVspKCkH9IHboVD3zX8mfSM5j9VrJjkxWMvuuOb3Hv00dTAKwhtxjK+yzOhKmb2aJHyZlCT0LYlOUtJrhCYIOBGjsA5DTdM01FVFVQnQEGOkrmup1yZQVwIy2ZRDVZGxEuh0u3rPRgB8TDsWWS/hWMbJAoDzBb4smVtYoNvtAlB4ASbzeCC/44ryaHuRx4nE0FCPa4bDIVubmwx2dhmPhgx2t2nqitg0pBRAtaFSjPL8mkSiDjUooy4mqePMpnS6OOWsZDYlJpy2wWo8ZjQc0ujxSW5MgaowWWixGTiVBROj46UWmLbjtmmQAAkWzO1EvsjMv7w4VNcNVV0zGI6w3tFfWGRucZEjx09w8y23MTc3DxjKotOyqJLqaEndy0JCVVe6eCL3Y4yAmlebtM6pzzqW7916bZvUVwaH22bfdgBhHMn7aIQrLAxhAYfk4VVryUxY2TEJgH6t+3nr/Wpfh/Z58xgx2UcYviru1I4L0/vIAofcw8d/6kfa72Y2s5m9fWwGKs1sZu8A2/++H2+d3D3TAn2bJ/Uosf9qu9YUR44R50n+yspZjKJZlIyslYGhcIkUKgoSC91SxFJ1UmG8Z2c4pgoRU5SMAwKSkDn04L0lNg2hHuEs7N+3hENCSi5vDgnJYFLD0lyXwiZhYpEwocanmq3aYn0BMYr+hDWqk+NItuDClXWs70hGN834tOdZzeReJhsn5TJxk6bsqk3ycbJRgCUpM51qyfYstNSu3EViyCl+tXZahzPfgZmEFOSJoAI/oFopegbUyZIJepIV6Kbi4IEDdDsdCQORG5HjjQIX8mGyrVUUaXffY5OfFkOiEF5FkhVNFQqRo42RdMZoOmMTiKGZZHOLUp9YSwCF3AyXVy/R7XTYt7KCiQJwCbMDjLeyMmsMO8MhVzaHFGWfowf34eIYqhEmBmLTMBpX9OaXBLSqA5fWdun3e1SjHebnCub6BRYJSbRYYYUpnJZMmBLXTtR1g5suCN2e6gRNoPAGm2r+6n/xl1he7OGNtMe6rlswJyWp/+yQei+gUgiBTqdsneJcdqhT4zTMJSoTKe/nvW9DcWwrkC0gSyKHagkwg2rBWGuxSBiWUVZIWXiCCsJ67/DOE1UoXupY9IvQMSA7/wIKFhgjz5mBF18U1FVFWZaMqzHeS4hrQplMrRaSFGUGVKyR0Lbcuq2bADMYCZG1ypgRR1/a+u7ODueefx5MEmaNc5Ci6FXVjTi5BpoIz505y8MPv4ejR4/hy4KiKKU/iGa2lr8yPoz0qQzUCCtJTER/pQ1YK6EzoCyeJOOMOPdGwgGtBQQcNAo0CDAs30+AFXHOYyPhevnamfnmnKOqK2lPei9t32DSbhI6tqnJmDLp1VLGGbwSZ1D0ngRUS6HWchMgDeQRpUjkGvl+Qx7vYqIJUetbQSUNS5PnkHEvW5oKC8zvM3M23/lkFBLL7Tt/b52AlHkYa5/PWS5fWePP//RfxBUlCUOnLCX73+Rkcg6TKVwTs3s/tveX+3Gul5RkDMvvpY8rIIfh8OHDLC4s8PTTz9C1gWP75nHWCMCM9Kmk5R9iogmBpgmMRpHRuGF3NGR3d8Dmzg6jqsb5gu7cHN/64W/jXffcI/3ee4rC45wXUFNFwqX89Tn1rzECiUjYqdSjMFoizlmcCoZ7oxpUMAECmYCCmWlndIzpdDoU3lN4T6kJJ0JVs3Z5lTPPPcdnH3uMs2eeoxoPqKuK3Z0dqmqMdx5fiID+3FyflZVl9u/fx/6Dx9h34DD79q3Qn5uj0+tSdjrCKtSfrfy76K0TPaG8KKJ1ma5ygWIUgDkZAR2TMRSdLt1eX0EsmZtIv3UMRyM2trYYDUfsDgZcubLGzs4uRVmysLhIp+zS6Xak/es122sjY32+H6PjQW6nk/tUBmjORhmFdWR03JX2JmHMkAix0WMnTVZCsDVbnLJYMxCIMYQkWf9kjPDKclVAXn+Tcj1O7ktuNGVQbQromv5sjSZp0EC8oJpiebyT/aSdA/y1n/4/5eqY2cxm9jayGag0s5m9A2z5kR+7etMey5Mc2p/1iWPx1SxPu1twSI+JCSFyG6OEbrBJGDetm2KsCHdOT0SZTExlriWTKRAHW+4sCUU7JYG/jCGZUic6wvJJqSEauSMD2BRJlCQcJmVB0YAxAYycN+FIyUMS4EMfSM+Qbfr93o//nw2jCh5Nl7QUzmR7ErBOyk5XxlsQau+hqV2pnJRba+3scrLdIJR98SyUTp8g2GIKrPoalutretN0W9Kvc9iX7K+rp3pd2VEm0wDRBqHKJ4OLBpvQuk7ELExq9FwukoLFxIlorbGIsDgGjCfhpZ2kTN9vFLDLK6aalUaBzLqpcU4YREY1xqT4dMKfAU+ShAzkatQ34ijnkpZ/XYIwGtItPC4N+Zm//dc5emAeE8Y0ozGF96AATyatCaAk4WEg2kHyWUK1vC/a1N/ee8bjsaRtz2yi9vnkLuqqptvtYq2laWopD3UIrTIPQ2hwXsLyvFM2lYajhKYR1mFsiFGcgqoaKRPO4ZyEQPV6XYwRx6iuKwGZgTpoX8sZ4FRPKSURx7XGYq0nJdFaMhia0GBQgMCgwIw8kGn7iTJejAg+y/Um4Epd14wHA1489zx1XVOWpdSnOjJew9piCDRNzbNnn+cbvvGbuO6660hJGZNRAIAMnCSE8eGyXpMCWEaFvb0vWoAtJfCFAHsZgJK2k4RlpSFgUTOdxSDhNwL2qfOmIFtKAtY5J9o6KSRKZZ+FGKibBl8U4mTGRNXUUhd6v7kt5H+Teq+578m+Ul/SjfWbCWI9AUysgdBgVafLKPDlnMepwHi+ZoiRWu8lhsy6y2Bsvh8FNVCAVJlx1k72Tfmz6vzlw/M4k3IfTAnnJWxO7ktAw7bB6DvvPWvr6/yJH/5hOmVJTJFep4vXfpHvzyAM0D3bjBGQX8fAvH1Pv5t6vmQmx8srgy2Gsig4cuQoy8vLvHLmaTr1LivLsnCSmgpSJMUgLUdZWk0TiHhGdcPuYMD27oDN7V22dnfZ3N6hKDv4suQ7v+u7efChh+n053AaptgoKCchtxoypyy8zPrJmk3OikaeMzJOiCC46h0lCSrLQE2mriZEXD0pcCbvpbxjDJS+YDwY8srLL/H5xz7Lpz7xCa6srsqQbhKDrXUJGfOeXq9Ht9uh0+2ysrLMwUMHOXbsKMeOHWNp5TCd/oL0aachgN4jfBddTNH2XfqiLW8QwCXmPpXbulaX0TM47zHOCYhknYh3W0eMMByMuLK+ycbODoPhgNFozHAwxDm556LTFZ29JP0i5ibe9mlhOk3aiLRJo9kkr7a8UJAXC4z2OxkjJYTQAiHUFE76f1E4Us6gGBuIgaIoiSFSh8C4bkjWS9CbdYzrRvpVULahaqPFKL+D03Oy6bvO7T3/Rdt57gsxSsIJq31AFgWmw5m1DrQe/vKf+1PteWY2s5m9fWwGKs1sZu8AW3rv1w8qQZ57/+HAUoYBzFV7RpTVoz6fTMhkL9lNvjBGWQgtYCR/MxsngWaMyRN8vZjqSghrW64jblNQofBANIZgPMFYorF0UwPJkpKADMkkYmow1BgTcEnS6k4hMzLBljf50fZOpdpJ0NcDKn2t7ye2B9Bpzzs1WZs61fSdpXxPe7ZOvps8z8TyFjs1oa6ZZJT7w8wki00TVka7fU9bEqe6Fbg1si1/J9oLbbUCEL2c20WHjQJdphSINCSb0yLn8jdyQPTyLCaJJpVJ+lQFGE+MNYmmDRGUssrMjpS36A0IuCFhZhCCOtD5WH08Q8IlWdmd1JM4KvmZslnrqUZjSguu2eFn/+5f5/jBeUwzwAYJAfHOEVNN3ci5BMDRlPTkcCUpT2MMvvDUKi4dFcjyhSc0gaIsRYxejw2NhEwWRUGME/ZSdvzFAZCsR0kBoULDu2KMFN6RYuDKlSu88vJLrK+vaSjPWJxL69owKO88RVEwNz/H7bfdzqnrTrGxuUXQLHZNI+FAZSFOvCE72aJVJP6WrsAre2s6y2FmRhgjQI4ANVoFRh3XHBpnLYPBgJfOnWPjymWWl5eJMVIWBdYKaIWGARpjOHr0KAtLS+w7cICiKEU7SQocNDV90zTEJE59VVWtk5hSEp2wJPdtMoigoYQTZlJuHFL2oWkoCgGujDGEasz21gY7Ozs0TUNVVS3g1DqTTsSavXOUvqTsdlnZt4+lpSXGVUXdNDjrCeqsVVWt4FkGbuRPLjPZlMfSbJMxAWVXGQU0t7a3KYqCpqogZcaDMmmCsMi8F0065x1FUbCyf5nRqFIheUkWIPU83VuM/IIo4JefF+0PUhfaVbVOpP/JP+3ztPUhZq3BaAbHpCBnMuCtZe3KKj/yIz9Mr1tiDfS6vRzRI8drnRllFcmm/DfryUxKberA/AcwRCMaR5nxZAwSnmQMZVlireXQoUMcXlnm/AvPs7O5yZEDK3hE5NuEWgWrJetiTJHkHE2K1E3DYDRmY2uHje0drqxvsLWziys7zC0scO99D/DBb/1WlpaXIYEvSqo8PuT7Ub1EY40kZDDSxiQsV5ISWGNwzghbyTmIFpKGy7rcj6V8rAWnum0WcM4zGg157bVX+cqTX+YrX3qCc2fPMtjZxRsYD0cMBwO6hWeh6+l0u3R7XZaWltm/fz8nrzvFyr59HDx0kPnFRXrdHq7oEXA0UVjL3ssCQoi5/2smVGMoXM4emxlasgCgTWZP32y1qYywlTBW1IOSYXd3yOrqOtvbO2zu7DKsG0IILC0t4Zyn0+kq6OmEYavXClrXcik5t7WSyKK9J70xryCchIRBBsnLQrLPoUB6JIBLlM6S6hpvoBmP6ZUFvbKk3+1SFgW7O7uMBut4J/1oYXGZgKFJlvXtIes7Qyg7BARAc6kRMXtt76llFwmTNWVWZErtb1NORDDdZzOglI+dsJwmgKrsn/utlM1P/+d/tn3Omc1sZm8fm4FKM5vZO8CW3/snr94EOllgapI89cXe79vp+ZS1rKI8uc8TCYRd0872E7U6KJLeNqIR+60rn4xT9olOuvRQAZXQOIPEdMhVCvq9TWBV2FreAoZgLI11NNbSr7awKRLxBFNIymInq3CkzIwRT0Jgjqnwh9Z05rPno97LH3EY/aPt/VUsCdui/ai3JlKkey2nPN/7TFNblKYuM2zRLfqaloS1c7XtaUs6IXYqwCmYXQaXdP9M9dcbCEVSRpnDJGG81SkRjbACpG0lYTKhE9nMk0uRlAVDDUq3t9jk9H5F7ytlmr7um7lHmESIAnBk5y+DOfmVSMpwM5ByZrWpGtX3e/qMkVThHQym3uQf/r3/hoNLHhtGFKaE5DSkR86bGTnZSRcQqJH7UVAII46K7G+oxhVFWWBQ/aSybFOXCwNGnP0Qgwpki9Miq8XynDEKa8gXAgxFZZesrV3hpRde4LXXXqGuKkgiqBubRpgITnRNyIK8iOM5Ho/Zt38/Dzz8Hpb2H6CuK0IIoq+iTmuUmDeMEVFuwe/kXEHS4UHSlXrto5m1Q3ZgszC1soKykHbTNGxtbvLpRx9leWGO/fv30emUNHWjZSDOTV4x7/f7NCGAhqPtAb+cod/rMb+wQL/Xo+x08EWJtY4QBGyqq0bYZAiwXhSFlu1k3DKYth0772nqmuFwxMbmBtV4zGBnC4fUa0LqpGkaup2OdM8pUMlqGKHR8BjvS46fPEmv36OuG2oNqYsxEZqsQTRtskG265dGwBOr95m/d85SjcasrV3BedG0ikHCC1HWQS7HpOEvmd0TYiCROHjwAItLy4zGFSlGcVCvGpmMgkD5HOJ0kwcn/YHRRqEAqHyrixYZVFKQDi0zkyIo6ynFhLESBrSxdoUf/eEfot/v4q2h0+nKgkUujlxG2r6nzzkJLryqDNuNk+NzVs6WEWQABQtyuZVlyfLiCjdcfyPPfOXL7K5f5vjBfdimxqdAYY2GceVllKC6RdDExO5ozObOLhdXr7C+sc3m7gDjBNx44MEH+MhHvoOVffuJKVGUhd50Bk4UFFLNL2c91mZQSUBCY8FZg/PCMszgqXVS96LBhwCrmgUt1DW7u7u8/NLLPPnEE/zOb/8Wly9eolN4hsMB9ajCRCgLQ6/XZWlujpX5OZb3rXD0+HGOnzjO8sp+9u3fT9nrUXQ6ohlVeDCWppExS4BhAfW9l0QENgNLLXgpTST/3k0zhdrfLWOIRtlazlI3wgQbDsesrW2wvTtkMBwxHtVUIXDw8GEBBY0jomGOUUC0fN0YVGBff1MmbWWySGAzoAfyO6YgrbyUJTY1ZhljSKmhqYd4K0lQeoVnrltSWktTjRnu7BJDYHFpkYXFHs5b6qrGYFlb22DUBHpziwTr2RqMGFQNKHNJW6f0Ly2amBIhRoIymZJmCExJyt+q1l0eq2NQ0M4giTr0RM7pnFH1yKTYU9vHf/qn/nO54MxmNrO3lc1ApZnN7B1gy++7BqikDj/TE6o86Zq2dhK/12RaqxMPdHKKUfZJkqwySFaP6FSHIJ88odnEJKQkopMnjAhv6j6yb9IV3QmrRMgKIgCeQi3AhJOsZ0EiYTQbTz5FVCHKJI5Smmg2GWTlDALGJCZHTdk0LSmbXES/zyX5R7VcivkTyJro1fWwdz/ZchWoNNn6ln2TmRJ+TXk/qTvIE2sB0qKKxH5tu/oqYnvakt5fVqFISOiagEsCAshqZwaXEslEbDJYLfNgIFgI2ih8SriUMElDFm0i2dSKworsqzyhQ9qN6kqTYKLf0v6XS0HqsDFS/sbkO9b2qmWWQTDdPHFm9fM1Wg+JRD0e0TEGF3b4x3//4xzd3yNWu6TG4WyHhCHESppnLrdpPR39nHIIEtIvjYYDVeMx3W63BaLysUnQI3VsBGAoywLnvDJtcp2JUHckURQFzllCU/PG669x9uwZBjs7kBJ1NcbpuS26Kq3nMNlplgIW8CslbNnhxOnruffe+9jZ2cEai/PCVpFnyn0MYlQB6ynAKGi4nZ0W5VbnSlgBqv+iQsR1LUK/o/GItbU1PvG7v8P1J46zf/++1vkpikJFyiehJikpK60N2VEmV8smUE0SdVqNK/Des7S0zJEjR0kJhsMR1joN85uuL9X4MQKMGAMhNIyrik984hOsrq5y6y230i0sXlfyQQAHa7WFpqQgnjxDpyNaTzFKKLCxDl8UlN0OJ0+ekrCzupGxNU61TG3AbU/VupO3CqjqsC/9IrGzvcVrr73KgQP79d4D1kh4zdSZoAWFZB+pJ6hDQ1mWlJ0Oh48cJQQVs866PdmSAItRQc699ZCzFAq4mpmHXNUPY4rK/Ju0EakDceqlf8l1NtdX+Ykf/WF6nQKTAmWnSzQyhuTfPUNmnOWy0r/aT6+171u35/KV9iXNQPSzpL0L+FCUXRaW9nF4/wqrb7zC5Tde4cjyInNlQccavLW4lq2XqJqKqq5pItQxMaxqLl1ZZ3NnwPrmFsPRmJASvYVlTl1/Pd/+7R/h+InjOO8pStGRMqJ8LX3YSNu31gqwpG3Ne4/NYatOmUvWyb7OYb1kn7N6j6PBgPOvv8GnH32UJ774Bc6/8SbDwYDxeMRwd5fQNJTe0StL5no9+r0ec3N9jhw+xPFDhzly7CgHDh6iNzeHL0tsUeLLEqwjqEZZDrEzCrQa7VuFF8BMil7+Rh1f8jNKU8jMGa0fAwlL9KLztrOzzebmFls7W9R14Pz5S/T6C5SdLr3enFzDCRvPWU/TBAFSk5RTCKpBppkBFZds70Faj/w25vZljIyBbdORHy1izL8B+pwkARppmO/3mOt2GO1us7m2yr7lRZw1rKzso9vpCHvTiyZe4SypCaSmYWdnh42NDc5fvMSho0fBODZ3R2wlKWfpgzImmszWUjAppAgRmkqYWnkcbRoF1qfAL6PM2jQF5iUENEb7gTBlZYHhL/2Fn5KCmtnMZva2Mvfxj3/841dvnNnMZvaflv2dn/uVqzeBTnRlsquvqUn69F46H75q6+S4yX+0jnh+b5RdIdN+o3pLVtOtm6smexIqMrmGnF1WQHXyZ9ThsaIr4oyEruUkuhih8VuQFMQpkZxMkmRyJCE0+T+TnQSEQWM0S9GeVzs5kiLSOamWl97/W/77emzvtWACFO2tireeb/qY/BnyZHnvSxw14RXtvZ7USdDgw4gyfBQ5mWBpV18dne1G/Tt5JSNOqEwf5XtpE7JFAKV8Bp3ItzdqsDFh8w561mwWg4vCSCNp8mUjQFTSlMlS89OlEzFOhL6FJTD9SHL2FpszWU1DgJiJaWGk/F6ukWXt5cmuulmQWtOMRSkGSUWdaj78wW+g3zGY2GBtIaEnGKkBDceSSbqArQIQyRmtOqxRQzfQ1WKU8WBzinarmdn0fRZ0FqfcSfp2BWFQwMIYQ1mKmC4pcuHNN/ncY48xHg5xTlgHRp2Apql11VpoHeKISkr70DpA4nA1TcOF8xcwJG644XrNeCXP4X1BVVU4L6yvHLJnjGSMIoda6DNLWUh7ERBIWBMYZTBFASOss4yGQ7Z3tnnp3DlWlhaZn5+XsJFpbR4FHaJqUWEknEvuX9PbKypprcE7NwEWk2gxDXcHbKytU/qCxYV5FamdsMDqumq1m3KnzM+zubnJ2bNnefHFlzh69CjdToFXUEvKQcarPJbml3NW6lDbdR6KEolqPGZ3Z5eVlRW5JFLvcm3Zkl9yJwrUG+ljVq8rPVQAyzNnnuPQoYMKiElbS1HCUeumlhBLICVpEyE0OGfIUc65vpumZmNjjUMHDlI3wuCQbiPPJQxB2ueUdu10LFJATrMB6k2Kad8zSJ2FoKGVSesQAbrkiQUk9N4xHo745V/+N9J+MQK05DrK99ACpXsGD90nZ+HU3y8FAHM95yvKx7xd/uT+mu/bGEtVC9A4Gg84ceI4Cbi8eoVev6/hapBiIIWGpqlpQi0ZFRU1T6oDJgkp5BVCYHs4ZnNrm5dffoXjx0+wtLI8GXeUUWO1zUl7mw7P0qyimvHMqu6S1Jww4DIraWt9na888QT/7lf+Lf/bL/wCf/DpT7Ozsc5oe4vhzjbj3SHdwrKyuMCBlWUO7FvhxInjnDp1kjvvvIPT15/m5HWn2HfwIHOLC/hOB5zD+IIoaohEBECd/CZrrVqPV0AJ3S/JECl9OrPClMHUhrYlwFjqEBlVDRcur/Hq629w4dIql6+scfnKBkWnR6c7x9LKflzRxfqCZCwhSUbLupZQ6KaRccTYrCspAKloNSa5L8U/rZE5jLQnBf9jxCBAXUJAeucd1gKxwRIoTGKu49k/3+PAfJ96sMv6lUvYFDl54jiLSwscOHAIXxZYbc/ReqKRRQUR7U54zQDbcZYrl84TxgNOHD3M7qgCHcN0iUUX/nR1JjO/FPSftA8FopL8xljnpa8iiyCZvRRikDFCQ1JDlO1NE2hC4Bve+x7pXzOb2czeVjZjKs1sZu8AW/mGH5c5S555I055OzmebJywb76WXfP4a9u1hhkz7RD8/9ymnqv9c417mmKh7DFl1+yxtzy/ADLTAIPCKF93Of2R7Or6VLtWuQpQlsGdCRMqGgjGyWTTiKNVJMmvxp56u/pZmRTk12EuRQ0vzKLYUy9jhN+jjrYLcn2BESYO5+S9mpk8yx7bc6v65i2VJ3atdklKGLLz+P8lU9Hq0juKsMvP/o2/xrGVLiaMCBF80YGUSPUY60RfR7RnZPVf7jM7uTKvz2ykDI5I+xMR7qIoGQ6H9Ho9yazmxNlq1PF3zhKCsDkyqGI0q5YvRCz6yuolHv/8YwwHA2WaqQaQiojHmCSjERKSU2jYm4Q9GYpOISv03tBUDb2yA8bwyPu+gSNHj7G1vYMrSglhCSIKG0JQHRbpS2KaqU63iU+jAMQUc2W670V1Uja3NlhdXeXTn/h9br7+NAcPHqQsRSupaRo6nU5bRbnfGKtASL6GyQwCaX8GVJNJHDMxcaKMgf78PDffcis7uyMB3UQya6L9NPVPVVWsra3x5JNP8olPfIJ7772XW264jo4XJMY5AemM6u7kukJFptEQpIQIIieyuHsiJYPzBddffz3jqiJZYVcJOSCzdQzGaPlZAYI7rkNsEpDwhWNra4PPf/5zHD16mP379kvYm4Zgjsa7LUOkrhpizEwKOZfo7zhCE3CmAK2jEBt63R4nTl3HaFwRo2i1ZGc6g3rTlsFVCV+T9mrJ46D0W3I9Zedc+4fR46UOBQo2JjOV1vixH/0R+r0SYqDb7WS/uR0/9r7PgNtkgMifp8fetj3p38w2m+x77b+AaAQVnl6/z7FjxxgNBrz+4vMcWJijbxK+GdOzlqqpSEb0j0B1eBS0qOrAzmCXy1eucPnKOmujinHV4LxnfmGB7/6ej3Lf/ffTnZtT0C4z4ER/KLO8nBf2m4S6gfOqXQQUDoiB0WDIS+fO8cnf/X2eP3OG0e6A4e6A0WjIYDDAe8t8Ad2ioFOWzM3NsbJvPyv79rFv/34OHDzM8v4VenPzFJ0Oxkr7dtrGEwbjvIRQOYexksHOInifhL8KowoFjmIUMEcqAUgynhba/50vBFCKMByO2d7eYWNzk83tHcZ14I03z1N2OiwvL9ObWxCWVD6ZAilR9ZucdRAkM56Mfwo0GkhKT7JN0DKUezU55BABCUkRb0WTrqqNjMMp0IQx3Y6DUFGYyEKvZKnfw6XIy+ee58C+JaxzLK3sY35+AWs9UUPw8pKOXEf6tCJsoL/JlkQzHrK5scbmxho7OzscOX49oejy+pVNxrYgKJMtKktJfrclW6cks9DxR38birKQy0QJl4sxQWqUqZWEoSi1KuWofTWpxt5f+ct/Qct6ZjOb2dvJZkylmc3sHWDXZirJJPctdo1N17avcvzXadMT8P+/mMnO3MT5vNq+6hPpBPGqjW/d+ypAbvLtWw7+P24GdA18z3/XulQywg4TbEWBHN3VkkTrioCLEZ8cNllsMirGnT9f6+W+rpdJDvDySl4+q2aSxeKiwWnIWzJBhLaNCm5bZSIZnRTrd1dBTPqcuV1dXTfXKJQ/xL5aOf4fsahisi41fPsHv5GFnsemRp0h0TxymrIeA0Uhukf/b/b+POyyLDvrA397OOfc4ZtjjszIyKyqrFloRFWqkgoNSCUhEDIgG2wkbMNjdzceG5sGDN3yI7dAbTcYt43bdkN3u4UY3EICtRCTsEATUhUqlVRDVs5TRMb4jXc65+yh/1hr33sjMnIocBmS/FY8N757zz33DHs6e737Xe9ymtFMGq8yTpQFZFQ8WkAVWQ2OQcKdZJKfaepGmQxyDX0vzhV6RF+JgG1x2mMKzGZT/sHP/AMmx0dUlYSZyEnF8UyaYa0PkUW74M6duxwcHBFDpGkavBeRcV+JTpJ3ypSylqeeeooPfPCDWnsr0DAryyJrSFBKApKlNW0cWxxHvf+l2HPRHiFrRjlhz6SUaNsFLzz/HBfOnmU4HMp9r7Ft1p1/s+znKpyrrKxSDwJqrPRDBDgRRpncb0XX9RyfnHD10UeZzxcY1Y4qZVzOBRL627Udi0XLwcEBL774Io9efUQ0YayjD5HZbMbxyYQbN29x4+ZN7t7dJySpz8rX+EqyrfV9L+0A8FVFDFHqKWX2zp6h7YIImBujmfxWjC803M4aQ47iDJIzKUeeeeZpbt66yXvf+15tW3IfXvWgAGKInJxMuXbtFV588QWOjo4xGOqmkfaJaK0UseKcMyFKBkO3FFA2kjXvNUfn+8tP+6l8sb4blH3W9zfLLgT6DLDG0C7m/Nhf+2tUlQiBF8Bk1S5Y/WjZTu7fJp/v/836Z7MMWXv1d/J59bc42X2IdF3PY49eZXNjg5PDQ0aDhspYqZ8UqLxjUDcS0qoZ26paMqI653CVpxk09DESVVy/bRc8/dTTGAN7u3sMR0O8F7afADQKxqmWklR6UrF/T06ZxaLllZdf4h//8i/zN378x/mp/99P8vwzzzA7OeHk6IiT4xNi6NncHLO5scHe7hZ7e7tcunSZq48+xmOPPcYjVx/l0uWH2Dt7VsPcKqxzkjVtGRYpzzXvBci11imQZHRZQqs5S4YyYU8mEcZXMxmsF504YyzO14SYmUzn3Lx9h5euXePuwQG3797leDplvujY2d3j/IUL1M1g2Y5hBShlXWjKRsdfkhCfVGlQFnIke6nNWq8xKftIQ/c1HCwpYJ9V887VmZQ6LIHaJBoi5zbHnNkY05C5de1lcug5d/Ys585fYGtrm9FojDFuGSpdwkdl4BcotTAupS6l/WfNvjkY1BImlyI3X34RazIXzp8jxkgfRI8yW0/XqxC/Mp9RZjcZYTgrq1TYmlEBs6KVJ22cfO/qnYzH8t5g+MjXfWj15amd2qm9ZeyUqXRqp/Y2sH/WTKV/9qb3dX8Z3Gf/tEyle8pu6cCkleD4G9ibLfpib/KwOs1dfZKflewtWS9WJ4NGnCooPtnrneT1vluZnEX2LRylYkavQz9I6uXVl7C8jtUG+XjvccqlGmWUrJtBw1fuswc+/r7kTKUZf+Y/+6Nc2h1I9jdXk40ldD3eZCRKaaUjU/QqnJMwsgKIyHZhJ4iDWspQJu2SYStomakej5FwtBg0E5nO770XllEfAl0359mnn+QTv/RLnDt3BkikEITdlOSa+hDoQ+DzX3iS2AdGwxFt2zE5PiHnyAc+8D4uP3RZHAWbccZSWWEe9DHy7ve8j/e9/wOq9yLi+FlXuSVUUO6lABDSMPNSg0mALQm7WweIUgpUdUVOmbZtabuWmzdu8HP/8B/wnne+g+3tbXXYxeFbgmvaDnIumQPlPkU7SpzrynthNuUMaAiQpoOXuhIxducdCcO58xe4dPlhDo9PRPx72ZiX/9F1PZPJCbdv3+YLTz7J3//pv8+3fNPHOH92j2effY6nn34aVMBZmqShDz2hF6bVpQsX+YaPfYzz585iXalPDS8JAkzUVc3Vx95BQMJ0YpS04uQC2GX9rdyXwxH7SFV5jk+O+MVf/AXe/e53sbm5Qeh7nHW0bSd1gIRBPvXU0/zNn/wpcpIwGICUAleuPMS3f8d3sLmxQe0qFZYXB9JaCfV67J3vou16vBN2w6p07rWswCEKfqWkGjUP2LnUZwEgSxspv5fhIOGseSBTSUzHK7N6L59fH1RaB4fu/VuOd+/v798P5D6NKynsDTvb23zzx76BT/7CzzM7uMu7H7nCnVeuM3QJk3pCEPH7woLBeWLOhJSZtx3TxYKDkwk3b97m6OREmGvGMhyPuXzlCt/68W/n8fe8h+2tHaqmWekoOU8MAUp4W4qcHB/z3HPP8YlP/DLPPfkFpsdHLGYz+q6jn88xOVN5z2g4YDQeMhwO2drc5NzZHfZ2dtnbO8Pm5iaj8ZimGeLrGuc92RqsczgvrKgYJZzMVxXeCxgkdadluWQQCudlZRZXici4AGOqLaeAVN/33D044vj4hMlsRoiR6zduUjcNdTNg0AyomxE5SyhuBjACVAurtjwbJDNIzBFvJUTWGwtJwBqBWrRNYIgkXcxRsExZkIVlKc+djDWR2nWYlGmcY3djTI3h+GCf6ckRFy6cYzgc4L2jbhqclk8B32MSrTLpHKpZmSTRgEHALtC5jgERHBRALMae0HWc3L1F1wUOT6ace+gR5tS8cjSnw4vmZE6Qeoyx9JrXI6OAFRBiWI7J3kkdRM1kl3IBrOUzS1ahjuWnTKVTO7W3rJ2CSqd2am8De/OgEg+epT/QHvTbf15NHMXXA5QoE637NyIz/1cBOFk1OtRZgNcC5JT18CbsNc//AMulCt+ElcvKBp2A68RyDVgq4FLSzGOoMyb7PuhEsv+bsbgOKi3Pp3PrV4FM/lXnu7/8MuWm0qvKwLxFQKXLuwMIc4z1ZCS1fG0hZghBAKMQSoib1IHREJUCFlkrE/eyf6kuoyEFLEEX2aep6+WkPiNORQwRX1XklETLZXbCz/3cPySniMmJGIUN4aylj5GqrplMJhwdn3Dm7Dkee+wxYohMJ1Nu3rzJZz/z60wmJ3zko1/H3t4ufd9iMdROBKT7EBltbPIt3/ptTKYz1Rcxqq+j4SMlFE7vtbCj1llBznm9xzXHX0O5YoyEPrBYLLhx4wa/+As/x9HdO8Iwco7Q90th3KztQMI6ZEUfdQRFx01e3nvGoxHnzp7jkStX2N3bZTgYYIysyhfB5ZwzfYxgLI+/5330QVNxF1YVsj/G0HcdbddxdHjEK69c5xd/8Rc5OT4iho66rnn88Xdz9uwZBoOhZONTnZODg0MmkxOefOILHB8d813f9dt49LGrOGdUEFz0qJyGz/m64cqjj9L1PTEkDVErYZUqLaNMAosjhURMgWvXRKT9K7/yK0g5YhXwLGy5BNy6dYu/8Td+gve97/1cuHCJnDLzxYwXX3yBX/mVT/Lwww/ze37372ZQ1dRNTa/hrcYYrK/Y3TtDxtDUA2JcgT73mzjNwg7LKh5cwt/W7UGAUjGjiSGE0ZhfB1Qq4+Oycd1zjBUAVLbJ5/KdjB/ixD/w79oxy/sy5hiDhFNZo2F6Uk+/91/9PVx7/nl+7u//NF/31V/Jwe079Ec38bnHqKaNd8L0SRjaGAkp08dEFwJt23FweMQrN28xnc1Y9D1dH8B5mtGYd7zzXXzgAx/kytWrnDl/Hu+E9RL7wGI+4/jomOeee5YvPPEE115+mbZtqUzGpqjC27C9OWBY18JO2txge3ub3d0dtne22NvbYzQaMxyOJBGAF70d5zzGe9GyM5JJ0ttKwJYivo0RBqKWj5bcsm8aI9pDGQFtJBtlCTUTRufJvOP4eMLBwQGzxYJF23P77h1G4zHjzS2awRCMkbBR45fPlZwzqFacTJkKgwow0k9cAZWsgEorPTT5C5Cd3A8YYgxYY/CaLc8ok4ecILbsDmFzNKaylusvvEjuey5evMDm1iaj8QhXVeCU3alhfoU1KCxPzcyWBZgzxpI1Y+lKR7L0j4Q1mqAAMGTCbML0+JDjw0MOD4/ZPneZ4ZlLvHIw4WQRMN5jjLStmBREzkWUX8OplU1WGEqiPyV9FyP6d1GZU6eg0qmd2r8YdgoqndqpvQ1s96O/D+BNgkr/Ipo6i29grwnqvA6oJF8b8W6MTIruBa++OFBpXaT69Szfz+p5HXNZYJ2EISH6GXKnct3LDGzkpQZEhjU050FtJQGa8r3Yg67dCFCyfqSVySR0ZQafNfuffi7ld/+hM1my2plVmEtx2O7f1+S1zIPl4PeDrGXzlxxUEk0lYSrNyVjRUQoBlyNdiOoUyb0EzVAmgMWrnWQRhJZwM2PEYXHO0feiGdS2C5pmSNf1EsamxVVVlegyaXm1iwUxRa5fe4mf/Qc/w9mze5A0XXQJe8vQh57zFy9y7ux5zl+8JIyClJlNp8znc27dvMlnfv3XuHv3Dh/60G/EWkPoO4bNEF95uj6QjeU7f+tvE5HblJe6SuLsIGXhyj1pprtVFS8d7cI0Kv3PqAZM33fEEJkv5hweHPLss09z8/o1QAR7U0pL4fKsDBgBbCSzG4g2VErC+kE1rObT2TIjVF1V/I5/6bdz5coV1UtSBwlUoFbCbB65KmFwWUOWsgLRmUzf9yL0vVgwn814/oUXODk+YntnmwsXLrCxsUHlxcHW3knf9yLEPZXsWk888TmeeOLz/M7f+Tu4evWKZqIS51YARHDe8/DVRxAMTpziumro+17KTrWojRVQqe96Fu2cT3zilxgMBrz3vY8TUySFQOglbG2xWDAcb/DCCy/wyCNXca6i8hVd3zObzbhz5xYvv/Qif/fv/l2++qu/iu/89m+nD4G6qWi7BXXd4JzHVTV7Z86SorQDYyTE8H5LKkxv0Eag4TvrXTijgN0yPHRVv8bKvlnHToMAga8LKsnJVifQtnb/9vK5fGceGOq2ApPWx7wlmEQBogTsCjFiFXgZjkZ8+7d9G0989rM8+bnP8rVf9RUc7R9gJrcZ0GuokbR/6S+GLkYVtYYQE6HvSDlzdHTCjVu32T865mQ6o48Z40S7yFhLMxxSDQZLYCT0HSkGEYUnE/tA33Z0fYeNicYbNsdjNscjxqMhG+MRuztbXLp0kTNnzjAYDqjqCl8PJIub9llnPU4FrZMyanxVUVU1lSti2zLepSRaYfeYMomMgrnWSsgoRpJ/OOfpQuD4+JjjkxP2j2a0XeD45JgQI7tnzlA3A9FtUoZUH4KA10Z0pKIyMlM2Eh64fC4oCpsjKfQC5K1lKqy8BwVvSt1WdS3tWpNmmBSwJJyRFCPDyrO5MWJj2HD3uadlUaEPnD1zhtFoRNXU+KbBeGGwdTGISLaGuGYghh5rJHzVGl08WDL8BLQzxmGMaGeJHp1owYXUY/Wc3khCifnhAZPDA27fus149xyD7bMsbMXtkxmLmMHVYCqMMYQo2XWLNh9rC1UmAxrSLFpdAioFzQ4pGmnKUDXwH/+H//69dX1qp3Zqbwk7BZVO7dTeBrbz0e+7f9PbAlRaDW+vxSK6175YUOnevV/rHP/sQSWTJawolTJRZ0zCzhKh66idE6chF+dIVnhjFFdunbWRUhIRZvGg9CySfnjpuRl1wDCQg4YBIp6rMZqtT7KyraafGZs7MGgq5iwhRVW1LMOkxxcBZQEWYhRwa91Zu6cYl1VTHEIBVh4EKpVr/1/aYh8wJJq84E//Z3+UK2dH5HaK9bUAKxmchkomdYKzZimTkCUpg3WB7qKfYa2h7yWVc0oyUbe2MEqEqWSMOAyFTSPMBkfbdUuH7fj4mM995lf51U/9Co9efYQYenLSdNGa5t06z1d99Vdz5uxZEdFN6vjFxPHxEYf7+7z04gv89E//Pb7ma76Kc2fPYBUowhgVrs586MMf4cKly/QhqkMiwFXf9ZopTRyeApYZDfkr7KziEMm9St0L6CZltmjn9F1PykkAr+lkWd+lHGIS8dxSXhkJEUT7SXmlnAh9IIXIYjFnf/+A5557lheee45/+V/+Xbz78XeRUpQ09inRdT1V3RAzPP7udzNftPdkudQ35JyJMdJ1HTEEFm1LXddU3uM05NF5j9FwsRjikpWQgRvXrvHyyy/x8z/3s+Sc+L7v+9fAINcR4jK9N9Zy7sIFRqNNcpa+1Xf6Xbkmo303Gdq2ZTab8Lf/9t/iK7/yy3nooct0fYtJZSwzdF3H7tlzHB0ds7d3VtuYjA19L2F91669zC/+o1/gp37yJ/nv/9yfW2ayMqoblDK4qubKI1dp2x5rVHuq1NSDBk4duyiXrN21jPVZWXgC9LFkpLEEptS5Fu1hDu7e4d/8138fTePJKTAeSejTupU6Wx9fVtvQcWUNNNIvZJtsSUn0vtYZVLYAIgqcyngpws2SIXV1L33XE7qWjfGYC+fO8vKLL/HO81tsegUEcyaHQAz9MpwsaRr4mDKVtu+YM0fHE65du8Gtu/uczGbM5gsJu3XSVozXrKqlnkIga6bH0Mv5BgPH5nDI9saI7c0tNsZjdre32dneYndvh82NDTY2x/jKC9BaNRgn7TojCw3Oewl5sx7jpWysEfH5AnaXbGHe+zWxcNFHKmVkrYDS1nswjvl8wf7+AXcP9pnNFwC8eP02w9FYdZIa7Z8SkqajJLqcsMyOZl0JtU10Xbds4xjZh5SonCfESIgB65xca+VlLHHCxIJM7RxEAZJMCpjUU9vMqPac3d0ktgvu3L6JN4YLmzv4pqYZjaibAVSSSS2hGtsFnMZI2FqIAswoM4icsAZCkAyfKUadrujzWNlWciwwzix7nbOWylWYnMhdS5hP6WdTrl17mTsHh1x55+MMzlzg1vGMg2kPbkDGEFMmYmCZOAIZT3LCIJp00nXlWZezMJVCCKt+rnpvf/gP/Qf6+1M7tVN7K9mpUPepndrbwP7UX/ix+zfp1Hc1Sf4X3t7Erb5miehE8r6Nr977Vft8cab+x5t6qW/3pqxPkBWk8Rb6xQQT5syP79Ae3+VdV87z3nc8xKOXz3Hlwi4Xdsec3WxobKSf7HN48yXakzv0033ak7ssju/SnRzQnhzST47oJocsjvdZHO/TnRwuX4ujfeZHd+mP79Af36E72qc93qc9OaQ9OSIuptC32NhjgrwyyhCJqhOi6atDTJo1x5GNpfKOrILDpIRRkGjdsVu+SmEVRoA6gQ8Eld5kmX5RpiLZ5Iwn8PFv/ga2RzWWuGTqCGtIJ/nKOLJWwr8KeFK+E2CohH4JOOGcE1aRFwaOaIrIvYpjI8BEHwJ1JavLUVeKAULfc3x0xK99+lMs5jNGwyHOWepaNIMklCrz0MNXOH/+AnU9oKpqEVv2XtOdyz45Z27ceAVSYm93V8PD9B6Atuup64bLDz1MCJGcNfRBAQCrAt1WhbELwGSMgASiRVLYICvG4CpMUMrRWgFmmqZmc2OLza0ttra22RhvsLOzw+bGJpubW2zv7LC5ucnO9i7jjQ02tjbZ2t5ie2ebnd0dtra22dreZm9vj8FwyObWJnt7Z7AGPvWpT/HlX/4bqOuapGLIFG2TlNja2qIPUZggcsHLv9aIbpNzjqauqZuGQdPgvJfsV8qmMsv7lXsT59HilV1hreXzn/8cDz/8MGf29uS3CmAIICihN7s7uwo6SptcL0NFP3DWMZ/NuHP3Dp/8xCf48q/4cupaRLmTpq7PyorxVUVV14xG42U7Kk53zgKizOczbt68wfve8x729s4AmnJcQ4EwhtF4TAiRyhfReOQC77NcGJUK/Nn7huWsAEMpXzlMFvBQwVT0u3LLi/mMv/7jP473ohVTV9XaEUuxrMCh9W3yflUn69+Xz2U8skaAWXHd5Tqck5TyGQXPnaPy0t+6tuPo4JBr167x/PPPc/v2LQaDIW3b8dnPfg6sEVjeOWKGru/Iej1eAckSAiahVtL+pM05fOWliBWI9dZKJq8YIPbEtie0vYyxOVFZw7Cu2Bo3nN3b4uL5c1y+cJ7Lly7y8EMP8dClC1y4cI4zZ8+ws73NcCQhm+U6MKpxpIwoo4Cp88JWKtcKkKOEaq3WbST8TY4lv8uoFpuRhYkuJI6OJ1y/cZObt+5w8/Zdbu8fcjyd0wzHXL7yCJvbohmFXkdSIAld1MAAWbOcKRhvlfFWxp8C5KcS7hZXfQEyVeV1dSrjrbCZDGD7BQObsaFjc+A5tz1ie1jRTg5Iiym3r7/IxbN7nNndZmfvHM1ohKsrorMEMiElorKSrCa1QJmUpowLywoVUe4QJCTOlHBoBZHWX8ZYwZg0Q6XcU5AFKOPItsI6z2g0ZDSouXPzFbrFjK3xkO3NTbouEPtO2HLa/kq/FkY05DLmrQH1pQ9In9XFKh0XPvLhr+XUTu3U3np2ylQ6tVN7G9gpU+m1WET32j8PTKUvxl51Ta9h0dbCpMgBl1pcmHNms+E7fvNv4nt/9/dw7uweg7oiRmGJRE3JLhNPET3u+0AIPb1q1cxmLcdHEyaTKYvFXLN1GbquxfuK4XDIaDRiMBiwMfCMBuI0z9ue/aNj7uwf8vL1G5J95+VXuP7KDe4eHhOqgWo1ZFk9tkL3T0mciKSr/oaM0wITAEEcEpna3mur8i/A0mvbq3/9T28GQwg9JifqPOdP/8Af4cqZMZWR0Io+CJBmQof1wkiqKk/X91S+IqlTHEKgqurVxDyL84WCabJNykJWhJWBo+mdoWgsySTeO6chH5GTkwmTyYQf/as/wnBQcWZvj8Ggpq5qYZ9EEQn/4G/4cq5efRRX1WQEtBBhVstivmA+m3Ln1k1+6R/9Igd37/JVX/HlpKhZwrIwkrq+58LFy/ymb/pmZvMFQa/NGINTxzJpSE+pEXE45f6qyqvelGgDyfcA4qCs6ltYRhImVUC5UharhmHWASqSFKk6QtJWNDNalpX16XTGwf4+r1x7iZ/+e3+Pb/zG38T73vMevDOEPiz1XRZtx5VHHqEZjIiswI7yV45czrti15T6M6hWjIaFFFBHRG4zi/mCycmEZ595mp/5B3+fM3u7/Jbf8nFhemkbsep0W+95/PHHmU7nkA1mTZC/AB8YyRQ1OZnw3PPP8lN/8yf5vt/3vYzHQxbtAouhazuaZoAxhsF4A1/VDAZDQNhyTllmXdcxnU544guf52/9zb/Jt3/LN/Oe976XlBOLxZymEeZKTJkzZ89BNjTNEAyitfIqE8dZQvqkvUitFcd0xQAyBXTV8UtAAdWa4c0zlaRYtJ5KGa29L9+be0Ck1bbSpvVXy99bY0UTSpkv4lAnulbK7O6duxwdHnFyckwGmqZh78weMQSm0ynOWn7Dl/8GtgY19C07mxsMvWHgDC5Faq9tzUrdG9Uq6/sgY3uWkLi+j9zd3+fGrdu0C2ErxSQZu7KCtJX3VL7CWBg2A0aj0VIvaXNzg9FwyGgwpK4qmrqmqmsFCbSAFSzwVYOxDutF1wwn7BtjVQxbWruUUxbNNOcdKIvLWU9V18SYltnS+pCJwMHBIbfv3CVluLt/yGzRMt7cZLyxSVUPJKvgspyFgdT3gaqu76kXdLHG5tWYYow8MGKUccRXFSEE+q6j9jVO69B6ETK3RhIfhNDhNKy07zrGLjP0ju3NMSZHTOq4ef0ao6bm8qULVN5RVxX1YEiHhuAaSIWxlTImG2wSNrPBEHMkKVtXAHUJJYNMipG+7/FONKaSCp+DWYaZShOxWC+AP2ScA5czXcyEBBhLZS2pm9JNj0n9gpu3bjOdL7h49Z0w3OHmnQPaCD0OfEMXs7Dk8tqEKkXQjHzSv+RqVmOajFfOWf7Qv//v6o9O7dRO7a1kp6DSqZ3a28BOQaXXAnzuNaOrdfdbLsV1z8b7y++1zvHmQaUvlcVsGDQen1rm+zf5Pd/97fz+3/s9vOPh81RWhTqNTOhCEA2f4pA5pfc71a0QRz1jcBhW7BO0NFIWoeCs951zwqYIyKQ2Y8VRMBaQFeM+JGaLOfO25/Zx4torN3n6med4/sWX+NSnf51f/9wT9DEz2tikaobLleaouhVLVktKD1TOkpXyVX0ZdR4e9Ph70LZ/asssQaWGBX/6B/4oV86McLklI/dvjSH1LdaJULnckzgURjN3WbtiHZXrXL/34swVJzvrRL14SyGKqGxS5pA42dLmJ5MJt27f4q/+yP/IubN7nD17VrLC5YzzwnKLOfM1X/u1PHzliuiM1I2GxQgAOZ/P6buWk6NDPvFL/4iXXnieL/vgB0SQFggpLgHDza1tfut3/XYODo+Wmkreq55WFhZHCJpaCHHu5CXhWzFGuVcFM8X5kxa2DjQZZT3dHzYomlIChhVnJunfbKTdqoq4lKGGoJksrK6joyNuvPIyv/gLv8BoMOCbvvE34VUkfAkqLVouXLzE3tlz9IpVrYNK1loZNpTZswRD1Gm2RjSwjDESyoKCKlr/XRtZtAuuv/wSn/jEL/GJT/wj/t1/5w+yMR5TV6LF1HWd9N+64p3vfJzQR5z1hLDG6lsb8/qu5+jwgCee+Dyf+MQv8b3f93u1XQlLImmZ1HXNeHsb6ytxWlOS7G8F0CRzdHjIs889y9/923+Lj334w7zz8cdFy0WZFNZXhJjY3T2DsY7RaExSwfR1y8pCZK0dkHOB6ZZ9ofyNKvJuShmrfTGgUgGFiq3KarV9fZu8fzCoJJcr1+KsXFdhJ3V9x3Q65eDgQESkJ1NC39M0DU3TCGsvRjDCuJI2kvnoRz7Kzt4us5NjKjIbtWNvNKQxCZskpEjGQwUXvV+mtJewOxlH2q5nOpsxm82ZTie0iwU5BjLgvWUwGDAYDBiPx3JNg4amqRgMBjSDAVVdU/sKa4R1ZW0BEwS8EN0jCXGjCGc7h/FWBLC13FYC0uC8gNXOy2/k2WtxrgJrWai4/cHRhOmiZbFoubN/iHGOjc0tBsMRg+GYuhkwb2VMNVbCQqV/2qWw9avHe0PlKpwrdSflFYMAImaNGQoCgotaYcbaDDHgrcGmgEmRUdOwORpT03Jw5yZNXXF8dMi5s5oFbzikqmu5piThxaZeifKvj99L/SQF3LNej1U2FTmTSXgd40s/cJqcQG9Anru6wJCNjJcpR6wVQEwYsolYNOKMwaDtqm+ZHB2wmE65c3BIqoZceexdHM97bh5MoB7SRkM0lkypO0gx6P2wnBPlLM+OsoBgDBjMafjbqZ3aW9RWT9tTO7VTOzVkwvHmXqsJ96n9c2bi0y1fPnXk6QEj0/Ff/uCf4P/0h/893nP1AkPbUZsOlzs8EZMiNhkcVuj1MZNjonEei1L9kyH3idC25LjA5A6TW3KcE7opJnekOCd2M2I3JYU5MXWaAj5BDqTQErspoT0hLI6wacpGndgbwgeubPDNX/0Y/5t/9eP8yT/6b/MTP/Lf8Omf/Ql+4kf+HN//h/4A3/GxL+ORPcvItpAzfdcR+0DoRLA2hUiK975CCATVmAlR0rGnKEyGe8rrS2Q5a9Yb8Y4VVBDnV3QvpC95ryEpCLhRnIkShuGcl2OtgUZyfBEdzqrRA4gItK5ai5cs4WAZWakXx1oyy2WKwKqG1KEOylL0eJVlToADT91IuJd1HqM6KYPhAGuchMVVFdY6+j6QojjEAgRJmRwcHCwdonI/cr3i/EuGuyxAk5FMd957YpR7MgomUkAGJBMSWPq+V1BTGDPlPMhWnGaVK7+T73QfdWyNsZriXEKFCkiRpRWzub3FeLzJzs4Ot2/fJqUoot563gIOxbjSLrrfRGBX6tAYYUMJWIJoIvXStvtFSw4iGF5CPU2W9uKsZWNzk3Pnz6umVhK9GWUbWuuW4MT+/r5kkcsJ6x48fpf2OJlM2NzaWh6zONPWSvmGGBmORuSc5N5jXJazVbCvbmoGgwEhBMbjDWmH+uQQUEXCL4uA8bJO10xbONYYESDPmaiCylHF1Nfr0RhDpeGdKMC0BOKWdfP6nV1++eDyeePtq+9LW0dB4qQaMrPZjEMNbXvyyaf49V/7dZ577nnmsznD0YgzZ86xubWFNZa+7wixJwTJGIYCentn9hhvbpP9gOQqJvOOPmV5xUjbtqLV1QfBWo3FVRV1Uy/D0jCGwaDhzO4uly6e57FHH+W9734373v3u3jvu9/Jex5/F4+/8x2887FHefjyBR66dJ6L586wt7PD5njMoKkx1tDHQB86+ijtAmNw3mvK+1rAJBCgS8e8PkTRAorCwDHKUvTO4b3FeRmbJCuZMIwOj494+do1Pvf5J3j6mee4fvMWTz/zHAdHEy5eeojLDz3Czt5ZmuEGEcO8C+BqsgJaXZCwrr7rlvWRs7DzVi8Fc8q4raCOsxZnDSYnnBHmTc6RZBPZRBI9OXXY3FMTGJjIlbO77NWexe1XmNy+Tp1bLuxu8IHH38mlc2fYHI/AWBKeLlfySqIrF7ue3EVsSPgENsrzGROJPhOqDB6cgRxFSytGeQa2bSvtXrUPy/Mup0zSZ3r5nJMsKjkLJmdizCyCJWUJr6zosHlBSj14T7QVo60zbGzt8fCly6TZIU9++hOMXeIdD1+gtglvIl6ZxDbLq4ypxsjChzGFmSbsUmsF6Cp99dRO7dTeenYKKp3aqb0t7LUe1Pdvz1/k60th95/jNV4myev+7WvXJRMYfWHf8IURKv6DXvebEWb/6+xR7MFOiEypXv3vQXb/PkZDP2yWc0djdWUQHAGDTHgtGdvPWNx+iS+7eo4f/nM/xHd841dCu0/qpvR9oA+GEKDrAov5nBgDMw1pC0HSSU8mJ7SLOV3bMp/NaBcLQt/StXMW8xmL2ZTFbEqr77v5nK5d0C3mtPMZ7XzOfDZjcjJhOpkw13163aebTekXM4g97eyY1E1J7YS0OMKHE/ZG8LUffIzv+50f50/9sX+Pv/Tf/Rf8lf/+P+f/+p/8Qf7g7/4tfMMHH8Gf3OT4haeYXH+RcHiI63psEBAsJehjJORMTJqNzhhigpxF7yPEDFiyKFiAQdfPbWkduAwuW1x22OyWLadkl3utl6z0FuBAQZuUSUEyp5VwprwMUROB9DIBF2feEUJctqecJX10cZ67e1JKi0MhThFAZlg3oGLSGPC1JyGaVRjw3mCsnh8DCJCVdEW8qioGTcNiNmdUD6iMZKYiCzhirYNUwKfAYtEyGo8wztKnQB97+thL2I81zOczLIbQ9VqGmiVIAZl14ExYVZL5DA0FSSlhLGQTCTkQUk8kkE3CeimDmCLWW7rQEVIgIRokIQUymT4GQhQdL4yGzqmzSVKnS7t36ZvOWXwlTCnvHcPhUIR6QyLjRIdEgXfnKrx1eCvCxzFIEFyKqseSJfNiLudKSZgpWQA/SgiJFVZHBjDK7jAWY2R131nDxsYGw+FIs/z5ZYZHZ52KHzvaeUtT1eLKxZWiTIqi+0KWrFFtN+fk5JB3vONRuk7Ew0MRCQ8RX1eEGBgOx5BFS0vGz3tBob4L5Gw4Ojxma3sT71cZ/ciiU7POvBCWpLC3SpmXzJRSF/LeO78EmUobyUibQIEkuR0Zl3MW51pASAFJ81JjRgBXk5HQSylkGXW1/1lNU2+t03agL/2TlaGZ84rJZa3HGY8zwuhMuaJtE3f3j3jhxZd44oknePrppzm4e5dB03B2b4+d7W1q7+m6BfP5jJACWAgk2tgz7zpiTviqZjZfcDxf0BtLhyX5irsnE7KvmfWRPmfJjOYkNMuqDhdZhOrbxYIUemLfEfoWS2ZQV4yGDRsbY7a3NtnaHDMaDmgaycrmfaUvCVvr+0Bse0xSgWcVmLdGAAKjj2mbIRlLSEnDbQMuJyqbcUQqm6mcoa7luMY1ZFMTsqMNcGv/mKdfuMYzL73CK/vHvLJ/zN3JHDsYc/mxd3H+4Ucw9YBkHX2S/iJDSYIciX2HiYnc9diUqWxFXTU467HWY6sKV1eYyuGbCmczOUXJnJcyCYvxtSSWUBZkioGceiwBn3uqfsEodjy8OeLR3Q384oTDV55nenQTQ8vFy5d46JHHqAZjbDPAVA0hG7oQabuOGDosCW8BNFuhFV2ijBCjs5V+74xdjikyzgsom5OEu1rtF1VVLZlx1js9XiZppWQj42EXekKIxAKipV41AMEYj3MNBkcMGazHVAMGW7s0m9s8+ug7ubB3hhe/8Fle+MwnOddEdpueysywdDpGeQm3zTJ3IUt7SZp9VEAluc9TO7VTe+vaKah0aqf2drUHhmqxBpK80etLZPd75K/1Ktdx//YH3teaI/AGr2x0Arf2wtx/PLHijL72ed/AXn3617YH7GeMOlxCTpfrTT3WyMp+5Qz95IA/9h/8b/kf/9s/zSNnNzDtER6ZxIaY6QNEBV4MmnkoR/pOMkAt5nPadkHXtYTQ0fctIUgq9BiisoQCoRcGUN/1dF1H33X0fS+rriEQQyT08j5FYTaUzzHGZbaqFAMxBELfQgzk0GLCAvopdCcMTMfZjYp3XNrkOz/2Qf7Qv/09/PCf+1N8/pf/Hj/7U3+V//Y//37+re/9HTx8boOtIWwOM42LjGvPuPYMvKV2BpuSZESKUaouZaGgmLI6LqWaojAEVv8eXB2v95LJfplQCzCRU6auaxVklom/sQbrHNZ60QFR/1zqxuCdV0BFAJasTnFKScLacqZtO5zzeNXJ6PsOcmZ6coyzonllrWE2n5JNkqxeJjOZntB3LU0zoPLCZMiI45xSYr6Y453jic99lrrymIywkZzFALHrSSFgkWxEt2/fYntnW0JDrDpJQNe25JyoKs/+3TvUdSVOhrFUmpGuruulmHhOkZQidVXhrGHQ1FgjukoiF2SKdIyCvAlR1irxZgljMt6LYHHZF5OpvMNXTn8rYJY14JQ1ZA0YZRyZgiGsMYq8EwDNaAr4tu8ki5axxCBA0f7+AYNGwgRHoyE5JerKy++9w1lhZzgtR5QZBgJoOAUykoYZrv+FRFN7hsMB4+GQ8WgsQKjzVF5AADmOwWBp5wu6rsM7r21QGG6V98t+2YeOvluQSbz3ve8hpcRsNiNG1blRRlxKiflsjjFWMvZ5AXoE5JLsfN57bt64yeXLlxmNhhJalRLz+UKYRsqk6tpu6QRHBbgMkIoIMVrmSXSmUHApFbaJ6k8VgMkoq6osKOSUiTniKwFUQxQxdSnwXGSatZzWnVvts3q8FNMyDbo47yIcXQBA1hiFBkuKmXbRcXI84fnnX+Tzn3uCz3zms7z80svEGNnb3WFraxNnLe1iwfRExtsUe2Lo6UMvYHhK9DnTpciiD/i6oQ+Jo6NjGUdjJGWYtx2T+ZzBaIyvaqwCoNYqy4u8TBjgrNRVVXnG4xEb4zHDYcNgUOMqEaWuqorRxoiNzU2awQCjYap9HzXbZMVgMJQxo2okOYCKaWcN2U366hTUR3WG5IkF3kq/TDlLFkhjaQOczDueffEaTzz1LK/cPuDlm3d4+vmXeOXWPjtnL3D+4SuMt3dpRhvgKqJmN8UYuiDgdUxBArGTPGe8k/DalCImJ9EbstK2jBGQswCwZIu3Huf9khFXVZX0WRLjYU1jE7absukNV85s8/DuJofXXuDg+kvYbs7O5ojzF/Z4+JHLVMMRphqAr4nGEbJkP80Y+tARugU5tKS+XU0ljCx+JCOhx6mEv8UMIZGXwvlIH1hR4+Tn+tlouCVWQvmMs6TlPwlnT3r8GCOkAFm0t1K2pGQ0CQMirO4cyXmq0SYbO2c5c/Y877z6CJu14/D6c1zZ2+DiVsPA9Aw8mCxjiyRlgKBJOJag79oiQXlOnNqpndpbz06zv53aqb0NTLK/PehhXabv/xzZFw3OPOj6H7TtTdoXfX61tYngmzFxVu7f+mB70L7F2TLqFhmjzKUYyFlWMk3s+J7f8i387/7Nf5WajtTOcSaR+qCr9rrMnnUiGSMxBvq+o120dItWnc1EjnEpqlnYHEnTPReqfdaV6KghaFG/X3fKsob8yGdx0DICjpSVftm29ndNQ0Ju3mBMBtNDbElxgTOBs+e2+LIPvpOv/doP8t3f/a1827d9hI9++IM8dvkSY1/hY0duZ0wO7hLbOTn0mt4544BKV8lJYDVUz1lDTgaDVz2oTLYRjGhHvTkTrR1roLaJj3/T17M1qiQMMGdyFs0cojCRrHVEBStA2lZWzZ0Qgjjf+n3f93gvGhwSOiLvJXOYOIZgFISx1E0jYryZJThkDLRty8H+PsOBZCDD5KWuSNZMXjEKg2t7a5udvV0WnQBEMQSsNcJgCz3Xr7/M5OSEjY2RZPSKcj6jWezIMBgMuXt3nw+8//0qBh6xVsRuvXPIrYvzS5asVJX3ZE1RLeFlhW0jzqox4jCmKI6zNcLK8FZW9yV0RVl+Rlgwgi8J6GetQgpZjim4QxYgSg4OaGbC0NPOpzzz9FM8/NDDnDt/Fm8tMYrwOYBT3Z6UMhcuXaLvOtAMUTHpfRRncOlgFdaBnAtlbkkrWn9lyJLhKfQ9k+Njbty4wfvf/z6Gw0bBOGH/oP3IGMNsNuP8+fMYI+CfURF5aw0hBo4O9nnh+ed49OpVhoMBBqirWvp8FPBSilsYddvbW8trDiEoe8gQQ89sOuWFF57jIx/+EJUykIpD6b0nqXZW23bs7OyKppWVtc6MADf5viHVqCaThCyugCD5TdlJ+4sKYBc2Xml7RrNNWWA+n/E3/vqPS3Y0IyGFuRy3HFsqStuYnksd8dJfrRWAEA09nUxPuH3rNi++9BIvv/wSh/v7kAKjYc1w2OCsYbFY0PcdUetK/kbMmqMfYiLGTIgRaz07O7s8evVRAQxzpptPOb57h5efe5YXnnqSdnrCQxfP03hP5QWsTimLhl0GawRoauqGupJQOFtEzLOAv3VVMRqNqJpa70fCh2UckIyQzXBIVdUSbprkOpWkBcZKivmcyVbKx3gBDZumoaolNNb5CuMrsnNk4+kj7B9PuHV3n2s3bnJ0MuHG7bscnUxoBkPOnjvP1s6OjG3OC5ii57RGBgCD6I4tgV9NfBCtIVlDH3oqpyw/ErWzeCSbWuUqTDJApWL3hhiiJISIPS4HTO5xBJxNXNjZ4MywYn54l8n+bXK3YDRoGI+HXLh4kWYwpKoHWF8Lm2+97aQsT+4SMipINzlreLK2anlJAoDyjCw3XpiNclBdrMgC1Jb2vgJetWuU/qXjTQHUiqW1MNSkGSyFSSk6fEb7hlU2mLWeajAgY6jrmhwyLz3zPJVxXLl8mcVixmIxwSrTD2XMLRYLjCYFQecvBgH8P/LhDy+v59RO7dTeOnYq1H1qp/Y2sJ2Pfu99U3O116Ph/LMyswqfeH1bTpPu2w5o9pZ/InvT518zvZQHrRbqF6+2B+wGX8S+WSadloSsxxog4wiAk7TAs0P+P/+3H+QDV8/gciugUw6SyrmqyEYyg5mcMSlhcmLeLjg+OiIDg8EA7ypxPDQ1dGEDpJSQW11NSo1BQ7TkvdgKmEipsD4kbCtnCYWRSaq2RXUOrIpOG51tZsQZLJPgci3GCINHwCqw3hFypk0R3zTMFjNqO8aZmj5Ebty+y3MvXuPm7X1+6ZOf4h/+/D/iZLqgj4lsHGawq46RMFzqekAIAvxIKEIUUAmwqYhm8xoVJ5aSgCKGTJPn/Nk/+cc5v+mxcUE2nqSTapcTKRliylRVRd93VJp9TYABYWeUELYYgzgSUsqA6MoI0OSkbteEZWMIxBSpa0nj3bYLZtMpTz7xBW7eeIV2PlfHWhzslBLOC5MFZXyEEBkMhnz3v/Q7wHnm8xk5Q9suIGVu3brF5z/3WULfYQxUmokq5cKmSkKSVuf25PiEj3/82zlz9hxGM8QZFaYuIrMpiaMVg+gTxShAQeh7bR9SfiBhTeLsiOMTY1oycZahINpuStuSdrkCEuR4qxfqbBVws7DsJsdH3LxxY6k7VARxm6ZZArACnmQuXL7MuXOie1RAohilD6WsDBzVNCppwsWkv6xBqksrwFsMkVs3b9G2LU1TCdjYCUNN2CUR5yusMRK+5h2PPHJVs7ZJ++z7jq7rODjYxxjoOmEPRQV+1/WaCgDhq4YzZ8+yubnJfD5XR1W0juazOU8//RRNM2Bne4t2NpF6caKRhYYWVXVD1/U8+thjGCO6WGVWWsAOtG5QZ7iMQXL39w6PxfE2VsMLFVgq6GnpD0ZDGffv3OIP/Jv/Ok1VYU1m0AyUsHgvqCQhnio8XeoqCQhjjCHGQOg6FosFh4eH7N/dZzqb4p1nY2ODRoHgEDr60KvzrkDCsn0JUzSlQIiZmME5yThmjePcuXM8/PAVNkZj2kXLrVdeYv/WKyymc3yGC3sjvux97+Gxqw9jlHWXU8R6cegFvFiBG2YtXLGua+q6Vuac6CR1neiyWesYDAZY64SRpppsKUv/CiGCNXgvzwrnK2mvyv5xztEMGh2zBVhIKRMyZGPp+sTJbMHxyYS7h0cMNze5cfMmGMP29i7j8Qa+bkjKjhRARvqp9Avp02UMNiVs1jq51pzpkgzUOQYqC433kBO1r5dySs5VhGSwviaGHkukdkBs8UQGlaWpLONxw3Aw5PrzT1HFHmtgb2+PuqrZ2NhcMtisk2ds1wddrBJwl8IwzRKC6ZbZ2+QObHnuqRljBHxRcHhpOr6X9ilacaJtlteYesZoKJ0+g+Uc945vAs5p+elzpvR9sxSYl0UK6VMZZzxg8ZWja2fEdkGYTZkeHjM5OeHu8TEPvfMdpMrz8kHHLAibFlcRsgClGelDVgoFa+AP/Yf/4eoeT+3UTu0tY6eg0qmd2tvATkGlL8Le9PnXbH1CtjYZ/JKa3qPLUdMOF2cpkrHY2HFpq+G//k//94w4YmtUywQ6JqrBgEgmG0PTVNgEi+mM+XRGTJIy3fuK4XAozkbTSFiWc1DCTlTMVCamgAIjxVFeTmiV0SAZn2T1XVghK8deHLMVgGR0NdNY1ZZZq235kDXURISrvXUySdYJaiQTUsR4zeiFzOkzRoA0W5FwTOY9bZ+4tX/Ap3/t1/ns57/AP/7Mszzz/MvUww2wtWSYc16yKKljIEcyGK2DNwKVcoa+ayV8yyz4Mz/wx7i022DCnDYk6mZI17YMvGg7CfNsVZ7WGHEYlqLEAmw4Db+qqkqyyxnDfL5gMBjgnAACXh28GCNVJcLOKSW6ruXJL3yBl196ScCmvscCfeh0pVwYNYA4+xmc9xhNHV9VNQ9fvcrDDz3MYNAQQ+Tw4IAXXniByURC6ZwzwgCxEgok4uPCVqlraYuFjTUej6XenVtlrFoKu6rTo9OV0seKg1xeBWxYau0oMOE0xEYca9EZMoXFYizOFYBSQkNKGZexpbTvUplJgYtK2SbeCQOrCHI7/ZxTwnlhVBgNvambRlgUxdZADnG2lTGyPsJp5rn7TTS1JC23sYYUEs6Js913PdaIuHkfemLUa64EYAihp6oaBoPBElgojEP5LOXvVAcpZ2W9ZWHU5JSpmgaA0XjM1taWXGPO9KHn5OSE4+Nj+q6nqjw5RbpegEJfVbRtR1bm0tVHH8NrW0MUtqT81DEuZqyMJVbL7LUsFWHx0k9VjF7YcJKBLKWEt4b9u7ffFKhUHHhTxisE/O2DaNEdHB5weHBA17XaFiSM01oJM0x9T86ZmIX9UVg9wlBSFmc2Era5xmBp6prhoGFjNGZvZwdnLSdHRxzu75PbGRuDiu3NDc7ubnPpwjl2tzZpKo+10j6ccwrklX4jN5OS9EfvJdTWewEkQh8ErPaewWCgbCQFH/T+M9IXjXHkbBQItjjvsSra76sKX9VLkfsQoowfzokYdNdzMltwcDxhOu8Yjjc5nkzZPzxi78I5rLXUzUDCOa0wMMv5jbEKvKKg0XofkbGy9N/SDmKUtlCYlU1dUWt7lsIBdHEmA5WF3C1oTGToM5tNzaj2dIsZL7/4AlcfuUq/mLC7NaaqaqpBg/M1WfW3SnbTjABvKQcdR1bjV+lrpV2V76SWys7yPiNhbmVUKJeN0Wx+S30l6Z/kAqwLqCe/v5chdf950XNjhBklIdaqNZdXmeFk3FEGr/Eko/pMfQd9D31LN51y88YrzOZTds+dxe1c5GCemM5bumzJrmLeBbKGbcsCkwBL/4c/dAoqndqpvRXtFFQ6tVN7G9gpqPTmTZUZ3tDWB8711cMySfvSm4jdOoJOhGXil5OwEjyBM03kv/uB/5itekZYnGCyo64GtCGQyPRJwl6IkcXJnMVsLqvrVcXW1jbjjTHj0YhmMFRwR0CeECMxqZj1mrNhFDCQua6uHhuhGZWwtuLMWCsOT5nYFpCJMrFWICDfP+FWZoA4AOKAWsBZJ6vyRurDWCvpkq0F1daQsAzR7cBVYDxdSGAdxlma4ZiXb+3z//6LP8r/9ON/m+Q2yNWQNkZClpA3EZUGXVsFneDf2yLutawZqwyJJi/4s3/yj3Nhq8KllpitCIenhCdjrAcNlytONIgQdk5JQLKl01RWro2EG6aId37JdhmNRqKRYYw47TkRegEbfu3Tn+aZp55iNBpCklC+HAMxx2WXqmphBbk1MWSj2dXqpsEYJ4LCvYSmOSdAoLcO7+Uau65jMBjinGQk64OIbQ8GA3WAArbUtbKxMuLAyGq5nJ8lm630MSkbY5S9tgwh0ZV/dTybuiFnOYbB4LxoFAnrTVly2h5RZ9jYlb5RsQJ+oY5qATFzlFCs0jaThh4mBV6MFcfdFqCpAGOFbaPO37KeVZenACKy9cFtyzthfhWHsmkEqIsxCjPMCTsFDWHyms3OqEaTtQIkrDu2WbOLWQ21RNkJKa6AmsKIsNbS9R1oG3dWQGc07FCOt2qjVVVJnccExrJoW4y1vOvxxyW8R0W4C3Or/B6t83KveY2FIcWm5argY2lL6+fPpgi+SyiPdQ5njTCVfv+/QeO9iFVrKI9RoKHUQQmLyynR9YWRdMzx8QlHR4ekmBgOmxVoaDRMsoT4KpvHWBFi7/pARMoiBwlFdk60zIyXcM3GOzZGAzZGA2yMzE6OmZ4cUVvL5uYmVy6c5cKZXTY3NqgcjIZDYa/lRFVL2FfRBCrjhYA/jkrBpJwTbdfJuGAtVV1LaFxdL5lUxoD1Ik4vWjhSH6LZJUcWQNbhvKcZDrHOq2C2jPnWemLKzNuWg6MJdw4OidnSjDZ47qWXGY232Nndw9U1pvKr5wOr7JAgILUM5XY53hvNNld6qFM9uZykDcQYqayMiylnrK+IOTMcNKQUNUxVWEzeGZzNmNAzcIbd8YCRg9vXr7GYnLC9scHmeIPhcMhgOKBuatEYMoZkECFrK+xKsgDwwiYt5b8Cw0vbdHpPIYguobfKIDbSmcwyOlb6wvK9Lrw4L8BRDCUDoxEgay2k0ehCjbUSIleAYowwo6yGraKgXNdLm0hahqUfCmtZgLzSlxOQrGipWWtwKRIXc1K34PjOHV564Tnq3fM88p73c3gy4+7xnEW2dNkRjSMZR1gml4D/5D/+97UmT+3UTu2tZKeg0qmd2tvATkGlN2dSGveevzgn91tG5IDvtwft+6WxV4NKIMLGEUNjM0zv8N//4B/mPQ9vkLsplW/IASbTKceTYxZ9K6EWXc/J/iH9ols6ent7e5w5d5atrS18VYOVlWj0HmOM0nwwa6LQAZYMCnE6xGGVdPW9smnqWrQ8ijPrnJNQBWuX+6AAgNUMZLKfJSn7RG5XV/Q1I45B/qYkk2vnnAidKi3AubIqCjFnvGbHKcePORFdoss1n/j00/xX/8Nf5nPPXCMoXd9kSeFsNZ17/4DH54MeqTlD6DvIiQFz/ssf/BNc3mlwuaUNCesqQt9TOwNGQvliihrqJc47WUJkBGBR8M6uWBnFhMEkYSolvCIhTpm3hhgCn/vMZ/j85z5L4ytSCjRVrY5GlGalwJVznhCiggGFzRIoMEfla9HNKunOVSA+ZQnfQ49jjIiPi2OoYRWIE2IsEsamQE5S1ox06xVYWUAWswQZCxCjbCQNlXMK3pTttgBEOWFdCeOQ8qrrNSFrfblKw7PU2SrbyzFLu7JWsgKWbQLSqIgSK+2SdVZSTMI6syrUHmLAGHHEliEvGdVF0XPrsZbMhTUT0LGElcr1lsx0WdtC0cyxCAC0YmWtdFMqXy3ZR84rqKYhiFZBMeec1KmG6KVUwqsSIYZ7HPgyZi77ghFWz7Jdqt7O8y+8xAc/+EHOnDkjwIGXELEyrK73JWk72j7Uy7YKWmTBk5aWS/MpZhCWYV566pDBO8PB/h3+rT/w+/EGIDEajpagUmknaPhm13YcHR1xd3+f2WxKDAJOVV7KWC5LdeQQh76MNzkJMzTGREiJhBFNecBquVTO43xFPRgwamqIPf1sQphPqU1kazjg3O4258/usbO9xdZohHcWa6HSNimXrBpKyoSSMVPABsliZ0HZi2X89irOL8cQ5otZYyXFnCRxgC4ALFlQRnTaXFXjvBcRcWViYeRpOpstmMwXHJ9MOZnMiMax6AOzRc/mzi6+HlLVjYRoek9W0fqysGDXgFxnJaxX+rVoqpUytHq9dq3uCrBSlfZcNSQ8xgtIX3uLTS02d1QkTGjZ22xonKUymeeeepLdrQ1GVcXmeIPRaERTD3BVDb4iu4qMiGkng44nwthjCexEmsGAru81RLXBOUvfB3KWkNKcC3NJEkeU60ZD++q60nZtpI3pYkEZZ+R2tZxKW5TmpeNqXs6ZpFut+qbRc5Q2L31XdRNTkv6qYXXybC+LDJJFziQE4HIOnBXwN0dSu6A/OaE9OmHetdzc3+exx99LtbHDMy/fpLU1yTUsgmSw7WMiZvgT/9G/q1d+aqd2am8lOwWVTu3U3gZ2Ciq9OZPSWJ1/3ZG83/I/c1DJABmbM1mzyAh3J5FshcmRPD/kD/6e7+SbP/QehjawMRiS+56+6ziZTDg8OiTnzPHhAe1sTjuf03Y9BsPemTNcvHyZ7Z1tWRVGZ67G0nUdWcN9ooYyOWUBNIOBCjev2B9BJ6TyF80aNBAGhxXQJ6lwcYoSPuM0JEOOq+wmLw6/0Sw2CWHzeBUPdtZDhtCLMLQc3y2zAqErxQI6yXVkFVUGpfmT6XGkasSLt0/4I9//X/Crn3ueZrxL20asM1SV1HF8QALV13qkisZNYoAwlS7tNNiwIGRZ3c45Qd/jq4agQsYxBgyipyHMHWFkeO8IIZCt3It3XnWUJBww5UylGjhJdXBiilgy7XzBT/7ETzAaDkihJ6kuE4C1omkkIt/CSDNY6rpmsVgsw63KX7IwZCovGk+FLdXUDX0IErbiJEQGIwyno+Mj9vb2cBpK6cwKuE0pEaIwqSQET5xxlH0EBWCRfpbzGsBTQBx9L2DWyrk0KsBvyjHW2HHrx7DrLCEjDDi0XoXdooBmlmN75yUUR1f7hYGUWLQtdV0zGAzoWsm4VyuQmhQITPfpBZW/5V7KNb6WOWuJqmFm10SZDQLsGSdl3nc9lbJIKi/Xa61dtiP0/qS8LFVVLwGprCyg69evM5/Pec973qNln8lZAKSgGRxZ1otA3EsAR0fWqOGYbdfx7HPPcfXRd/Du97xHd5HyKyL/5ZqKWQ1Zs6rzZIxk6pQyK317Vaaslad8WGMu6b3W3nF8dMDv+97fS+UstYasoYBKjJG2a+m6jrt37jKdTZnP55CFaVdVtd6/6CDlJStLAOCURdxc2DpIdrOMAI/W4Z3HW0vlNMytbqi8pwsd0+MjwmLORuPZGQ+5fG6Ps7tb7G1tMKg93hrJVKb1KCByYUZJ1jD5rlZdNmGOpazaNdo/qqoSzTR9ppkijr4GKBVgTPqE9BdjLVXlGY03qGoJ++qjsD4TlrbrFUg6YTqd0cZMMxxzZ/+APmQ2d89QD4ZYL7pDzolWj7ESgmq135UsdZIFEQpQTQGPEKDQ6v3movdX2I8I0Ods4QpZcjZUvoIYqElUOVDnjp1RzWbjCNNDnn32afb2dtnZ3pJwYl8xHI1ohmNsVUuYsvEYV5NVF23Z1HSZJ8dITkHGE2UTppQkC52VxQ8ZCyREsrRXrSIFdQU8r2plhSV5hhkj41DWDLCmjGdWAa3lxegx1/pFRk+yPvbouIoR5q9cgyblyBI6ahSAQplTySayz7gANitg7zxdihhnICdS15EWLWkx5ehgnxt37jLaOcP5hx5lf7rgaBGYR4OpBnQx0/aBP/aHT8PfTu3U3op2Ciqd2qm9DewUVHpzJqUh55eR8bXPkcnK1LnX7nFkvuQmE8okqkGSxSp2UDWEFKlM5FwT+WP/zvdyaWdAlQNVCqS+p2tbbt26zWQ6I/QLcgzMZxNCkFXSixcvceHyJaq6BnXgUIBDnG5L7IOEUlSSAh7ZhbqqRYRTJ6S+0pAWI5mmxqMxzaChqmraxQKWWjJJnMqcqasa5+W+6lqEwrM60laFqlEtJhRAEv9C9HuMOj8g1CLrLCFKNreUBIwyyrwpDquESEk2o+wqOjzHC/i///m/wv/3J/4e9XiXYAzRiA5K5SU70rqtP1LLW2Og73tMTjTM+bM/+Ce4tFOT2ynRWIz1ommymGNsBUaACTRMqaq8OqfiSIUoQABOhKmLs2yVTSbpm4VNUtc1ZHFEFvMZzz71NJ/8xC9z+dIl+q4lpyjMGKcMmmWoIty4cZMbr9zA+4pHrj7C7u728nrI0gZEm8crY2RV7jlLmIe1kgmq7XpefOFFXrnxCru7u7zrXe9iYzReAlppKUSb1vrdvf3JFJCohCUp+6w4mTlnZQGstqWUwKxCYowy4JxzhF7BT2VdFACpOKgrJ6+AeYXlIeCjgESyXULfxHG9u3+Xv/N3/g7GGL7pm76JixcvakiLAjdWRc9LPWYZT4Al60XYFgLelfq935KCKyAgAspIEAfTMW8X3Lx5k5/+6Z9ma2OTb/mWb2FnZ2dZ5s4p4yBnZZlp38riyJdTPv/C8/zsP/xZbt++zYc+9CE+8tGPUPlK9lFHue8lrLE4rMYY+hBgyVaTEMbZfMGnP/1prj5ylW/4Td+o4wkCPEpBaDvQ91r+6yE3ZVthha1Mj3G/CRYilldsJW8NJ8eH/P5/4/fRVBXeCosyxMRkOuHo8Iij4yPmszkxJeq6YtAMsMqoLIBeqb+MhFzFFCXzmYLlekvSdow4/s45mrpiUHkG3kOMdPMZoWtxNrMxHHB2d4czO1tsDBo2hw21NzSVp6qUmami1zkJO8oYCd+sm0aeDNqXUyx6OMJkK+y1dVaZtGsZrDIyxpQxu/Rj5+S3VV3hfYXxHusr4QsZSx8Sx9M5iy4wnbeEBLfu3GFjY4P94xOqeshwPMb6Gl8PRGfMipC1K4w4LyFvGO2HRkElzc6XNVFBGe/WWUn399lyf957Mj11VUnPDT0uJQYWtgY1QwcudsyODkjdnHFjFUAakY1htLmJq2qsrwii6K2sXbdc0Fl2lixziJSiAJmq5SUi7KUtKpCtQJMWu/ZDActLOzeqCZdUOLuwEAvwXpiH0qZ1DF6br6yXx/0mz/G1PqTdR3hs2q71d3KdOkplBehMJtqIjeA046y1nghkJ2NkzpI51iympK7l4PCIRRc4ms7Yu3AZUw+4dTglGEefLdk4/oP/6D9aXdOpndqpvWXMff/3f//337/x1E7t1P7Fsj/1F35MZwz3m3mN7f8MTRkFb94edP0P2vbGJqVRzv8mruMBp1l3gr+0lpfXqFLUGDLOiHA3zhOzoe1a7t68zuPveIy+a4n9nKO7d5menNB3QQQ5u47J5IiYAqFPDIdDNrc2RYA5JY5PjplOp0ymU2bzKX3o6bqOyonmToyRtl2wWLQcHx0zn89oF62EiMRICD3Hx8e0bYs1VsSBQ6Tve+bzOSfHxxweHHByfMLxyTEpRrquw1lL6Ht8JSFhZQIegrAvcoIUJMQr9gKOGCNhRjJBR8CZHCWrUmEUqHZDVBAAXcGPKRGDOIPdYoGNgcpkPvQbv4q6cvzjX/0UpmnosiEbj3/DulbHQB0/YzKeyHf85o+xNawg9cSUMVb0MHIMOF9jVHxZQiOEDdF14rTXtQAZAgxImbiS9UcdxRjCUiC3azsq74ih5+jwiF/6xV8g9D2j4RCyCjurJ2EUyIgx8fTTT1PXDZcuXeb4ZMIzTz9D3/eMxuMVAyzKuTUSUx0iueeYMn1MhJjYPzzi7uEhjz/+OHtnz3Lt2nWeeuppOhVrtlbC7FKSkK0+BLq+V+0uXSlfe2UNJypgiwCSq79xTXA66/4xSf0mTZMdgpwnprQ8TwhFB0iyGIp+TH5gRzcYUhI3K2vq9zt37vDk00/x+See4OLly9y8eZNPfPKT7O/v46xjMBwAhrZthfHX96KBpABEua/S1tdfqGN4z6vosSChPTFlDbHp2D884h//yq/w6V/7NS5dvsznPvd5fuVXPkUGdnZ2QEXgUxZAKOVVmItVUfg7d+/ysz/3c7xy4wZf+VVfRVXX/MIv/gLPPvccW9vbbG5sEPpA13Wik7R0PsXBz0lYTCEEFm3LSy9f42d+5md417se5+s+8pGliHnWe7PWCeDLWuyOWqnrewA2rSsKS0md8gJq3ft7OYe0cdnHOUvXtfz1v/7jmJzo2pbpbMaNmzd48cUX2b+7T4yR8XjMaDTEe9HladuWFAUENVkcZ0lEIKGAbdsv25qE3gpz0FpLXXmGgwEbw4bKGkzo6KYnxPmUgTOc2xry6MU9HrlwlktndjizOWJ7PGQ8qPHO4J1oImUkhDeTcd4zGg8Zj0dUdU1Mka7tWMxbcoa6bhiPN6gbEd0OvYwRoGC0Al0hRBaLBV3fL9lgdV3T1AMGwyFNU1PVEuaGMcxDok2GkGEya7m5f8jdwwlHs5Z5yHTZcudwgq1HDDe3GYw3sVWD8bWwfVICI4wpCX8WEEkHboyyZmRoEYDGANbIOC/bNUxvrW5L2aMaQHVdEzpJhOBjx4CeDRc4M7QMckuY7HNw8xrDxrO7s8VoPBJdqKrBD0a4ZoipGtog41k5X4idgPIpQIzKTJK/kEk5EHOQ8TGt2nBOKyafU4ahUZZW1jDnMq5ba6iqWliSqs1mlZHkVMNOO5AAf1YYw5h74KIH2nIPBYlQJuyyU967MzmLoHxhzJosoeBKGZTaMUawXhWfL/t756jrRtmrFmsyh3dvYVLgwvkzmBwJ7RxvEl/z0Y/dd/JTO7VTeyvYKVPp1E7tbWCnTKU3ZwZ0OfGNh8Uyl7rf7ndmvnSW9GWJpoJscTni44JcN7TJkK2nyguGi7v8hndc5F/5rm9l7Dq640N8tvSLQN8H2nZGF2bE2NF3MBgM2drextcV2UDbdrJCa0T41TpZKSdJ+ERdV8QYWSxafZ9wzlLXDTEG+hCxTsKotre3RfgZmEwmLOZzplMBnzCGjfGYnd1dtjY3xdnwnqZpsKqtVNgA1lqaqpHy1vTxMssVh7awSvrQ4fCQJDgwJtEcysbISr8yTEzJEBUjOYiwa44B7x299YTBmL/+93+B/+Gv/CSvHPUY29DkEjq3svJILc4u2iZCCGtMJQl/S+0EXEXXC8ugNoaUJQMaiP5RVpFuYRZIiI13nrbvcJXoglhdyRbHUPSNnNPU3VHAttj3XL92jR/7n/4nHnn4ITY2xuQcqWtPiKKlRM4MRxtMJ3MuXrzEzs4efdezv3/ASy+/xAsvPMf+/l0Gg4btnW3O7J1hd3dHmEumgH6G2XTG0fEJi7Zje3uXx97xGA89fIWcE+2i5fbtW1y/dp3nnnuBo4NDnLU0TaNAmAAA0o+MOGdLPRB1vvT7uvIKEK7YFuK4SdnLNskm10fJPCbtRA63XKnX4xkMRsPHbBGELw6fEefNKGvCOS/aOMpMqbxna2eHq1evcv7CeUKMHB8f8/LLL/PK9esc3L0DKlA+aAbkLCGO6HWLWO5KW8koS6M4h6+eqsk1CsgmgFnfRxHYjZGN8SZXrlzh4UcewTnL7Rs3efbZZ3nxxRdo25bNzQ329nbZ3tlmY7xBVVfE0HMynTKbzXHece7sOd773vfy0EMPcXx8zPHxMTdv3uSJLzzB9WvXqZ3nkStXeOTqVXa2t1WQfRXms2hbXnnlFV555RXmsxkXLz/E13zN1/Doo48xHG8I8ATL0KCsYt/3hOrofVtl0qz6lzJFtV60SErHk49rY/GyOa1Z7T1Hh3f57u/6bXSLGYv5XPS9nKOuagmxTcKeDCFItkDWkgUokFSASSXbieBxCYdUttlo2KyyDsZA6DtM7Bl4x/ZoyJnNMZujAePaMq4kVHLQNDQKKBSHPSIMLadha3VVaXhroF0sCFHCYZtmQF01OONIGYKG+Za2ZZbsUEkiUEBp64Tt2AyHDIdDATTWgIqswGGIiZOQOGl7ppMZpmo4OpkyGG1yNJmTjWc03sT6CmPdMithxuCqZsmEGjYDBRIT3lp8AcjX+oD0OekHwjgswI7Bu1rvRUI6nRcGYlMLOJ+zAjhdy86oYeAiVZozP7iBzz3t9JgrDz+MdR5XN5K0wVdU1YBsHfM2MBpv4ryn6zqaqoIUSKHHOIg5YrKROUdG+qVxRJNkGmIzyWSqXAm7VwHvAqKJxpWMASFEQpREGyDjU8meKUeWPp/X9JdgJcRdQKKo4aP6I2mzUhj3Tm1Kf1iC9Qooab8px5N+pIsuykAGQ2UstfH0FqLNGG/xxkJIEKMASgij1hpLjoEcOkyOzGcnHBzs0/Y95y9fIbuau0cn4Dz/yh/8o6trPLVTO7W3jJ2CSqd2am8D2/no992/6X8BQOmLGTq+iPO8aVDpPnvN+5EJ0ZsxOUJhBfC6v8uo+Ot9tu7IrEwp8vdYvuf45Xfrh9T1w9exvLzq8tGQlg6IOKRZVgbDjC977Dy/9WNfyW6d8LGln8/IIdIvOtrFgr7r6HKmqiSLUVVXsmodAs2gIUYJIYixl+w+mq1IMs1ETR9eUTc1Mcgkf7FY4OqKwXDA7s4OlXV0C8ksc3R4yHQ6ZTqdUtU12zs7nDl7ho2NDTY3N0lZhJ+9ZjAyxtC1LYPhkJyR1M1IeEPTNMvMNH0fJBzPyOS76zrJYGcMQUNWYkwSJqIZ6aJqQ+EsKQZSDpAVgNJQOKoNfv3JF/gjf+IHCH6D4zSgsoYUhFWVraVPFhBhZJsloxvOMGtbvM3Uec5/+X/+Tzi34fC5B1vRR7mH1C7Aydp8VVe0i1Z0bRARdAHjMqEPjEYjFm3RtlrpLQ0GA2GEWWEyWeto2zl9v+DJJ57gL//IX+TrPvS1NLXoSVkr2cCcd/R9z6WHHmEwGnPp4iVyzrRdx/HRMYvFgulsyo0br/Dyyy9z985d5tOJOnqSsc55YbhUTcPly5d573vfz9WrV9na3qZuarquJ4SeyWRK33fcuHGTyWTC3Tt3ODg8FBAtS8iUr1QnSkOnRNRawcMs/eV+plheZolaNwndXAeAS18LQYRyjWZRyjljkuQUXN9v9VeAHwl3s7iqZnNriwvnz3Px0iX29nbZ3JB227YtbdsymU6YTibs799lMplweHjIfD4nJwHY5NDl+IjovHUU9oDowmgIj2aTK9dMYT5oiNloNObsubNcuHCRvb09Edn3nrZt6Vqpv/39fW7dusXt27e5desWMQbpC7VkfDxz9gyXL13i0cce49KlS2yMxzjnOZmcSF+dTJlMTrh7d58nn3iCGzducHR0xGKxoK5rhoMhKQvrq+97zp8/z2OPPcaXfflXcPnyZc7snaFuapxb1/FRh1etTEsfPJY+CGC7z/R45dhlhJQ61t8bg/eWw/27fMfHv43pyRGDgVw/GWKIxL5f6kVplC3ZQsiJmBOpU/2iLO3LOS/3lQ3OerxzDOqG4WBAjnPa+ZR2OsVl2Bo6zmxvsrs5YnPUUDvDsFatuapahmBaqxkurQogK+Ojbmq8syRlgcUY8ZWnGQwYDAYYDWELIZIyWC9lbpXN2PWtAFuqVySLABW1rxkNR2CdhLYZSxczGU8XE0nDgw8Ojzhqe6J1DEcjXrlxC+srNre2cZUId/chglGAHymoummWY1UmU2kyh2VIpmoNFYBYmDja/pehlAIiZSrAYUzGkfDeYG0idQuGzrJReeJ0xs5wwMYgE7oZd27dYHtjxGhYMx6NNOGBJxrJ/mmcw5Cpm4GyV+XcQUHpEORvGWeNgl8hqL5YTDR1I+Be5SXbpTE0dYPV8PGUooAsgEHqNUXJ2Oedp48yLhcQ3Kt2oTGSAdEYAWlC3wsDVkGlEr7bdZ1oZmmbdxouWLTf0tpCRCnnqAkhUoqi5bcclyTbaUn6IN2rgMBJEld4Bb4UxCuylDHIM3W+mFNVjnYxlxBHY5jP56rNZ3jp5ev4qmbvzBlG4zFf97v+QOnJp3Zqp/YWslNQ6dRO7W1grw0qsXRovngTHY43ZV8Mc+gtDSrJqur9lpck/nu33nP8NeenfP3GoNKrLRdNBV2hRBfyberxcc5DZ4b8tm/6MO+8uEuaHuJiRzebyyp3H0T4Ux33ru/JRnRe+tArgBTxXgQ562ZICD05izaRc46mGSy1Xrq+p+97xpsbbO/sSDhb2zGfzTg5OpZsSsdHGAxnz5/j4uVL7O7tUdf1ciVWwrFENLicW1g4drmi2zTNks1UJv1VJYBXcV6yruCKA92slZf8F1OSbGY5kYmQI1oMYD2uGRFNRXJDvvDU8/zX/48f5pefvL501JyvSFiydQoqIcLpRsKautDjHdjumD/7g3+cC1s19HOyqbC+JsVAZaBPUWFBdSqdWzIJSrkYY4QVVjUSdpNlRTtr6vMSxpXKynKOzGYnPPH5z/HjP/qjfN2HvlbARishXAWIyTnzGz/yDWxsbilwl2jbjq6TFOoxRhbzOW3bMp/NCO1CWGzqBFV1Td007OzusrO7y2g8Xgqyo45LSon5fE6MkclkQkyJxXy+qo8U8M7R6z0IOKAhOgqwWCtshVw0bZY/Bl+yt+lnkKEha/8q/xlQjS0nDLUkQu2u7Me9oJJBNEz8MgOixdcCZDaDhuFwKOyWAvyFICFIiwV939GHjr7r79FRMvcxcIwR0fms4JhRVkgRVbYlzEf1mawTZxMVXPbq7NZNswTjhG0T6fuO+Vz6eR+E8dar4H5Sp308GrOxMWY4GjEs4IZex6JtAZhNp7Rdx2w6JafMyfExM2Ub9l0HKqo+HI0Yj8fs7e6yubUtGjWNMgsVNC3AD0tyhNRvAZiW9bhmsv/rj4u51LD+3AC2gIsKKIkzDidHR3znd3yc+fSEqvZ4J4kI0MdbEYpPMZIQIfuYJYOb0PtWzEjvPc5aauclG1uG0HWEtiXHBZujmq3xiO3RiK3RkI1hjbfSD2svwteFBSfsPNG9ss7RNA11JeybXsPTnGozeWUrmbXMg6UNoWGOIFkukzKrck40dSXXrFpG3jkBoftAiJmYoe0T0TgiljZk2j7R9oHZfIEfb3Jzf5+dnR2s84w3NumDiLH3IVIPBvJsSIlKM4eh9RqjasVpmFdp/zlnnFsBIa7oF2WpVWH3yHMoZycC3zlQ24y3CeKCgYehM2w3NRvO8/Izz7C9WdM0kiFua2uLoGBPNhbra7J1JIQZ66yhaWRsDarLVFi3xkoCg5yzJHpQXbes4K4shDiMFaCpqitNeKBtT0Py0IWNnKWtpiTMRWMMRp8ppoiir41DBVwy1sjCzdp30rQNKEuznM8YQ8qiI5g0fC/FFaAkz1ppG9YaSYAhv5R+lCUhhLUioC6LMMKUtq4wyoQpLMeTegu9hIEaIMWA95aUMkdHx6QUCSGytbVFXYmYvNHQxQ9/zymodGqn9la0U1Dp1E7tbWAPBJVQb2vpQn2x9r8eqGSKs/F69k91L2Ly61eHXryWvdnwNwGV7rdcXCSxAirppje839ewvC7UWYClHGiamhR6vIkwO+S7vvnr+Jr3Poptj+lnJziDMEWiaPf0fc9iPidmCevAGFxVk5BJIxpWMBwOmc/n9H3PcKhsoF4AKKsha4PRkNFoTAw98+mMxXzB5FjYL4uuY2dnm6uPPsrFS5fwVQXGsFgsaNtWwSpx2ADR+GgajLFUyjQqYtQxJQaDATllmoE4sAJoSMrpovESk6QO77peJujLyXrJyBOxmiWubhqM81SDESEbkqkwvuHupOeP/MCf4bNPPkM13KDPTvRCDKtJPRmsJUfRaKq8wYcJ/9Wf+hNc3KppbGa66EE1lVxOGC8r2AUcqqpKnNx1MzAajpjP22UbtVYyfQ0Gg2UmuLISPZme0C5mfP5zn+HHf/RH+fqPfB2Vt3SLBeKorbKffft3fTcosNHUjaSht05ZD4G+Ex2snBMmCguiqRuSarvUdY2xDl/qSR2ZdQen7/sl4NW2rTIBxJGxpR0q66rv+6XWDsYsRWudk4x/K5MPD+qyBVQsfdOw1t90W16G0AngII5iknOXsCcl1BTnDy0z74WhUkK/ClDUdZ0CfHIVfS8A7DLMTU683FZOUIClvGRurIAl9Rz1vtSR1ONlJDSypB8vIsYpJUCykS3mC7q+UwaUihsDxghTpdJMjt775T4oIGutJfSBEAMxBOazOX3X4SvRxMopKWtNGCgCeHgGg6EwVioBkoqjuawPBUGW97bWVu630o5yqccHmRFHWMBI2UsS0Ktu1XJ75vjokO/89o9zfLSPc5aqdqLBhoGkZ8mGvhdGV4wSZup8RUgJVznqSlhJjXfUzkLoWcwmpDYyrC0bowFnd4ZsjTfYGI6ovWR9816TBiDMvEoZSiavyrsA5sZA27ZkYKCszAL6lfBQXwlIlDSsreu6JYhpscvfiCaSMN2ihrU55+n6jnnbsUjStmKChGXRR6aLjnq4web2Li++9DIhJrb2zuIHQ7q+wztPNobxeCxtYdmnVPxds54VUKSq5P06oGR1UWAwbJYLE14ZSr6qVMNN+pwAITCoKkxoaUyEfsaogsvnd7n9yssc3LjB+97xDnw21ANP33fElPCVgEHWe6z3uKoBDc0LMeC9X449Xd9T1ZKZrvTTWLKhYfFeFzuqSrKeOoc1TtqGMnEKYJ2V8eOdZPt0Xu7J+4q+76EIkms2z6auRSdPnwPOCZvUlPtXHTNjBfwpfa+uRYevgEUyxkiIdUpJ+oKGmDplX0n3k9+GJHMAhdKhjKFJRlLRh7LShNaSIRij41WW/l0WQk6Oj7HOcnBwwPHxMefOXWBvdxf0tzlnCWX0FSlFPvw9v59TO7VTe+vZKah0aqf2NrAvjabS/7qgUrHXBVv+qe5HrZz/n5Ap9EBH6IsElf5Jzlts6byzWqmPocN7YcSEEPGxpYlTvvydD/Gx3/h+zo4rcjchhw50BbPvWtr5nNl8IppIvqKPCHBiHSYnamTFdrFYiMOyBmTM53MqTaFeNTU5iXZHzpnYBxaLhVDgK8/Fixd55OpVNre2iDkzm81ZLOYsFq2AB+r8Nk0jABIwHI7wdc1wOFye06pYb2H0VF4yFS0BLhVjjqHQ/0WPQgAKFXq1kt6ZlKlqj0FEUY1zmKoiG0M9HDHrM3dOEv/Pv/Sj/PhP/Qx+vIfxDdaVes1EZ0jG4bB0szneJpq84M/+yT/O2ZHF5Z5sKto+UnlHZSAamYwXMKA4W8UB63sBwsRRUY0goO86ydRX2C1rGYP6vmUyOeLXP/1p/tbf/Ek+9vUfxSKOjlVhbq8aVN/1O/9l+iShDlnZDnlNe6g4finINcYQqOpawB/NymeswyuLLCYRMXaqMZM0XKM4ROV60b7jtPxL/ZR7L/eJhoixPhbktU+v0XXW+2V5v7weLeOUEhlxiOR2FUjS3xW2VDmGcFf0uFmoR8aILoxV56owXeya5lRWkWhvxaG7J8RT2Qbro8h6u1z/G5MAeSiTwBTWUxIwrDiycg8rhkKpg1K/ZskQkZCZrGVjjWiQldCcwgKMmllwWe73DGOq36KAGEVPrOgJKXgk512FzMg9vzZTSTaVOn719+uWy3WUajEqQmxknM16Db5yHB3s8x0f/zYO9u/gnWUw8JBE9LyPiRj1dHq9znq89ThXUTUV1krdEgOxnZP7BTWwMXSc2dhgd2uT8bBh6EVk31svrrq1kh3PSha3RMZ6J4ATRhIMFAFrJyGRdV0L8GQlDDOrdLVV0Wa5LenzIfRkDZv03uMVqPZVBdaTMMRs6GJk0fb0QRiSAUtrPH0f6ELkZDanGY6ZzTsmszlbu3u4WjLgGeep6sGyHlJKjMdjSeKgYHhVVaQY8TqOm7XskMvQU+03OUu2yhC6JbBZWC/lcSZjudOsnYbKZOrYwfSI689+AdoTvvo3vBdnEtujEanvqZ2XrJ0ZyeJWVVhbEzMCduozIqtGXsgC3KWUBDCNkUXb0tQSQphRVlIUtlJKEVhpoCWE4VbVwlws/dcqUysEAfq8k6ymKSUBhTVELet99ppR0ai2oHMrJq70TWncRp99rLHmUs7kIhafM1aTVZTx1BkBq+SciSeeeILxaMTVRx8VFqERMLWMb1mF/FNOWCN1iTLHYhS9sdLfc5ZOI8DzlK7vmS9axuMNzl+4sGRFxRjJSZ7XbdcJMOY8H/5d/7oe/9RO7dTeSnaa/e3UTu1tYD/053+MMj2Q10oAU5wAmUOI8/EaXtmrbN2TWN/+IHvDHVb2AKDKmBVA8rq23OfN7Pwa9oDzfzH2YEfnQdvus6Uj+U9x/nuqZHXOZAzGCvPFSyUTsuXW4Qmf+cIzDDY22NrdVVDC0nWyKu8rx3BQY5VB4qyBFEkxEruWFHpy0rCsGOjaVnQecqJdLCTluq6UyyRcMrDFKFR8V3nG4zFnzp7VzFjQd5JZbnoyldChrsdr2NGgrgX8UEcqKjui7ztSiDhnaRctKUUGdUPlPVHDHCaTCbPZjPl8ru1cPM4YIs5LJrMQAqHvSVmc9dAFrBUh1b6TTD/i9Ue8g82NAV/9lV+JsZbPfvazuiIvTmgyRlJDCyxFThFnDTZ1fPybv4FxbTE5CuBohEUQ+45etYNKmTl1OsokvKorBVUEVOq6DmMMjQJpZf/ivFlrmc2mzOczbrxynReef45HrlwRQWIN+ypOfVVVvPf9X0aMGe8FKDLGggIhOUPX9VjrqZuGmCRTmHUW651mJhJ9jYQ4SGXVuu96rBN9mCWwscakEQFeacMGAZQEIC2r6mXVXJyvnFkydYSHI2VtjAV1bpYvxEGSchXwAiP7Gu4FijBgNKTD6HGMVWDRSAhcNgJQFMDCaPiHVcaNCMqXsWAVXuK9hhtZEWIni56NhPPpHVphYAngIkwho2wiGSP02pFrLQK7RgE5Yy1JhXrFeZM6ylkyCpb7yjnjrJe2VMK8Sn1oNjwUGDJFAF4BrT4EvNP7MJbKewUHhLkhYVYSBrQ6ZwEV1ssbUEcY1hEgsbKffrn2Xuze71dmtIOvGElStsUpLmWZUqRdzPmRv/jDtIs5BrDZEBaRGCFGQ9J2VQ0k+5uva2F0VZ7KJHK/oJ2eEGYzhi5xbmvMwxf2uHx2l3M7m2wOGxpvcGTqqqL2fhkMXVVe7spAM2yoNSQwKXOk8p7RaMzm5gZN0wjoV4TcNVOaMRJ63C4WxNhL5sCcqKqK0XjIoKlxzjLwMnZiHCEmZm3PdNExbyNtgoAlZMM8GG4eTZm1gY2dM1y/tc+si5hqwHhrF1xN1Qzx9YCUDYuup+sDxsi1lbYRQr9k45W+IYwqGdeyMnZED2ilVVbGAqNtUfZPVF7KaqkhhMGYROzmxOmEG889yezOKzx2cY8qtXTTY0I7JfctOfTkAgo7CU+OGKpmKMfMma5dQE7SXrTfV1XFfL7AWYdXDbCUBDDJyrzq2lbaWs50vWSzzEkYTQZJJmDLeKRt3ejYnDQjZV0JYFsAIWskc6JXnTtrlDWn7GBDScTAkq2GgoZZxx4ZM8VyzuQUMTJoKtAtF2qAT37yE+QYOdzfZzhoGI7G0g41tLqMw0bHnZyl3YGAxKWuck469sizvu9aFvMZfdfx6DveSTMcLUEzHdiEgZZk2aKMyVfe/xXLaz+1Uzu1t46dgkqndmpvA/u/vApUKvbqSXk2suL+hq91u//zq+wNd1jZA0Cd4kCV9+pSrTkaa3e0dDTWz6mTqDdjaz9bnevB/+43s3ad99oDN77KHnTMN20PuL1yvKROFiniynzOeaJxtDHzuaee5vrtu3TZcu7MOYyvMOqIlllyigGbM84AsadywnAxGKHFq1OcojAYvBeRUtFesMSi5aHnj0qlr+uauhksQwD29/c5PDhkNhPNFpD5eNDU5LLKK0LI1jnadiErpSkym80Jqv3kvdxpCD3tolWAqgPN7iWORLcUFI8xiM6EhmOIgKus/ocYBHjKEYiSocyCIWJN5sve914unD/LP/7kJ0XnJosuRs6I45RFU8I5YSd9+zd/jI2BxyQJs6mqmsVijlcwhuJoG6nBMrF3TvR/smrgpJRplmLjyl5RvQ+jYE3btqqNtOD6tWs8/dSTPHr1quh6qBNf+kxd17zj8fcQs4QJFlbYKhxMxIitsnCUViPOohHAIGoaaRGFNaDOvLMCKIUQlud0yl6QsKjS1tT5WzJoVhok0pzlmMJskMZRGALrjihom9dtVtlIZR9pAzpemNIpwDr5sNxuCnok+5RQuIyGl8mNrwARLXv0p2hbK4DTkrmkYZGyXdgExTEza4weY6TvZOT84uChoVzi3OYs11IcV7k//avbC9C0LK8s11bqSO7H6jnlt1brNmrmMGtLtjYNEyx9XhllAhxIO7RrgsDGGIyTY5e2uTyWti+9cijMp2Vdi5X7X20q17BW7npM+UHRhtMtcoOrcspZxg8FlWbTqYxJCVL2ZOOxVYWralzlGTQ1o2FD4x0m9oTFjDA5oUodO+OGh87t8ND5Pc5ub4pe0qCmqTyVE92jqh4snXPvawFOlCVpnfSnqCGgg6ZhPN5gPB7hnCMoK7C0qzJexdATekl6YIwwoeqqEsFuBaGEWWJJyTBbdEzbnpN5S6ehvF02zPrE0XTB4WROsjVtchxPW9o+4esBG1s7ZOOlLHyFMY4QElHBz6qqhUHjlV0U5ZzOCcBptR5yFqBD+oPcf2l/0g+0Zo0AqSlJWKBf0yxyThILpBTJKeBy4vO/9qvM929juzmzg9v0c2Hdek3s0HWtZOdTVo7zlYiQZ9Fqk8UOCVONKcl9OslCmLI8LwrrtvTlMqY1zUAA/yxjpNFxra4kJLuErSYdQwojyRgFqxHxbavMrL6TMDi5Xw0nLawuHdNKOzDGLPXRSpkZZN+c0vJZgRGtOmutaikZrIFXrl/nU5/6FKTM5saYyjtefOFFNre2GQyHAghTwoGtlDkZsvR9uZzS4wS4yikRQ8/du3epvOPw8IDHHn1U+J/GYowk9jAFSNbt1ko7SCnxyAe+Ur87tVM7tbeSnYJKp3ZqbwP7oT//Y/dveqCpn/GmrUwoyiTnte2Nvl+z1wKVXtfu+37N8RAnJetxZaUPmb88+LX+09d7wRo9fDU5fuDrDctnZW9+zzVb+h6W0tQAAP/0SURBVE2vLjsQOVlLxpXJaLkmY0jGYqoBdycLnnz+Gp/+1U/jBmOGm7tUwzEhIeES6tA65zFkEUh1FRgRLpVV6qgOpiMX4VBlYmBkBTgZFU1WXRJhRAjYcHx8zGQyYT6b0WuIjYQ5CFOiXSyYTafMZrMlC2Y2nbJoW/m7mDMcDhgOxYHLKdL3PZPJZAksGWOYzxfCxoiR0XBI6EWwOYRAyBFX+eVkvUzsY4yE2GOcwXtH5R0pB2pr8Cbxgfe+m/e/73382I//BM1wg4wTplbXEdWhlxC3yHd+6zcx8JnKQcYSUhZWVa9Ze2xhsYijHqPcq7USjiSr5tK2QhANkPutaRpCCDRNw2w2pW3n3L17h2svvcSjVx8hazidV5DIWst4POZd73kfGXGExdmxIi2zBLqKU6vXtNREWYWrgWZIUxZMAStkdT6piHRZ3RbwJKoYexmEsrIGinMp+yJ9WNtxZnW+4uyhK/Ug41K5tuXgpk6i+kTL/VYdT1K2m/WwPHV4zZpTKH16dSynYWECvklooVFQxjlHLowdZSOllKi8hpEYAUGy9oXVRrnsV42v5f7XABprJYNdSkKVE1BOjpOTOLf6Y9mm4Y9JPfkC8GWEyaAjeykybCnL5Vi3GnfQa1n+XTtmcWpZ0+8xBTAtznYpYwropowMBbf0MrRf6L2BCMTr/aMOqdzyCjiSa5K+tGwX+reqPdPJhB/5i3+Rrp1LHfsK44e4usFVnqap2BgOaZwlzmd0J0e4vmVn2HBpb8TD53Z45MI5zu9ssTUaMG5qBpWn8RWDQUNV1YChC4mqHuKrell/y2s20NQVG+MxG+MxjYaUCdNKBLxBWIJ9H+j6TsanGKicYzAcMhyI9tKS8afVM190zOYLjucdnTKSbD2iTYY7x1NuHZzQRtjaO8f+0ZQ7hxOMHzDc2MRVDdZ5nBPgH6zoY2FkzPQi/i0hqzKehFBCtqStOOcxBmE16rPAaLhnKGL8oCCxgCMCMCDC+M4vBa0lxE/1jKzF5MTJ4T6f/IWfx4eOxfEB/XxKjj1d12KtZMqLSRYQRENP2p6vag3jlOsuGnrGWhFkDxE0SUVdV/rssEtR85gidVXTtT3OWdFeqiplXXkGw6G0W2Oo63oFsqumnNS+/F8AFQFsiti3gM2uMJtU40zCzITNKAsfq8xtpUPGKKzdnDPz2Zz5bErlPZX3WH3O/eqv/iqf++xnuXjxEk1V47WNDQYDnnnueS5cuLBMPGBUVNwrW4yMPNNVdDzEsOyjzkqmzju3bzMejdjfv8tDly9TD0cyP8jS16Mu4KCMytJmT5lKp3Zqb107BZVO7dTeBvZDf/6vrU2l77f7tj9otzXn4UH2KqfnVfZG36/ZA0ClB9uD9isr8MWEDbN++nsAqi/isl5tMhEEYU2sf37V64s4zxex6z32WoASgMsiBishQkKbFwlWcWjmIdG7IZ0ZQjXgCy/c4Nnrd3j22l1OegPNBnawgRuMWYTMIhnaPtKHSBcifYyEDBE0DbWImYYkr3nbMmsXTBYLpvM5s8VCXy1d15ONIWkab5JozKhfgTVI6msE4IlRsoNZa+najnaxoGtbUkoMmsEyBbo1hsV8zvHREbPZjEW7YDabMptN1amRjEppTX8kpcyi65RhYWi7Vhg5a+VbHJ0CYHiTqEzG2cz5c2f50Nd9hF/79c9wfDLBG4vLEs4RcpJMcP2cj3/T17M9qkmhI2kwTIoJZ42yQvTmdcWapZaIZdAMhNGwBiaUfcr24kBba1ksFmQSi8WCWzdv8Owzz/DIlYc1nFHDlXQFfjQa8ei73k0bRAy2AGtyLat2nHQFX8pkBZKwBi7EoKvcJVTEq3aIAlJyyPvZRQJoGMS5eK0+fj+msXRM7/tFOerapeub1ShgCrBVwBKbl7VdjpuzhFHJNwUT0LHGCHiR1/Wnlr/TYxQwpjTqck1LgErOkfM6cGKWd/Dq4VXKQFgQAh6Js70GqiwLQvYtOktlX2slxMZIYZeLXWYfMEZ1bwqDSWpleczltZXT3LsZ1trCPWVeNqkgulFG1KoOdN9yXXrAVb2uTmBQBzVp2NIaUGlK6OCa016sXFdKifl8xl/6kR9mPp/hvWEw3sA2A3zt8RZSu6CfHBGnU8YucWFzxJWze1w9f5aHzm2zPW4Y1xXj2lNZyfpYeWHXlPAmjKMZjnEa3hVixCozcDwesTUeU9eVApGin1QYOTEG2rZjNp8TQ8R7EWIfDAaMNUtfXUvmS8nWFmlDZNb2TGYLJPFbTXANuWo4mrYcTBd0yXA078iu4WjWcdL2ZFcz2NiiHoxwVnR1vK9Iqv8T1/pvSsKITDEI8OVFl25VpwICxSjXLGW+3jvlfRnD7DI8TvuSk0xtZWyS9lIaj7Rvk3vuvnKN6y88hw09qetoKk/Xtxgn2dzatqeuGtXHk3E05UToe5q60iYrx7dW+qiwkJyEJ661FWstw8GAXsH6pOBrGQe9gjZZQyuzJoCwCsYHzX5pSiZMLa+k/TGqwLlV0X3JTCnjRCmxSpMCrNp4SVQhexgMN27c4FOf+hQvv/QSL7/0EtevXePGjRvcvn2H8cYGw9GI0WjEhQsXWCzmwi6KkZwTTd1gjGN//y5nzpxZhsXKwoX0r8IyQ7FbTMmDKONJt5jzhSe+wEMPXSaGwGAwwPgK6wVgLPVALsB9aRty/FNQ6dRO7a1pp6DSqZ3a28B+6M//qL5bm/Ev7b5tD9jl9QALUMfpde2Nvl+zNw0qPdh0bvVqe9VtPhjsedBPH2xrzs0b3f8bfL1uX8SuYvmN68dlcdSzMWRjwCSMySIya0XvpK4HZBxthlyNOOky+9OOZ67d5NOff4Zff+IZJvNImy0BTx8jsV8wmc04nkw5mQpYdDyZ6mvCZDbjZDpj0XcsQlDwKRNyEuYT0IfIfLEQUGg4pHJlcr7SpynCwOJ4SEhX2wkDKcZE3/fUdY33shJe1zXz2YyTyQn7+/ssFguOj44l81XbMWgGOOto6kZDMiQ9c993MkFX59x7L+wRZQk5a3HGUbmanAwhGkwWVo81QE5cvHCWr//oh/nUr/wyk8kJIQZmbc+i7/HO4VLPd37rNzKqgBRI2YARrRqnjoe1lq7XtObatrKuAq8crBXDyy5DxVT0tG0ZDgbMFwu8F92Prltw9/YdXnzhBd71znfQNDVOdUwK+LGxscGj73q3CMCqw+eVpQUswQdxQMTpMcYoU03ALKespLqqBchQ0APEmTcaHlKut9Sz0zThcr8KdizvXABFxQ2Wjp5ZauYkUGBBqkHeC5AiZZuyAFtyDcKcKA6RdDo9Z5axQY4krwKqSLCKAC/l26zMq5wS3qpjrSCSZQUosQRnxIwxpCDlWoAo51VPSZlqcr/K+FuWx8ruHXcUjCshMEtgTP7TkgF13OQXhemldUNxFBWYUbbV0pmnHKuYhiuq0L0cXe9nbS+5MGGfoSCSKcfRPm6UaXUvoKYhfjp+pZyFOaf90xTnu4TqlvtYA85KGUohSgmsLNMu5vzlv/yXCH3HaDhkNKxJ3YwwOyJNZwxzz07jeOTcDg+f3eXi7ja74yFDb/EemkoZSb4SeLiwG62lbhoJB8uJGDoMkUHt2dwYMR4OGQ0HaFUv9bZQgFlYSZ2kr0+JpmnY3NxgNBYgySkTMMTMXPWRJouW6aKjSwZcjW3GBOOYtIH9ec/LN/ehGmKbEcfzwKQLUDX44RhchWsGpNLWvcM4y6Jb4Jyn7VowRnSDTKZSYWsRnFcdr5wUTBKNtxBE5H2ZRQ8B84W9J/2+MJZEVyzhnGQwSzGSlY1TxpmUJMuY1THHp8Cvf/KXmBzsY1LAaXazBPQx0feRnCD0gUEjobx91xH7nqbypNjrmCrnFVzT4TW9feiDdhkB8Mu1rrP6jBNQc3Nzk0Xbaga+ClcpSGgtbSfZLlGWZ9LMbTI2lT6kCQmWDLUSaitn6kNHULA/JhX69h4U8CZnbrxyg5//+Z/nYH+fx9/1LgaNZEDNKfPQw1fIwKd+5VfZ3Nzk4sUL7O7tcfPGLV2o8dRVzVd81Vdy8eIlLly4gCnZLSvJfrfsNfo+5UhGwtENApBJWGbk05/+NKEPnDt3XjIPaptFgSTnnYx3ZGJcPVOMMVx5/2n426md2lvRTkGlUzu1t4H90F/4a2uf1ib7D9r2QFDnQdtWv3ktgGZlr/vlvfbA869dwhsdqjgX6vDAfc6Xvn3ja34jkx/f69i9hr2JXYp9Ebs+uFoeaGVJMWOMSM+ik8OY9TghUFnQZNr4qsbXtYYsiIZH1y5IMVB5z97OFhfO7rG9d4a6GdIMBljnqQdDrPf4qpYQEl9jK4erKnxd4yqdcDtZhR00AzKGGIXWP6hkhb44glGzY8n7uAQp2rYjw1J4ezwesbGxwXA4YjqdcPfuXY6Ojuj7wHw+p+taYow0Tc1oNGJ7a0uo+30QzY2+x3sn2feiZMrJCkQ0tWSvS1HTKeNwtobssU5WpyUsIZNjy3hU8/Uf/Qg3bt/hqWeeg6ohpExdeQgLvuVjH2bcOJzJwlQqK/IxYDW7UCmD4sAsQTZ1SLJOzgvYVoCasjJeNHqChniEGLh16xbPPv20aCppOAXKJnLOMRqNuHzlqmRsU02OEl5RmhGUzyLEXBz+rCEb4hiJQHNWqsuS6KKWlyEaq/CoVMIrNAOTtNXSwGWfFVdItkk5SdPOug9ZfleAGvms4WkappGRkB15J8yB8lshE2nfLu+WQJNuWwNWCsghZa7Huq8fF3Cm7CeO5QosMQo4CWNn/aR6ntcYqnKJNDPSvyVMT8rHakYoIYisgXRr12fUwSWjDt6avpGRey47v/r8WiIK3q2XyT2AktaYKdeCXEP5nBUsRcEj+UGp75UgNWtjQmFuaMWvyrxcrlGWkoJjUs6ljvUa9PvZbMZf+Ut/iZwCfehI8wmD0LM78Dy0t8GVc3s8dGaXvY0hW6OGQe1pakvTVKLNYy19F2gXLUYF8wVwSRIKlhNN7djaGLAxlN87A94avFVNHRU/7/peQnA1K5a1ouXTNAMGykgiZ3pNKDBvO6azBdN5S8gG4xtcM8I3YxYRjmcLDk/mtBHscJNZF5j1kVkXiMbjB2MCBqyEMhtfgTXEHDHOYJ2EtxlrCDGIqHKWTG6+koQJOSW8F2CmqoSJ4qwlKGAqzJ8oYv6qgVXaRwEDy75lHItRGJIltA50fHESxiqhdBbbL3jiU58gLhbUTsLhioi+s8JM6hYtlXWEvpVECdZQewHBDNCHXpg3ztOFKKF2BVQ1aFiYhLCFEOh7yTpX2r7R62u7DmMlFLyuaqyztG27HEutgmjl/q2zyjK0EkaojCxfVctGam0BmAy+kgx1kFWzSq6xXbR89jOf5QtPPMF0OuHyxUtsjMfs392n73ounL/Au975Th5+5BHGG5tYZ7l+/TonJ8eMRiOee+5ZYcZZi3WO+XzOr37q09y4cYO9vT0Gg6EyyMSyWekhWmuwdpXNLiVhp7aLOU8+8ST/8//8M1y+eAljLH2MArIqUyynJNnndAFA2IQCJl794Fcvz3dqp3Zqbx07BZVO7dTeBibhbxRX4r5vy/Z735Y9VYpI/JbVXmumE6y1z+IRLI+wdrD7P8oK1+pVVsFWL7OmW7Q6m5xx/Tjit2ZMjpgcsTlKjhd9v34OQ3FA7j2KbCxsgnvP+yBbOjdvZMtzvdruv48H7Wfy6q7X/xUv7b67eNWrHNmS0YTH6tRaUswQk2gD5UBjIyYsiPMTZod3qQj89t/ym/nX/pXfwb/xe383v+u3fydf8cH3c/HcHuORaH/UgwH1YCCAka64+6qiqhuqqsLXIvyN0RpYakSosKl1Qo23hoEXppEror/qrKaQcIj4a4iRRFxmPtva3mZnZ5ft7W1hKJ0cc/f2Lbp2wXw2ZTKZqhZJT9M0nNnbY7yxAcBsNsMaWYXuuo7FvGUwGKgDJOcXx8bI9Qr/BLKESfQhqOMLubQ5MqPhkK//+o+SUuAzn/sc3lU4ILYzvv03fyMbw5qcAiIzI2yaqnLC4FJtoqwZw4yKIQs7SUMGsugmrTx16DphWhl12q06613f0s7n3L1ziye/8CRnz5xhNpsxmUw5Pp5wMp0yX7R0IfC+D34ZOQs7x6j+h7OOrpWy9hr6UPmKGCQUUXREikiz1LMx4jALMCU6G6yBHSjDzupvjeqFLLuKdgPd9R4z64OR0Z3WPq6wCzk/a8yb5e8L+KLfkbOAX9q3xKlcO+5rvM9F/0SBwNV5Mhg5hhxf9GWyAoOulIMpTKjC2Lnv3Aqa5CV4snot2VsKSsnhCtCjDmwBm6TAkagV6VM5CZArjr84hFIPGu6nBbkEA9bum+VVrJXpfbY8v+ygNSNjcAHWCjNDwKJyND1uuR852urAZYtqPa3C38CsCYRnQdz0WPceJ6vYczub8Fd/+H9kdnzCuPFcPbfL1TMbPHRmlwt722wPGwbeMh7WDAc1vnKSzMIKcyoGqf/hoAGQDJgh4JxhPBbwemM0onJATtTeC9NI2/x8vmAymSg4Ixn1nHVUTjTZmqpWkWhhc3R94PhkwnQ2JxmHrQYMN7epN7YIxjNpAzcPjtifzEU7KcLNg0OmPUQczWhMtgIgGVeJtlDKVPVK8H89rBIrDLqQAs4LMFTYWLaE2qrOj3MSuidi5wLOYCzWebxmOBQAXrNrliygzipgJHpJIQQqzWoWgwDYTlmjWVk9AHUO3Hjxedr5XNurhhZ6YT2mlLHZELtASj0ZBWNiWC6OWGsJMUkZNA2LtqOpax1WSvieo+tXwElpa85JmHGKArQJQCThaUs2p/MYZwm9sLGchjFLtjwZJ0GA0nX2VlkkkEx4UjZVXS/Hl67vePrJJ/k7f+tvEfqOnZ1t9nZ2eeqpp6i858LFi7z73e9md3cXX1XEFBkOB1y6eJGbN27QLhZMJyfM5zMGTS1jic6Qjk9OqKqKrusYa2gmKiheyt9gSTFIRtSSClOGPKx1PPfs83zyE5/hs5/9Na4+chVXVbxy/RVi37O1uaXPAFkoMmSskXHBWcPDH/gq7aundmqn9lYyk+Wpe2qndmr/AtveR773/k3qEtxrmaWkhiR20r/o9oyh8Ajk3ToIUlyVsoq87gb04mipA4aKycoJy8plJmIJviJrhhKyTtislVTtSg/3zhE15a1FdB1i35JjhyGwt73J3u4WmxsjfOWoXcO8Ddy6s8+N23dJtqIebdLFBFZSDKNOlzFegReWTtBytoRmx0OAHvKbA5XS0hkUYAtQAGz1GTLZZA0/WCNsZSNAhtYHqOiwScTYL52u4tQ75wgKxqhfJuwPo+WdkAxoxhCD1EO/EE2ixx65zOMXGy5fOMs73/EoH/rar+LypQt4JymNQ98zm0yZnJywmJ0wnx8xn8+Zz+csFovl35hklT70ZdVdVmuTajeU92kNJCmO5WbtGA+GeOuwJhPaGcSEiQaTHdFmFnlGHzpc8gxGY/bOnmdrextr4PbNa0yPDplPp8JMwZBMTciWzY0NLly8yKOPPsqgGTCbTen7nr6XcqybBuc9VVWJI6epub3zoPpDxorOiEHCfrymBW+aASGJqLf1Tibyqsf03/y/fpS/+Nf+Ht6P6GPPn/zB/yMXzo3//+z9ebxvaV7Xh76fYa31m/Z05nmoU3N1VQ9VPdHd0IhgRAhwFaMIGuKVYAxqohBvjBHNNWS48XVzvTGoQQWiCKKIERClaehueqS7umuuU9Opc06d+ezhN661nil/fJ/127uK5r40MfeVTu/nvH5n7/2b1vSsZ63v5/kM2ORIrcimlE4oHUhRA1oYWsuEPZkx7+LZU9plcnSMpJiNcE1mKYHU0W3b0rYLxjtbXLl8mU/+xqeoF7V4RaUsKSosxlqOnzjOH/qu76EqKmEn+K4w2p1JVyr7HuViUmlNytH2cS9jJUmflF4v+yqFAEpKF0EsBNw0RtLe4l4JVQcydGyTTv4X84Z1ty4ZrOgwg+5zb/p8hnwyZiQjVffxPC6l/F27IMZvbXvXRykFSeQxHVtBIcyDGDOTy3YAD2iKzBLsgJNujNn97u5nCJK2BAK8CKOje7/ag490MrAMGitFzAXqm+7sVEKZPKYnZMxNHRNCCzNjORJ1x2bPx7PkSLZV+pocZ9nuvYDTb3dL+eX2626/EmmQ7NO8+D0AE7z5mC+P7dL/Rop/YwyhY1p1+yUJqBhQiMuO9IWoDIWKjG9d4Q98yzdRqcDqyhrHDx6g0h0LI4MoSgngu0d+JZsjUrUYZNwtSktZFPQqkeLa7AvUDcQqy8SatqXNLBabwSNrrPi16QJriqVnEXJlYLqowRjakCiqPkXVQxU9Gg+N80zqBdO6pQkR2+tz4/Ymo5U1kddqTdFfERZO7iemS87LoKG1BcE5yrJHTAZjFCF5ogooAyF5kbeiKbEoH0jKgjYoDTpL2wB8SqD1MoSgKiuqJRijwGqiSmibZbtRWEOqu95bCWYoiiKvo8rhCyzHHKM1ZXI8+alP8OIzT1GliFUJYwSct0bR04a+tvS0oSwco0HF2nDASr9idTRkMBxSVH0oSmx/Rfy0bIWKWsbwssjbohiORiJjDEEYWilS9Xr4ELG2kHFLG0kx9YGkoChKYpSkRqWkD3STBVVV0rYuAzRyLDpWagcqxSjeVXbpNwXeO2IKfOITn8CkhElQ9irmswWjlRWOnTjO4SNHqPoDGdutgFN4z3w248UXX+TmrZusra1y+vRpXn3lFYaD/lL63ev1uXN3G600zjW4tqUsCprW8a7Hn+DQ4SOEJL5Kvm1Q0S0lgCi5N/He8+zTz/JTf/+nuHt7m9Gw4sK9F3jnO9/J2XNnGA5HtK7FGM3qygopJWwhfcFay/u/60/kM3i/7bf99pXU9kGl/bbfvgravzlQSUoheWpZ2UC+WZfb5+5/JR9SXfy13BA6J/4C1haQC1QfROJkjSE0IhmIUWawrBHzU0UScClF2rbF1VNcM2dlZcRjj76N973nCc6fP83RwwdZGQ5YX1thZTSgV5X4FGlaz2RW86Vnnudv/8RP8dRzLzFcO0zUJRG7J/FqV37TbalUU/kG/38DqJSUFCPyx5uH3LeUTrsHYFmgvdljZO/bEjJ7rbVGk9keEeq6wRoDWao0sBbfNll2ESE5QjNnsnOXk8eP8O3f+s183dd+gDOnTnDm6CGZ1Y2O4FuMVsSY5RazOc2ixjuHD556sRB/o6ahabNpdja67iQaIQijaC+gFLp452XCmhjapgSvvHYLHxMPPXw/lY2kZoe+BtUG3MLhfINSwg5StqI/GDAcraG0wTnH3Tu38K5lPpuDEgmHQmOMZTQacf7ceY4cOUwC6sWC2XyOd17iuDOoVFVifFv1KmKM9Hv9ZRS1D4HCWrkBLgqKskBpTVGIkW3Z6y/PFQFKIvPU5+f/+Sf40b/5d3HB8yM/8sMcOTTCxJaerUgh4bzD2oTWeVY4xAx4ZEAmF7RSzEuUdK9XUdeNpAvlmfFeVRFioGnkpj3GRNsu2NnZZjab0ixq5vM5KoFzToqfqqLq9Th6/BhHDx9DK5GviBwtG+dmkAmkLgw58c8WFh8jIUp6m9T+iejFwNdoKfRTV8xaSUkTI+MgxWzuF7bIM/w5SjwG+V6tNSFHo4PMhINIb9IeQEnWbU+xnPdVN67pPWa/XaEmYKwsI5/h3Tctv7N7VmU5Yggi50mhRauOmaVIUT6jtQK11wfKoMg+UjmeO8VunMktgyiy/rL4lAH3TiYUo4wFMR8PLYOqfCaDbjF16LOsS0qZgZUBZjIIE0PAaAFEuwkDGcH3At171uvNTyGjzy5ERresPfu/ayrvH2Gi7QJzHSAqwI2A3mkphZVzR++JYN+7jO579y5TZYlh93onn4pJgH2j8mRGBpV0dCw2b/D93/P7We8JUDysSvpWURQCLqeU8F4SvoqiAMAHT0oB78T3p7SW4XBAf9CnsAXWCMsnLr3GDLO6FjlUHq+VUsJYMkY+k8+1GCIqGSJhCdAbWxKVQpcVmAJdlIQEm5OG8axmPJ2ysr7OtG7ZHE9ZO3CQxgd6/QEhCtjR+oA1BWUlY4VRmZWkDTEEyqpEZR5m8IFBv4fzLgOSKjOWLMFHrLYE52UCRmtQCVsYQvQyNuTJDRBfqZTAZpZOB+BLF5LzT2thQGolsrCYRHos9wkWlKLI3m8ypom5tcUxvnOLj/zCL0Bbo33DsLSUhcZqRWkNpTFYpRj1FIWW47s+GrA6GlCVJb3BEFNWJFMwXFtjtLKO0aWcC8agrKaoJEGu6vcwxuJcK9dbLSCZ7VJMlaYsKyKJmEBr8b2KSfZHovNJ2gWvUwaT5DzQWGvwPssFlZK+l9mDAubL9fjq1avcvHad6Fr6gwEnT57iwMGDaGMye1YYUWVV8cILL/C5z34GqzWHDx1mY2MD51vOnj3D65cu0ev1aJqa4XDAiZOnqKoRb1y9wpUrl7E50c8WBePxhG/4nd+ItkXuNx4rJCq5F0lyn2eMYTqe8Yu/8Av8+kd/Hdc4MNAfVpw5fZr3vPc9nDt7jsFgICw3K5LHLq309/zxP98NHfttv+23r6C2Dyrtt/32VdD+94BKe2ushABE8nQ3Oy/PdsASiGRNZrG7akZMcUNnuqkzHTwnicQYheYeWuJ8Z2n2ub62ytEjB1ldGTLoVRw8uMGZ06c4c/o0J48c4tDGGisrQ8rCivE0Ca2zFK4rIGIkEPIaaua1Z7oIfPrzT/NL//JjfPrJ5wiqIpkSZeye3ZLZC90OUHv+Vv96oFL3lW/6vuUL+eayey6zd+S5btl7P5W/RXWsgUiRZ/xVPhQqJYqiRGtFDJ5m6y4boz73nDvD+uqAk8cP8dgjD/Dwgxc4c/Io/VJjNMsZY4AYM7UdYR11Hght2+Jah3ORpnG0rsX7IIyftqVtW0IQCYPzTgywvcsAQSSGsPwpfj+7rCUfFVfuRH7l459gdWOFe+85xdnDK6wWmtTUxMajokPHBqNEDlBWPWxR4UJgPhem1HyxwPmAylILFSOFtRw7eoyz586ysb6R5V8TprMZ/b4Ug2VZoAsxLC3KQlLkMrCDUtiyEvAzF4DGGCk0rKVuGpTW9PoDjDU0rcNYg7WWhpKWPj/7c/+Mn/z7f58f/uE/z7GjG5jkKXRBDAnvPQkp9DsQQbqHgm6mOwMpAmJ0TI/05j6V459FMpM9QlKgdcKOiEHYNdaKd1VCzGaVNgxXRhgENCmLUsCgGHHeYYxEUVtrca0Yxlqb04m0+EKFnNynlDCBROIj532HbKTsU6X2eDOxp8hSWQYm7JVdk2xhG+0FLgRUeOu2dwWrvJS/Oxd/KWaWgxJASUAIYbiAgN57vmn5mxz+Xc8ilcFtraTQ69a/G8uWBWFwUjAbKzJHpHCU9VBL0KFbnloCScI2WrK3cgKT6fqzlu03GQbq2vK78n5Jy5UHpaXg09kgXGstnliyaNm3XY/Ys0t3j4v83m2fSDHlNd35fS1lc/IFu9vGsg+ntxh6y3oI6y1kWedyP2b2pc5MsL1tL7j0puflxdx3pBgHSFqLFFohTEA0ydW027f4cz/wx+grATNX+pVMMWgwRs5FrSWFbdkyQKdzGqOAQwIyiFQWovdLRpIPnqLqiSzYyPVPZJ9S+GulCTHgnce5QMjggbFWrknaYMoKlxTTumVnOhf/H1WB7XHj1k1Gq6v4BCm/N6nd66+1Fuc8ZSUR8TFGgmuxGRwnSdpaYYywI6MneEdhCgb9Pm3TyFia+7oYN4NPChcDViu5uqpEYTWuk8oWhbC1jKGJsgybkzm10gTXJccVAo5mgCkmvzTV7/oU2cy8Ox4pJZxbUOjEy88+x2/+xseoYqCvFQNrMEYmpIyV4zK0UBpFZQyD0rA2HDAciFfVyuoapqrQ1tIfjhgON7BFiS4KMJoIhIT4AhZllvpZ6Ve5X4cUsbbEGEtEZG8xCYM1ZmPqrv93YGqKEe+9hENknzmU+Gh1/dhmA2/Xyhi8WMz53Oc+w3A4Yn11lRvXr3PPhXs4fvyErMcS0FOZsZi4fPkyV16/RIqRXq+Ha1sOHjzAsePHePbZZ+j3BzRNzfHjxzh79hxlb0SKkZs3b/D888/hfQvIur/3/V8j+8GKRNC3tfhA5XNNpHpyIr726mt84mMf5wuf/zx3t2cZ2JfhaW1tlSNHjtDr9ej1qzxGRpzz/NTHv7B7ru23/bbfvmLaPqi03/bbV0H71wWVltKQL/f6lxsyMpqRS4m3+CApLF4kZSlitcY7h2sWLGYz2smE0foa73vfe3nPu97O2+4/y5HDhxgO+vR6JRsbqxRWUxYaUiAEAThMAhUSMQU0UoRKgahzUQYkAZbqtkZlH5/5vCGqgrkDr/v8tb/x4/ztv/M/s3H6PJgemGpZZMEuM+nNWy3l178qqGSi3OQBoLr9tPvd5JvTpCDlZJe9y5MC7M1N5YQYZCBHk7BG4ZuaFDyL2ZR6MubcvRf4s3/8e3n32x/m9KkTDHqWwoBvG5p6jk6BwkLK5qjaiom2+IJo2rYh7mEUiVzM433C+Uib2UghG826L8NUcvln3Ct/S8Ky6J4LIeAi3JiU/PQ/+yXmIZCiZ9Ukvuadj3H88EG0iig3p68cul1QWQEQEuB9ZFE3LJqGpvUkwDlPTGCNZjgYcOHCBQ4fOoxSsLW1xWKxIGTAaTRakVn8GFhZXc3FizAKer0ebeswVlJwrBWpCilRVj1SBnjEz0OMu21RkDpT1apPNBW6GPLZLzxJr1+yvj6iUJBCEuaN0gLeaLOMDpctEyAiZvlZWRSZKZGPfWZ6NE1DVUlxG3ygaRuKooSUCEkYPSkEYnD0+32R12nxAIk5+txk/6aUvS7kNZHVpXzMUmbJyIy0+KU0bS3MqX6FQhgaMcv2FEkKq/xZmxOUQpBCC2QzRTIm7xfplwBJIDJNlX2BOgBL7Zn13wswaHZZQl2Bn79GZCopSXKUKTJAIsBrB1x0TKY3D36KmGVuu0CHgiRsLa2lkMqjwtJgXBhLso4aAdJiJydMYkrbbQv5WApYJcVhTDnhabkOmVmSizezBGp2U+5U9sKSEaXb9o5pKUwtY8RIXRhfsq3L8WXP+L4XtJHffiszaO979r721s9Djk5XAvKlKP45Somfjmy7fLZL/NrLVOqAq73f3z2/BKD2sNm612XFlYAtSlICU/67VIn5nTf44R/8AarU4uqWymp6haXKHkmubTM4KPuqV1UMhkNJm8ypd7IfRPbTtA3z2Zy6XmC0EQZTv09vONg9J7KMU+SlMk41TUOMCVtWlIOBLM+IYM8nxXhec2d7BxcVg9UN7m5u4VNB0RuKvMoalDH4ENFFQYxiqCxsQZ0Zp9LftFJUZYHRmtY5rJWCvrCWmDzJCpBZmhJCwior3jeZSVT1erS+JWkNWmGNJratMOdiwCioej2atsWWhfiy9fvL/qO1AGoq+66Rush60Bl4CFGk7vI+YWt2Z4rO0kQB4UHHwPVLr/Jrv/RL6GbBgX4fqxPagDKKaBQDDT1rKRRYAquDipWBMJkPHFhntLIijCJb0h+t0x+MKHoVZa8PxuCiXBsTCpTGmILCWsqyoHUtOqfaWVugjc3gjvgEWmspqyqHEWS/p5TE8DxPSIRl8puMmj5kADTvr16v4vbt2/zcz/0c995znvl8TlGWPPzwwzz11FMcP36ct7/9MUKQCZuiKAnZRkChee2Vl3j90iXatsUYw2NvfwxIvPzyyxmsWnD+/HmeffZZfve3fAdKyZjs24ZPfeqToBLz+YJ3Pv4Ep06fAm2Yz+eUZYFrWyAbkQNlUUBmwt64doPPfuYzfOozn+f6zVvMFxGbHRDIx9oakbEqpSjLihemi+U5vN/22377ymn7oNJ+229fBe1fB1Tit32lu5Hvnutm9XMxJnPcy7bLeEr0QiQ0CxazCY88dC9vf+QB3vX2h7hw9jinjh1iY21IVeTkl2RYTkyniCKgJSsYpZIkvKSIwoKyUnouE7FEIpRyuojQ6FNmTsnscYqBum1wUdFimTrFl158hZ/+uX/K55+6SKoO5XWXG7y0Z1vkWf5/7qmugN37tw0FOulcvCWiirnISyKNk5KfpMB3bIm8y1XqnEukdThUAdgUaesFs+kOx44c5L4LZ7nn3EkevO889917ngcfuJeNtRE9aqyS1JoQOllBvknPhVzcw5ByzmV2RE4YC/KaFHyetnG56E3CTMqz7G3bAvIZ13kqZUAqZhNWWb6YqMp3C2MphICP4MyIH/0H/5jXb4/xVFQuUahIWWpW1wecOLzKhaMbnFnvU7ZTvGtwTSPrnGDRtoQgRZF0G09UhqPHT3L27FmqqqJe1Gxtb9HUNTFGyrJiMBywurqKLUWKopVEKQfvKSspMLuoaZMBH2M6lkES/w3vGQwHNK2n6skMdVmWJK3QRUnUBW1U3NnaYjabUVqDTgAaW1TEBK5tIKXs6bTrsxGzubPfI59JKRGCzPbHLPvp1jmlhLE5uS9L5wRY8hRZbiEAg8Z5T0iJwnaFiLweckISWZrRFT571yGmKOBO5xcieXYowCiNRhGTMAVNno3WRkC0DhBKSdhUKWYwOJ9fCvEGSgCZzUIGEWS1ukFGPqK751QnzJL3detKUqQlELILTuwuLzOk9raUWU6AUgb2mFaLuWxeeN4enYEhlAAdSoms06gOWM5T9YCPQdY7/90tX+RxslbCHImy7K7l9e/gJnIS05LVkVdJxsJucXm8SbIfyGDlrq6t+9m1XbALREpGysX8WwCl7u/ud/Yem2Xr9uuulFiAsJw4DwIgsYeNt/vh3/L93e/SvwWECm9JFCRvRUIYPF1gA0rjlcb4hmbrBj/yn/5ZjJ+RQmBYVagoXnAKRVWVFGVJYS02mzCbnNwl46nIe5umoW0bEimDDRVlVWIzsKCyaXuMibYRYD6EhNby3sKWoBTBaJwxtC5Qt4553TJvA01MFL0hjU+0IdI6j7F9tCkhR9cnLeemmFqDjFGW4Jx4+LgWa4yMLcFjzK65tvMeozQutBSDkhQjWhd4FyhMgUFjjezNQEBZjVEKFROGRL/sYZUmejkGawc2mNRzPAlbFSgv4Kq1BfOmYTKbUvV6oARc6vV6ctxiluYlgVfKqpJAhq4f5IS4LoEuRo/3jmuvX+JTv/ar+MkOG9ZSkDAGMJBMoqcthVYURlFqqDQMSsvKsMegX4lkfn1NAHBVMhytUPR6VIMhpijBWJK2IonTwhEsrPSFGMUgvCgKirIk+Ejo/PiKAqPFZ691jl6vJ4zPbNofspQ2+LA8b1NO9lR5wiAEz+e/8AW2t7YYDgaUZcHpU6c4c+4szntu377NSy+9RGkLHnv0UcqqymOw4tXXXuOZp59lbWWAVorhcChS52NHWcwXvPLqKwz6fSaTKY8+9igxwvMvvso995zn3LmzFFZz5cplLl95nda17IzHxAQPPvIw99//gICje0IYUhIgM0Y5sb13zGdzXnrpNV544WUuXnyJra0tdnbGNE1YjjoBKJWiqipeXOyDSvttv30ltn1Qab/tt6+C9q8KKrFbi7zpmRglyl1n01JINDEQEmg0MQhDQAOL2RSVPMYE8YghsHPtNd719sf4i3/hP+PB+y5wYHWICg6TvKS0xYBKkajAdcWT1EBSCMXO2LsrjFJOlslshuVru2wC1QEiMZLQIhFzDdHVNPWc1ns8BqcslAO2Zw0/+Bf+Ci9eb0XKZCxVry9+HMuippObLDkJ+a/dYTQGkYeoLi0lJuwyCSsKGykXjykJGBEzC8X7gNIFWmUm0WKBThEVA5W1WAXBO7SCxXgHNxvz6Nse4U/9wJ/gsUcf4tiRDapCYVTAEIXZQyQtTdW/TLGXC0+Qt6gsLep2K8iMeszG6CmKTEWo+y0xRHz2Q4gh0rRi+t354aScWhSjgA8x7P703glLZg97yfZW+Zlf/ji/9MkvUscew2JAbFuSinjlUWHOEM83f/A93H/iAM18AsEJGIMiJYXPpu0mtuAW2N6Is/fcz/ETJ2iblq2tTbZ3dgjZH6nX7zMcDISBUJXLWXFJQUKo+UmK0cFwCEAIwuTSWmRKKSVSlpqYHEMNIuUZDHpoq2mjwinLrc1tnPMCHuXUIB8gJEXRRU/HiC0KFos5ZVnlIl4OWAccxGyeXhQCaCmtqRcLhsMhTdvSqyo56p2Rdgr0Cku/qkiIXDLkqGcfIvP5nBCyF42xGC2Ak8rnVUoiT5BkoIZ+vy+AggaXfdG8cxRW/FGG/b74owWPKawAGkozXzTiUdKroGMpJZlVL81uxDbI8hPQtsI6U50MLcvk2ANoKBJlafHOUZWVFMFqmddHTMLeaL3HGDFd994RvGM46JNSQGXsw1hhnoHC+8ysU8JY6phGCjm/y5zKZLPfUseWTMkTgqff66EiKG2p2xZbVPjODyqDKDF6SlsQs2QupSzbQ2bv66YhJbA52hx0ZhdGCmsosgeVeFFllkeOYAfEGNeaLMMTjzEAbWQka10jgEv2bur3+7Stk3MyM1lSyhMHeQhR7F4wOgjI5H0QgrDtYoxUVYl3LdYKiNG0NdaKf5bKZuQkYc11/ThloLsDRZessz0Mta7pjmX2ZZhSKgOCPoFRmQWWJBRC+5owvs1//Z/9IKYZk7ynV5YymaEMvV5Fr9fLMe8i5+zA1aZphcWZ08qUUvT7A3rZJ8na7FeVWYIqeeazufT9EFlZXRcWDFomR5REujtluDmecOvOXULSlP0hqqyYLBpmdYO2PQbDESEmjM7jTJZfFUVB60Qm1a2vz0B/1e9jjKFtW/qDPvPpFIDRcEjrHJAoi5J+UZJcIBnNvG0Yra2RYmQxnVBaQ9UrcMmjS0OJAh85efIUN2/f4dKVyzz34kWu37wlARiKrHfSqOg4e+o0j7/jXbzz7W/HKs2l1y5RFIWMMdaI3E+BJlFVFa5tcV5S2oy1kITBZHPfNUouXlevv8EnPvkxbly9jPWOQ/1+ZiYZtBaTeqvEY6nQGqug0orKQs9qRv2C4aDH6sqI4WBA1RuJXLGs6I2GDFZWUabElBVoS9I50c5a5vMZvV6PECO9PJ516Xm7/VGkc3p5zuVUuSwNrOtaAD5txMcqKZpGzpeqKvnnv/zPKYwVKaJrec973s3a6ioJcEHMvI3WfOITn2A2mfK+97+fA+vrNE3Dyy+9zK2bt2QCQ8v4PJlOmc5neO85feoUxlhu3b7FBz74QY6fOMnFl17n9u1bpBR4//vfx9Url3n1tZdlXZsG5zyr6+s88e53A5qqLGny9dfobLKUWX4d0Otb8Tl8441rXL5yhc27m9y9e5fFomYxXxBCpNfrMxqN+Iefe5r9tt/221de2weV9tt++ypo/zqgUtd2B4bMHogJMkuotAULEkFpUoiUuqBUCuUdOrSMt65z/sxRHn3bvbzrHW/jA+9+nAvnzsoNR3B416BTwKokEpIo0rgIRG2WC1e5iFFKZw+jDj8Shk9CwKYEu6BSBn921x6wFYXVhGZBu5jSzGfM53OS0gRlcRS0Aa5tN/zBH/hheoMBtuyBMaBM9o+S/SB7bS+otAdS6ta7e2OSAmjXoArIN8IpSvFGZgxoJakwKkYMCa0iREeo58wn26wOe7zrsUc4f/Y073j7o5w+cZT7L5xlfX2N4Fp6pSWGFqtBE1FJHqiIU5rYec10q7Fn5O+eS6l7QfxXUqZoxZiZRksGWCSFSPSeECMheEIGnkLwuyyk/Ah7EuA6QCrmJJ1dUCkQI1T9DX79ixf5b//GT0L/IP1qgCaJ3MIodPSsGI1pZ7z/iUc5fuQg+JbFbMqrr72Gc56HH7jA0CZUM0bVO6yuH+Ls+XsZDkfUTc3m3U3m8xkAtihYGY12Z5Wtoap6GfhDAIEMZKgMtGhjMLozGFboLOMKWf6w1xNDWAgiI1S9ilT0ubM1oW4DppOOpITzCWMqUja7lYJEbtCFGUU+Lt0j++NkBHAJrGT5U8z7ufPYcMEzm074yR//Ozz26CNUpcg3qqpiNpvz8MOPcPzkSVqfCKFjDEl6nDES500u2ItCwAJQpCRSO2MNZTbaJgZef+01FrMZqysrmGxcbWzBcGWdA4eOoDIwk2LEty0vvvA8b7xxhdMnT2Ay84IMOKxtbHD48BFhCeQiGqUk5XDZf2V80gp2trd5+qkv8fDDD6KVpiwKko9gDIeOHM2pVCKpc22Daxs+8iv/gocfepDDBw8uZWnOeVCK02fOUjdtZktJ0SiAVgY7FBgt7IkQPG3b8IXP/ybvfuJdaC2plcSE1gX94QhdFMybVthIKeJcy872Fi9fvMj73vtuSmtoW09IkRhFYmmLcinBWx7npRF4ZoVpxWQ6YfPOHQ4dOpi9X7KMU4uUqHWBW7fucOzYMRb1gsuvv05dz3nwwftJmfHjWgcoTp05w3g8QedUNWF65a7Y7fe9Y17+2TRiHt+BOjEGXFvz5JNf4MEHHxDJixV5qDUFg8GI4AXITCRc8Cjks2EPKw7kvHhreyuo9FubImkFUQygk1IkbalUoN28zl/6s3+Cop0wqCpGg2Fml+zKX+UhQGbbNNR1I+CGNZSl+K9pJewllUGsGCPeB+qmpqkbrAWtLf3BAG0KIoakNBFNSIrpdMGiaZn7SCgrbFmxPZ5iqz7j2QJT9oQxk6WyZSnSNAF1xdy6Y4qkzHDUsGTxloOBrFcQdki/kuPT1DVFBip7VUVlSvzcoSuDzybdRilwLaXR+OAZrA5ZO3wAHRLX37jOL37kV9iejCmOHGbl8CGOnTnL8eMnGA5HItcMgeRqtm/f5sZrl7lz+Q2eeNuj/K6v/waCa7l56yZeJVJmAVZlSduK51Mnf5QxRya4yMxJ5SPb29t85gu/yfMvPU/0DlzLQMF6VdAzilLL+hudKK2lMMKwKo2i0lAZxaDU9ErLaNBj0O9x4MBBbCkei4PRCoPRKqsbG7QhMVrbwKdE6wJVv4dzjrIU2XDrWnq9/vK6V3WTAVqBEd8hGSOyp1qeLEsZuE0JWucobEGM4uv1sY9/DO8cq6MVYox8zdd8Df1BT4DbPAZfvXqFS6+/zpnTp9ne3OTKlSvce+Fe7rv3Xj7zmc8wm04Z9HsQ4/JYuyBgfchM4aZt+cAHP8iBAwdJqmBne5vnnn2atm144IH7eenlixhjOHrsOBsHDlCUVQ6qqCDKJJla3tvIuCUMLC/3QMELazVE6qZhOp0SQ6B1PnvLicl5VVZ8x5/5z996Au+3/bbfvgLaPqi03/bbV0H71wOVBA1JdLKviGE39pcoEeiLlEjWoGPChAhtTTPZ5OSRdX7oT/9xftfv+AAHNwYEtyAF8ReoFwtSDCLZ0SKNgwxWpCQSib16CDrWjBIpTBfeAyQCSskNmTyx+zPkKN6uGKDqiUFqcIy37jDe2hSjcFMQ0URdcvP2JjN6/A//6Nd46dXXCCh00cPHDlyR79eKLKgQaGkPfkXqYtW1GJF2BYlLcmOllaIoSjEK9hGNJsgCIMkMrXIz6vmUZjFlfWXAh97/BN/9B7+TRx66wLFDqxADrm3woQYV6Pd6tHWDXnoZZNFexrE00BiJ1O4KcJXESHn5O4IlJZWI2u3uziT7vyuUQgykJKwiEkS/64kUczS4d14AqHzTu5fZ1D3fgQkpew6FLIOLCYxd4do48Ae+709Trh+jPxySkFn4xnmUj/SUwRCo3RSdAqVWwpTKAMzBlT7f/OH3MUxTynbM+uoahw4dlaJ7MqHOSUzGWoaDIYNBX1gSzlH1+ygtZqkqmyOjFL1+j5gUrm3p9XoggUhSVFQlZVnhgqcqe6QcCx28p9fvY5JIfpxWqN6Iu9tznJfEt7KUfhKiIsUCa+VcI/edbt8KO6krcMnnRmbq7PH5cc7nCOhW/D6ywWvrGq68/jr/41//a3zd135AknuyfM85T0qKP/K930vtEj7PGjd1vSzqdZbeWWslkSinuunsf4JSFFYYOjevX+eTn/g4J0+cIGVvEGMUEcVgZZ3H3vEuMR+2lqaumU0nfORf/kt2tjc5feoEqpPt+EBSiuMnTnHfAw+IT1UStpA2Gt+NSd04EgLetbz04gt88YtP8q53vgOVfXB0FNnQ+Qv30xsOKSrxfPGuZfPubX7q7/0kTzzxLg4dOEAKMh4ZW1A3Le957/sk2QhJiBMTXjlvTWYDKQWFLZjPZ2xt3uUjv/Iv+PCHvxbvHb2iQMVAwrBx+AgHDx/BBTFUb9uWup7zxSe/wKsvv8Tv+sZvoCpFdiQqNU2vP2RlbW3pvQWIBJFEkQ2NiYn5Ysbl1y9x7MhRYgq7wHFmqmlt+Y3f+DTvfd/7WVtbp64XfPzjH0OpyAP330dRaLwLkKTf33PvvQyGQ5qmJaS0NPaWq4PK43dexB5QqQN3OmlaU9d88cnfZGVlxGhluPTEWSwW9HsDTpw4TYqaXk5ZjHmMiSnmfiZM2beCRh3Tay+otHd9ur+V0oSUMKI1JSmFizCwELZv8t/9xR+idFNWBj36vUEu1gVMD16kcLPZHNcKK3AwGApL0YoUS0BfkZP6KHK4+VySMcuyZDAcCSM1KVrvcT6StMVWA7bGU67fukNCc+TYcSZ1y86ikeNsLMoWJGWwtiSSPYa0bJNBScqiFRmYGEQbkR+FsDTAjj6gy5KYjdGD98t+I1K4kE20DQYDUeFSoBqU1IsphVKs9foQIvc/+CDXN+/yG5//HF94+mmC96zfc5Z7HnsUu76GGQ7AWlaGIx576BEunDnPSy+8wOvXL6NjoGwDO5evcfE3v4Ba1Pyh7/xODhxY5/mLz2MqYfOkqCirEte26C5ZM6dbirRPAIztzW3euHqVZ55/lrvbmzRtg0qB1DaoxrHeL1jpVVRaY5Rss9UGozSl1ZQaSi1spZ6FQa9g0KtYX1tlOBqyuraB0oaqN6A/WkGXFWV/QDkYUJQiVw5J5K0qn5O9nngnFWWRU0XFp0/bcslUkr4l29A0zXIb5Roqx7bzmKrKgk9/+tPLBNX5bMrv/t3/FjHKvtDG8MlPfhJrC+7cuc1DD9xPIvHySy+zvrbG1tYWvaqHRqS2733f+2S5zuG9ZzqbcenS61y7fp3f/c3fzGAwJETxrRpvb/HSyy9x7dpVPvjBD/Klp56i1x/wvve/nxAl5U/6fRTPrhCkv+V7AgGyZeKjUJrkxfNNQHhha3XyeNkHJaD4wHd//3I/7bf9tt++cpr54R/+4R9+65P7bb/tt/9rtf/6x37urU9leOGtrYMd9vyZizVSIgafTaHBRE9YTHCTLU4fWuEP/d7fw3/yp/8Yf/r7/whPPHovowKUW6C9Q+uWFBs0Yr6cYhDsKEAIihA0IRhSAE0rvib5kVKAJGBGSp6UHAlPDE5mwbJJdAz5Odfimoa2rqkXC+p6QfSO4Bqm29ts3bnNfDqVYsF5mrqhbRpWRyuM1jZg9Qi//rGPUZQ9vFADRGonc+dv2UOd/G53l3WzxTHHrMcY0cjNukkaHSKpcWjvsMHj5mOanS0qFXjHQxf48Lsf4o/+4e/kz/7AH+NP/vv/Lr/vW7+Jc6cPMSgiKtQUylFoT1kkilIDYozamd12flAkTcqz4EmJH5VOoJX4rohcMUuD0vI3MHvZH7LF8n7ZWkVC8nAEsNO5eNx9mF02z95HTj7qihfxJ5EUne79NssGqv4Kn/3cl5jOW7TVdIEyRhkICqUMURuCtSRT4LUlFgPor+LtkDrAZDrh7ImjpNCwvrrGysqIpq6Fbr9YkIB+r0/VE4mYVkqMcxHWifee1rXLwlRS1HYNg3Vmf3RSFxBWgJjUS8GbsiSKjmGnwEfNoo3EpNHaYq2weGIAraxIsHQ2jF4yg2SWuwMp5eh0s8Ny3GIuuI0RU+1OelSWFd476nrB1cuXeO7ZZzhx7CgqCaNIIWCIVpqqKDh05Dg+BJFigix3z/fHLGfoCm8x1d6NT9+8e5cvffGLrIxGwqQBoncoskF2UXLk6HHI8tC6rtncvMuXvvQFelXJsN/LXmpK5KLA6toah48cQXdyH+maAjJ0/lJRZHZtU3Plyutsb21y4vhxSJHgHCkEvI+sb2yI31X2+WrqOdevX+Opp77EubNnsNqgkqTxqSy9OnHy5J6xMfcBcmpeXhcQYLapF7z++iWuXLnMubNnSCkQfEvynqQ0g8EQW1Yk1NKPbDoe89LFiywWc86dPUNpLSF4UgYRirKk1+/nftUtLwmjK0vOptMJFy++yMb6uqxpSrSulf3uhEn46c98hvvuv5+zZ88Dirt37/DMM0/T7/c5fOggCvFGE5AmsbW5xdGjR8XTRncC567JvpA12O0nXR8V9p3HOcfdu3e59sYbHD16BOdbnGtImalIgvX1dUhaotlDZjbk70pJltF9byKDiEoA/eXzSwApr0/3e36fILHyvSEBSlMZDe2M55/8LD0VKDSUWY7snGM+n7NY1NmIGIaDAcPhSFIi93iKeS/pXHVTs2hqvPMoZegPB/QHA5SxTNtI7RLzNjFrI9vThut3xyySweuKedSkYsB44UhFBaYEW6GKCh8AbcXTLR9v2S8dyJZAC9NVgMcMQHf/tEblz3RjksrANySck1THFMUzzxOhUITQUJWG44cPsTEccv36TX7xI7/KL37sY0y1YeUdj3D4Q+/n0KNvo11bYVFWqP6Aee34HR/6MB96/L3YxvPGK5e4MhvjtCYk6I2GnD1/Duc9H//Exzl05CDve+97uHv7Ft45fEg5qU6Yfx07LyVw3qGUpmlq7ty9w+uXL3P3zh2ClwkNlcRJLeY0QZWBWE1OWsxsQ6VECipATjc5Jddz19akLHNVGdinM+TPJtrGyD7WxgAyXmgtYQukhG+zZ5WWa2SIUb49g0mSwpn/RiTAwvCJoIQl1wE0Bw8cYDKZ0GZZ73PPPMNoOGQ0GhFD5NjR4xLg4FouX36dumk4cfIkKysjbt+6Sa9XSX9RiaPHji3HzLJXUfV6nD59hoceeQRyUmcIAVuIyfxwOGBnZ4dnn32Wc+fPM58vWF8/gC2ETRUyCzmFDNgG8U0UFq88p5VCq0KueaZAm4KmdSIXz2NhIh8bpTj72BPLc3i/7bf99pXT9t4h7Lf9tt/225sAkq7FGGiahsV8Qdu23L51izuXXubdF07zE//9j/CLP/0/8R/+0d/LOx8+xUovoGKNdy1tE2lbaOpE2yRm05rgkkhRnEMHkcuZUGPDHOMdvjGE1hIag280oVW4JuEaL1H2rcQ0O+fFsNQHWh9wLuJcxIdICHKjPJ8vmIzH3L52g7vXbnL3+k0m22NUEvZCYTTra0MOHVpFqYa6HnPt2jX6/R4pBWwGEPbuk12xWxL5HcJCkQI4S8GCw/uW4B3eO9rJlDiZwmyC39lk++rLbL/xAueOFPzff/838HM/+d/xuY/+FP/zj/4wf+nP/TH+7d/5OA+fP8CRNejbBZVu6JmIJUCMBOdlPzqNSSU6FRgKVDIkDzGKITFaoYymiJpe0FRRUwSNjaBTvoVWgaQdQbdE7VHJiAVwKlDJojCoZAR4ihodNSoadNorDREvheVNdP4pv4tHjt0DLJkMKC0BqOV7FcOeZ2gdH3j8MawPFKogBQ3JEIOYZQcFLgrTxmiRnUSliabE6QLKATfubDNZtBRVj8FgQNu2TKdTZrMZVVXRz2wj1zraRvwgdDZdbZpGigME3GmahpSSpNs5R0qJphGTbylh5eZaZmcFYHFNi0ZRL2oUivlsgQ+SsBaTQpuSmKTY8N5l2aD4KLH05ZD92hUsXcEsRRBLNCPESFGI8WtZiuFvl6DWtq2wFozBuxatoKoKelXJymjIaDgUr5TS8qUvPsmhw4coilIkKM4ti6qu8FJZ7lUUFpuNwI2WY+y848rVy8ymE8jAm/diEmytgIfBB5HDpMRsNsO1jvlsRtuIR01hDL2yXEqLpF/JzH3GUgAxPKYDeXNhnZJ4eklCYZvxBFkPYXCAc2KqnJIAwFobMVhOEu9dFQVVWTIcDGSfp0TKRvUC1sjZ3/2tjRHZKgJ4OOdZLOY41xC8FJY6JwaWhRSgdb3AOSeyshBonaNpGkAixMuyEBaCEt8YnQEkAdt3j4O1YuY+mUy4+OJFjh49ilJKgIHscWWthZT4+Cc+wblz57j33nszCygxmc3YGe8IqJlTJwVckMLXWM3W1iaj0Ui2by9ws4vdSHsLS0hl5uRsOuOjH/0ox48fk3CAnJQYY6AocqQ9CufkfOtA292v3WUndewwpfYawb257V3HmBmS8nFhXUrBKwCZ85KiWFUlxggw2dSNeM5Mp1hrWF0Z0e/3WVtbYzAYAJLyJuspoOhkvMOinpNSoiorhqMR/eGAlBKLRU3dNPhk2Vk4bm1P2Jw2bC4ca0dP4kzFVu2ht8LdhSNVA9ogkm2fNC6AyvH0TdPIdnkPQRIU0YaQJz/QhqgUjfMUZUVIAqDZQtgyKWZ/rCSS2Lpe0Gb2Vdu2cm2LARtaeipyz6njPHTvPbzw3NP81f/v/4d/9JFf5pZJPPyt/xZHv/4D9O+5lzRYZxEMqD6/53d9G9/zB/4Io/4Kv/6J3+B/+eiv8I9+9Z/zwu0rGCwETbQlbVng14acf887OP7o/Xzsyc/yd/7e3+XDX/chmsUMaw3j8Zi6Ee+tDlwhg2ghBmbzObO6Zmc2wceARVMkjVUGpQzJGOqYuDtdMGma5djdOpfvGSIRTdIFUVlchMYFmlaS+Bb1gs3NTRbzuYBKMTIZ79DUC7xrmE2nNE2Na+V6IP5nMj4VWUYNidlsStMsdqXKKrNqoySnpmUfl3JMZSaq3HYI6NTr9Xjs7W/n5IkTxBhZWV3lk5/8JJ/+9KfzZ2F9fY13Pf44J06coG0bbt64IQETSlH1esLwAvqDPknlsdk5tNa03uFDTiAkyfijNV966kv87M/+Q6bTKRsbB3jmmed45OG30e8PcE785oiJkP0BUwhEHyiMFelliGgUwQfm9RxtIcSGup2RVAAd8alBmYiyEZ9qkhIAd7/tt/32ldf2mUr7bb99FbT/6sf+iRREMh+E6mqAjvmQongbyW0bKkeGg8yWVVbT05G02OLckVW+81u/gf/mh3+I7/ue38eD957CpoZKBwgNhVGQZ69UlrY510oxkORGI3hHyiye4AR48ZmOHbMHRIghF9uBJhdhrm3FD6Btca3HNS3BeWGgzBcs5nMWiwWzyYTpeMJ4a5vZZMr47l1u3bjO5p07zOZzNJph1ZdZzRAZT+bc3R4TyiE//nP/gp3xFFtWIivKBVQip85p+T2iCEpmRVVmSqiUMEChFIVSVFoR2xozu8PRFcu7H72f3/mhJ/ihP/V9/Ed/4t/je//Q7+V3ft17OXPyIP0iUtmAji1WCRtII3QuMUqXY9lJvGSlOgkUKC03b93sqhS5UmCJE03+grcWg7lD5NousxFysS5dZA+Qlj+w++bdX7XsB0kTEmBJm1zMZ0aP7kCm7vXMsNJGAJ3OAyYkmMxrPvnZLxLtgJRNX3WWpCSdUFZ6czcTbWwp+0YrLBGbPDubd3jwgQcpS01ZaMaTCT6b0qKkn/vgaHO/a1pHTCLPhJSlN1JAxux/Ya0lhpxolws7+X3X0wTEsF0YPcL6iSRCSoh1uswIK5VAKwpbdTllAoIYiUdPnRm1koJ6t3jZBcCWDLWYpAjJ5ttamyUbJKXIdDbh1q1bXHzxec6eOSMgTJYvyDbILPmtO7c5f/6sMAQ6ZkhmQCmd2SEIcCE+O5kxlSJ3b9/iC5/7HAc21gRAipnhmLfFe48tSo6fOEnrHNpafAiMJ2NeevEFRoMeq6srAEuPjpRgbW2NQ4cOo7XImETulzC5z3XgXvCShHfrxk22tzY5ffLUEoRIKeFjZLS6Sn84yoyFiGtb7ty+zXPPPsuF8+cZ9PpLllhnUH/mzNk3+eV06XhyLuXlZwBwNp1w88YNrr3xBvdeuCfLhkXm6ZynqHqMVtYgm6C7LH+7dOk1mrrmvnvvpSrLXEQLKKS0odfro7TBWAGxjNZEL2PiSy++yOrKkH5VZvZSLr5TomkdX3jyixw/cYqHHn6E/mBIUtB6x87ONq+88hIba2scPnJ4uf9k/JB9O51NOXT40K4HTO4PXSqenPh5DJQSOTMuPHU954UXnqMsLYcPHsBnoFblMcvnBLSNAweJMUkMehKvq9SxR7LPTkaGdo+37gafPFCRul/o/pJzXAvcn73ijDVZtqTQ0aHcnM/8+kcY37pFaD0Kgy1EBqeSgMrWCPjVyZ3qtmVnOqVZzFApMRgMqHo9lC1oY8IlhcMSdcncR7ZmLbdmjlkbiUUPO1hh5iN3xzNqnyj7Q0mjs6XsB1vmtD/x4JGtkmI/hIB3DmONALxJ9rrKjFGAwgrALLtI+pB3DbYQFiN5jDDaUBgDIRCDI/qWE0ePsDFaoXENT37h8/zsP/xpLr/2KqSE15rjDz9EceYMd6sSbyqsqfjw1/0OqrLP0888yyuvvMq1mzfR1rCoFyLTNAZjSoyxaG3EbB5IxnDo8BG5Bm/tcPPaDb7j27+dG3duEKNHJ4g+5qAEAch8EEZSvViwvbXNzniHeiH3Bwlhx8kYLBMrSSlql9mfSud7GrCQvQulGwVyql4+7yIZTA8eTaQqNDEI45IkwSQqhwwUxopPUk7fTDm9LUXxh1KwTK2M2derC/Mw2bC+G0NSEmBXrvl5/E1y37a2tsbhw4eZTWeUVcl0OuGlly4SU+TgwQNcfPFFXn31FUbDFeazGcPhkOlkIgmlIWLLihMnT2VWkFw7hQ0pzEutDVtbW7zw3LN84fOfZ/PuXU6fOom1hTCIy4rjx47J+YCYfpuczBuCMNBVPie1lgmTEANaC/gUvRewLUWsETBfrqW7LK4YA/e842uW5/F+22/77Sun7TOV9tt++ypoAnXkgjDJzTXkm/Y8I611IkVHYSC4FqMktr4C5pu3eccDZ/mx//6/4qP/9Cf57/7zH+CJR04xqhyp3UHHBkKLAZIPYuDsW5yvxfsnBnwrM/exSwrLunsXvCTp+ECIgcVixqKeMp3sMJ9Nmc+mLBZzmloMT6fjKfWiYT6ZMtvZYbqzg8uzxdPJhJs3rnPr5k2uXLrMdGfMzp1Ntu7cZrqzze3bt7hx/QZXL1/m0iuvcePqda5dvcnNW9u09Pjlj36S19+4jt4jfVOAzWyEjrkgrAsDUfanSQmbAtrVqHrK1uWX8Ds3+fATb+Mv/sf/AZ/+lX/EFz728/yDv/3/4i/+0PfxNY/fzz0nDzAqE/g5oZ4S2gW+qdF5prKrl1AiM4td8aDl92UBlfGemG9qya8o5MZXIya1UUPQEJU8lsniCEiw/LcEilKmM8nPpKIEFWX2kwBGAgh1KWg6I1/ipSDSKHlI6pO1Bms1NrNcbGEpCom4LstCIrirEbYyXLjvNBsHRrlw7VgSYsSsVBT/J2UIKJIWaYcBTAoE15J0wY3tmk8/d5mtJnFre4vauSxpE2inrhfZ6yQyXcyJKTKfT2mzPKduxBdF/LmkUMhCDKKXFLSUIs2iJsXIYjanyEWCtRbnHAoliXgZpLJaYQiUBbI92tK6iLUV6IQtLE3bLs2gtel8bIQV4/ONeYhRCpIcZ+1jQGX5RUJmr421tK4Vw+fMq0NLbHtnQO+WyX4CXr36yovcuH6FtpmJZNJko9lsnq209BFr5PeQk8amkzGvXHyRQwc20CnRNovs/SVMwrr1tM7hg0MpYVbFJCwMYUTJ/hCmX46aTknAZ++lmFueE7tm6SKVy15maNq2xXvxBQpeZs6D97go+yhkuYvWUlzGEIkhQVSkKOBcyOlewXtImUmQWTzWiNeWQs5N7z1kYI4cEe7z52KUAtg5T4jiVSUMKznnNLIfY5TtFOBOJHc6s6tSkgJNwEwB6cqiwGUG2gvPPcfhgwdYXx2JCXEeC+q6ISb41Gc+y8raAR59+ztZXT+AC4G6aeQ8QIBEn2VoIGyoIi8rxkDwjie/8JtYI5I4hQAtKSWRkWmdk62kaBZoM+Jcw2Ix4+6dW5w8cSzLlAO+9eLbFCBFGXN0BqaSzn08CAjbyeDIMjMBkkBbQ8j9FSXHJ1/RQAlzT8ZKSUXTWhEJGCu+YLLaikjEB8etW7fQ2rK2dojBcA1jCupFi3ddkSxsxbt373Drzm3mTUPZ77OyusbKyioJTe0iLhlaLDOvuTFe8NzrN3jp2hbXJy29A8cYB8XtyYKbO1O8sqiihyl64u0Xsj8aYrquSBiFTCoEh0pRDKeNFukRAm7EIH5rKiWCdxitCM5hMt7XuhYXHMbKuWGMoVf1xDfMiz+fVpETxw7x7scf49lnvsjf+rG/xT/4mX/Ak089CUqcxFTwFMZw6dnnGS9afDmgv7LOt37Lt9G6yKUrb7A9mfHK1au0SjEPkagtKTNdRQol160QFVFXBNtHj9Y58/CjHDx7D6/euM2//yf/JF//9R9kNtsREAyJqK/rhuAjRVHiXEApQ9s0cn3L0mKMXJtUZispVZBUQdQl2y6x1QRmPuETeO9o6pq2Ed84l6BVmkXSjNvEztwxXTRs7+yws3mHnc1bRFfjFjP8Ys50e4d6PKGdTsC1WCVpZ8ZaMcHOY9XO9g4xBJrFguC9mPYnmVhDCftMLyVyQUzfQVjSGbSPSfqfzt5Ljz72GGfOnmM0WmFlZcSXvvQkf+Wv/Bf0ehUP3H8/zrVUZUVpC0bDEVZbbFFhyx6Xr17DFhVN69FGUgfLsqJtWn7q7/8Un/zEb3D21GmGvR6jfj+fr54D6xu8+4nHmYx3KK0mNDUpOHxb5+tyN3kQaX1L3TY57VGM/0WMD/V8DjHR1g2DXh+rDYSIb534POZTfr/tt/32ldf2mUr7bb99FbQf+dv/NBdBGSTIvgM+JlKe+Y0pYrUiuYZSR/x8mxMHh7z37Q/wF37oT/K93/X7ePDCaaxJpOixe0CEJSMihhwVL/Hyzrk8Y9exj6SAcW1L27a41smNSEyZmi4eNjKDLUWND1nyluNp21beUy9q8T4JgWZR471jvpjR1g2+bWkXcybjMePxmJ3pDuPplCbfuOgUSMnJTbdSuGLIS9fu8LP//GO4ckNueqPGO/F8Si5SJANNxCRNqh26cRRNjRtvM1SBM4fXeNfD5/m93/IN/Pkf/H5+4Pv+AL/3W76W973rPtaHPSnys89AVZVoBUUhkcFVKWlDSyDpyzQBfPa8ofPM2CNB6x5vbV/mqd+2dbOlXetYSlJIS1G3u4w9nh654peXpNoTcAp0TqYSnwV5dEVzBzjpzFKKOWlOmYpf+bVPM21zIqASbyeUkSQnJaCZyfR/KfM1URmUKXFREXTBGzc3ObjaZ6UyxNBSGJXnoSGlfHzztsQk0cwZMqAjSMgMs4BCPkjfzm8hRbmZ1kq2pytoY5bZ0El6gCInCrkQcdmE2jsBoEL2KmqahqIoxNNnzzE1+buU1jjnliBDx44qikJAkOy50gETHVPJuZbbt29z8YXnOXXyRGbwyDYsl5N9Wba3d3j3u9+bfS/I0owMSudjqpRagoJt23DzxnWuXH6Nfq+/lE+FnCYGCudFIlFVFcdOnCAmRVIG5xyT8Q4vX3yR4aDHxvqGgFd5vUCztr7GkSPHMvAloKr0Rkmk83k/xBBom4ZbN28w3t7ixInjAkx1bKkE6xsH6Q+GGJsBwaZha/MuLzz/PPecP8eg18vj4a530okTJ1FG+mCIkh4mr2UpWu5MWmsW8zm3b97i5s0bXLhwDzofu5QN6/uDEYPRirAoksh068Wcy5cv4X3gwj3nsdbIeBlkhystJtZdf5LlRl584XlGo4F4psSA8yJ7kxNC8dzzL7C6ssbjjz/BYDRasiHIUrLtrW1efvkl1tfWOHrkiKxj9tLqjp/WGqXFC2o4HAnjwYhEc+85IKw3uRYoBfPFnM999jMc2DhAWZSkpXeNsBGC9+JHozQHDmamUmZoxSS+b6ZLCEwCLMg5mtm2uY+8tSXEwwVk/+q8nw1ipmSUAHWJRGkTOtRcuvgMhY4sFgvQiZCEgZFSoGmEARuCp6p6rIxW6PeGlNrgkqZNhqAKFh7Gi5bb2zO2JjXTNmD7KwxXD7A9W7A9naNMQdnrE5KwkYy1wl6MYgrvvJcJDAQIk3wIGZ3kPOpkYHlD0ZDHa1G/ZSlmNzGQgThbFCww9KoByitU67EKDh7a4PDRA9RuxjPPfpFf/qX/hdcvv4a3hpg8SQuDxsqux+uC1F/l4H2PkKp1VFLcvnWDFy6+gMuMYzHtB6sVq8MhBrB5hbpxJg/YqHzvobViY2ODRKKylpe/9BTf9u3/NzZ3xsxq8b8rbQEx4pqGulmw8C2T6YR6PqeuFyLv63aXIg9SeTcpSf4LXu5NJBVV9g9AzOdTN86qJaAqjFXnHTEmfEigLdoWwq4ObnmudJI32TwZR1OKDAZ9GWvz5EAn85Rtl75MvkZIH88SzY5xnMc1lWXIJgdArK6usrGxwXwxp6r6nDh+gjfeuMYbV9/gxPETVL0e1lrG4wloSaarqorJZIeXLl7k3NmzFNZy9fJlPvOZT/PFJ7/AcNBnNBpy++YN2RfWcvT4MY4fO8HNmzd56ktPcfjwYfr9vlyn8zlt8hjRXaPI3bN7jezj1Y2ZIV8/g5ek05i9AfNB4Z53fWD5Pfttv+23r5y2z1Tab/vtq6DpFPJlXhExeG3xyoKWJCe3mBLnO4TZJnffeInTB3r8t3/xz/DLP/Nj/LX/5w/x9e+6n/XCYcKc0IoPw3Q2Yz6f0zatyIXkTh2fgSTvnRQQWcLWmVYLxVn8BEKMtE1L0zaSgrSoaduWpl4QvKNezJnPRNLm2pbFfI53LbPJGNc2jMdjppMddsbbTMdjZuMx9XyWX6+ZTbZJoWXR1rgs72nqBfV8hvctjoDXmtgf8dP/7CMsGIAq0LrIpuFQkugRKMOCIQ1p5ybbl15kTU34Q//2B/gffuSH+Gf/4K/ziz/zt/g7f+2/5N//7m/nXQ+e5fhan35y9FILoSX4hrZd4NuaejFFEUnBi7G4y6bjmcXw1tYV8rt/Z4Dn/4iWlv8twaUMXy0LATKYpTOwqJagkYBDAhiJ15GAZR3Y9eVApQ5Qkr/7vR7WaDbW13jooXuJwUmRqLUwkvJPlFn628g3C/soBk9IiaA0bdQ4XfAvP/55rm05Gt1n7gONF7AkRtBK0o68FwaNyYyLEMT7p23FdyJkz6TpdEYi0TYZ3GxqSB07S4uhatMIqGPkc71+X74vF8cxBgHrkshxfGY9kVlxUmhlICIEyL5JKjNjRB4hxXcHMLVNI5LC/LmyLKWIz9/VHduU/UmkwM9sxa5PZanMfDrjmaefYm1lRGE11opUDCXbmXIhFmNkPp8xn834/Oc+l8Exj3OS2lSV1XLfkc2v66YWAC7PzpOBmd11kGQgW1hsYfO6d2a50udT3o7ueZ0lUrErFve2Pd4k0J1Hu9uusyxFGFgdkCLsTXJhhMomJ0oKdiFIiaxNZ0agQsBH5zwue6mFIBJe5xwhg+wC8nVglCyvQwFiipnNKcVvB8p750lBEhK1UrRNwwvPP8+gX7EyGuZ97jJwAzEkLl58maZuefyJd9MfDGVs9n7Zp3QGKZLszOU6FWVBiMJsE0BJzu/XX7/E+sY6tsgm4nk87YYmpeVYduP+tatvMJ1MGQwGy7G/63fSz3ZBEjlumXGSjeNjNvpWXZJiDBgj/joqyz2/XFP5mAlbT/qFQmGUwSRQIWKVFr8XJZ5f83rBZDZDlxZ0IoaGyXSL8XQHpRXrBzYYrazRH4zQpkRh0LbHIpXsxILXN6e8fG2T126PmQTD+omzeDvk+uaMG9tzvOlTDdcwtgJtQVl8QtIstUhdlUooUvYpk/N9CSznYlyAWQghkZLIG0MGLHxmj6l8jnYy5KosUCGwTmJAwOqWex44xYUHznDxxWf4u//T3+QX/snP8+wzz1NHTTCW5GoB65uE1ZZaGepejzgacOqDX0O5cRCjJFnyxp1b+BRpvSMoMKWwqARczwBgd55351OmyUYUTitaa5loxaH77+PEQw8zmTv+8l/5Ed75+OOMVldpXL30KWzbJvvHyRhX9Xr0epLumqIkv4q8WkAakz33krZErWkijNvAPCZabXBa44jCZAzCpEZLOtrCeSYLx7SJbM0a7uxM2NreZjLewWrQMTCfjKlnE27fvIZvFqjoaesZVWXFZy54PHKdmM/n2D3yVZ2NvqV/y/4KGUBqm4aQJ+B0x140RiwAMhuyLCve9sijPPTQwwwGI44cOcqjjz3GpdcvMZnsYIwwhr13GKXoFyVnTpwCH/h7P/4T/OOf+Yd86jc+yaCsOHr4CKujFQwK7zxr6+u8573vYTgY8Gu//mtMZzMOHDjA4cOHxSMsg6xVWQqglBmGbb4eSegGtG0LWUrcXatEnilpeW3bCrj2lmvBfttv++0rr+2DSvttv30VNE2QSFmEmZSyV0dZaPo2sVoGHjp9iO/4pg/wT3/67/KTf+P/zXd80wfppxmln2DdmCLV6NhCFCBEEtyyF0v2eWjbFud9Nqhu8dkcs2kENPJO0o7khh8phrwYJTdNjXMti8WMuq4Z72yLGeZ8Qb2YM5tOmYx3mOyM2drcZGdnm7peMN4ZM9nZZntri/lkynS8w87mXeazKUolXNtQFkU2jUzYXDzaqodHQzXgl3/149zZmeM8KC/m4cNSYcOMkWk50I88cGaDr3//Q/yn/9H38pmP/Ty/9E/+Dj/4p/4I3/a73889p9YpmOEX2xTJY1OiNAWlrQhNyilYAYVHq0RhdJbtsJTnpDyr3hX3ex8dbNKBMv9Hto6Z9Fvakg3U1cC767aXgaQyYCRAk/izmM6Uew+AJADU3r8zIJLlN73S8s63P0JTTzKEoYhdEp8yJGWJ2gq4hLgRaQKlAauipJsR0Bqc6fPLv/FFrm23hGJIEzVtEO8W51rats7og0S8CygaREqWEvO5eHbMF3OMMZIe17Hl8vFom5ZFvaAoCmEMpETwAgi5tqXX6wmgmmLeVmHwqFw0ilGzeGYtQYe8j7qC3DlHWZboznhaawprRW6VC2gBAgTIiTEKoNWBZEn8VLrj9KYb+MwEU1lV9NlPf4b5bJoRnC7NR/qHTCqLj5hWikuXXqPKSUJKIYl6iSx3C9k3S5hoKnt9detncgS6yfuMzDARWZoAQcvlZpPkbt1TNhyO2ddK5XS6EAI+/+wALelbu8sV+EKaLFWOo8zA7wItwnDKXmpRQEuSyDClz4kvC0kkbDK6pt9SIMWcqBdiBvgz2KVQWV6Zz6fMhiKzFwQA0hijKAoBD19//RLGaMrSsqjnyzj5BMQEl69cpWkdH/jAh+j1BhhjBWjI/U76TrcP3/wI3i8TtwTY8jRtQ9M0PPv00wL45dQwlftABzCl7OMzn814+eWXuHDhgoCQb+pmu+PG7nGUN6SMKnnvlv1bKbX0ehLz9T3eTl+mLZeV5Fzqfg+5L5H7kFkyQOQ6NJ/P2dzcYmt7m9l8ji0KVtbWqQZD2qTwytJi8bpkFhTXN8dc35lz6eY2tyYNZrTB8OAxpl7x0uXrzFxC90dQDqAY0PpE1JaIBmVAyyNlw3hSkjj6KGNGShFrxchd53PT5+vE7rGSscR7jzFSqIfgBWDP6am+bSgMHBhVHNkY0isin/zER/jxH/+b/OZvfgofBLxIPtHMWg6sHmB9bU1sFk1FqNbgyBn673w3p77lW+H4McYp0roGHz0uRpEiisEZrfckkOt8QihUShh/y/MhASiRhEaoQyRVPaYJeoePcOS++1k/foK//jf+Fg8+8ADnz55Fiw85KGHCFcpQFSWj0Yj19XVW19bo9YWdozLrZ/c6pNC6QNseqihxSjN1nrFzzIKnzVJOHyKt97iQwJZ4DG3SLDzMmsD2eMbd7W3u3rnDztYmbTPHtwvm0zHJtyxmY3a27mI0TMdjOS/IvmBIOIiM93Isgw9iZJ2B5s6s2+V9KM9lpp3WuFZYTgKUdQxbDUnx4EMPce7ceSKJM2fP8s53vpMbN2/kZAExlC+KgmeeeYbDhw/zrscfZ21tjaNHj9JkAGs4GHD+/Hm+9uu+lkcfe5QYE6++9hqHDx2Wcb3fA6Uo8jXIB797vcrnZHc9ChkMB5loVBk0d63cJ2qd2bdKURaFMMPyBMp+22/77Suz7YNK+22/fRW0HLKLIqJTwCSH9nN2bl7mwvEN/upf/k/4uZ/8H/mrf+nP8YF3PsSpgwOGRaRnIjq1RF+jooPoIIpxZQxOwCPX4vONQtM0hAwSeedzSpujaRa0TY3zwmrqzCpl5rGmrhcs6jl1PWdrc5PZdMJ8NmO8vcPm3TtMxmN2treYTsZsb20yn82YjMfcunmD7a1Ntjc3uXXjOrdv3WBr8y5NU7O1tcl4PAYS0QdKo4m+heSxZYmyfYbrR7n4ylV+4Rf/BUZpYjtlcfcqO68+y6pt+FPf9138tf/mP+OXf/4n+Pmf/hv89b/6F/jjf/Q7eODcGieP9lldMZSFZzS0WJsoSyMJR9qQMISkcUHjfYvRkcIoUvQYLQWpGFvmgjaJjOS3a7ne/P9fS8v/dtseYIlcIIoE8q2A0t6/BVSy1mJtsfuzkAQ48V0QjyVjDNooelWJVYn3v/udzKebCFlFi9FqLkjBEJEiLWXzVUnq8qjoib6B4NBEvKnYDiUf/ezTbNWaVI6Yu0Dd1LRugRUjGupFDcjsqiQjyc8OBAhe5FUi5exmtoVRUDc189lcJG5KDHbrWtKLQgaFyqoUn58YaVvxyCB77/R6vSVjyS4BFpFLdABcV2CEEESqkxlMIIlDMbOSYozi97Q0f90t+lFd6lln8ivLUXJAMVoTvGfQ7/Hk5z/P+upK9jQSICZzQIBE8C3j7W3euHKZtdWVDC57YadphdF5Bj53I50N2juwTef0MxR4L8CKzklyttjtI0pQJdIyTr0DCKQgU3v2jVLCrlkCtG+RXOrsSeaceCEt91mWxwkoKCBnWZYUS0aNFPcmA8JLAEmRzxMp4lMujrz3GeCSfR+z7EuOg+xJ2Yt7zrEk4JNgVJm1kH2rlFYE77h8+XWaxUJYZIWlyMBDiJGY4OVXX+WN6zd4/In3sLq6htYiKe3kYynLfLyXQrZb++53nxMIRWoqfmCyPxS3bt2kbWqMycBQ3GWvyRgmYOBrr73GYNBbSjJF9rsLIoXMwiIvdwk25LXRxhCzL1la+orlfpoL790+8NbWfZcAgyCpW0kpAhAUKCPMHwECE9euXZdz15aMhquMVtZRpqLxiYWHVpX4cshWHXjp2m2eu3ydy5sT5lEzPHCEqYdb4xm3d2ZEU6KqPl5ZdNEjaSuS1yjAReMjyhaEgDCv9hhrxyBS8CQ9TgCmJR1Txt2Q+4cYkgnoaYwwrrSW0dloRfAi9T135hQXzp/lytVL/MRP/Bg//49/huef/hLzyTZFoSgqiy4MZVVh0exsjQm2IhZ9Dtz3CPd+6Hfy0Dd9K6uPvIPJYIV5VbEgkJQnqYgpCkxRCoib/X+S+DLnUUWB0oQ3efjtKvEVEjPvAiRT4sqK8sQxTj/yNrwx/M2/+bc4fvQox48dRamED5m9V9cUmdm6urrK2toao+GIfq+f+1rHHlXiG1T1iErjk8JrzSIkxk1g3DgWIeFQhKTwERatk+NW9KgDzF3k7nhK7SM70zmbOzvcvn2bra1NUgqQPPPphHYxp55NWUwmlNZQL+Yi3c+Mwy5RVClJbuzYvQro9XoCLmVAW+XgAbXnoh+ChEZ0DMaqrMQ7LSZ+9h/+LLdv3+aeey5w4d57efKLX2R7ezuPeQoU9AYDtsdjXr9ymVu3b3Puwj2cPX+OBx56iHe/5z2cu+cerrxxlR//yZ/gR3/0R/mJn/hxXnvtNbSRUIHjx4/n65usb9diTkytqhJbiJm8MQYyy9BYYcRrJcB+9x6lRTZYN81yEuq3Y2vvt/223/7P3/Y9lfbbfvsqaP/lj/2cGGWGllhPOLJa8cQjF/h//Mnv409/3/fwtnuOMzQeE2oKFVGxJbqWED1RJWKe9Q1ZghGCSC1il1pCZ3jr8b5jerglgynmxBYBm3ZT3GKIpCAJTK51tHVDDIGmqZlOpyzmM2Ex1TWLxYK6WdC6lqapqReLbLa5kN+zEbhrnUQuA8ZKApXFomNCqyi5bUWPVAy5eOkG//h/+RWOHj/JyRNHefShC3zvv/Nt/PBf+LP8sT/8+3nvOx7gvrNH6KkGExeY1KJijdFBKPWUpATeiUmwlJaZM6CRWVWbsAbhZ6T8vj2FlKKTmGRdzZdpb2ICSUnBXiCne/AW0Kdr/1vAqLcW5Bl2kGUoWcpuode9Z89n98jjZFOlVNptu9/bvdcYTcpeSVpbRuvr/OonPsv23BORhB1rZfY5pl1OSIdaKKVF0pkSSpulnKhVliYK0+TG1ascPrDOsF9CcpBatBbGmFWW1rtl4RqyFAGEqi/rKEl0ZMlb9z5jJJkrCmKwp/hNAoQgRaSyFh8TPgoTiZy2FffI2wQcyTPUxuzZvt337QWZ9v4kgzckkW01TQMpEYLn9q1bvHzxRc6dPYM1ZulzobPETCkxtwaw1rC9vcP5c2cFsMqz5THLNFKMzKdjvviFJ/GupSwsirQskK2VpKfEbl+PGVy7cN/9KCPyW+cc0/GY1155iZXRgI31dRTZPwsBm1ZWVjh48BDairl3yvuCJIAS+Xxqm4a6XnDrxg22t7Y4duxoBrA7Bhisrq0zHK4sJYneO3a2tnjp4kXuOX+eXiVFkzE6Myk9R48epSolnrtjjRilSNmDKwb5Kc8lnBMw8vDhQ5iOERQToOj1Bxw6fDSn/UnfWSzmvPHGVRbz+dKHSTx6ZbtsYSnLkuvXr7Ozs8362qqsWzsXNlcShtXVa2+wvT3mfe//GjYOHKQoK3wI+fhlmV0SDxNITCZjXn31FTY21jl65GhmYGW5EMLk01pTFmVmF2gWiwXHjx2XcZ20ZDz5HCd+8+YNvvTFJzl79kxmoQk3TWuT5S8i/0E81knAgQOHQGmKsiAt4+Ple/cOXssxZ8/50B2TlM81/aZzIX9CKbzqTloyPKowKuDnE1548guS1mkqfEh4NC6ImXRLweas5cb2jJs7C1pbYVfW2Wk8iwCzukUXJcoWoG0GvrWMTRk8XM4IZMaOysCuykU2+dxKUYzxXXAUhYDTIl+V71JZaqkzsGmtJkUxfk4poEkUVtHvVQwHfcbjbZ595mk+9usf4+XXLmGKAmssRmsKa0QuawxocDGgrMGuraOOnuLEE++nf/8D1AcPs2UrfNkDXZKCAFq5O+f7AjHGT0sZozDWhlWPflmCD8TM1mGZnKZyjIQgUCppVBQfqYUOFL2KQb/PdGfMs196iocffJDDhw5z7epVjNLoFCWAIAPJHQiqFEtAmT19Ap3HDgXkcTekgChm5TuWxyxLC32MoDXaCvgnfTARoqd1EuBgrcYu/QAD/X5f7n1ixNoi+w9FAdoTWGN3AeUoaZ7BiReanO8RlIwp3RgfMpOJPF50Y3aIEVNYyqrHqVOnefaZZ3ju+ed48cUXqXoVo+yjFkJgdWODM+fOceLUSYajFUKKjCcTmrbh5u1bvPDii7zy2quEGDi4cYDDhw+xvr7OysoKMUaOHz/O2bNnZbzNe6K7XhljhOGY2bS6Y4Xme0SlhCVJd0rKp4lBWOvd/Y1zYqNw37s/tNzf+22/7bevnLYPKu23/fZV0P7y3/xZkqtpd27zTV/zTv6b//zP8F3f/k3ce/IAFQ2VigTXEoKTBLcklPaQZDI6xF1ZSIwBQpAbyyigUAgB51qca+UGMceHN02DQrGzvY1rG2bTKTvbW8ymM5rFAtfUTKcTnBOpnDWa4DyLxZy6rokx0LYCKsWYDb5rkdIF55jPpgTvxQ8HRdt0s9+gbPaZQKGjxErf3b6LT5HeyhqzNtFfPcTv+uZv5Tt/33fwnd/xe/j6DzzOOx4+x2rfMKo0pQoUOmKXvikasCgsKmmpTvINYgdxaJWk2FQRoxMJobjL3eyb7qoyiLTn79+mdQaee5sIZwT4SVJR7bnhe3PbU5f9azS5QSfvzzcDQl++deCGNCniu+flu7ob/e45eb4rAFQuDlXMxp5FwaVrt3n+5csElVkLRPGaT3JjqlOWeigF2hCVFbNuW5CEP4I1GkugR8RNtphv3eaBe88S/AJjkCQ3U+B9FE+ZLJWRfu1lBtbkVDalqaoKMnjTyeVS9oepqgpblNTZcFsbg3eO/mDQ9RBcjPgQSZm547JPUtM09LJRNHmWN0Yp7kOWipGlVDYbtsYM4CwWC4wxNFnmEHOiV9WrCEHOkTu3bvPyxRc5c/pULr4E6IohcuL4cRaLhUjzjBQF3ntevfQa9z9wP8HJspTSeC9+UzffeINXXnmJtdVVYvD08n4JITAej0md2XIGwowS1sj58/dgihIXZIZ7srPDq6+8zLBfMRqJ/0/Xl5zzjEYrHDp8BGUMIYNKoNBKzr22bYWxFRPz+YybN26ws73FiePHURkgstaC0qyurdMfDNA5xc07z/b2Jhcvvsg958/TzxIkYwQESSoxm80ZTybcvXuX7c1NtrdFfnv3zi22N7fY2dlmMpkwmUwIwbOyssLxo8eoF3O0FtmaQore4WiFg4eOiIwzs9/qesHVq1eoFzUP3HcfRu/uMzKwMJ8vuP7GNdZW1yTdDpHVhiDJcm9cv8HlK1f48Id/BxsHDqIyAClSNTk9dk2cFT4Gxjs7vPbqq6ytrXL82FEBzLQAoLYQM+LWtfjgMdYSY2I2m+GDZ31jnaZ1hMwsiMGzqBd89tOf5sgRMfMlRUkJVJqU4KmnnuLEyROS/GiMmNWjOHjoEFpriqIUULYDJjJgqHKR2o0Tyw1CgOIOWDRaWGzdNotXUQacstdYN/agNCk4dHB89jc+Tjtb0LQRU/bR5QCvCm5uT3nj7g4zr1CDFUJRcf3uDvMAujfI4sf8XRkclqazR1IGOJZjo3gKDgb97MkmgFFhxccqQ1CZGabxIQoIkUFAlXbZrR2oFLzDuZrCaI4cOsDG+hq3b93gV/7Fv+DSa69y585tvGtRUUyn+8MhvdEKyRTUUTEL4DzEjQ2Ov/sJDr3jcVbuf4zZYEQzGDJDEQsjKXDLSQstibKqu+7tEqpk3I8YYFhVDMpSQK88/qukEBHs7vsV8pzuvqOQdL9ef8ChI4fZvLvJM198igvnzvPeJ97Nc88/i6ksYcnqkrHKGEkS3Q1UkOCQDrhLyESAMXb3cyHSNCn38RKlBQhNSuR5KacvyiHI9z/yJCFPgCWg3xPwaDKeUJaVTCBkQKhXVZRlRcygi/RTAZTkXM57IkqQQYgZCNszYRGjXOM6SWcH2vsgfWg4HHLmzGmaumHQ78kyAFAcPnyY+x54gKTEw29tY43Dhw9z4uRx1jfWOXToICdPneTUqZMcO3aME8eOcvLESY4dP8ahw0c4ffoMx48fJ+ZAiJTZgzGKDNgYYZaGEBgMBtQLYfn2+31CnuBTZJYnMu5pYwgx0NQ1IYrfklw/e1zYN+reb/vtK7Ltg0r7bb99FbQf+dG/x4FhwQ/80e/mP/7+P8yJ9R5VaqmMJLt09b5QryMh7HnE7ncpJKMPpFxsey+PELz4JTkvM/zZlDEEAYVi8DR1zXQyYevuXW7duMHm3btsbW4xGY+ZTaf4ts2m3HOaWoCk+WxO24re37cO73ZjgJu6JjiH917ilIP4S8QEGPGrUMbiEswWDePZFIymPxxy8PhJ7n3wEc5euI+Tp09xYG1Az0RW+xZroF9aVPJYDSJkyzdDykASk2itwOjsrSIkIXRGO5b5YbmA0bxZEtYVi5ATfpY3629+z/KR/5GPU/duuVeWYkuKlrcUXrl9maf+Fdvem//f2mS5b36um0Xd+8jvXv7s1nF3X3SFntxsWp2p84UUdp/5wnP4ZElEAeuUluQ3DTpFdPbZ6FK5lFJE3zIoDZaAdnMODiwn1ge852338fu//Xdz4exx5tPtzMAQfyMQP5vOY6IsKyl6lBQQpitWM8DTtA3ee6rslWGtMEpClDQbleVaRVnKdpUFLkZckBlwELq/zgVKkVPfluBRBhZU3q4OsNNKGHjGSuHCssjQy3XU2Si1bmRG3bmGW7du8WJOf0vZ0LbztxqtrPDKyy+zsroq5272/nE5kfHI0SNZMiUdqq4XPPn5z9Hv9UgxUJUit+vW/yO/+qucO3cPVVXtAo1JQN4L9963PD9DCEzHY1595SIrwwEHDhxYHkMBSRVr6+scPHhIQKUMFC/75p7+472nXiy4c/sWk50dTp06tTSAz2gKq+sb9IcjkXhpg/eO7a0tXnzhec6fO0tZShGvlslUhrZtmE1nEhwwnzOdTZmMx9l8d8Z8Nmc6nTAZT9je2WZr8y5t24ASgL7r+TEl+oMhGwcOiQ9N2mUqXblymflsztmzZ2SWv/ODyqWhc46qkr7VSeSk0lVUVQ+lNG977O2srW3kbZN9aGwukvM2kRlAMSWmkykvX7zIoYMHlulvZGDJGMPW1hYXX3yRo8eOLkFGawu2t7Y5fPgwLgS00ktz+evXr7G5eZdDBw8Ssl9Rygyx1167xKVLl7j3woXl+aWN9NkDBw8CSphoUVhd3WdlOzOzI+/H/GLexk7GmQdE8jIzoEP+XMwpZCqzGyNgVMItZnzy479OPVtQ9oc4LLcmM25tj1lEjR2ukoo+NzZ3WLiErQbookIIYtL3uuK965f5T1Dd+JnfkcSIO3qfATx5NWSgQpiLcp3ZCwAqlYHkwuZtimijIHp6hWU46GE1vPryS3zxyc/zwnPPCdNFdt7SV0dbAdx3Fo5pSKT1g/RPn+PAO97FocfeiTpyjGa0xliVtLogGptj5yGpCCrvZ6UBYVCKf1MHKqUli9GQ6FnLqN+TSYAMHunUnbeQuu97EzCVcDFgi5IQE6YoGa2sMB5PeOG55yis4R3veJRr168SYkIpQ1mKrFpWTWSeXVCBsO2EFaMzY8ZkCSzI2JdSxAeISaGMwSq5Lnf9z2hFVUqQQkwiMw1JpMdNWxMyE7ssCqqyXI5NArrItcWHgC2KJSgjEwYZpMmm+FopQpBrS8cS3Dvud9cYndmRcWl+L6BjWRacOnWKQ4cPc+jwIQ4cOMSZs2dZW1sXj6ucaNcxyH32btJKYW0hSbRVSb/XpygLilLkbFUlgFjXQhSGaAeS1rXIxpVSzOczFOK7lGLEFlYM1JepqTKuCjAlkw7eB2JMDAZDQgjc+8QHl8vab/ttv33ltC8/rb3f9tt++79UW9UL/os/9yf59/7gd7BSKQoVKQsxW40pUTcNznsi0LpdwCg4Jwwm1+SfwhDyrvMNcbgsR1ssFsznc2azGZPplLquCb7FtY3cVIZIWzds3dnkyuuXufjCi7z68stcv3aNyfYOd27dZuvuXa5fvy5F4XjMbDZlPhefpcVizmQ8ZjLZoWlqQpbXlVZuWgorN2zi1yNyhPF8wa3NTe7MZujhkNVDRzl2+hxHT5ygv9JnsFKwsmKoisDa0FLoiFIGpTQmFzygSMu75khSkaQSIXl8EHZXCE7McmOQG8p8052SRmWeU/dInTdQLm66Yjdl3OrLtmWtIm9QuZDpCu+YJSO7AM6/qSZFwp5yDjJLaPeZt4BlXVG35yGgyK4crrtZXj6yn0LnuaC0orCaGFoeeehe+lUhbKQYSMFl36RAcjWhnRPbGhWcSDd9TV87TDtmfut1RnHK9/87/zZ/5Qf/BH/5z34/f+DbvoEj6yUmOS7cc4GqHBCiQtsCFwUgTblgda5dAqPOezGbD54QArPZjKZuMMYwmUyWbLKiFKlQyOBK27b0MrDSvafbJ9baLEUSXxUpxNWS/UR+X8gFUbePE7JfY5Y2dJKDEIIYguf118bQNE1ehhRU1opPkfjUwGKxwOci987du9zd3CRlkCplL6bXL11ikI3GiRHftlx69VUmkzFko/7FfI5zErE93hlTliXeu+wrlQuyXJiIL5FI+0yWDUof2U2KU7nI6tahKz/3NpeDAED6pWvFEFYpYe/5nIrm82y5vE+K3s5vSmVQqgNodZb4NW1LUQibSfql+GjFKIlkxpg9EuAgXlnBo5H495SisBi6Y9GBg8u+Lsa13TkSMyAXu/fn9fBBjLI7hkoMnoQwlLzzKDTT6Yx7772Ps2fPYwqLC57WO5E1uVa2L48Xsq0ZrEGYC91xUUrhWtmn3gdW19b47Oc+l/efyFTIktLr166xvrYO2aR+PpvxpS99MQNKnpSBLx8CZVXy1FNPkXJxXBYFOkt8lkySpddXx3bcTXjr/s6j33KYFL8umfjoACSVjc71HgmO1YYiKfABQszAhpj+m6qCsqROcHNnwqVbt7k9W3DozHlabbl66y6bkzmYCm1LZMpAozFkSIWo8iOPlF1flTXKRX8KaJWwGrkmdnDKcuzeBZJDjCSgsGU+H2R7lUoolYjRMej3OHb4EK4WUOxX/+Uv89zTX+Lu7Zuk4JeehylFCdFIkTrBtG7xtmT9occ4+6EPc+xrvhZz4UFm60eYVGvU5ZDWKto8uWTQRB9Qndw472edhDklmrI9j5jPr5Ro2pYQ5R6DxPK9KSUikUDCq4gnEVIkEIkxYZImevBJ02qDWlnlnne8HXNgjY9+9lN84UtP8oe/+7tYXRmhFJQ5gWx9fZ1e1WNj4wAroxErK+K11Ov1qUqLtVr8vTrhnTIkLCGHPkwaz62tCfOmpXWBECRNLgQZPxIQlcEnzdxFpnXLZL5gZzJhc2ubO3fusr25TfKO+WTK9u07LKZT2rrGGpH6LuaLJTCUUmKxWBCDsOustcK0MmK+3o1vTdPmgAbxGot5zBfAP5vNZy+32Xye2bR9+r0+IQjwFlqHa1p80+LqBoMmtA6ToNAG3zS0i4ZCG0jI/Vv2+kvZTD7GyGw2I+Sf3ntsTi1NKdG2kmRrM4u26vWIIS5Zjt12k9l4aY8p/2DQp23bN99r7Lf9tt++oto+U2m/7bevgrYy6vONH3wvAyuzs0kbPJpZ40nIzQJJZr5CzKa1IZCiJ0UHwUNOY4ohEoJER3vvxUsj+Jz0JjcVzjlc21AvJDUrusBkMqZtBGDyzjGfz+X11lHPF8JuaiUyeLFYsFjMxei7bdFK0TT1bjGXhFHVFVlieCqFpAuR6WLO5vYOjfeU/T52NGK0vs7BQ4c5cOAgaxvrrKyPKCrDYFAw7JUUCik0zBCMpPIYYwgpCEFJRdBiUIruClIBoISVIj4NKCk0RA4hhbvOTCe5IVf5ximDBLBnBnhvybTbVL6Rf9NzmXHQAQ9SgP+bZir91pZLIfhtvrcr1Pc+5HmWZVZ+55735Ndy8Vsag1Hir6T6K/zUP/pFxrNWCuXYQJBZf5WCMO1SwLcL2vmUYwfXOHdsg2/64BP8wW/7Br77276Re44coAoLqDdR7TY6CUiakqaqhswXDXVTo4xQGGTfsmQwpWymbU0uhjPQoY3GO0+/16fMM7w6sw06oKeqKpTWlEUhviXGimGvC0tvF5Xf3zGUull3nQFD3bGv9swWs6dfdAWLyVI7loW49GHnW1zbcuf2bV6+eJHTWf6Wknh9FGXBaLTC2toav/GpT3H4yFEUu15e9WLBdDLl/vvvx7WO27fv8NRTTzEcVAISKlCIAfPKaIW6rrl+4wYnT51aFssdKBFi5N5770PbghChaVrGO9u8+spLDPs9VldWpH/l2iKEyMrqapZIifwtZsdfnYGIkGftUxL5260bNxjvbHP61CmsFs8ylwGb1bV1BsOVzEKT6O7NO3d47vlnOXvmLFVZYIywzGKUgrw7x7rtSIhBsur6QfbDYQmcdUCSGH+rPeBBbzBgfeMgPko6oPeexXzOpUuvMZtOueee86CEwUT2loo5FSlmk2uSAHMihxIPlulswaHDR7JBsgBbMQWMEWBO+m133spx2Nne5qWXLrK2tsaRw4dJUeSfSkk63MaBDZ5+6imefuop3va2t8n6OjELns2mHDx8RNheruXlV16iXiw4sLEh7Dcl6XG2sLzy8iv0ej2apuHcubNiLq21qIeVFhaa0iKhiWL+LcDiEg3bHTnyLyqDkEuEPT+XcrpiigKkCksloqMIl3V3PiMgzWI+4R//o59hPJ5Q+0i1soYzlpt3Npm1DlWUhKhAadmnTpixhdFEBVEhEwbL9VBy/JVejo8pRYzKfUjCwGS9stcOmf2hlSxHaQuJpVdQSpGqtPR7PawRGdG1a2/w5G9+hldevkjb1KQYJMZddleH7ywBOdPfYHTiDAcefhuH3vUuzOkzLIYrzJSlRhOiXLNIAVKDLQqS0vgIMSqMMpgIJoGJIkPO+u+3XLFEImYUGAXroxUMe4255QOJRFSJIOFlcs4rOT4mAiH7YwFRQyo0G4c2qOspNy6/zua1a7zj7e9iczzBZ4lZCBl8zsBVUQhbRmuROqYk9y8ppjyG7IK8KEXUSlaydSiVEy+TAOkpeELMxtk6G68HR2nFN85oDZnRXRQF/V6fpESaa7Rk75ocUNFdG0CYOtIndg35nfMUWfrcXWeck/VP3WQNIuUL0QtzCGFqWiuM0RRT/kzCO2GXqxQpjEUBVgvbt2M9GqWpbB6rAFuKkXg+pMtrkS1EOmitlf0cwtJHj2w47nNKqYxhkrZYWEl4645HN2aLd93uhFgIkfvf87VdZ9pv+22/fQW1f9PT2vttv+23/xO2b/n691GEKamdgm9IriY2c0oCJjhMSkTncXWDb+YSm42oK0JINI2j9Q7nHYtmgYstzrfMJlNc3RCcyNN2trZZTOfU0xmL6YzQepr5gvFkwmQ6w/lA1esxGPQZ9HtoEq6e45oZk527jLfvMh+PaRcLQtsQvSNF8RxxzlE7h0sJZS267KHKAcVoHT0cMXaeS7ducW1rk6nzmH6f3soK1XDI0cOHOXzwIBsHDrB64ADD0SpV0adve+igiD7iAnhAKwexFVPvJDKmlDLzKBpUshIhlAuZZRPCkRTjwkmStD26u2mZZZaHAClyWwsqZVlAEmAo358tW8aO8u3e8ln5Dk2e9Zao90jKD7lZj0rMw+V2W4l8702P7jIg3xExwsYiQSogViidUKrFWCkwYgpoIzPVQl7wKB1ByfwzSmdSgKFxkoCHLtG2wvkEeg87Jc8by9y/Fl+tEMRXgpLDKwdZrQwpzHCuwZRDEorCKGwK0MwZ37zC4V7gP/zub+G/+FPfzX/8Pd/M73j7aY4UNfNbr9NsXiXM7lKPt9nZGrO9OWU6nnP35i1mO1v0jKJfFBQYijxjXFUldT1nUc9pXIMtLFFFGtfQuIZFW1O3LeQkqX6/T6/XE6+UEEgp0LoGZRTWatpmQagbQtMSYqDolbRR0uS8c1JURC+FRE4PS9lTI3VmuBmc6MC4mFPeYpIZZa21pDjl2e6UpLDQylAW5XKGO3iHSgmjFCSF0mIyfPrcBdY3DnLlylXKXl8KXCUSvRdffJE7t26zmM24+vrrjPoVBQGNJDmGBLY/YnM6Z7R+gIiSmfToUEmS0owtiGhcNvq1xlBaRQwOYzQuiAzCmmLZ53WeIV8Catl4V2dQIiFeWlqLFFDS+SRFyRqLMsJe7FelyP20mBsvTeHzz5gktUpb8frIi6IoK/l+YzGmoKwGWFthTIlSwvxSSlP1exS9iv5oSH80ROcEO4UAPzEGYkjZ0JgMHssxFLBHGGht0xCcgyTR4TEmQkgCnCuNKUpiBs99BBfESyg6xwvPPM1Kv0J5L5mIyhCCHN+gIklDIOL2mAJ3zLAUskxvOcGQKIoe73z8Pdy6u83lq9dJylL0epmxFXjhuaexKhJ9w81rb3Di2LHMkoloazDWMplO6Q+GDFfW8j6UAtQFnxl38l0dAqMyQ0kpTQwycaCyl0zaHQiluM/nwF7wJiXxx4mykwWYMdJXvFJEowmE7M2miKnkhVdusO0KDpy6l2LlMONZpIkFmB6oEqWz5CjGnBwHrfekDFYl59FRmDhyVDsWWt4ipfHJkJT4p5G3xxYFPgTx30nC/rEq4d0MWwCqxbUzRpXlnW97hGY240tPPc1HPvYxnr14ke2mxhmF14lkFUrn80UZkrZQ9EmjA6w89m4OfuO3UT3+Idyp+xmX60y8pW4h+ETyebLIB7yLpGCILshkUvRoJQBShGWCnlwC83VQhn5UkIdBo5LCNY62FdZbxw7szuUUEtqDbRPWJZSXR/JBGKkdkwmFVxavSmI54vzbHqd/8h5+8/JNPvH5z/Fdv//bGA5KTFEwGK1w6NAR+lWPteGIYa9Hr+ozHK3SH65R9oYYWxKR668xWpR8JAQ3NGArxlFza+7ZbiOtKWiAOngWrWPhHD4ltClIuk8dS5pYMFk4xosFk9mUGzfeYHPzNsRA9C3z6Zjx5h0Wk21U8PSKghQCVmuM0ssgBG0LUlKkGMQHi4TRInM0Ovs1Rif3FdkHM0VhDgbvJAnSy+dS9FitZF96kTDHBD5EWudJqAxySf92PrBoGpzPbOukUEmuy8Jk1VilaesGnRDvzRxQkLK3Zq8s8a1j0B+glMJqkbJXhYQfxOCFtUdnPi9suKos8U7uOTtwab/tt/32ldf2mUr7bb99FbTZeFNucILIGGIMkpAWI9GLjC0Eoekvb/68FLgp39iHLiY7gzxt3aIgJ7cJw0gB9XyBa1rq+ZzxeMxsNmNnZ4emrvFtS9MscN6hMiiicwwyiL+AtRaVPQUSIl9QWmOKgqKoJIlFaQIKFxPj2Yzbm1vUzlH2+tiywlQVZVUxXFlhbWODQwcPsra2xuraKsPRCoPhgKqoKKylyEWneEfILHBXyMjPzERSAhcplcnzXSXzr9BUhx7tbXvwoSW4tOflf6Xv79xRlx+WwpRumb9lsUL9/y1NCaBEBqKQ226UzDEDLYkgLAhVYGz2ZZHp/qWRtDCzNDFpbNGndZGdnRnGCFATl9Hme8ARWYFlMUY3245CGYuyPV65fJVPfOqz9IcrlMagYgvNlDMHh7zvnQ/z7/4738Z3/p5v4Mhqwez2FdzkLnExITVzQrOgnk2ZTyfMZzOmkxmz6Zx60dA0woprmoYUs9FvLk5Dl1pjMttIaZqmwQcPKvtlaE2v6rG2urqMWF4sFkynU2II2Zw7UVUlbdOQQiIqTdSGJkaUtRRafFKMMZjSYpRExFsrM8oqM9CsERBOimgBlawx+Lyee2VjXeEmXUJmo9um4c6tW7z26iucOnECpRJW5/QnFKPVVU6dOYsPgatXr7AyGmXGiVr2jel0xvnz5/nC5z8vpv6q8/QQ+NQUJadOnUYbzUsvXeTY0aMUVqRuUsiA85F77r0PUxR4J/4e450dXnn5JQpbcODAhmxH7sAheFbX1lhZXUcbKz4+OnsrKUWMSeS1UVIkg/e8cfUq3juOHRUvIJVZVyHC2vo6RdWjqCpilmxs3r3D888+K55KVvqf1kbSiJQixMBHP/prXLlylStXr3Lp0utcvnKZq1eucP3GDa5efYOrb1zj2vUbXHr9da5cucJ8NuPI0SOkFOWsTIqYFP3BkIOHD+P3sAkWizlXLl9mNp1y37335Jn/DPjk1maPuhgj0+kUUGgjcpkQQ5aVKlzbcuLkSTGbz+dmAmKSftKplcgyxVdeeZkDGxscPXJkd2TIY97GgQOgxFD7mWee5aGHHlqet8L6CKyMhty+fYu2bSlLkSB3gGZRlmxtb/Pggw9x88Zttra3OHfunPirROnjPgTx0TJWmCVkkCwDe+S+LoBSN5YKmBH3MBxSPleUUpguGbED83LSYupYNNmInpRoW8cv/OIvs3HgEDdu3WFrPANTLKcG8kUge8jI9ygtoFA3fnV9de9PldexG5dVNl8X2aSA/t5n4CklrJb1TcmDCqz0exzZOIBFceP6DX7+F/85r9/ZxI9WOXD/Axx++FFi1aeJGnwSGZcuCLogVX04cpzB+fs48ti7GJ4+z7Q3whU9gi2IWjwHyWl0so75uoFMcshAKFeUzjOQDLQurxa78yXLSxEI+GeVQqXEymBAocSVcPf7ZXzXScy5FaDFxGjJekxK5Hb5VWECR2H0bGwcZFo33L7+Bi8+/RQf/vDXc+f2HbwTVnNwjqIoQGmGq6vCqcrMNQm26BI5BaDu+lQ+FCQsCSUS+yheVkrJNStbzaG0wWib2coCsMQQBLBHAgZSjAwHg+UxjiEI6ynKGJaS9JUIGGtx3uNcizUin81dZ9lfQx7T8/QQ2oiHnlYC7Lgsm3ZtK/dOOUm0Y6MaK6Durhw5d9DsZVgUJTFLqlOeyGiahhiyNDf78AljXcaTlFm8ZQaGqqrEtbINWu8yPmMIy4mklAHijgkr+1jWSWvFvY/veyrtt/32ldj2IeH9tt++Clp3g0BmLoikQ+K6m7bFtblgCTLrlTJFPHgvxXBMeOepF/XSP2M2nVLXC2bzOTvjbcbbO3Jjk+O0N7c2ufbGG4x3dmgWcyY724y3t3BNg81xxr1+H1uWmRpegja4mHAxEgBdlJT9AUWvhy17uJTYGo+5fusWN+/c4c7WFrN5jbEFZdUTdkBZUZQl/X6fldGIjfUNVldXWVlZYdAfUFXl0sfFGEm66m5uuoj4XEfk4iAXMvl58iznv4mWvsy//30tCVi355HziZYP8qzz7vSy8D26d2glN4vyiCgdRA5jxCQ4qUDrIz5qAoZIQaAgUuKjRZk+dZv4yb/30/yZH/xP+NDXfR1//D/4E7zxxnXKspKi04pcUdruzu2YVEppyMtOsebf+oYPw2JKERymnbJRRf7493w7f/4/+G5+3ze+lzMbBX7nOoWbUMQGv5jQzCY0sxmL2Yyd7R22trbZ2R4zmUyZTKbs7Oz+PpvNqetmKRfoig5rRZogxacAFjGIBEjknuKbVGWWUNu0TKdTnPOUVUVT16jsU1PkdJyO8UBmK5h8852ylMl5WQfxb5LCOoSQi7iuoJd+EjJ7pzP4Toihr1KKsixlGR0YHKSAVex6WoXYAWfCuFkZjTh+/ASHDh3h6WeezQVWBn+N5tatG1y9+jq20BJnjspAophp9/p91jc28ncKI6UDozuQRGaqZT1i9ikyxtDvDWgaAarJy+wKuZAlFp0c0YeAzybRMQgA6loJClBZ8leWBSF4VE48Srl4CpkZ1B3nDoAjA1Pdc0pBWRY453Kak2E0GlF2gPVgyGA4oix72KLEFiUmAyNN03Llyhu0rSSz2UKMbjugxGcJW4z5rF9KWnaXrTMDLoSA8x5t5HiNxxP+yT/5J/zmb34ea62A+dlTpSgsOzvb3Ll9i0G/lxkLgXoxJ0Xx6CKDbFLM7WGo5NAF13oBdLMkczAY8uADD7K1vcOTX/zibv/NrMrLV17n8OHDDAaDbDosp4y1lrt37nDs6DGqSthN3os/jWyrTEh0sPJugSnjkXyHSHmkKpd+0Y1U8l+3tO5PuWa5DFYqLSwQa7NkmiRym3zemDx5cf8DD0ifyMv4cq37/r1/q3xtNVlu95YRbc8vktTXqYnEpF+2GchgCECkMJr7z51Fh8BH/+Wv8JFf+TVeuPQGB+97iOPvfDfrj7wTd+g0t82ItXse48y7PsTaY++Hsw+hTj/A4MF3cOZD38i5936Y1XsfoV45yNQOIMsxFVl+p5SksnUTSSnK31FSFLuHWAnu/Xv3d/awalPeF92/mBL/K3t/HmbbdZX3wr8552p2W83p+1Y6ao+kI1vuBG6E3AIGQnNJQzoSbGP4kieXm5YQLiTgAIYAwWAcE/LFYAwG07u3Zcu2LFm2bEuyJR3p9F3VqapT7d57NXPO748x1q6S4i/cm5vnPo/jGtI+tfeqXXuvZs655njn+74jBAHt5E9UdtZ4Lul3Rv28qGhVUA8m6aNNv5TfOZuIPN9ajtx4E1t272dmcY0PfuijfM9f+056rYxW5uj0unT6E6TtFtEaehM9pqen6XY7TE5O0ul0SJJEJGug/m0KoBtZmLHOUUfDyqBmcXXIsIrU0VJHKKuasqwUqJX9q32kKD2rg4KVtYLF5VWWV1aZmZlldWmJbqtFORywMDfDaLBKORoQ6oq6Kgm+ZjQaEhWcCTq2MZb3RqIRjzwfpWKdjyITrQrxIWp6gjEyPkY9h2mS4Jz02QZMSpwjcQlJKj5+AiSpN5n63NV1TVVXhChs2DQT6bdIB3XRBbElSNV8vPayEOmDp6yqcSELgCzPFOCVe2CWpRhjSVNZcLLGkGeZ3Lc2YzM24+syNplKm7EZ3wCxvLiAa8rSNpM39QMJIRL8esIRg5pT1lIpxCszqZl8VGVJURQQpbz0aDTEV0JzL0YFdVWwtLQkprXGMByssbq0SAgVZTFibbA2XqU2Vnw00iyXalVJgklSqfIEFFXFoKxYWlllcWWFpdVVyqoGI5WjXJrick3odBWu0+nS708wMTHJxMQkvW6XbqdNq92ipRKlVqtNljVJoKzciY+K0apZZsxQkpVM4e3I/82y7Thj+CvD/A+gUM/6m6+R53yNTYCsAjfJg3nu54D85ViO14BnysAygPVa4FlKRmME0Kh9UJmRI8SEEB2VD8zMXeP++x/gD//oz/iTP30/ly7Pc+DQdbzxjT/Ct37bt/NDb3gTf/Te9zIzM8M999wzTtzlnMp0uNlXjMGTSHIjQgtCiOR5l/e978+YaLd5zctexN//G9/J/i05cfkyfrBIGC1DOWC0ukgMFXVVUxYVo1HB2rCgVPPhUj2/fF1TjSsXygpzA7ASA608l30LUSQyWonJGikB7esKax29iQn6vR6TE5NkScrS0pKwlIKYk/b6fbo9MZO1RtqXxxKThBowNsEhCY3RMu+JlpsWWdX6qnoDLNkNLIzmPErCsG7+Kgmd+NZIsifGzleuXOaJr36Fgwf2kyZa09Bayqoiy3P27z8gyUUdePrkSQzQ7YhPVJomWAuXL1+W1X4VVGIs1iX4EDh2ww2kacry8jJPnzzJ9NQUGJFxAfgQqerA4aNHMTYhceIdNRisMXP5MkuLi+zZtXM92dNqfGmacfjIUUZlRUBW1aNWWbQqIYshEELN6toy58+dZfvWrfT6XWWGqBcJhla7Q6fXJ82EqVQUI+bnrup5OUC30yZEL0wULEVZcPDgIfbtO8DhI4c5dPgIR44cZe++/Rw6eJjDh49y6PAR9h88yNGjR9mzZy/WJSxeu8ahQwclwW4kZtGQt9ps275DvOi0xPhwsMY5ZSodPXxIq6kJqy9oslbXksh+5StfYcuWbTz22GPs2LmD7du3r1977d/Xri0wOTlJU/Y7UYaA0UppIUj7WFle4uTJp5iemmTHtm2S+CMyGe9rpqanFYBPKUYFD3zm0xw9eoRet6usPrlnLC0vjduAVflqVdWsrKxw4403U5YVp545zdz8HEePHJZxRttOCIFt27ZjrbCuBEyQASEq+CovGppSE3I8AkLJ2EGMWNscq7z2QUyv5fuEjSKfIgw07z0f/chHuHjxEhBJs5yo663rY72Mo82YJR+4vrgg/UHfoz/1j5o/x1rZC2H+oXB/ILEG56SfbdkyTTkY8okPf5ynT58ldHt0Dh6kdfggxdatLCUtyqRLmk1hQouRyyjabezUVvq799Hbs4982y7qvMPI5YzIiGmHYFLxStJ9kh1XEE3/afYKZQ7RnKcNQGQzd3jWVdAbkVEGE8qKs8YSfU2WJHRarXVjb72ORtGoMcNpA6gXxxtFhkUUzx9hTYuU0cfI9q07aGcdrly5xIff/2e87lX3UhZDVtbWWBkOx1JNYwLOiHeVcxaICnAKyCF+aLJf1oiBtDQ7AZiqKshNFSuSWtF8SytRQNpZASj1pon3Mn9qwLsQapyxtLJMJdIBo350dRCfMpSRaJQJixrdN4BoCLoI4dQkXtlXzXZfy3eAykejAOjBSx8YV2BDihgYzAZASDy9gheQv7mnNH1AmErSv0HuGyAm6XUlBRIaI/FEPQFlv6Uf1bVUBm76hq8FkJPFB2Hfeq14uclU2ozN+PqMTabSZmzGN0KEiK9qkVtogl2V8gjKIqirmmJUUIxGVEU5ZhwNB2skVsogh7rWUuSGlZUV5ufmGayt4X1NVY4YDFYZrA3Ilcpc1ULHTpxhsLrK6sryeOW9rCp8DNg0JWt3qCLMXVviwsws56/McHHmKrMLiyyurFJHQ7QJWatDq9sj73RIW21clpOkGWneotPr0Z+cYnJqiqmpKSYnp+j1+rTbHan+kufkWSarbqlUwHLOYq2Y0hqdbDdz7vHcewOQJO/R1/8vhkwpn/2f/GLDfjRYUZPP6Iq0HIKm32MGUnN8BjFlsmAcmARI9bkDEiIpIVoiDh8cV2YW+eCH7uPf/szP8Ru/+Vs89LlH+NF/9GPsO3Ad3/LKb+Pnfv6X+eIXH+feV76GTn+SI8duIEbD7p27MdGoybtMUNHEUD1TodlnnaDK5sBEJ+GH/vb38q/+8T/k3hffhhnMM1q6iok1eSJGwatrqxRlTVF6hkXNYFQxqiKVt1S1pyxKUHZC7f24H0TNIEIQo/jB2hrFaCSlp51KeUIQNl+lPirG0e0KYNFqCVB5bfEaAy053wBlwXtGw9GYURKiGNyLV5dM6OtaEoq6rsceOg045JRBtH7d1pNllGEUlcnTPG/YTU1FJGEJqQ+RPkIQdorO+fEqc/Ah0On22L5jB4ePHOXKzAyYZuVajGJb7RxjEaACAdlcknDoyFH6E5OEoKCPXs+6EuCuAc6sk8qKqa5Ixwh53iJrtVlZXZO8Ncj+yu8DKzpuRPVmGie3uv/OWvI8lcpOUc57v98V8E/ZPz4CxlKUtUiRNIn16r9EFH+fqqpE7lFVlMqk6Xa77N23l71797N7zx727N3Hnr172H/gIDt27WbH7t3s2rWXrdt30un1abXbRGOovMcYK5+pK/jGGDHb1qQrRkn41oEvYVN5L5UIjZVy39Y5nnjySW648SZO3HmCF7zohbz/gx/gyuwMQdlfzhpNKA1PP/0U/X6XNHUkzpJYpx5aIhuTpE6SaKNgC2ow7r1nNCohQppm9Ht9jt1wjK1bt/LII4+QJhnWinF1lmXijaXJaaXVn1bXBtz1ghdirDBAjTKfikIqKJoxK0naUIzCDkGviTEiOWteS/IsCbwxwuIS1ps2NG3MQc9jAxI4K0Ba832hkaAhzJeyqLh48TI2SUiyXCS+/73Q8bMZhY0m4kalQM2fN3I56Xsoc1TaYERZsSGQZQnTU1Ns3baF+z71ST754MMMulvZctPt9K+7kbB1B8vRMbFlBy9+4d1Ug4JYC8AcYsQHg4+WEkthHWWSUOU5I2uIrZSBLxkFAROClwIc1AF8wISI2chCes7rqA9poPIYbxv3mYZlpKymKPK5qB4+RVnJW5/FTBLWUvPZ4+9QxpJ8fETIUxETIHgZVT2GMqDHmzG17xDbDhymNb2V9/zx+7jl+K0cPLCXdubAV0z1+zib0um06XY7tNttev2+MJc77TFrqbkXJS5RlqcjGIe3GZVNWBp5Focly6OSog6UPjAsCkZlQVHX1LpgUEXLyMOo8iyvDVi4tiis2MVllq8tUAwHWAJVMWDl2jzlaIgJgaoYUVUFWSpge6oVErMsI8/b6n0o49fKyhpFWWGwOJX7RR9ItNpojGIc3oDHWL1XBO0TysAtSrknhhhFupqlhBAYFQWJViONUeaMo6GwbkMQ0/80TUE94IwVaXiWyjgVtMCB93LfDDFinZWqpsqCN1aAprquiEHuYdKF/9+dW23GZmzG/7zYBJU2YzO+AaKuRd/flEgXmUOlHiSeqihFblMJyFSV4olUjgrKUcny0hJrq6sUoyHFaCiSttEQYyLFaMTV2Vnm5+dZXFhgYWGe+fk5FhcWWF1ZYXVlmZXVVUIUanWz6l77gHEpVYhcuHSZcxcvsbi2xsh7vLGYNCVptUjzFjbLyFpt0lYbm2TYLMOmKS7NyNsdev0JJianmZyaZnrLFqamp5mcnKTf79Pv9ej1e/R6PdqdjiSwaab0dydMJIUvjD5vXktsmORsSDhka/O+v+qxPikfT841qWScD8mK4zg2vn/jF49DkKHxxFuT8OYYJDmX7/ChgaGsJk1WvY/E5LgBkSKOSEaM8nxm9hqXL18j4kjTFstLA/769/8g//k//w79iWmed9cLuenW2+j2Jjl+2wle9OJv4uZbjlP7wJGj1/Frv/Y2/vWP/zivfOW9/PXv/36lwouBMs9aEV9H8axVrwXrMDbDWUevlfB93/VqptuetF4hqQbkBEKElcGAYAwmSYjGUVQBaxNckuFrBYNqYYWURclgMJCJtn55A7CEGEmSFF8HlhaXMYiEzBgzpucLACkPMPR6Paampri2sMDs7FXm5xdEMqBeL2ma0u11KbU8vSTdAu6GGBmNRrhEKrYJ8CSV24KWl/e1GmurbK65vkErwoUgiYTVSf3G9zVARpqmAmSoF1Oifj21FxZiVTarzPJ5LknZum07t9x6nKzV4syZM2MAIU1SgkrRAIxLyFotJqem2bV7jxjdavWioijFk0hBneAbs171MVFGSuMtMjk5TVFUwiDztSZEktQURcEXvvB5tkxPY4Doa1KV80gVI5nMGANXr86yZXqKRCWuVa2Ajo9S/l1BF1nBl5Vxr98TojAxm3NnGhDPGNqdNp1el16vL15tU9NkrTbdfp9eb4JWp0uvP0Gn06PxJGqSsOa60QAkY4BjgwRPx4JmrHZOZaA6Tly6dJn9Bw5w0803s2PnLo7dcCO7du/hvk98glFRUHvPaDQa+9vVdc0XHv4cWeJAq62h4KJRFlCtEpe6rqm8sPdK9WURCar0gYnJCXbv3s1dd72A06fOcO7cOW1LIpMJ6g1lrUh0Ku+Z3rKFXMG1sqoFSFVQFxCZZ2iKIQjbp0liGxlyHEvKZCCUti3tAmXkKU72nBFSxzuVU42TYTVqr+oaowbExlquzs8LUKWAlYzaisg3n/gsGZ6CVfq9sh8GxsDRxusuyX1zTb33JElK4hx5lrBzxzba7Yz3f/hDrKwN6ezdz/Sxm/BTW7FT26ltzu133MXL73453SznjtuOU/iCyonHjfECzlS1p6hrCu8p6gqcxYeaxBlMlH5IbACjgJRRFGDJbpC1GQWLBCRqtq97LW7cHqNCa/r+BmiSkwJEGQu8V7mkKOz0vrR+fVCGdHPPathqzXsI0lcjRuYNSQpJxsB7luqaLQcPsf3IddR5m3/1Uz/Frt07ufH6I2RWmESdVo8QAq1WTrvdpt0SgKnb7dHtdmm1WqRpppIzAcTk/pMSbUJ0GVW0DMrA4qBgpSgpPBQ+UtSeovYMy5qRj9RY6mgJJqGsA0srayxcW+by5cusrKywMD/PaDDA1xWDtVWuzV9l+doCo7U18DXVaEhZyuJeXdeMBkPWlP1qjCHPcvr9PnmWC5u8kspqvpb7SpqmyiYO4hmZycJIpVVBE+eoKqnKmKaJAucyxlRlNbYDGBUjkRYr4NztySKKc7IgVysLK8tTEmdxzjIqhoQg46l1VozGE4f3AtBLf1mXRBtjKIoSHwJ1Lawxr0ViNmMzNuPrLzZBpc3YjG+AiCFQFIUkkMBoOJRKHE3y6qXkbKhryrKgKguK4ZDRYMBwbY26qihU82+U99Jptei0WywtLSp4tMLq2ip1VTIcDhgOB5SjEWiVG6PlwNMsH8vXri0tcerMWZbXBthEAKKsrWbbaSZMpDzHJQIgNT/TrEWnIwnexMQkE5PymJycpNuRiWK316Hb6dBut8iznCzN1F/AYXTlzurzqAmpMbqqPjYP51npSgPNREVENN/8Kx8b/775TyZy63mK2eCV89z3fs3QSb2xknxGrewSIkRjqWplZ9gEp1VlBFxyVDWUdSQYR4iWNGvjo2FtWBBCC0xKxPF//tRb+Mmf/FnqSqQ77fYENxw7zne8/ru57bY7ePLJp9ixYwc7d+7iTW98I9/8TXczNzvL7bcd5/rrjrBvz25+6v/8N/yzf/p/MDnZJ4b6Wav242MzksZhIjEKcy54MKSy6h0KenkkFNeIxTLdxGBCpPJSCRCbaJsS6UtdVxA8mbOyYq0JnX4ZwrAR+n/DzJDcSNgSIUSuXp2TFdlMPLgaMCnPJTGZ6E8wPTWF956lpWVGQ5n8S2ItnkXtTkeSxzxnNBqNE8sQgiT31uBrAYJiDLQ7bTUND+R5jksE9NwYYUNyyga2TQMmtfKcGIUNVlXS32G9vVjn8F4/o64pykLbjsdZR6fTpd3p0Z+Y5NgNN3L+wkWuXp0TzzInFb0ESAgExHh69969uDQTBoYmZuKvE/Fq8so4QZSMsiorqXplLFmWs3XrVqxzXJmZwTrH2mDAcDgCLbc9O3OFL3/pEZXHGUmWEZ8aa8SfZ2lxEWJg69atJImU7nbaP4J6yI1BQWXVeJXAYHRVX8170fPaAEwikU1IskyAByf9ytoEq/4kmKbqV3P+VTLSyBKVgSQgkgCbXpP1jVc5jkEKaa1JknD4yFFe8IIX0mp36E9OMjW9hVuP30ZR1rz/Ax8S9p2Co8456rKkKgsuX7rI1i1biCqRiZr8W2PEG6wpyDCWEKqfnq8hynenaUqv1+PGG2/i4MGDfPSjH2UwGEhFOlDza6fsBcPCwjX2HziAcwm1D1IEQThmeoACJjaoTaUJ8XisbUANZVvEZpMCNQ34ZJsxUx8NkDMeU5W5NR5Xx8whAaeMcyLijFGA9rgOIpoNCwxGZZgN+yhEeW6Msga1XxqVIHplvxndB6eeTjHKOG+tIfqayX6X3bt28PH7Ps5gMGTHoaNM7jvIIG+z7eBRXnj3y7jnFa9kz47dfOnhR3jwMw/w9NNPYRzExhtPr5uwEO24n8W6xtYe52vSEEQWrWdcpGfKTEJBIi/gEjGCf7avkhzU19gW5Ps3bjchYqOR6m7GUlWestTrG/QaBKk2GPX7ggJjAixteN60S2XihRBUMimyxuAspTOsYunvOcDOozey97ob+K+/+zukieOu592JDZFWmoufYiun3W7JIlO/T3+iT6/XlwWndnt8TccP6zBWFits1iK4hCLAalGzUlQUASosZTQMq5qilgUxHw2Vj1TBUAUYljXDsmRhcZG5+Xmuzs4yXFsl+IrB6gqrS9dwRIrBgMHKCnhhrdYq1U6cpdtpkyaJ3Nv0XFgrPkShlnuBr2uyLKXdaom8PxF2knXCKGx32tL+rdGqfALgiEG4MIqaa5BnOS5JZOzT+41LxKsuKjtW7iUCGLfaOc5Z6rokRi9t04Axws5txtTgg7B1N7Tbupbqn8HL683YjM34+oxNUGkzNuMbIWLAGilJW1UF1sqNXErXFtR1SVWX1F6SrGI0YlQULC8vs7S8zMLCAoPBgGvXrrG8vKxsh8hwbUC/28VYKIshqysrLC0tMVhdE4mHlHmhqj3RONK8RbQJNs2Zv7bIzNU5KUWet3C5sI+SJCXJUpIsI1Vpm9MVt7zVot3u0On06PX69Ccm6PV64pvUbtNpt2i1Mlp5LkBSLsaPqVYlSrRcvHOJVEsykgTLJLKpdKWTmvHzjSvWmuj9z5j46MTVqWmyYd249Tlv/JqPJmGyaswpx+TwCPvIZTm4lLIKVN5ThUA0CZGEYFJq74gx5fzFGf7jr7+dk8+c5m/+wN/jP77tt6iDZebqNR586BEuXpqlrD0hBib6HXbv2sc73vEO7vv4x9i/Zy+9VouXvfRubr75GO/6r7/FZL/Ff3r7r3HDdYc5fHAfzkQsAWfBWYhBQCPrZP/HiaSGRcyWpfKS0wpfnl63RWI8zkoikrhEAcNUfEmMwfhAYsBFj/UFph5BMSCxwjJySUqaZGAsed7W8s3gEqkUZLT6m3GWUVFolUIDxpK1pB26JGFqaootW7fQ6/Wo64rBYMDK6gpBZXKtVotOpyMAUoxiQK3gVVkWIj8wRgEP8e2IEXxdi3eRyhgaJgVN0qrSKUkMBLxpVnwbULLUFelUZXPi3SMJel37cTtrgAtrJTFIEgFGkjSj0+uxddt2Dh06wu7dezhz5hy+DtSVp6q84EIBjLH0JybZunU7KFBXKwMHBLhN05wsybAGnJNtxkrVokYGmKQpnV6PPXv38vQzp1lZG4FzxA2eQsZETj3zDF/4/OdInaGdJbTylMRBVY5YXr7G6sqyVMSrKpEBRpFc1b7GJY6iLJmcnKIOgeGoANYrEaHMOZHoSBJrrRiOO5dijICNRGkPklevsyuIhjj2plMARB9RKyoFL4a4oZFo6XUU8ES+M1H2ZGgAHgWJDhw4QKvdwbmULGsxOb2FPXv2cvMtt3L27Hm+8IVHFAwSKXOMEYPh6uwsVy5fptNpi9/J2DNO2t3GENBEWI4N+OFcQppk9HtS7OD48eMMh0O++tUnNeEXf5qqrhgVI5aWljhw8KCYc3sBo2uVh1n9zDForybHIajvUZTXMUp7F6YE4i0VVPLVsLhswyxaHzOfdUxRAYzmdxE55xoiz5R2al1CUC+pZlq8DnjLI3FSjRHkcxrTfpT9YVgHvZxWiGv216sfXTTCtKnKklAV3HD0CBfOnWV1eZlsaivtbbsobYrJMi7PzHL+3HnOnbvAxz95P89cOE9BxAdIa0M+DJgAtYnUCPEoBgPBYrzBeoPzkbSOJHXARDXJbx4hYPQnIWDHz72ATX6DRG7jz+duiwpO+YBR5pM81sEmr0UExoCRAmw8B0giRPAR47UdNEy+GGWhIXpiEMYjIRKipwye2iWsRkdn+x4O33I77elt/MUHP0xdB26//Xair7FWmHXGQJZm5FlOr9tlYkKkcO1Oh26nR563cWpW7ZyV+5QBm6ZE64guZeRhuahZLT2DOlB6KCOMqpq14YjCV9QYgpWKfEU0LA8KVocFo7Jk/toCs1dnGQ3WoK4JZcni3Cylvi6GQ6piiDORPE0gitn+aDQAlZwFBeqrWqqRGmUx1WUl87fBcMy2894TiZSF3FN87clSmRP5IM8b1rZVhq33UuZOmE92POcryxLrLJlaHLTyFiEEBoOhfG6Wj/tkVN9O+WzhR8dQk2epPvcY9RWrywKDyOY2YzM24+szNkGlzdiMb4AoywLvJQFYXVnFqPSjqiqZoHihUYfaj1chQ12zeO0aC/NXmb1ymVNPP82Fc+eYv3qV+bk56rqi3W4BkSxJdZVJKtkUhVC466oWs8okw2Ut0lYHj+HSzCyLq2tE67BJikkT8lZrTMnO0pQ8y2jlLdp5Tq/bo9ft0e/1mZyYYGpigunJKbZMTDE9Mcmkyty6nQ55lqo/QEKSOFxiRSLUVHobr0QKmGPtOrBjrVV2kUhEmkcT8nzDhv8H0SSz1rl1Q2XJasZhePZ+PGuf1MNiNBzKinDt8RGMTSjrSB2MgEhJRjCSCH/xS1/m9NmLfPFLX+VHfvTHWBsGfu3X38n0tp1s27mbqa1b+ZVf+zX+/P0f5sKlK9z9zd9Mf7LH/MK8JHIGnve849z1/BP8nR/4W2TO8Lvv+i+cuO0mBitz3HzjIf7zO3+N7/3ub2Pfnq383M/+FFsnuhhqoCbGWitZR13NXIeVmhLSzTFjIJooObxzuCSj3e1jbSrsByt+EuIVY0kTqSon11lKPSdZNgYWkzSVCmLOkibim2EV3Eh0JddZYSYZaynriqXlZVod8eRqtVq0Om26/R79yQkmp6aovWd1dZW1tTWZPCv4mabp2HNJEvx1YMFaRzESz4oGVBGJjJqqKuMibmCrNOymoGyIje3H6ep6s+rcgBOSiClbQo1WjV2XWIYQSFIxqLcqjZL2aCXh6vWZ6E9y0823UPvAuXPnicFQVwGiZTSq6PYmOHToyBhsy1ptyVkVkBF/kvUy87JfgbIoJDmxTb8UWcW+fftZGQx46ulnCFFM860VP6DUObLEcfrpkzzwqU/ywQ/8BZ+476M88On7+dIXP8+pU8+wsDAvsgzrCI2fhxegZWV1jRAjeautDCWVdiiAERG/EWu1KqQRXkcDRBgr0jl95/j8y0OAqIalNGZwaALfMIAaiRvjvi3XVwAc9TYaf5+CiTFQez8+h4JpWbI0o9efYt/eA9x2+wk+88BDnDpzlqDMKAFshKFy+plTjAZDuTAK4gRlJMn+N2Oegj4bxkfxFkvI85yJiQn27z/AC17wQh588EEWFxfHQIoAQLLPe3bvxhiDV0aPtWL63zxvfJxMUwFwzLqT/1BTYq9AklEJjldwCnTQGP/QAcOoFk4Bo2fJidc36/WjEU3K8SPebhtt6sZv1vYcFAhkvC/rfVGurfyxb0BDxFjfWgEhjRWmn1PJ5s4d27h44RxYy+T2XdRJm8rl1BiGZcVTJ09x+vQ5TBRPPIsjVB5femwwuMqTVJ609rg6YmthHMUAgUhtIoUJVPbZ7bJ5LkCOAKFjENQ3zwXkaZ4/e9s6Myl6AXoI8t148UAimPF767qRvm74rqZQiF9nI0m7jET9nBgCPtT4WFNHkevGKKxqfE2sPfhAXVZYmzDyEdubYv/NJ8i37uLPPvoxzl++yN3f/EK8r+h0OrTaLZLUkbdyWq0WE5OTdLsy1nW7XZJxgQQB3cRI3QpDyDq8sdQ2pTIpS6OKxcGItcrLHS4GRsWIsiwp64oqCOBUBMOgDgwqz+qoYHUwZHFpmdnZWcpiSF2MGK6uMD87g4meUFdUxYhQVxADlshgbVUBNS9AnoGyKFT+K6zDwXAgZvkKala1VPm1xhCUnWoUsK7rWgzDVbqK3jOstWNQrdVqkbdaKtHWCqIqJ00UVCqrEmKk2+mAgdFoKN/Dui41xMBgKMVeorKcmjGnVom3UaPucf/ejM3YjK+72ASVNmMzvkEiBE+oPa08l6SqlqpXgPjOqM69MeQtSzHrXry2yJkzZ7i2cI3Z2VnOnj3LlcuXWFiYZzBYo92WcurGWoqRAFQhiocKMZI4JxKsNGdlbciV2TlGVYVNUrJWG5eJrATrSLOcbkdka71ul163Q6/XZ3pykumpKaanJpmenGRqcpLJfo9+w1BqCfiU55l6JXTotNu0Oy2ZRG5kKGmi2uyzMfJTVtClQpdEk/Stv/6fGpp0BC2/G9TEdz1klfH/XxgMiXO08hy0hLexjhAMdYjMXJ1jaXXA29/xW4yKkgD89L/9Gd7y799KknaYmb3Gxz/xGU6fvchLX/YtZO0Ot504wbd++7fyX9/1bn7urb/IPfe+gq3bJrl6dVar5gSOHdvP4499kZ/41/+K9/7+77Fvz06+5RXfzDvf8Ta6LceO7ZOcuONmUhexscaEGmOCPBRMiggDAZQeovNPMNgoJqLRBKINRBMxxuFcxrZtuxUsswQkYUaTtRAN0Tpc1sKkOdGlRJviTSLlmBWNy7T0ewiBNBP2Wpbnev5UuuYEXFobrGETR6vTptcTWWV/YoJev08EVlZWmJubZ21tjaoSj4l2W8xgkyQRs2X16/E+UFayUpwkybjKTlSpVNTV+gb0TFPxyWgAAKtsNq9VwxrwiA1+MfJSjbi9sJIkgZazKwCAVgZSKWuSiAdHoj5JdSXsqCRNmZyaYseOnezevZennnqa5eVVhoMRg8GIqvLs3rOHVruNdbKKHSMCqiXCmjNmHXzxWnVIvI4E1Ku9H7Ps+r0+O3bs5NDhI5w9f4G5+QWCVu+yzsq4UlcYAqUmXHVVMhisMBwNKIuRsPZU0pYqGwHE1+XylSvceOPNpGmqRryo345IsZrzJmwOAeOsGosbHSuslXL03su5I6KAkiTARhlKMUry2zBCmr4u2O669Bb9jqbfmzGoI5/TAD8CfAhIIvsoYPTk5DQ7d+/h0KHD7N23j49+9GNcvTqvwI3IHGsd50+fOk2/15OELgQB0/TaNEiMUfN3lwjQLVJG6Z95rkn4RJ9Dhw6ydcsWPvWpT7G0tMTKijBaZ2dnOXr0qIKFCVmWk+W5QsV6PjXhpWFLbTgmGuaRMo6MttnGjylR5p+ANurFpOdVL8Z6m0PONeNj1MPcEOvj+0a0XmOMJ63/G5RRZRTkimqyjoJHzXhtECmas9pug0gAmz5AjDgTKYZrlEUBQI1jEAzRtrC1IzUtjM3EhLsOGCx48cYK0VPhCc34Grw+hElk9WcDbMa47mcmD22TY4BoHTAS0GcdKB0/f9Y2/Rmbv2tYTsJuGn9WkIWSpkhIM8aNf2747GZM27ifQa9984hR2nIMAiZRB2yIuIY5hqW2Oba7lQM33042McmDX/gc5849zYte9EIBZq0lz5XN3GrR7XTpdGTMnpqaZnJigm63S6qsJmsMiZVqm8aK7JUkw9uEMhoGVWB1NGI4KqhqkYKVVcmoLBgWJcO6pgjgjWVYVqwOC1aHQ5aWlllaXGLu6lUGq6vgPXjP3MwMw8Ea5UgsCspiRFmMlI0LWZKQJlI8whBZXlqmKAqCr8lTWShp+lGaiFStuVfU6ldkrRQP8LrdOankmKiBvfeyQBKDGnFjZLFFx8iqrCiKEUEXSSKR1bVVosrmmgWO5l4qxt4io23ueWkq4J3cj9bN+ht532ZsxmZ8/cUmqLQZm/ENEjFEhsOh3MijrDAtL4sXTDEaMRisMRqN8FoSNhuzC4TyvLh4jcVr15i7Ose5s2e5eO48C3PzLC0uY60jz1tEIyCJrKQZnEuxSQubdxmFhPse+DyjWjx/jDXYRJL3NE3FQLPdptPp0ul01RdJpG39fp9+V2VunQ7dTlurucjPdqtFq5XTyhvvJKnwliSOJHWkmSNLnVRWSRLxVrIGYyLYKD+bpK9JNnSbpVHxbRSLyAr3/514Tj4jx28NVVkxHAwIPogvS/P7r/nxwuaJGAJGyrJnGe1Ol8tXZhkOC2yS8tjjT/ATP/nTLK8O+cVf+lUuz8wRTcL3/42/zdnzl5ia3oZNMn74zT/Kl770KF/+8qOkacrNt9zM7Owl/tk//T945uRTHL/tRvbs3cYzTz8lE3lqjhzdyx++93f5vd/5//Lrb/tVXn3vPUz02kz024RQQCgpR6sQSqKvEPVAFI7HhkSwyfNATs764apXyfgopUqT94Yt23YSItRBvGPE3DMIw8k6rEtxaY5JUqJLIc2xrTZZq0VUWQqIEXCailluohXWUmUsOZXWJElCVYl5cbvTJs1zWu02vW6XJE2pqprlpSWpfhiESWKdpdNpK2ih0jMFbsuyxLlEVnabCMLMsMpSCUF8Kkxj2NycEW0MPgSyLBPGk24ToEjb7HgVOApIpKu/Degkya1M6s3YV0rKbDstS59mGTFEWnmbTq/Hlq3bOXLddWzZtp2Hv/BFHnjoc3zmgQdZWFxm9959SOVAQ1VLtbJnATJG/IvGDDKE7VFX60UCvJfS1SFGJianuOWW4+zdu5fPPvgg589fFF+e2o8ToLquKIshxEBVFVRVqTKKSFWWJElKVYtReO0Do6LkzLkLvOQldzMxOTlerW/luZzDKMbPUVfgG7BZgI0GoJDzZY0FNRAXH7N1UEbOKevMDwXZFCtRgEYSrPH3NKDGBhlXw9WRMUiAH0kKhVGTZ/lYkpamKf3+BDt27uL5z38+vf4En/rUp6nrdTDKezl3S8tLPPLIF2i3WxggeGFBbAS8UI8xq+XRpRtGeZ8mo91ejx07d3H7iRM8c+oU73jnO/nNd/wn3vveP2TLlm1Mb9lGlrUwxgqoWtdyH1FAzTTePwpiNecwIqzE9ZPWgE0yNlgrUkiDvMf7hvnVsLuEXSWXQ45JPrcJOdcNE6o52xvPul4NHZD0uur7BfQQSVAD/BkjYJkPQs979jXUNjGWVzvxtNM+WpQjFq8tsG3bVjBwbXaG6D1JNPRsh8SkGJsSjMM4KVggQEuNSQzeRaKLeDw+etCHiR4bAi5EEh9IfMD5DfSspkEqgEQU8Kd53lyPEKT9Nts2/mzaTdTPMHpcAlkjdC8FLUFY0WLurZcm6HVvzlH0+pH6HQ1Apd/R9IEYIlGQKv1dILEJNgqzuvaBOhoGHnzWZv+xm5jYtp37H/wsX/7yl3jhXXfhvafXGHTnOYmztFster0e/YkJ+hOTTE1M0Wq1hOFstLpkmgrAlEplOB8ipBnBOVaLmuXBiKISmX8VImXlGZUlZe2pYyRgGZQ1oyqwMihYXlljOCpZWl7h6uwMa8srWO8p19a4NneV6CvWlpdYXV4k+JqqKhisrcl8rRjh64oszbBOKiGmaYYxskDYjGfS9/243xkMXgulgLBchR0k19kYYeQZncdZa0lSWTCwVu5PUkRBWaAhUBQjYaSmUs2zMeyP6qcn0mvxZiurCqPSa1m0lM+Q8U3aW9OHNmMzNuPrL9xP/uRP/uRzN27GZmzG/1px9fJFSi2fXjemjL4mTZzI1HxNDJ6iGFGUBbWvSNWQcW1tjZWlRUbDIVVRYAGHwdYeUweqKrBa1NQxitwsVmQmkiQ5tckI+SRraYvPPnGRy6uRielt9DqQ5pYkzUhdTjt1pLkT36S0RavVIsukIkue57LC1fgq5bL6naYJzon+P80y0iwX/5YsVW+YVDwULLRzh6k9qU2ISYqNiNFvGolZJDUi+0nThLSsiYkhqo9sGiKJs2DBW0M0DmdbOnvWlee/IiTHWU9v1rcL46AoRpJ0GaNQf8RYJIGIWjHJaMU2vQI2aTMoI7/xjt/m4JHr+Zm3/Byjsub47bfS7k7xznf+F177utdz7txlPvvwl3jw81/myZOnOHvuPN/9fd/Nw194iBN3HuclL3kBv/Ebb8MQOXHrrdz/kb/gr3/v6/mBv/l9bJue4PbjN3PrTTeNqwAlBtLEYo3HmoBBGBkCvEni2yBiwkhQGZdKaprkrkkCjSaXRg2XGyjFYjFhvUR8JJAmjksXLuDLCmcMzkk57+hrEmvEI8R7UutIrCTOvq4wSNskynld99cQYM9amWwba/ExUJYVo6JgMBiS5y2mp6YUbJES6846itGI5WuLFMUIpybFeZ5j04ReXyqE1SpdKofiNzGsKqJL6PQnxMfFi1kwxlCVpXiRGJFC0iTS6qUkE3thKwl7Q85r89N7j1EjYauvUUmDAYpiwPz8HE8/+SR79+yhnedyrazFA0mesXfvPqKxeB8pqlKumXMY6+hMTDC5dSt79u/j+Ik7uOtFL2J663ZZuVfzfgeMdLw4e/oM01PTtFodSS6dMC5ihMNHjoyN800DvmHw0ZA4aOcZZVly/vwFfIy0Ox2yPMdaAV2tFXDGNlW4AsRoSFxKBGySMRgWLCyucHn2KrfcdgcHj1yHcylYgzUQ6pLoRZq4tLjIyZNPceDAQVp5hiEKWKbg3q6dO8myHKKUh5fqhZFoLNh1oCJEz/LKMnNzc1y+fIX9Bw+pgbnF2oQYDZ1un8npLVibaPIn5cQvnj9PMRhw5Mgh2a7G4WVV4dKM6S1bhKkU49j3CKtArZViCC5JOHX6FDNXZ9mzf6+0BwVzm6Sw223T73XUA2+Zc+fOsmV6mu3bd0hbUzZnWVVs3bJN272ySBroxTqwjultOzhw6Cg333o7L777mzh24010Ol0xwPZ+zIYdjQZcvnyB2auzHDt2DGcT1ZlJct7udGj35BpXtXhPOZfIMGKEIYQCOKBgzgbpWfOLGOV9zXskUZYPiQhQqO+Uv4nCenv37/wu7axFrlVBoxUzbhqmmmTdWCegdAzKtDSilxOwej0hdk2/tcKQlPuuVKUU1qxjuLZKklgmJnqcOvUM9WhEJ3W0Oy0GTgbDEMAZOQ+GgLFhvNhBNMJeQqRxJhoF5fQQQX/nEDcb5GRGMI3GT8Gf8XY9keO7mo75RlkxZgwqyXZvIBJJQsCbSG0MAYsJjZw2YIInCxXbe31MMMRgMNFR1iPAkUZDHgo8KWWoiLEmaY5B9y3KjIOo5zcaEaJihJkr2JbsvYmRxMhB2CSn1d/KSumYP3uSerDGPfd8CxcuXqYYjkiNwXi5f7k0p/BQB4uNUQHxBLD42usYp96HTSVCY0QOF6UwRh0tkBBjosCpvNfZSOJSjE3wwYDLsElOCMLUI0ZiWZDiaafi/beytIhzhlY7J8RAmqfKMI163QV0zvIUr35TqXMyV9G26r3cTQORxAg7VsawRuovbGc2jA9Wiw1YaxVA8mDA11XT++X+mTq5rzr53Kj3GYPc92OIes9XBqgBq4b1zblr+kuzzdcCQt98971NC9yMzdiMr6PYBJU2YzO+AWLm0nmZ5OpqPkbo3MPBAGMMVVEyGg5BvVlGI9XqG0sMgcFgoFXhpPQ5MeKBkfeUocY4I545oRT2DZbCtQjdaap8gvsf+iIz14b4mDDRbbNjqk07z0iTjCxt0W7ltNod8nabdi7+NXkmgFIju8jznFbeIm+tG3DnWUaWye/EkFu9c1IBoJJUqr1F1yLL2kDEpBFnJTGKSU5wLZwXX55ooc5SSDoEn5KQyYQPj6EmtzWpLzGxEnmLThz/R8NaRwiePG+xurpKq9UaS/KEOaEAkksJ0fLeP3wfTz9zlhtuugXrHJ/73OO86Yd/hHtf+SpWBgMefewxXvWaV5GmKR/9+Me4+eabGY0GPPPMSf637/teXvvqe/niFx7m4IG9lKM1Zi5d5F//+L/gjttuZf7qVW65+SZe8pKXsH3bNvXLgna7pVIYAX2a5M7AeoKzMcx6crK+qZlAbtwuQNJzIwoCp9N3eYNNpDpaliYszi9wbX5ezXEl8R6ORgxHQwCyLFd5xvq+NUCNS8RryVorJaSdI0lTkSIZy2A4YFQW2oYy2p0OdVUxOTWJNcK2yNKMoihYW1tjOBiIdFET0DTLmJqeoj8xQavVwgcvtH7vGQ4G+AA2y0nzloA5IeKDsGBkci8gI4ipcVRpgpxrNW9W42ajUiWvld+aJMGqP1KW5+pbZKlqWRWen5vj5FMn2bN7N9YYKUNelaBV7fbs2ycAiJaIrnRFu91u0+/32bNnD/v27Wf/gf1s3boVl2TK9gGrzJSqLBkOhjz9zNNM9PsKRGhlwhApq5pdu3YzMTEBRoxmjZUkyVpDnoo0rtfvAZGLly5x4eJFRqMReS7SRaM+P5KYWKzKZ+vas7K6xuzVOZ56+hmyLONFL76b648dw6lnloyD0ibzPKcohiwvLXHqmVPs3r0bZ4wA63puyqpm244d9PoTWOuotV96LXFurJiBGwNVVbK2tsrC/DwXL1xk166d48pmdVVRVTXGOfbu269yOkdZFBSjIZcuXmBhfoHtO7YRohiJl6VIVIyxTE1vUR8TvcaAdVL9yRoBb7M0xRh49Mtfpt1u0Wm1qSplbdXCXlhaXGLHjh2UZc3y8grnz50jSVJ63R4+REajAh8Co9FI2KKdLlbbQlDmT5pmdLpdtm3fzp49ezh06BAHDhyg1+urLCoC6kXjPWU54vz5sywszLN/34Exw7CqaklcY2RqeitZngszRT3TrMrHBEQSP7Dm+Tp6ov43CKgjgM86CKsDkr5doRVrBAg3lrIqec/v/Z4AwtaSZCkBYfM0DA95YaSglVFZoGIujdeSyNLWfwrwKKBkomXYk6Zyoq8h1szPz7J79y6WV1e4tnCNYVGSdbqk7Y6Qw6zDa7U5a42wfbACZo7HYR0nN76WAUMfTegx6bYNWBxsfKduN0rWGkuMn/VR6yBUEgypR3yUon6w1w3qn0eEvN8lEEijJwslnbBA5kckxlLFhOAdmTUkCl3IcciXWt0niwAwFgXDxiZYCmDIRqL3OCMysCxJmZycIhQDZmZneOrk07z2Va/i8sULcklDJEllPJa5TSBVmWszHwK5L0lT0DYE6+OPgv2+roWRai1plgAR76vxeGGdI0lSGcujSpG1LfrgqYOn8pVUv3WO0WiEMYY0cVIoofZYI9Us87wln6GekHmayV6pV16MAeOkWlul3pZZmhFCoPa1StJSqlIKtERliSVJImdRQeREK8jJ/iJM2dDIagMWo2yo5zAwBdOlrqqxvM7IiSQGBZH03mWAMK6CGrlpE1TajM34uoxNUGkzNuMbIK5eviiTWfV3iSGONfFVWVJXlZQ8j5G1wRqj0ZDhYEiv26PdEjPu5eVlWfkKMqmqYqSoPdZCmoDDkzqDsSkx7+Pb0zxxcZ6Hv3qKxbWCmhbGpthQc2TfDlJraOct8qwlRsidDnmrRSsTICnLFDhqCXOpAZia7VmWSQWTLBPWgzKTXFPFKmmkTAaTt/BepD+kjiTJqHF4m+KTFibJqZOMNZdyrig5NbsALmG616ZLSVJewy+e5vJTD7F4+RTbdu0lGpEm/I9GM2mWiZxjaWmRfq8PUdZDQ4jCbsBgcIRo+cjHPs7P/vuf58abbmHHzgP8/C/8ChcuXOS6667jumPX8zM/+7O86U1vIssdX/ziF3EWbrzxOj77mfv5oR/8u+zdvZOnnnycndu3csdtt3Lo4D6OXX+UfXt3c+utt9DptJmansZYYZ+AMIFsU61JE5NGevWsrGRjPAdYahKdZ4NI/31QaZws6bY0TTARVpeXmLl8Bavbi6JgdXWVpeUlAYuSVEEKMQg1Viq3dTpdjPrZJGmK1ypStffiOaXA0PT0FKlS+ZeXlhiNRmzZsoV2pzVOaIfD4ViGQERBKPFn6vZ6TE9P02q1qOoK72uK4UikG1aYZmmrDS5R9pkcZdQS0aicp0lQay9Sv6ASNpmgC9jUTNhReZ21Vo2qZcKepilFUWCsJM+LC4ucO3+OhYUFrs7NMXt1jqsL88wvLGCs4/B1R8my9bLTxggDKcuFAdjtdpmamqLdbqvcQaVM6mki+yFVI2dmZrh85TIzs7NcmZ3l8swMC9cWmZ+f54Ybb2Rycmqc+ActWy2fGWh12kxOTjExMcH2bduxzjE/N8/Zc2e5dPkyMzMzXLx0mdm5Oa7MzHLh0iUuXJTH1fl5fIjcceJOjt92G7v37Kbd6Y6BGO+9SIliwPuasigYjUacPXuW8+fPc/HiRS5cvMj5Cxc5d/4Cc/PXSLOcg4cOi28XYipvFDyQz9TEMwSGgyGLi4s88eQTXLkyw6VLFzl9+jSXL17i/IULrKyucv2xG8hbOT4IQ7QsCubnrvLUU09x/sJ5njl1mpMnn+aZU6c5ffoMi4tLHLv+GO1uRxIyZ7VtyzgxNp0fyzZLTp+Wv33iiSc5c+YsZ06f5eTTT3P69BlOPvU0O3ftIoTAwvw1Hnv8cZ555hSnT53hiSef5OTTJ7lw4QL9/gT79u2XxFpla0ar+rXyFp2u+N91Ol1aLSkpHhGA0Rjpn7VWE12Yn+PJJ5/k7NlznD59mqeeOslXn3iCU6dOszpY45ZbbpV+qb5BDTDUJOSSvK9LEhugGIS5JgSadWbSc8emsdTKoiI48WYqy5IPfeiD0taNwTojY+54DJOHQQEmbQPN6xhlHGnA3qhFMBpZklPpn1Mgyis7Lk0s586exlo4fvw4Fy5dZjQcMFxbE0+fNKUKkWgFRLDRYJVhFDEEI8D71xhCNTaAH3H9tZ6o9fdEOR/j98SIjc9hJTXsJmn8+lNwIxvAbQCUTPQQaoINeIKynizdiT4t42lXa2z1K9w4MeSmPVNUwwHLlcHYfDweeK9g0RjgijjdN9kvPf9RmKzynuaQ5I4pP6VNWOeYnp5iOBqxsDDP3Mxl7v2We1heWWEwGpGk4qlnoydtWGfqU5ioVF7MrBtp4EaGsuxDVFDGRzHBNgrMGx2LnZNxLoJKkIXFGmLAR0/layrvKRSEzrKMViuX+VlZkiYpuc5zXCKAldH+JuPZuky2Vq8jkVBLBUdrpOKvtVJ1FATo9kG997RNRPUOq+saY9a9l4wR0LauRQLqXIJLpIBEI19upG0inZQ+aseVRgV0s4iBu1fpdVmIDNo2gDCGm+7+lg3ndzM2YzO+XmITVNqMzfgGiNlL58elWo0xlGUpK8A6mSiLkhgjo+GQwWDAYG2N4XAEUSY33W5HWADLK+NEPVpZvY6+JomBxEScTTBZl4XScf+XTvLEhQVWQkIwGVUUKjmh5PqDu5no5LRbOVneIm+1yVttsiwnz6TS0BhU0p9N4j6WwmmluLSZ+OmjkRckiTBSMJa0LWVxI5boMoLNcJ0eZZpyZW2Nh594ig8/+DD/5c8+wH/96Mf580/ex7kLz3DPi+5g+dTjfOUT7+P85/+ShdMPkpiSnTe8AG/ahP8HTCWj/jIyiQ6sra3R6XbG1PYYZVU8BgNGyqunWZv3vPcP+fP3f4CdO/bym29/J3/37/5dPvbxj/G3f+AHePe7f4dOu0WMgff+/nv41m99DdcdPczJrzzGC593gunJHnc9/06OHj7I7p07OHzoAMF70jQhRJn41lp1y7mEc+fO8cgjj7B//z4FPGQGb1TSNs5NNh5Xk+WY8T8yydft62nQ/3VQSeahQeRK3nPmmWekRLGRilyD4ZDFa9cYjQptGylJKuCSc4nILLNMkrwkoShLVldXqb2wxKa3biHPW7g0YTgcMBwMGI6GlIUwfNqdNv1eX445BClTX9UUxUiYFt6DMXQ6HSYmJ+j2BMSoao/3nmpUYBED9egSOr0+PoJNRK4V1aCbKMyl5hw0lXxQEElPEBhJctIsG4NIDXupWS1ugKUmavUZ2r59O9PT02zbvp29+/Zx4NBhjt1wI7ccv43pLVuJMZIkstItzyUhSVPpl3krhyiJvMGurzDrarZTSW1/ok9/cpJ9B/azd99+9uzZy5GjRznxvOexY+cu8lYbFPhzzhGDJ3Vilt4cQ6vVotfvMzU1xc6dO5mc2kK705GEyQcpr57n5K02E1NTHLnueq4/diO3nzjBzt172LFjp1Rri9KI5Pxo8rSB0eK9p9/vs2XLVnbu2sWevXvZsXM3Bw8d5s7nP5/bbj9BmmUKKklZ+EZaFuL6CrszhqIosNawc8cOdu3exa6du9m3dx/79h/ghptu5MUveQlbtm4hxkhVVzIOBI81lh07drBz1y527d7LgYOH2L9/PzfdfAsveOELmZyc1HFOEjnpjgqiqETWGkmEt2zZyu7du9m5cxe7du9iy5at7N27nx07drJ37z7uvPNOduzYSVFUZFnOtm3b2bdvP7t372Hf3n0cPnKE5z/vLo7fdhtGjcyD+htJQosA9w3TT0G25tpJMxXQpukzJkampqfZs2cvu3fvZsf2HezevYcbbryBl9x9N5OTk2OpJlGZN89hKknK2yTlzXuFbbLOKlIgQStqyjBkCAhoGxtZln5mXZd8+Utf4tr8NUm4nSM2jL8GuGjGL02UGzC4Of8NAByDAGKJll83GJI0EcBVq5tZLQYQfMXK8hLz8/N02i1uuflmzp45TbW6wmCwxtTUJCbNKOuIdRmEDRCSMQQjHkXPhpX0eVTgUwEXYMzmkgGn2Sj/jLfrTxflGoxZShHiBjCJoI8Yxd8oyL1AaiN6ggnUDioDPhqqKjLZ7zARC6ZGC7zuxl287GDC7rwkhpqLKxWVySijAO9C4pHzbqN8j7CUNh7PutfheD+b53Kx5I0KMkbjmJyewhCZm7nM4489yktf+jIqHyiqptpaQStLSdKMGCOtdmtcHVOATQERpQ2JjMyA+CsZMM5ikoSqrinrWjiaDasQadMhSlVDaUdQh5poBCSsdTEhNdLuGxP0qihwWlyh0+lI3wDKuqLWAh/eBwEiqwqiwdpk7EOXpan23w0syyj7XNcVLllfHGuaQaLFFLwPArbqGI/eiwRIN2Lo3fwXVarayOK0n4Ug7cQCdVnpAor401mjDDwjFeqSxHHDSzZBpc3YjK/HMLGZvW7GZmzG/7Lx5Yc+rbR7L+BSlBVT7+uxUXdde9bWVpmZmRknlWmSqlF2lxAiZ06fYubKjFa10pUpH0iJ9Lo90nYP09/Ohz/3BF+5dI0670mlFB+I0chKYL3Cd73iTg7u6JM7sOOkPxdTbSsVpJxzJE4AgizXlXjdZq0lTcRk2Wm1IqtV3RrQySlLKRJJ8gQbDalr4V3KzKDgvkcf5ZOPPcb5xQWuP3CYg7v2QAx86vOfI8ssZnmOH/97f4ODYUD36hNc/sIHqQezpLuu59a//lMM3Rbis1Ys/+/FxpHXGLhy5QqTk1PkeXs86Qohio+EdUQcc9cW+Uf/5Mf49td/B7/6y2/DmYSf+qmf5B/8w3/AA5/5FOfOnebtb38bE/0u3/atr+Plr3g5iXP4YkSqzC0fxa+krr2WR7eUZYkPgTTLuXD5Kk989asUwyGTEz0+86lP8UM/9PeZnpqE4CVx1YSrWYfeGE1i14TOXdezgQ3H/rVApWYiLKvyDTNEM5ngCaOSD/zZnzFaWyVLE9I0Y35+jvn5ebz3dHp9pqenmZiYIKo8xQfwPjIYDFR2U7F9+3aMlVLRi9cWWVpekj5Sl4xGI4bDAYPBkLqu2LlzN0ePHCXPc2pfU4yE3TIqCllxdZY8z+lPTDC9ZZpdu3ZjnWVtKH9frA2kApJLIG3Rnd5CdMJ0C0jSnTpZES8rYYVsDJnEC0AknheaCKokrkl6nLXjhBtdcTZqoh1iYG1llcHaihpaJyRJinOWVrtNu9vFpeJ104AkRhNTYS013jbCRBEgrGGUSNJaq++GgNNrkvTUNXku/mhpmtDpdMem6N43xuO1JCSi+RFDVwPDoVTVq6sKX9ci4ytLylJA8OiDSl5FKttud8jbLZIkpd3uQNPsjEix5HvW5YNeK12OhnK9iZJkBSKtvIVLErrdnhjiJo2/isj1xBOpFGAyE1mJGOqK/M/XkjzVvibPciyWTrdLq9MWQ35jGA1F3lIUBaGupY0QKRUoTJOETlfkwFEBI2Ij3xIvYxQwtArA1FXJ6tqqJJEKGDvrqGsBWrIso9PpkCQJKysr2o5HIic1FojkLamcNzExgU0EwHNOwJEGOBIQR9qJD540kYS2ObfCjJWqXeVoRDFYpSgLvFcmCZBkKS1lEaaZeMcYY3Ha/o0VP5uoHi9yKY2wDLWN6kbNhiMRNoAv0l8i4Bu5UTPu6PsXF6/xL/7Zv6Dfn+DixYtgHC5t4ZzTIma6v8rIW/8uI553MkwJY0/ZHMSobUT+Rn4GfO1J0oza16ytrjBz5QKjwQr79+zi8KGD9Cf6fOy+T7C8WpDv2Mfk/uvxrSlq18HHRsoXiVYoQuKNJD58xghoMb6tmIYdKudCxtDmd3KOmj+nAVzHvxaxkhCjmnFYmFcCq0oIiBQxUeWARIINhNTgJtq0J6ZIkjblypCtZsCRZMTfvOMQt/qLbIkXKG3GBbuDD140PHqpJmQdvEkpQyrOgUYe1oQN51dBPWNw6hiFsszk93LNTQSXWOqqIrEO4xwtZ7DlGvPnTzF/+SJbJyd51bfcK+zHy5fwdaWyV1TyX+Kc4+rVq6yuLjMajVhbk4ImdS0SMu8jVajH9yhhc9e44HEh0M0SOnlCX+c2iZXiIVmSkFhDYiJpYnHKoMudpZ8a8iSj32kzNTFJt9sDY2l3e6TtDp2padJWTtJqqZdlRpI4ilFBu9WmKmuRL1fCcsUIsASN9Ewka3HcJpMxg9NaS5YLqFardNNYI/1wvXXJuA9EK/590melHQnDtn7WvSGUFYkyK416/jUAna+1QIV6HL7+f/934+/ZjM3YjK+f2GQqbcZmfAPE5fNnqeuauiyFqTEaSdIRvCQKRowVR6OR0J29ZzQcEqPIasqyoN0WGdrq6hq1r0kSR5bneJPish4m71PYNmumy31ffIoy7RJcTiRSB2G/1HVBqEfs3znNvl1baefCKsrbLbIsoZWL2XGaqKxNfZHyPBeAKREGSpLI8zRNsCp5a4CkxrC2kYY462inOS5pUdkM35nkY198jLf+1jv56oUzFMWQrZ02N+7fy417d/HqF5zgW1/2Mu44eohHPvEhXveK5zF37nEuX3iGKhqqfJL9d96NjwlRprQg06nnrBo/BzxpFAYbfml1xc8YkS0VRUGn0xI2hYEQvax+GnBpQpa3+PBHPsJdL7iL7/3u7+SO227keXfexovuOsHBA/u4/ugRXvPKV/LaV7+Ko0cOkxgnVq5Wzr/BUFQVH/rQh3no4c9z7Mab+fCHP8JnH/ocV2Zm2b5zFz/zM2/h/PnzvO61r+GzDzzAnj27sRZ279ol+2GtmHfqqmdz3OPjX884nn28/01I+sd6XqPPJUEwOkFF2UghyKTXAWdOnWJ5eYlE2SzD4VAZIpa69toWBOgBw+rqKkmaMjU9xfTUFN1eh+FoxNLiNYaDAYPhmrL3AmVZEIJnOBxSVSVlUeKsY8dONTI2RrwurKysRqIyeFqkaUqv36fT7eBUhjQajojeE30QcNA6krxNkud49ZaQpFPOiY/KWtKJu3PCEjFGKug0MhujTA7vvQICcq5EaiHSh+ZvnbKc0iyl0+4yNT1Nt9dncnKKdlOtzgqYFIL8fQhhPPF3zmlbbi6uVj7bUB48BE+SpQI0OUuSpnS6Xbq9Pp1uj263R95qi9eMAlSJSyiKgkxZZMHXxCir382xNzJXkYO06U1M0J+YYGJiiuktW5mcnmZicopev0+7LZUjpYqigG9KehknMDR9UVkBWZrqWJLR6/Vodzp0e33anS553hK/JmPH7BnrBHiLIRCNMlT0mjUr+nme0Wq1aLXbdHs9qWrZ7ZJpWW4UDEQBIucc7VaLLMtpdTp0ul0BoFotMSh3TiQrDVlE910PZdyGrJVqe61cSqV3u3I8eatNu9Oj1+uTtVpY21T7c7TaHX1fl3a7Ta8nP5MsUzmLMOmEmSVATwPMjdtWFEChST6bZhLV0DhNU1KX0NLzII+OnON2WyoENn4zygKhYepp8mqMMKGk3YgENDRj0FieK+cmSRPpM7oNI2bF68CD3O9iFI/B9//lX5ImCTu2bWVubo5Wq4OvapHSGmWC6f2kOVbZZ2GrNWO5VVZWmklSbhQAbvpV4hJ8kHF+cfEao+EAA/T6XRbmZjmwbw9bt05z6sxpfFkS6sBkfxJw1Bgq7ZvWRJzuyzikYawf84bfGVAEUjfqe8cP5HXU14IPyPgsYNK6hEne37S9gLeRksAo1ERn6UxO0N02Tb5lis7kBJ1uh8mJPq1WxnBuBnftAsdaI2yrxVNXlpktc65VGQPfZTj0gKVCzrd0EDHAbwCz5rBDw3DR/TfNcUbEL0sl5M3fefWjCxgmpqbJshbzc3M89cRXuOPWW5iY6DM3Py8+cdZRFCPyXDzKBCxH2l3TNr18B9oOozHgpGpi1LEbg8g/y5p+uy3sLmOwWsnPKCPIGpXSKspnYxgvrsQYCXUgz3OquhrL8NJEmEBRdkA8k7KMEMQcX/qGIU1SiCL7DVq9EISthy48CGAbZQzW7Y0dAk1FXytzwSRJdEFSiwko8y9G7QfWUlXirYlujyHg1HMKo8cUvAJMOnYpa9Qas8lU2ozN+DqNTVBpMzbjGyCunD8LukJUlaWsPhkxUQwhUFe1lkYXLX1dCcNgeXmZ4XBICIGiLOn3+/T6PUngnSVtd/FZnzqfpM57rISUh588y4XlkjptUxuDtRGMyKswHkugnURuveEo3ZYYaqd5TruVkThLluYidUu0gpsTGnYjcRO5m5iejj2UlIXjlJ2UppIwWefI0hxiSp20OT23zG/+7h8yuXc/S6vL/OM3/EN++Pu/h++656WcOHqA63ZtYc9ETo8Ag1Ue+9Lnmd4xwbv/6PexnR4ve+13MnATTOw6gkm6zwKV4GvJuXTCO/6FTuA1vPoRSOIWOHv2LHv37pZ3GVlRRCu51L7GJo6rc1fZsWM7dz3/Dm4+doROK+O66w7TzjNiDCTO4owlzzJQA2WnYIR1KfPXrvGJ++/n+Xe9kCtXZnjs8cfBOrZs3caDDz3EgQMHhDXha44fv5Xrjh6l3+sy0etpgqUSDk2Ox7P58axeY/z82cf8tWIjGDX+yOacGTBOmBHOygr0/Owsc7OzWGNot9tYa1lZXQFjWFsb4L2n3W6PE85du3YxNTlFMRoxNz/Hysoyq6urFKMRa4MBRVFom68YDteo1XA1eGFauCRh27btMum1lrqSsszBN/KCDKdtsNOVpNxakZlWCuaaCCFKtaC80xWOl3XQsIIQaVYcsyNk8t3ILqzKa5ptzmo1KzVPzjZI4Zqk33s/TgKSRA3AlWWWZfn4/CeJGyfi8nvJHZ2zJLp63eSeDTsFBX0EaJHz7INWvNK+iLEkiYA2ZgNQGBsGmffkeU5ZlWNABgRwkWOW9yfjCo8ZaZqJTLbVEnA5lW1pmgnDsmk0KADChmpdTRhpc0mSjAGThuGVaAUwAQ2EFSn9UM+1JmvWWeXRKRtGT5BzMu6I54h8jrECOJixD5AkUwLKCBg0fr96lSSpAOrWynUzDTNA/lwTV2UNbXhYZXRa57AKrtokUX82AX6scwK4JwJCNd8jrzXJcw3QKeAlRsY3awVgDEHMhSV5D1i3LvvyasQtybKAZ4mzuCQds0qdS8beVHaD30wDXsQN51pYUZp0bgBZ19uq9IHmHMhniYyz9lJSHSteL3IdxYfGWcvS0iK//Z9/izyX+8/09BZmZq+S5wIANtdWxqgm8RWgv5E+JolKjRpwqWFVNSm8SkqFtSVV9wZrq4QgnlNpknJtfp7FhXmRLe7exbkzZ6hX1gBLp9sjGAOJVKfEB2yQimTS1AXeaMhICu+PHyiW2jxff71B4tb8DlTWKQBMUAAzRgX4gngmGQKVCRQJmH6H/tZptu7YQbSWovYkzjJcmOPa2VO4lQW2T0/RiTX1lTO8+PB2VtIuDzz6NEl7gqXlZeaWA8FmIn+Toora34K0E6McKWOVQUVTKHV87ONj0mvcXGvUTFpYd5FoEtrtDjZG1paXOHP6aQ4cOsTUli0sL69SVSWdTlvGs2aciCIva/rjaFQo4BkJCg4Li0oBY22PKCDny0oB94Z1amT8UOaQPBWTemOCyGzrmrpuxv9mXmMZDtYYDFbBIAzCqiIEkVqjfdxZ+Z6oEjSrht5Gb7AbxwujMmS5RwhDyep7Q/ByL9S5SpJI/0+0empU3zD5bLkgzhh8XRNruU8F7zGN15h1lKV4O0k/kf4UG0ZuDJtG3ZuxGV+nsQkqbcZmfAPE5fNnxpNtX9UkylZqJv91KeBS1JXb0VAYS3UtchGrNH5gbCK6VpSEvM+DXz3DI89c5smLs3zl3CVmVwvqvEeJBRuJdUmSZIDHWinfWw7WeNmL76KdWZLMkmYtWllCaixJmiugpMwk9ciRlezGM0kSL6dmmM3DOkn2rEswWFp5mzxvMwot3vvBj/Mvf/bn+PAn7ufFL3kxrbrm+17xco60MnoU9ExJVi2T1vN0R8s8+vCD7Dp8PR974hSPnr/InsM3cOddL2Xn/psY0cWmnWaaviGe+1pCJpfP3SheIGma6IodPP7Y41x/7Hp8Y45tZLLZMJequuL48VvZu3c3+AobddJWyzW11rK8vMxnPv0AR48cBQyf/vRn+OSnPsUNN96EdZK0/t7v/z7Hj9/Gnj17ef8HP8jK6iqtdoeqKrn9+HFe+IK7mJ6c4PChA0xPTbJ1y5RI8jQzkZ9f45ieE80k/68KSdg2vl7/VxZvjWQPMYwfZ06dwsRI3mqBMaysrpFlKRMTk2zZMs3u3buZmJgEK2agq2trLCwssLq6QlmWDAYDRsMRZVmMQaKiLKirUldRm5ViSQp37NhOmor8KIQgfmJIdt+wTdI0ZWpqko5Kr0bFiKrS0vU+4NIMm2ak7TY2zTaISdbPUlB/nGbVtwGLZJVXJuJWk/z4LCmXSJMaIKlhKhFVpqrfYpTxFBUYQpkuaDK58UJYZVj4WlgWoUGWmmhWsZ2ATkZBIdNUZFMQyxoBIZvvaRL1oOWqrWlAK0Pl68aGBKPAVXPMVscAYy3OiuE+GGFNZmKurgeqQICAAZIgyTb5fkmYBLATloCxwpBKlCXV7KuwYHSHxmCOgGIxrDN2jFXwBSOAthXWwnqFyHUQVq6DfJC0bCmLHkLEJgLUiVyrga2Erbd++qXNBK/sqyhsIn2zfk/TphSQTbQCk+5DiAGXOqyTdzlncclGHyLGSTKNwblLFMhSECgEQhBZjPdSXa5pf1mWaaIqnlxOPZfQnw2jw1kpF98QaaJei4bhM95naSjjawWAMqkEjtKBSfc7aqLcsJtCDDgr+2KNJfoo8u/RiD9673tJU0en3SHLc6antzB7dVbaQoxjWd/66W2AJrmWchG1cqNWfGv2OVWgM0QpelCVI9ZWl/G+wkekIqCxOGukEuHKCsduvJGpXo9L5y9QDAe4xNHu9Wl4JkF9bqJeZ4TQ01w5iee+1sY7Bp4aZKZ5V9RjQdmH47FPwFRiJPqK3FmMr4l1gZvssePYUfp7t5N1W4Tak5qUajhi8eJ5kvkZutcus2W4wFRqmbaBXXnk9oPbOT0wzC2tcfvN17NrIuXs+VnKGDGpjE0WZUZhMFZkwrDBmFuPZ9wp9XcbX7PhZQzCgpKSdCm+9vR7PdLEsby8xGOPP8ahw0fYt38/szMzBJWDZVkmYIcyYEPwIuW3IsfzoZElK4CtDCbb9D9tB3XlKSqRISdpIkbuQXy2xvvbgHtWzLWj+hFFlaL54MnSBEMkSRrJswMt8hDUK8mq75qA8OInaa3BWBQMb8D6ZGzePQaYtG03j/H9pmEvIQtgVvtwULatQVh6oRYvqODluTVyXYLXSqhRGFFOq5yaRtar46exlhtefI9cu83YjM34uopNUGkzNuMbIK6cPysael1NRX04vCbGVtkNQSc5DQhSKZOpqgpCM5EwRnxQbMZXzs7wpTNXWXMTrNTgjSOYhFGQFcU8cciU2mEJmBiENl57XnjnbUx0MplUpBkJkDmHS3NZqd9QhrlJLF3joeScTpI0gdWJj7HCagBwVhLEz3/+EV79/W/mTz/8Me68/UZ+7Wf+Na944QkuPHWSY/sOs73XxsaS0bULPPnpPyY9/1FmHvwIS/ML7Lr1RfynTz/BzNVZ7j1xGyc/eR837j5Ma2oXuFzmgv8X4muCShihsCuYZ63h2rVFJqe2SMLsUikhrCt63ktiH3WlPLGOqqp4+OFHeOrkM3S7fT7/hS/SaneZnZvjsa88zlNPn+TK1VkOHz7Mo48+SrfTYXJigscff5ylpSWyNOPEiRNkScKRQ4fwZcmLXvB8tkxPsHWLmJomTo12raxaSlLaJHp/Rch8GvMcNoUxRhOY5m3/fVBJkkMBI1Aq/VNPPEGoa9I8o91pYwy0Wm1iiFKeezRkVBaUZclIq7WVykgqRkOGw4H6iwX10qhkd/W4zJgtIX1ix44d5Hku10v7TPDrDA2nUq1er0eW54QYxyu8JsrEeVRVFJWnPzmlPlkCGqxb8EbxH1PGT2xYSQ3zpGEhjSsKSfIw3uENAJFsUuDJWgECiTAGWRS0VMmDUWZcwwpJ00yOrZE3jc25AZpkXo4/aL9GAZpGfuE0gaFJUp7FRjFkaYYxIlkUEokRwY22GWcEkEJlGsjujkNAWWEYVVUpYIORbFhOR9zw0P3fwG6xmhQZDGmWU5ZSzIAmsd7wMNpHnUqtgpfXDbDURHPOm7FUzrgk/wKQyKUy4+cCZjXecuNtY2P25qrJWGfsuszNKFhjbTJuH83vBDiTbUb9gKyz4qPitT8rE685pw2A86zvMpLspamMR2ZcZl0qpTUAn3RhZUgogyki58GgFbKedUWEvTOWgOo4HmkMhZuWJp8jzUjGvhClLTT3KuvWk2HG7UuBtvH409zjFGjUdlXXNb/37nczHKyRJCmtdlvbf8LqygrOOdI8U3mSgAdB5VXS1yThbypGohJhI41BAbeANwZrwZcjRmsrhLoiRPF6q6pK2aRa7t0m3HzDMapqxLVrc6wtL2HSjHa3B8ZhkpRax4gG8Gmu4AbkERSy1k43vs7NWPOc7iHnTUFf2/wnlk0QAgkR6goXPfVwDdPt0dqxjWU/ohgNWJm9xtqVeerFJSaLAbuLa9ycF3zT3i537JticP4k123tcmjnNF+4tMTqYMDBbX22JkOO7t3KVCtQDldYGkbx3/GRiAXjIEi/MzHiYsQqCtmIHG1z2Core/bxqnG0ms0bI16QMRpa7S5Zq0VZVTz5xFfZMjXJoYMHWV5ZkXHESsWzjW2Lhp2XCGvK1yIHk3Mn1Vulz2vf13Gn9J4yCPPVOWkPxkBQvyKrfQ5j8EEgfgzUwTMqhiLrM5FuK8cSqasaImRpQpZJRbh2O9f+Kf2jroWpFxv21AbWn/e1sjAlpCmJpNUpo6ooCrxWEs3zXBlJstgRFaZrzneMIoU2UXwXTYyM1JcwohJUPRdexx6rLL8QRfodYuCmTfnbZmzG12VsgkqbsRnfAHH+1NPjVTGjJdGtggRNOVfvlebs5X3Na1lhlknUqCjwUX5n8z7LZcITF5ZYiy0CVlbMDDiXY7DYGEljJEYL0WuiDtYHju7fw4E9O3EO0jSnZR2pcyRZLpKZDWXak4appK+d0q2FoSSG3dY5YSnpqlmSZhANn3ngs/zhez/Gj7z5h/npn/gxrt+/FdLA2UvnydptdmzfIslRMeDyVz7Pylfv5+pgxJbn3cN/+IvP8qVzC7zlh7+PfeEy9cwTHDl2lKQ7hTcJAZER/lVhTMM42BBjRoq8MMbS6/WZm7vG1NQ0Vn2WGhq7sSJZmblyhdOnT7Nzx24++MGP0puYYsfOPeStLufOX+KBBz/HldlZprdt4bYTt3Np5jIzl69w/ZGjPProo9x0003cdttt3H78OLv37Kbf63Hk0CGOHD7MDddfT7uVCJDk5XoJ7iDGuE1i2iR6TeK3MWTq/38vmgn4+uv1fxtQSRJPgwmBNEm4cO4ca6urKo1MxxKa1dU1VgdrLC8vU5YlRVEwGgwohgPxOBqNGKytUpclIEalwQuDTibbyr6IwsLxtYA3W7ZsUYaPggWasDq37umV5zmTU1MCPnmvTKWKUNWYqNV9jKPd6+EjGCsSMQE45MyNGS4NCDJOAGRFvAESmu1JkkCMFOp3ETZI2EIQL46yHJG4pnqPrGgb/Qzva5y1In2IURlGwlyJjQ+GggwClEjy45yjCjXWWYpCvtsYKQAA4MZsn0Y6I0SS5hiCys6CJllRGT6Jk7+x2rbkb0WK5ew628YqgOR1dV4+UxMnpN3aZsCJsuG57VUSTGFAFaWAUg0Lpkmw5dMEiNBUUT5OP8PadaYT2n6I68ln45NiaJhcksU37x8nkV4YEPInkvA115wYxWw9CBtIPaelf6Kf0xyUAn7yLXq9EV+aoMmb0RMUlJFijLAjjAJKDZsHvVbNOTFG2DpZmo0ZSc2Y4L1IwaqqotMW6VCmQEsMQatfyX6FGMAaKu1bQRc7YlSqhg6WzfVqju5r/Wz2WY5EQtpDA8AKyCXwngJgCJiYuoRiOOQ973kPw+FQJHrOiqdUmlAU5fgayHlScKrZRW13LlG/K10gaLajf2OdowpgYqBYW6FYW5WxJQSCVoV0zlHXFWC5OnuVVivjtuM3s7q6zPzcHMWoJMk7ZK0ewTq8FYCwYR6Nd7JpCRu3S6vYsF0vxIa3NW3bxIiNUdqtHqiJ4GLA+Jp26hisLPKae+9hcmo7l2fncZlj8fQZ/OIqaR3Jfc0EQ+49foBX3baXI5M1WMvlSxc4ceI2SpvzwXMjLhUdnjw3R/CG/f2cw/3A3h1bOL2SMRwMtL1ZYrRErLCUItgYcAhzL+oRG6SvyzFsOLCIMgEFCHRETAz62Q7jElySsmVqgmJtmaef/Arbt23jhS98IU8/8zSpMqVrXdRppKohBPJWhk1E3tW0cWeVHdqcV+mkBGOIVoCVqpbFDOcsFunr0n6lYqJ4ygkTKhqwzhBiTYxSRTD6mnaek6e5eJhFkVHqoIexArQ7XXyT+4vMjXwtRREEUBcASdqwgFLNYoUsaIkvYaIMzuY+JNViZZEgeLkXNlYKvqrxlXo/Rekjzrrx+CLeUOKtlGWZMlNl7taM7Te9eBNU2ozN+HqMTVBpMzbjGyDOnzo5nnTVmpzITV+Sm9FoRKkr/c0qcIyRWhkcSSLVQcqqErPIuqI2CWuV4clzlylNhrEJIeqqJgJAGKPlt1XOYZ2TqnF1wd7tk9xxy/XkLpI6R5amAiblUslE5G+Nb1IjdWsqvj2bteQSi1U/EADjnEjgjGV5ZYX3vOfPed1rvoV7Xno781cv8svv/gO2HznG4soyNx7cz1IwfPD+z3LrbXcwd/YkR77525nbfgu//Mef5MTtz+ONr3wesw+/n345w+4d07i0h3Udgms9S3bQCCLGE/txaKbUzICbJAVJNJsEZGKizzNPn2bvnj3iJYHME6NKYYIXcOcT932Sm2++hc8+9HluvfU29u7dy0MPPcTc3FWuzs5w6NB+jl1/lK1bprj5xmPs3rGdY9dfx5Ejh0gSSyvPSFNHYg2tPCXLHFniiNFjxuwClfiwDlzIvspkN3ih3D83NDV51rlotv23ob9/zq/kpW40CONBDT/BkGcZi9cWuXLxAlku3jpZmjI1NcXMzCxLS4ssLi4yGg6pypIYAlVZjg29fe3H7JrmWA2GWj0oGqDCe/EYy7KMfn9CmCpatcyHRqIooESapuStFr1eb1xGvCxLTTAk0fQRonW0exNSBUpJIuuJiJGEQ1fCQZISSY4lCbC6ghzUxBgFLK2CftJm5O+dEzZbmqTKUjTUoSbLM7yvwKr0wKh0JBgCFmMda4MhD3z6c+zcsVvYf1EAryQRpoasLHtJtpKUJ554kt/53d/llltuIc/z9XYdIxCwJmK1NH0DlvlQY5OEmZl5PvrRT7Dv4G6p6pg0RszKSIlBfEtoJGYqu8MQw3obMgacE6ainFkvSbEyeECBCxrmishDv/rVJzh06DBgSZywTKxVwFfBKGONsmgQwNyKFMZYrSwXI1ZBlwYoQvdZjrdhzWizHkvLHKOiZn5hhUGxxmCwxmAwpCxKBmtDBdJTVpZXWVxcZTAoGAxGjMqCOgTydhfnlA+aJMzNLbKyPGA0rFgbDimKihAMNk3HnlfRICCqXe/jxiorTduqUcmisIQsly5f5Y//9M+4/vrrpQy5s8S6IoSasqq5cPEqT518mj179mCMsFzf8c63MxyOOHj4CJEaEEZScw5WV9d41++8i6NHj5CnCb4W8/ZoFMSz6+DHxuHD6NUVgEhklFFZItKu1EcpytjRXIOmXJ6AgA5DoByu8sfvfTepCQzX1gRoSHP63S57d+1g7uoMVVniXIqxiTAMo45Zphm/m/FQFzUUSIoK7BpjtGR9yXBtlbIUT0KXSuXDEAJ1JWNFxGJswuzsDO0849abb2RxcYGlxUVGoxHtXg+bpuKxFMVA3iJgUHO0Ue/CJoIl4pQxN46orxTDM8023RwiEDwmBvDyM6GmXl1kKrP82A+/gTf+4F9n2/a9vPeP/5jpHduwLqdYGZGHSNtBQgXVgE4nYWJLny+cmyGdnGD/DbfwxPyAz171+Ol9LIwiV2avwtIVbtjRom0qnjx/jVEVKEJCsC29f8jOydE23mRy/CaCCR6naxNR+/l4/NF+7L34DjWMyQaIEeDGkbZaeB84+fhjBO85cecJrszOUNWeaBzGJiRJJsynxI49yIwC6KFhBhkjbF4rexMaQ22V+XoflIUl+yVdTOZedV1hohFJsTHUwVPrmFXVFb6q5RjVjy1PU4bDASGKJNtqQY4QA76ulXUmbKkQBYk26mdnrJGKn9qYjbWkCvQkWSrgWdOuFBxKk1TOoQ9SzMXXlKPRuEJnXZU6XjZjXdTncs2EiSf3zBCkwrDcJ0UiR4zcvOmptBmb8XUZcufZjM3YjP+lw+nKlTAD/Ni4N4RAWZSUVUml5cCLsmA4GlLVJc5ZWnlO1AlzlmVgDFVVi7SoGmDqVShXxFzSJngcMVTYWAurI8sxSSBtZ9TGUdQelyfMzl8FA6mJtBJJZKMTI1eXWKWHywTIWpl0WeVaG2UhWE18jK7UG2NIs0wm9CYSTOC6G45ShyGf/tTH8VWg25vgvkfP8Cu/9+d85vEnGYWC+548y6/f90V+6s8f5uj/9q9J7/hu3vfwJQZmgm+752V0bM6BHTtJyyWefuDP+cx7/wvLF84IDT9qBZr1efr40WyJTeWpDSFJsNLojSQpde3pdtokiUr5EvGJcomT8tVEet0uhfoBfed3fSf33fcx3vH232DPzm3c/aLn84Yf/Nt817e+mhsOH2CqndOysHf3DmKsyDMLVMRYQCghysPi8fUIi7I+WGd1WCOr+jq1lAmyshO+VkRdc11PV57LpNDQ69gkmBsjGmFrYCPGRJyxJMbhcPgAozqwe/8BjJVy52VVg7G0Wh1279pNMRpRDAfMX52lKkYMB2tixq0m9JJYrFcEqnyg8pKYRs2vgjIn6qomBFlNLstqnECIYWnAJcIskuRSfX6iZGbRy+p+UD+Mqq7U3FdNrY2wh6JWQgNIEmHlOZV+ou06AkmajpOlLE2VdbJe8Q2VphrtE3IyJSEJQTxYktQRYk2aO6yLiC+Noa4hTTuE4HBJi9OnLvAHv/8XRDKszbCJgMa1L+WauATnMpzLeOLJk/zCW3+R3Xv2iqlwjNS+JsTGI0gSOOcEIEGTbpeKifQnPvEZPvbxT+OjJxqDj4Cz4KSSXABcmgo8YCRzdM7hQxAQADG7R33K6jpibYJLxcMnRAE2x6wYDDFYDI5Tz5zm4c99HoIheoMVahxEsDYRCZlzum9SWUzYCg1r0qocVI6xUSMKS8DhjHjDGSMSHKur9WmaY21K7Q2PPf40b37zP+VNP/pm3vimN/OmN/wob/ihN/NP/smP8eijj1NWkQ9/5JP86I/+GD/6//kxfvjN/4g3vulH+ME3vJlfedt/ovCWGku0Cf/hV3+Df/xP/iVveOM/4g0/9GZ+8O+/kTe84Uf5xKcfAtciGGHWCaAklk/eS/IpiaaYCRuTENFxN8n47Xf9Pn/y5x+kxpC2MqqqwgQx4M3yNu945+/y8U8+QLCOKop05wuPPMylmSsEDINqSNX4x3hPKEsGa2t89oEHuLY4j7GRVib3Gvni8XAwHpOa9myUuSbgrySshnVGn4C0eh1UJmi8yGadHnMdA5iAo+LAjil2TOSkoWRhfp7ZqwusLK8wWFlm99ZpTF1hQaR6SSbl7K0jWmmbdSMZV/aGUTZgiBHjBKxPYwV1IfuIxSOeMlmSkFmEQQNEYwk2o6zhC498mfmrc3z7q+5l77Y+FNeYO/tVWFsgL4e4ANYkmGhwRiRqxEiMhqDt2NWepK5BgQB8kPYdgj7ELNoEMEHYPx5h1JnosbHG+hIGK3znK17Cu3715/n+197Dgx/7DD/9E/+cWK4we/YcvfYU3ckteGeoKBhEy9myzSeuWt53KfIlM0nvzpdyqbONx8qMeW+Y95G4YzcXQs6XZlZYrGAys3zH8w6xd0uHiKGqDbEOEMSMug5QB0eJI0SHixZqOZa6qogxUIdAUFDaIHK5oAxKjCx4+OjBBOpQUYbAMDrob2frgRuYnt7Glx/9Mp/+zKd57etei0tTJqe2kOVd0qyFSxPyVkKSWDqtNpMTk0xMTJC32qRZKhVbrdzDRZoJibE4BaONa1HElKWh59qgZoSjMpY6RjwiHy5GhZiK24yRhyJaypgyrGFlWLCwvMrs1TmWFucxsRZrgbJgeWGBUJVQ1SQIw8zqYpEsKCowrqDVsCgJGEySyPdHSFs5JnG4LCVr5djGx845qrLEVzXlcIQJAjoSghpx16Spji3OYBJD2kpJsoRWOydNU1qtFkHHV1/XlEVJYi1WJXOJLhpsxmZsxtdfbDKVNmMzvgHi4ulniOPqGyKrCiFQjAqqSlaJKl8TNHF2TitcVZUkvIkTZoL6mhhj8OkED3/lNGcuzzHyMlMvBmu4UBLLNayvINT4ckTiC4Kv8SGSpDkQsXied+IOOu02eauNy1okWUpiNyRk1qrMbd2st3nurFC7Zbus7DUT+yxvCWsgRqamt/AH7/44c7MDXvdt38n09glGeY8HPvc5Dh89ClnOW/7LHzBfwxOXZ/ncpWXmKsf7P/Rxjh88wG5b8/wbjtCLC1w8+SBJEth1/QvYdvROfD6llWjWwZON8dxXG3/dJEGm8QLRfV9YuEZ/oi+gmbOICkVYHtZIsmSMIxDZuXsnt95yM3c9/05279nFxESPPM0xKj9qvvBrATf/bUgmJ4SKZ3OujNn4ev25/PtssEyO7DlHrivI/6Mh+yCfarV6VZ6lPPPUU0Ckrj2dTkeAzzxjaWmZmdkrrCwvU1UV3W4X55qqVetmoT6Ix0pUACmoRDRouWPvZfW33W7R6XQJwdNqtUDIHOPrliQpWZ6T5TkT/Qlc4qi9VNALKiOMQBUCSZrT6vYJRhgJ42ukZyiEIBWh0lQ8nxoZ2QZ/JWPM2Dy4qqrx/jfbUeaS954sz/Hek2eZyt60opOPGJcQo8G5DGNTiJa8nVHVJXNzc3zykw/wyntfQauVyjmJURJxl+JrQ+UNc3OL/Obb38E33f1SXv/67yDLsrGUzxgjrBbrSNMWZSmm3jKOyGp2CPDEE89w4cIML3353XQ7nTG7IMsyYgDrtEqbkZZXq2l5iAZrUwV7nDICRMrhEkddB6zNSNNcrkGI5LmwESS5jBw7dj0vetGLyXJhOBlbY52AjTEGognUsVYja7nWKAicpU4kfTHiDKTOYKlJnYXgsSaSpam0YK2a1jDhxEjdUFQ1p06f57MPfoE3vfkfcO89r+RlL30FL3/FK3jJ3d/EgQOHyPMOJ586zZcffZx/8k/+d17/Hd/JK+65h6OHb+IP3/unBA/Hjx/HYPiTP/kL2u0eb37zm3nFPd/MiRMnmJmd473v/RPuuusutk5Pi4+YFyP3ECKJy0iSHOMyfIjimRcaUN8xKgMf/ej9DIcDXvOae8mV5SjXOKEOlvd/6ONMTk7w/LvuxGkp85e+7GXcfNNxYpSqnFnSwtcVxghLqt3u880vfTnbtm8j+prUpaCAsvR3GTg2/mzGywY0lR/yvIGznRMgvIkQAoYG3AxSddFYTKwp1pb5/Gc/TV2McC5lUJSMypLEQKfdptXpgnWsrg20HQYSa0XmqcwokQo2VQbldXO/NNYIM7IuCd5TlgVVJQCHNB2V0+oxBR0nstTS67S4Nj/HxMQEt956G2fOnme0tEpZBfqdDibNREZrRIJkXSL9OgozTiAvKXevWOc4xuPx+DRFeQiWL/d4/Wmqku951Sv4Vz/6RnZM9vnNd/42/+Lf/nuKdouirpme2sIw1EzunmZpNI9fW+A//Juf4qXf9AqeubrIfG+Cevogl8qUU8ueSyuB2dkVBktrXLf3AElVki7P84JDB3Ax53MXV3hyvmLZ5wSbYYJXTZsRZlYMGCoS6/G+IM0ddQwElzAKER8NGJk7BF/jjC516CFuPO5Qy1gnKAjDAAD/9ElEQVRgtbpm4iy9dpthWTN/bYHTp07xoruez9yVK7JYZiPWGYq6Js/b2EYOGaUAgsyvvI6XzVl/blvW0b4Bu6JUTGvadqLVNo3Of6yRYhyEoP5WER/EEzN4PwY1rXq8iUxWGFPee5LE4WPEpQnOGogiY0YZfI0HU3NvIQoA7r0X+bP6VFVVKQCuzk0whhCE5dWcQ5dYsjxX3yi5v1ljqSop+hJDs+wkMu5GNi1FAIQhumnUvRmb8fUZm5DwZmzGN0A0kxWpVKLlXqOsrjcTj7qqGI1GIhEqS0Ao/ZKwyopvonTvJEm4eOkyZ8+dp9NqkRtPvTxLOlpge1Zx675pXnTTfl52+1Fe/YKb+aZbD3HDrgnyapmckk6WsHBtkdVhgUlzArJqnmgFJtfI3NSrxm6UujVG3Y1/klKpxftJtsmKZWMAa/i3P/3PuXj5LH/50Y9yZa3g6rUZdu7ZxsteeS//8b/+LrNXr/CCW6/jld98J5959GHe9SfvpSyX+aEf+B4e+9IjjGJK1t9CxJKlLfadeCG2MyE+CQqzRBq5C+tbYgPA/LcSL1SGIcmxrlLHSN7KWFtdBa24ZLUykkFkZ9ZarrvuKL1uGxM9zkay1BFqAQBTLQscQsAZK1V+nov7aEiSy8bMQmszP+ch7372+8bbnhsRpBj1hsfXiDEw8+zH1wz9AJm8ywpnnud0ez3qer3kcVGMGA1HHD1ymB3btlPXnoWFBUaj0Vj2KRKFmroSz5rnPhpgwvtAVVUUxYioUtDRaEQxKlUSIAmts8r8MGJm7BTcDGFdjhOCJPEbE+I8E9NvkQBIFR5jJJFoACFhFmrC2ZQu1/20auScpan6SknVslSlikETjdFwqMmLSAvE7N2SZC0gYWFhmaefPsPVuQWiSRgVxfgYjEGkbDpOxBBxSarkBsPszCL/57/5Ga47ejPf/u3fRSvrUFeeEKUHWOvI85xri8ucfPoMCwvLhGhxSYaPBuMcSZpjbEI0DucyAZ2NI83alIVnNKqxJpEEXn3FjHFUZcC5NotLS3zlq1/hwsVL1CESTRCGm01I0z6raxVPPHGSJ558iqWVNYpSwG1jDFVdkrVyjGv8S4Iw32qovcGTUJQRYzLqYMHkXFtc48KFK5x8+iyX51cY1I6alGAyorFE48AmuLzDoIo8ceocF2bmiCREHJX3UnXNGmpfU/uaqqqxNuXGG49zx4kT3Hzrjdx0yw1cf+NROr0WdSiwScCmcPTYYY7deJSbbrmBV736lbzuda/lT/7kj1lbW8G4SDAVW7ZPcMfzbuXm227gxS99Pv/0X/4Y27ft4b3veR++ghgMziaURSVEg2ipKiiLyIVLV/jCl77M3PwixqX4YAnREpHjMkakNTGKH5CPqOm8w6Y5EYdLcq4trnJ17hpXZuZZWRmSJC3KssZYQ1mVyJ+ldLuT+Fo6U+ULMX/fYFJv0ARW72NGKw6CsKhibOSRKhdl3VjZq0w0hIDXsVZQevWTCpE8Tem2W2yZ6DHRabFjuo8frnBt4SqXZ2ZZG5Vs2b6DickJqtEAEyucDZIAa7+wSqF1Cjh69ctxifoeSX0BfIhgrPrSNaOn9BOn9zCI4CvKuqY3McG2Hbt46HOfZ3lpiVe+/OVkzlDPX2H+1FexxTLUa9hQyzhfRzKTYkPAemEtecA3KrBmkA2a3AfZJs/lYUMkrT2xEmC9qsV/6BMf+ySnnz5Nahx33Xknhw8doJe2SU1Ov9Nj2769rNYV27dt5QU3XM/Lb7+Z5910jPNnLvDlL5/m1BOnuHJxkcuX1lhaKPGrA9xojSc+/xB33/VC9l5/gt/51FN8edDnyasl8yOocSLbVVP2oKxOfI2rG686YSolPpCHihPXH+H2IwdxxRBb1sQq4ut1RijKtA0xClELRE4XBHCssdCbZs91N5F1pphfWOKP3vsHvOylL2JqIqfbTkgTR7c3gdXqcK28xcTkBBP9CbrdPr1ej1arTeJSXRwTsMk2JvrWifzSJQQcq8Oaa6tDVgtPTUIVA8EaytozHEl1UoLFeyirwKgODOvIoPIsLK+wsrbGwsI8w7UVTKwoByuMVldYXVqkHA1FOjkc4KtSACW9FziDyNWI+lPmLjSMuxDwVTX2jIrq3VSrFYJxwtZzaYbLMtJWS1ihugDW+LIFXbwxGKq6Jk1T+Q4Fqpr7Y3Nv24zN2Iyvz9hkKm3GZnwDxLmnn6TSykZlUUhyXcvkoFkpraqSoixFAjccbQCeGn8XYcvEIFWdvvTE0xiXceTgAe59+Tfx1153L9/16pfx+m+5m1e88Ha++fnHueu2G7n1+kPcfv0+7rjlGLfdciNbJ/usLMwShssc3b+Lm647SCsxpBasEf+ehp3UGHA3E24Bk9YrYTWyo3WZ3DrQZLRCWuIcW7du4ZMPPMhnvvAFDtx0mH/3i2/l2I23QEz4wPs/SN86fuJH/iGvfcEdtGPg8tPP8Ne/7TXc+/wTrM7NkVtDZ3CJlVOPQIj0dt1BuuUglWmNIaRnxXOZOV8DUTJG4Sad8MtrySnOnj3Lnr17xobKSZLga3nuvZRC7va6ED2JM1iV2MlKpRivO+uwxnztUvDjhOa/3a7WL+sPPZbnspfW//Y5rzYc6vjM6LH+t/E1vv9rnCvQSk7KVAo62V1eWuDsmbNMTk7QbrWpqwprLGVZ0MpzZmZmWFlZod/vj41G61qSeKk+o2ajDStFvyN4YZNUlZQc73Z748pvIPKlJvFNspR2u4NTM9NOtysJnPqkeO8pFZjCOqJNaPV6BAwuEalaVVXKTBIGoVUwqTkXIWjVxobVpqvKtXpojAExZR9muZTBTtOUsqpwVlaFi6Igb7WIGEK0/NEf/Sn/7t++hfvv/zR/8qd/DsZy+x3Hqeuaa9eWeOAzD/HKe+8hzRKsFZ8cayW5S7MW//FXf4OTJ58mEjl/4TztTocdO3aIV4d+3x//8R/zW7/1n/nLv/wQH/zQRzlz9ix79x1genqrtouExx57iosXrvDSV7yENBHfjsFgyNvf/g7AcujgIay1FGWJtVLe27qU3/+DP+Hnf+Hfc/+n7udDH/oQly9f5sSddyj4Zjhz+jJvfet/4H1//D4+ef993Hff/Rw7dgPbtm0TGaKzPPLIF/nt3/5t7rzzBK12JtW1TAomZXWtIMs7xGhZWlrmXe96N29722/yvj/6Uz70wY/x3j/9SwajiuO3ncC5BB88SZoQsHz2oS/wi7/yNn7vD9/HBz70EU4++TR33H4HaeYA9e6KNZBw6dI8Dz30JV756ntoZYkY8ppAxINiwmfOnuWLX/oSr33tq2l1ckKosTbj7NmzPPz5h3j9d7yObrfNX/zFX5K3cl768m/CpY2ENOXhhx5jdWWJV73yW7AmYC1EtBKcSZmdW+RXf/XXeftv/gYf+NAH+ehH7gNruPmWW/He8cCDD7O4uMDrXvcq8kSqSVnrcFmGJ+FjH/8M/ckex4/fykc+8hHe8rNv4Q/+4A/4o/f9KR/4wIfZtXsXBw8cVOkkVN6zslLy87/wS2zbuo39+/dIZT0jVb+ss+Nql8IAkgQ1RpFexo3MILsuf2vuWVb93hrAN+rvRXmjTBY8xco1Hrz/41hfrXv4WVgbDKkD+GhI85x+v0c5GlKMhtRVRZblRJVIBh8kiXaGCLhEDOXFCy8KM6wWGa2AxOuG3hEZH8csLCAEuVcvLy0xNTWFtZarc/Ps3LGDQwf2c/rUM/hygLeGbn9C/tamuvhgxIgaqVKJegbJoPScNQIFEJrfAdgYcTHgQy2VzWLAGcNoZY2vPPoYL7jrLm659RiHDh/ivo/eR1VUrNUFyfbtVN7TD4Hvuet5vOz4rVy+MsOv/9Z/oSgtYW2VpZlF1uaXGc0t0PYFplglDpboGs8P/t2/zacfeYwHnzzH1bVIkfTwJAIq0ozRAt6ZGHHUBOOoo1z7zFluOXaU1977Cp5/+6088rnPCZszzakiWGr1nZLjbj4L9a8ToN7ikpRh7cE6Oq0OVVkwXFvm6ZNf5QXPv5P5+TnKWoBukVbKOZd5kVRIQ+W2zb1z3C5pboPyiwjqyWepKi8sOiBxAsRghDnsK0+WpBgFQ0MUMMwHaVdGGaEWAYqcUQnvhrmFdYncH63FIIb0YrIdZDGkkYmi1ej0nuNU/o6yX9E2muWZsEJTKbKQpCKXTZJUvaFqqlLMuyNiV4D2y6Z/NiCxGRcqEJn5Ld/8Kr1Om7EZm/H1FJtMpc3YjG+AaKQjZVESajGvlZU6z2BNSqsHL2bGxWgkk4eIruoFNWqWiUGWphw9epR/8y//KW/96R/nn7757/C6u2/n2PacLXYVs3QRv3Ce5QsnWTj7VdYunaS8egazeIGd6YiX33aIN//N1/MD3/FKznzlC3ScJ7eRTmZppQIKWacPBYmsEdCoAZDGr5UybpRibZXObY3IhYIPlKMRW7Z3+d7vfT0nn3qCL3/pUV7z0nu4/cjN/Odffgd2peKnf/jNnNi6lUN1zY+/6jW85yd/mn/wylezhcjNhw7x8Kc/w1OPPUlCh6JqcfbcxWczlDaGaRKJZ2/eGEZnlFZBAtsgS0C/3+exxx6TpE1NoWutksSGClgEL/KGUMuKeQyEWibOiQJyzSQtRqGcb/zvv7uDG2Nj0rHhsfGoxQNJz4dOHvXHs0Cm/9GIUVgJGJGSJE4YbAcOHQILrVabWn0oRsOhAHDGcOyGG0DLhstDZEd1LQyREITh0ACr8txgjGVxcZEzZ04zOztLXdf4Wn43HA7HiWtU1kPDLnJqei3gj5b81jLRUQEt50S62UykQcyyxxP+DYBS89NakVg0r5u/lTLvklRIQpyQt6TyXAxBQKQ8l3PgK9qdNgZL4jIuX5rld9/9B7zxTT/Kz//CL/HmH/lH/N573suZ0xdwNsOZlLoSbxznHJWvSFLxh4nUGBNotRK+66+9nhMnbuf+T32Sn/3Zt/DYV76iTC9YXFzimWdO8/f+/g/y1l/8Rf7xj/0Yc/OL/PIvv43Zq0uEmFB7Mdeu6ooYtYJYLQylhx9+hKoS5ljQSkMhBox1PPb4V/md3/l9vuuvfQ+/9B9+ibe+9RfZs2cvRo2by7LmXb/zB0xObecX3vof+NVf+TUOHTrKW97y84AlSVOsc1y4cJHz5y9KghYksRuMSv79z7+V9/zBH4JNWFkb8dP/9i187OOf5G/+zR/gl37pV/jFX/pl/tbf+ft84MP38bvv/kN8aK4zrK4OeMc7f5uqhrf8/Fv58X/zUzz2+FO87Td+c91zKZGE1KpcZnVtwL/8V/+aN/3wj/CmH34zb3rTm/jZn/lZbV/iuNOwHKT3icRpdnaGJHFkWYpR8NbYBGMTrEtJ0xZJkrK4cI2pyQk67RYQ8KFUYElGg3e963e47xP388/++b/iN97+mxy/4w7+46/9Opcvz+JDxNmUum6ugVSWCjFImfDEYZy0/19729v4uV/4eb77e76HX/+NX+cXf/EXufvub+Yn/s2/46tPnJT2bcA6y6io+NT9Dwh7zQoIGpVhGtXHDNQ0XZNzOUYZQ5vtTd81Cs5Iexe/pQZwjYBXxp8AFMLOsERiXeIIdPOEiVbCZCuhmzmWFxdYWVlmeXkJQ+DI4QN0Wxkm1sRQyrgdmsqYcmEFMGoqRAorpNQiGCLdtVgngISASXIfMMpecc6RZJlcG2M4eeo0k9u2Mzs/z1ef/Cp5K+Hee+7GxhHDmXNcO/8MLWqoC0Ko8LEmEjAxSBW3IMw08U1SYKl5rq/lIa9FtlWT2IiNHmcMRR2p8x5fuTjP33jDj/LoV5/hnhc/n1/6iX/B7Qd3U127ysyZ0/RshlmteMFNt9O2cOnM08S1FSbqQLuo6ZU1veGQ7Nosq2dOcsPOLbzxb30f//IfvYGjh/byt9/4Jq6MIkPbYVRBWVZEXxPH1TghBIOP4hFXVoE6OmosZQg8c+o0qyuLfO7B+ylGS7jEs7y2wKgeQKgxUap8jh869hotIFLXgWFRUgQY1hHyLlt2HWDb7oOsFTV/8YH38/wXPI/dO7fR77TInKPTapNnGd1OR3926XW69P5/7P1nnFzHde6N/qt26DAZmEHOiQAIgGDOWSRFJSpnW5JlyfKxbMu2bPlYthyvk45lWcGSbckKFJUYJUoUcwYzSIAkACJnYIDB5E47VNX9sGo3QNm+9z0f9WoWfo2e6emZ3rt2Ve1aTz3Pszo6qVY6iKOSZ+2cvE8Um2FBGKPDSOR6YURGwGg9ZbyZkKLILaS5wVhHvdmilWZYp7AqJHOaxECGZqLRopWkTExMMjJ8gsmxUemjJqNRnyBpNUlb0gbNWo00adKs18DKfUKApFzel7QIlcKm4iOmlGyQ4JnVBXCuAk0QiddSXCrJnO+BsJPn6CXn7YrC0jetMx7w9JuIgQKEOS9A7FRMxVT8IsYUqDQVU/FLEM5XDVPeR6TYFcpzqSRSLLwLTX2apr5ErPjKWL+o0DqgXC4zZ85cTHOSZOwYE0f3M3pgB2OHdzN57AATQ4cYGTzI0JEDHNm/h0P7dnP80D4mjh+iOXSQdGg/Uf0Yy2d1cdk5a8ibk+J54CCKSv44JVl3yG60MJNEMqL8Lp/szhYyHVmUOA/xaCBQnsHk5QhvftP1LJs7iwduu4P/9a73M7ZnP3Z4mCvPXM8Fq04jclKJpETIQGcn1VAT4pg3dyYbnnmS/eMJkz1LmXXem5m3+jxsEIvJseRxHmk5mRBZxKRVNgxfDYDhf0fSueLI5eu4FBFFAZO1GsZYwiBqV6qSE5eFv2w5y8N6o90wEHNQYy25L1PskJ3A//L4eTCsCIU3JfZ/XTJfLFJVzxbiNudBFR2IH48KMM77djpZYBaAW/uanYowFUBgARz6x/8Uzsm5iieQRQea6dOnU6lWyUzGxOQESZrAKSBSuVxmxqxZOIRlk+cC3ERRJMBUIH2tGAutVsLg4CD79u1jcHCQLM3aDL+CLaSUNIxzvioe+FLg+KRQdpSVEnAoSZI26wnwXhVyfMW4sl6SV7RP8ax9/y4+V3twyjnve+PZSQqkTPMppaOlN0lbKM9cw0GS5mS54+WXtzFr1lyuuPJqevumc+HFFzNrzmwOHT6GUjHWapQKSRODbKArgVC1IwgcaVbn1z/6ft797jfztne8iX/47N/R1dPJTd+9ibHxCYx19E3r53d+5xOsW7eW/pl9rFu3hk996n+TG8W//MtXaDUtCgHGwlATxTKOtdIEOiQMKmSZIUlSkiQhLkWY3JDnlj2797Fg4SKuvfY6ZgzMZNbMWbz7Xe+hXBGfk2Yj4YXnN3HZ5VeyYOFi+mfM5Kyzz2fw2AkmavWTHmwqkIeWHXcVQJq32L5jG0o7lLLc8aNbGTx+mM/8+Z9w+RUXsXDRHBYumsMNb7iOyy++kEcfeoC0USPCELicwBnyZpNrr7qK5YsWsuq05Vx2xZVs3badJMk8u8UQeKN2rQOUCpg7dx5z5yxi7uwlzBhYwLS+OWhVQVEhzyLSRLN1yx5e2ryTl1/ayS233MGjj27g7W99Nx3VXrJUoSgzMZaxfetBtry4n8ce2cSXvvA1jg0e4A2vvw5UThhCEArwWVSBO3r0KBdfcgnr1p9Jb18/F114MSZ3TEzWJCF0wtIrxrbWEYGvKGespVQps+nFTTy38Vn+6f98lre+9c0smD+PdWvX8PGPf5x5CxfzrRu/S25VWyKndEgUlwgDAayyzLQlMzJHnpRtiyxVCgW0v/cMQ9lEODnPFJXYQMCSYtxwiizUOkcURpI4WwsmQ9mcrnJEXyViZm8HvR1l6uOjjJ44zvjICI1ajVmzZqCVIk9bJK0mzhg0Du3ZecXYLe6xCqm+JeNS7q9S5bRMqVSSzYJizCslhsVOoZzM+Zm1PP/iizSyjJ1797B9z05mzJ3BVa+5jEgZsqFBxgYPom1CKVI4l+GUbx9jUcYSOpHbAb6ohJ8dHB5Y8lJt5+d/hfgpOTmeIAjIdUBeKjFmHH/4mb/kltt/zNp1S/nnv/vfXLf+NLrGTtCXp/RVyyxctJAsNTz79EZCHWFwqCynTEJ32OSy9cv45uc+y9/+4R/ykXe+nf6qZvsLT3P/HXfQEZTICMFC4BwmT8U3zsgaIXeOzDpS41DGotMUDFgbkdqIBx99mrvuuZ+OzhJLF83ikvNOZ92K2VQjKQri8hRnjHgRZTlJkpJneZvZphwESublzGpMUKFj+lwodzORGL5/82309wuoFChLbsTbDs9gtcYQxRGdHZ10d3XT1dlFuVz287eXP3tfOwFWNCqMcToiVwFGh0y2HBPNlHpqSK0mtZAaR5IZEmPJUfJwitxpjNI0M0MzzWi2UlpJytCJExiTUY4j6hPjNCdrZK0ETI5JEkpRhDEZYSC+U1rJminQAdZX7M2yHGusVDP1GyAlX21VFfdkBRZZI1YqFUrlMnG5RBzHBIVFgZeByy+JfB1ks1MKaIjvoFRxLO5cUzEVU/GLFv/zCn4qpmIq/t8TfqHtrCVNU9I0pdVskqcZaSqLNuvLrhfvs37xKbY68rXJc6odHYyOjHD00EGOHznIicEjjBwfZPTEcUaHhzkxPMLxkXGGRicYnagxNlHjxOgkx48Nc/zoUYaPHuTYwT0MHTlAnjRp1BsQROKtpEOiKCKOI6Lo5EPW2wUgI4CIMJVOBSr86wWQ0cZuFNakjI4O8pUv/TMDPQMc2nOYJx7ewOTwCJeffy55fRJrcmpZRj1wpMox0XTsPzzJrh2D3H33I2TxDOavv555572N7oEVOBv7j/UrJYWAHkoTxyXZUbWKIBS50X+J/3btJIDf2nXrODY4KKbA4DOsU78qmFByhie//G8+5/8yRCrn2V+BJEJahyJCMCDl1AMcGucCLJrcKrIcdFiSBbIKgMD/joAgAsSc+kmyfHz1a/99/Hen5YBKVwf9M2fQaiW0Wi2yNCNJEprNBrVajdrkJN3dXYShsCAKEAik3+RZTrPZ5PjxIfbv38++fXsZHx8jTVNfqaZCGMXSBoEWP4ksp95o4JxI8ZQWTy+lgzYDSeAvqeZXeB2FhcF84RlWyPGMeD0F3i9JnwL8OZ8Em1PAp4KBlnrfs1KphPUAl1Qfk7GrPBhlrcUpR+6BQvF9kSp6KO0r54l8QinEn8qJObbx1aDy3GKsJJpFASnnoFotEUaKMNL0D0znVz/0AXbu2cPhI0dxTkkFNhURhmISHmhNT08PV1x+Bdu2buWlF19EIUw9rRwaRxhKkp0bkdkZK+wSYw15nnnJliFJMkrlMqVSVYBb5RmKVoPTtFpNmq2GZ9R4E2OnUTpuA586jLFOYwnJc2kPpUOUCkFHpJll1+593HPP/fz6r/8Gy5Yto1yuoH1lxjiOWLlyFWNjk4yO17AqwCqNcYokdZTKHWjvAzV33jzPhjA46wi1VO3SSpNnKR3VCh//+G/xmc98hr/487/gL/78L/jYxz4mzES/KZBnGf/4D//IH3/qU/zRH/0hX/vav/Ga11zJ297+ZpGFer+UgwcO8Mk/+CS/94lP8Fd/+Vfs3PEKf/aZP+KCC88GlwHeV8UD31luaKUp1c5OQBFHJSrlKs5Z8jzFOfFgkcqJliAQ36sss+ggJIpiFJrjx4a44U03cN655xJ5A16tFVEcsWz5Crbv2E2tkeIIyXKfPmqFDsW8XWkB4U/OFyfB9v8u3KnybO+7U7xOe4YpJg8Bl04CSyffF2hNHEaUo4iOOGbGtF56yjEzezqoaMv40DFOHDtKq9nAWcfixYtoNhq+8qfIjsEzlAp/JyXAMr5vFvelKIp9oi2bNDoo/HY8A1cpQm/QrFA4q8iNJTMWpwN27tnDi1u2MGvePFavWIbKm9SOHaQ1eozINglcCjYTyZ0xKId4D1kBiTyt1H/vb122eB2pBKk0RoVYFaCcInQ5cWAJQkXqYO+xUT7zj1/iM3//z+gw5vN//Td8+oMfIBo8zMVLFzGnu4xLMp5/8llGjx6jfuI4MyrwyY+8lx/8xxf5i//9h/zkR7dRO3aAfRsf5sa//xO2P/Egtl6XQzcC9CljwFgZN2nmdyyM+JDllgBFYCykBnKHSTIO7N7NZRecz5/94Sf5+K9/iHe/5Y385oc/yB//we/x1je9nlZtAqzxZtiy1sH7SomuzKKtrHsskBGQBiVmLVxJ38xF1FO478FHWLRoIYsWLaSvr5cw0lSrZcIwoFItU62UKZUiOjqqVKsVOjs7qFarRGEs93TPJm6vZwrWqw5wOiB1MNbIqGU5LevItKZpDM08p5llNDPZGEiNE3+lzNFILbVWxmQjYbRWZ3yyztjYBM5YKnFMq1GjPjGO81VkTZ62KwbmaUqr1ZQ1k6PtNyj3H4PJ8jZIa/KMLJN1oxiFS7XDzo4qzgoTrKgoLPcug1Lez8oWG2DaM+bl9TzLwIHJjVyDqZiKqfiFjClQaSqm4pcg8iynVquR+spQ1hjSRBJxawytVovJyUmSJPFeGVLdJk1TtC4qiISEUYQ1lkMHDzI0dFyo1uOj1Gvj1Gs1JiZrjIxPcmJknOHRccbGJxgfH6fWzKi1UpqtFo1ajcbkBPXJCYaHhxkaHiGIYgyaIIraQEZQsFcCSRZlwV1I4Yrdr5NMpYKV1I6CIQTkac6WLVtZuuI0/uSP/4pvf+MHvLx5K9e95jXUhsd4/JEnGR1psm3nfm66/Q7+9d+/xu9/8k9513s/ypve+A4aLcPMRSuZtfIcnO4hUzHWL7IKkMdDO17ukBP4hDV3HmTwidKpITvtr37NmJzFixYxMjKCAqlU9T+uswRUEmDppPysADUcYIu3/HycAtSd+ghDMRe17mRiDyKpEbAhAjRRVAZvNLrvwCEm6i2eeOo5br71DsYn60Ldz8T7Ro6lOKJTDq74SdE2/+N5yrUsvipCBwHz5s+n2WoJsJS0SFoJzUaTWq3G2NgYo6NjZJn3UfKmvY16g6GhIQ4dPsShQwcZHx8HFFEki34BM0vEcUlKIHsJorPyXJsUFhlegqOU9/3ygIh1IgNQHkhyTjxi4BRPqFykXoFn4ZVi8VcqjrFImINAzGDx/aUwOi2kk0mSyO/5MVqMAeP9uOJIKmrlzpBbRytNcSj6pk3nyJFBxkbHJHHIcyYmxqSKmjWUK2UcMDo6RhCEhEFMEJTloSv+61CAIx0SBBGdnd2EYczw8GjbEFkpjTMOVMDY+Dh3330X99zzU2bOnMZppy3BmhStHM1GkyxJaTabGGtJkpQ0yYjCWPqHgtykOGepVqvMnTuXAwf2s2f3XjQhURhh8oxAhYQ6prOjg2nTu9m1e4cwuhwY4zAGHFp8eZyileRYq8lzxDDcaqwJsCbg+OAI3/3OD+npnsaZ688h0BHWOIzvC8YY6s0WloDxWotMhZggJrEaFZbZ9spuUAIabN22hXKpRLlUQivxNRHJLpTCiDgK6eyoEgYO5zKC0KG1wbmUQFusSYhjzec//1m+/4Mb+frXv0oUa5K0TrkSkZsWYeBQKmfJ4nl89zv/yQ+/fyO33vxdvvqv/8KF559FoA1aO6Lo5DXTKkTriGnTB3jm2Y2Mj02AsdQnawL0aYdzIndM0oRms0WeW9JUvJo0EViNs4renmm84+3vJAzkPlGKYwKtsMYQl8ugQ7LMEQQVwrBEvdHwM4MljCOyTMbUq8Akd9JP7edD3odI3xBQDec9jbzkWxJjXzDAicSmvQ/g2X9RGBJHIVEQEIcBlSigr6NMTzlgdm8nkc2YGB3l2LFjpGlGvV5nxfIVZGkLk6ckrYY3D5e/b73MThi3Gq3FbyYIRKIaRgIsB2F0shiFPukfqHVAqKV6llIKvMl3bix5Znll2w62bHmF8889m7WrlqGzOrVDu6gPHSYyCSrP2h6EzoNmvqHaD+eANrB0yutWgCXjNNZ6ebbJCawRWXFUwYSd2HIfdz/0NB/+yO/ws5/cw9mLl9Cftfjg666lDBw/doKLL7iYL332//D+G17Pzd/8Ou+74U3M6u6mFJZ5w5vewP0/u43//Pxfs3pmB0tnTuPIwf1SHdI4nJdaGmMxRsAPm6W4PAGX4kwmgCcGY3M5GWdpNepccfGFdJZjHnvkIf7PZz/LN7/1baqliDNWr+Q973gbJk3IWk3wEkXnN9KcNWCtKNitsOKsEmCpkSs6emfR3TeLJINb7/gxOgqYObNfWJZRQBhqyuUyURzS0VmlXCnR2dVJR0eV7p5uqh0dlMtlwkA2z+RanyKJU1oA/yAmV5qxRsJkltHIDSmQK0VqHUmakmQZmbHCYrLQMlBPLZOtnMlmSisVX7zBo4PkaUJ3Z6f3h6rTqtdoNRq0mi0vAYUoDGnW6zTqdfFbKoBZJ1ti0j6WNM3IcwGGnHXEYUiepKRJC2Ny6vUaJs8weU6aJRibk2apMKe9hFnGtPhBZWkqfzdJUH79NBVTMRW/mDFl1D0VU/FLEPt2bPOJqhUgyUtvrLXU63WyLEMpKdUt/jHiYaB9ghoEIZnJCaOwXSGu2RT6f9JqkjSbJK2EJMlIkpRWkgjjweQ4k0MQiw+HVlLSFsiMJfdeAsu9900UR2KcwCmAB5JYq7a30s89/5z5Y5HIKgRw0ih0UOazn/9Xntm4hS/9yzd5ect25i2Yza+87110hWU+9clPc8edP+PbN/2Ag4cO8q63vIXNG1/ivrvv54zTFvMnf/pHnHXemfRMn06GgpImd7ILrHAiocDvritFbsRM89DhowyPjtPb3SGlx/15/Xyc+pryFbcOHDgoHjEFdRxOQWOKJEs+uf04qcXzf+zk83/91P8+iipJ1slOehiJAazzgFOr1SLLDVu2bOOuu+9lst7klR27OXzkKHf86E6uuuo1jI6OMnPmTL9roV7FNDoVRFPt//4fhH/zKaeEs+IXteWll2jUG9g8RztoNBs0Gg327N1Lo9kgSzMa9Tq1Wo3JWo16rU6Spm3QpmAKBKckdUHhbxJGdHR0iH+RMZLoWEtXV6f48uiAKC4RRTHlskhaCsAhzzPSJCXPEqnQFpcod3RJ5bUgRCrbe+8khP7/akmnsC+s/3vKJ8kCspzCbAhFTlWEMaZtLF6UNXda6vDpIObo4HEOHT7Kxude4KWXXqSrq4OHH3qQzS9s5AMfeD9hpAhCzRMbnuGFFzaiA82Rw0c5cOAIBw4c5sD+QQ4cGGRoaIjBwRMcOzbMoUOD/OhHP+HY4HGGjg8RhgHjoyMcGzzC/v0H+Mldd3Pjjd/lgfvv4drXvoaP/eavU+0QGUWj1uSeu+9jdGwIpTV79u7jhz+8haNHjvHGN76R6f29GNMiigPCIASnmTt3Aa/s2Mndd9/D2Ogo46PD7N+3h5de3MLMGbPp7OqiVp/g5ptv5dixQbSGTS9s5dixIbp7ujh0eB87d+zi0Uee5MjhY9TqdcIQjhw5xoubt/Lii1sYHDzBiRPDLJg/n66OKoOHD3Nw/34OHTzI/v37eWXXDu68826OHhviyOAg3X2dHD46yIOPbODFF19heGSUadN72br1JW6/5VYuu+wSLjjvLAIcURB4rxjNnj2HeO65TSxYPJOJ8WFGR44zOnqckZEhcIZKpcSuXTt54YXneMMbrqe/v5fe3k5mzJrFjTfeyNlnn8n0gR6SVo0H7r+fSiXm+tdeTankCEPET6bwMmkDuIrMgFIxu3Yf4OChQV58aSuT46NgDbffditjI0P86q++jzCKyA387O67GB8bIVCaXTv3snf3Xg4cOMLefYfZuHELq1evJNBwcN8+hgaPcejQAY4eOcbQiVF+dNfPGDkxKlIj4NCRw/zlX/4NYRTwax/+AKFWaOdlah5oLr6WsfDfTBRKZgTn31OAj85L3JwHZuW3HVqB8xI+rRQhBpI6z214hMDmBEp7OZDIhspRKMwKHTA2WaeZGQyKjo5OojCkVCoxMjJCqVxGhxodhuDNlNUpc7MwOx06EMBWDMm9TNUzOIszFFmUnFx7qnTg8pwoiAhVwMJ5Czl29DilMOTsM9dz+PABJsZGSZOUUqlCudxJbjXWG5RbKz6KJ1tQvnLFf/6hkH6h/QYFiK9S6AzKKXITYEXkCUqxavlyXnfNdXzrG1/n7jtu4w9+86NcfOY6lHM8tOE5yp3T2H/gADEZeZqx4eFH+T9//1meePo5JmpjtMYOsGRGlUWzprPr8AhPbN1LK+oiJ0ZbhXMKK86BKJOLxxOGIHBECqzNsNriAo1TEIaKPK1z7VWX0lEtsf/gIe554CG27tzD4jkzmdE/nY5qB5s2v0iaW+CknLgtC3ROzr8AVXDCulQa5TTluEwpjhmfGOfAwX3Mnj2DJYsXMzY+hskN1WqFLMvaAL8xOWEYyH0VxKzd30coGKXtyyK9QIWRyMydI0kzrMv8Zpsi0KA9KOOcSK4LzzWRposBN4h5eJ4KaF8ul6lUynI/yY2sx4KAOIrJczmecrksfVKJlM8fFMr7/KWpVIjTSoBia3JsnpP76qu6YLxqGZOy5pR7mPOMpuJvFmb1gWdsFffBPDeccdXrT7bJVEzFVPzChHLFzDkVUzEV/6+N+2+7WXworCNNEpJWg2ajKYa2WSbsgDzDGEOWi4+M8lKuomKK81WqciNymSxNxCAah81zUr9zJowAg8JR8ru/ma5QKpUoxxqNIYqlIktqHT3T+3nr299BXCqJxMjK555kJHmZwM8BSsVCRB7iaQH+e2+2XHyvw06+8LVv8Hef/QJBs8LMmd38xsd/hX/72hf5+Mf+gC//+03sHzpBGGpmBZbZlYSz163hmiuvZG5vmWUXXEJp2gCJqBrIIlDWoL1PTruijuyXYp1mdKzGhz/yMXJr+eFN/0m14uVyBcjiZMFahJIMSTxCdMDLL29h5WmrCH2FMEm0ZNnosOBk0V3EKV/+l1D+Ov3/D1nQGisSHRRMTtbp6uzi6NFBgiDkuWefZe/evbzmmus4dPQ4x4dOEJZKHDs+xEsvvcx73/tu4kBz9vq1hMoRKkQ+0/aA+vl4Nej0/yskxyxazaK1pTYxwde/+u+MnRimHMV0VTpotRpM1mpse2WbSL60sEIKAKnwCvNZJtZXq8nznDiK21K2Inp6e+nu7iZNMsIoJM9zZs6cycDMAYIwoqOzi0q1Snd3D93dXRhjaTYbJM0GtckJlDWEUYCOy0ybNYfEKhqZJYgqZHnujfC9eW5w0v8F/MXzjDapEuQrxeV5GwQrXhMgS/5elmWUSiXCMCTNE5xWQMjoWJ3PfOZvMAZKcQXnDFnWRCvL1VddyZve/DrvExKzaeMObvrujViToVUILgJlwAXyUAlKB97nxFIql7nqyit55uknGRsZQpOLV42O0FGF01efzmuuvZQ5c2aglaNUCTAZtBqa73/vR2x+6QlS0yQMYhQlzjnrfD74wV8BlaJ0gnU5ygUoF2NMwH9849tsev5FylGAc00CZQh1ib/867+h3FEltymPPPY0jz72OCOjJ2jUZKDEZUUU5zgHcdjFBRdcysbnnmG8dhQcxFGJ5ctXUi538sILz5ObFoEyKJehEImHQmGUoq93Dpdddg2PPPoIY5NHyE1OtdzDRedfxYF9+9m3/xUIHCtXr+M3P/pRejpjIu3QzmFtjiXgmee28IUvfg0b1mS8mBwwBIHmbe94B294/Q3ceefP+NnP7uYzn/kMs2YNyO6/C/nsZz9HnrX4xO//Fn09XfzFn/81pbDMpz/9KVAtkV2qQMz+tXiuaaUFuw8innhyI3/2mb9hYOYcwqgMtoVN65TjMr/zO7/BqjUrsSogMyG33X4H99z9UzCGwEif1WFEYjQq6iIILSatUYk1Ls+AFGc1RkcEXZ1cf80buPunPyVPGxibUO3o4EO/9gEuOP9sXN5CmZAwFF+gIv8skv5CfnNqKD8n+CEiXjXGEgQBucnFH8ZaAUeUZzx5iZExihIJdvwYX/67PyfIGigC4jAEmwmYFIZMJjmDYw0ODtc5Olqjo6eX3mnTmDnQT09vH4PHjjM6PkEQR4RxLEC/DtoMPYVsdhgrMleTi/G0nJsk6kmSYk2GyeX+W3gd4otN2Fzup1maUSmVqZRKzJk7l+GxY5yxbjVLlyzhllvu4MiJCSj30bdoJbqrn6Z1EIbkeUasTkp/QcDs9ur/ZK6PcooARRaAUwblDIFzKMrkqkKOQpFSUnVUc4I/+f3f5o2vvZzuADrKAcZZXtq1j0/84d+igg6Wr1jKhRespbPUzey+DhbMmU6lWiIMFK45xI9v+y6jEzXue3YXk1mFTHVCVCV2ChdobKhwGkpZQqwNKnB09XUxe/pM+rrKTEyOMVzPGavJ3F0N4NzVS/nge96GxrFrz15SByuXLWZoeISnntvEz+5/mJZV6Ljiiy3IrUD7ohlaxaBFNuwApTSBC1DWUQpAuxaNyWFGju8ndClnn30Oixct44XnN5Gm4tOUZhl4mXK9Pkm92SLNMmqTNZr1OvV6vb1hUDyccxjnREZrMrAp2qYEDsoausqKrlJMrDW62PQJQ+JYmKuBgkhDOVDEylKJAjrLEdVSTLWri2n9/ZTKFaI4lj4aBJSrHQSRbIqgpNKhyKelXYJACgkYY4hjkW46f17CapfiIdZ7m0VRRGZyslx8OY0Hm7BOpJRh6NnPHszzYJL18lrnHB/423/zHXIqpmIqfpFiClSaiqn4JYh7bvmeVNOxhmazic1z6vU6AGmakGUpzUaDpNUiz8TY1zkxzI2i0EuHDMMnhrFOStAaY3CFYaoRI1frTT1RoJWmFIs/UhBVicolwigAZKGd51Z277TmfR/4AOVqhagUk5mfB5U8U6lgZnigScCk4rkAJjxrqa3slZ9leUBqLBtf2ExtpM7adauYM3cGTzz9JJ///L/yKx/8DSaTjFKgmRVHLLD7mdz3AoNHDhBMn8f1H/sTso7p5ECoDE47ApujjQNVwTqHsbnIn5TFuRLHT9T48le/xp6D2/iPL36ZUhigtcXkiQBlHkASuEdkEgBOye7e5k2bWb16NZVKVRZg8tP2YsxZRaCktLaY1wqTrKj2VlyHggUjwBQoJa9nYiJDEITt3XEdBKQq4Mknn2JyYoLlS5ex+YXNXHfdddx+2+2cdeZZDAz0c9N3buKd73onDz/yMBdddBFbt20jSVIuuvBCXnllG2efuZ5SFFIpl0T+kiaEgTBlimueGTHlDJRcz1AHfvdVjvdUpKn9ZQHEOUmAdKAwaco3/uM/2LXtFTrKknCZTLyVDh8dpNFstM+9SEwlEZW+YWxhoi2+RFpHnrkkoFKj2aCzs5Pe3r42kJPnOaVSiWXLllKqVKh0dFCqVOib1ke12oE1hqzVImm2qE1OYExGR1cncaWDSncfqVPUWzlBVML5fi3eOhlBGLQ9lNrH6FlKeOaS8uykU3+mtZbjiks0W822kXcpjsldRppnVCq9PPbo03zv+7fwqU/9MUEIWluSpE65FNHV0Qme9ecsBLpEoyFGzTKWpPobCBinwwKqFNleqVymFJdotZq0mg2yLBH2RxwThBGVcpkgkLLXciWdmFa7CEVEK20wPj5CFIVUKx10VjvRypHnCaVS6M2iA/Lcce+9D/CDH97O7/72b7Ns+SJwCVEobRbHZXQQiq+XiqVKVG752te+wT333M23vv11yuUQa3PCIKazs5NGo06rVcNaRykuyXV0UK/XSdOW9xWS/lmwDtGaUqmDzs5uJicnaSV1HJZSXKGnexpJs0m9PoEOFL29vSJxxOJ8VS0pUqloNFPGxmqoICdQAdopLMIw6+zuorOzm5HhUVrNFtOm9RGHMmYtAaOjYzQadfoHplGKI44fP45CM2vWDFBi4K8RloUKHEoX8swIo8p85atfZ8MTT/EPf///oaenkzypYbKEUlymo6PsWQcKh3h+TU5MiI+KUx4/CYTxQSiKR2cIZXLz3AkFShPGJfp6pzExNkYzaWIRZkS1KsCmzTNCHXnwu/BzESm2ElT81Zi0B4mKJNd5BkXxeygBA6yvkmiNVMxUWmOVwqAITQKTJ/jKP/wFqjlOHESUosLrLBOPJx1SSw17jw5zdLTGifE6fTNm0tnTy4zp0yiVS+w5cBCrA6rVTpyVTY0gCMjyDBVqjHPEYUSz2SSKQpKk5dkwFqyl0WiglaLVagq4bYycrq8eZ3IBpJw9KUXq6upkYGAaExNjnH/+uUyf3s9tP/oJY7UUXell+rylUOkm0RE2CKVwhJHKbxrZdLEaRLTn70CereSUVOiTe7Xcc3AhTgkjRilLQEZsm3TGiuuuvYrzzz4brGX7jh3c+P0fMlHPcSoCrXA2YaCzh9BmhCGUysLaVDYhUIY0bZEFVRJXQoVl4jAAqwiCyPuhWbRpUo3gt37zI5y2YgV93b1U4pAkazI4NMy9Dz7O/Q88TEe5TFc54K//9FN0VKs0kowTEw12793Nk08/x+69BwniqsxXpRCFMEpRMegICAi0bDTIPSbEGGl35UArR4BFuRzbGGf8+EGMyVi8eAEXnHceGx5/Ah1EaEKSJKHVatBoTLYNtJvNJmmS0mw2yLKMeqNBlqVyD88NePm6dRa8R5EzOdrmlDR0ljRd5ZgoUEQIYysIQ6KoJD5NzlEKA2LtiLCUQk25FBKHAQP90+nt7aWrS7zTrHN0dvegohJKR0SVKihFtaNDGOveoy/0lUUtsikZxyWMybHGUI5j6edaPAe1tyzAOWwufTfPc5QTtlMchjjvjyddTPpXlmW0Wi1aScJvf/WWUwb6VEzFVPyixBSoNBVT8UsQP/vhTRiTkyQJSZL4qlZizqj1yWpvzYaYdxdlXYOgKPMMIyPDTE5OSsLZ9gISgMP63WTnfycMxTOgVC5RiksEUUwQRUSlGB0KeKCclIefqNV441tuYP7iRYRxSarOcEr5XV92W5JaScBpA0zyXkkglIAkWsvKGNq/o7T4skS+aom1Dvxu/Zatr/D1b97Izl27GT0xTDo2wl++/zLU0FY6O8tc/aufwM0/m2bUBQoil8ki28qerXMd5GQ4DGGgwFmisIObvns7z216ifd/6O2sXL6MAHDWEAVidlnkSfJ/ITdQOKSy2e7du4mjmAULFryK0USxDrMKRYAxGTrUhGFAbjKMyXBOFprGCgDg/E6/pHhiLJ0bRxiJ/83QiWGyLOMHN9/M3EVLcMCqlStZtnQp3/7mtzh99SoOHThAoDQzZgww0N9PkrQ4MXScVatWsWbtGmGK+d3KLEsE2PJeEdrKQVugleccO3GCWr3O2NgoZ6xdS7kUEQeBMHKsJFTFf6dgSyfP3aNKKtAoa7jrRz/mgXvuprNcJgoCTJ6R54ZGs8XQ0BBhJEk4nOwn0o00Js9RWsA1pUAHwgxTKFqJSD27urro7u5u76wav3hevHgJnd1dAipVK/RO66OrqwtnLFmzRaveoFGv45Sjs7eLrp5phOUOaq2M3GlyC1EcY/wCXlhUVpIKv5g/FcgqgKJ2Il1INzzwaoyhXC6TJEn7d621VKqxBx5jHnzgce6770H+8q/+EqVztBZWjMlzwiBs+6gUrK6i70i7yU6+Q1hTUq3Hy2S9KXFxfCDFAfwgxVjjk1mRfyinCKOINMsZn6zzwAMP0T9jJpddejE4w5NPPMHxwaO85S03UIrj9hhROqDWaPCpP/4TLjj3Ut73/vegtQGVoZQvGQ44q9mz+wCTEw26uvrYtPllvvu9m/i1X/sAr3/9awlDjTEyDiV5luQ60KHvX9JXirmuAPPA+fmDU9DOk6D2qbTFYkQDMv69JESqDoo0RgDMU9rXG9yjisqSqv17uKJogjznrj2JtOdi+TtCqZQxKVKsgFDaSIshtiEio8y/fOErbN/+Cl/+0ueolhTOiMeKeIb5Sk1+PIgUtwB5/PF56Vl7XBWzmpMxKu3gCPzXFmFVWt+H8jwnTVJUMXfj5wAlsrGCwdH+DGmmdt8PvHF98R4BooSFIz/XGGNRKiLASp/VwjIrYXCTQ/znP/8dUVJDe0C7ANmNtbRyS+YUx0YnOD5W5+jIBBNJTu/ALGb099HT0wM6ZLLRpNFICMOYMIiIo4jEZBhkw0U5qaxVGOLj5eCtZhMNtFotjDEkaUKWysaAM0ViLw/nWcHCUNT0dfcwMDCd8ckxzjxzPZ2dXfzozruYmGgRdQ8wsGgFaVghC2IyrVEWtPElFFQgVd4UOGxbyq2cgEo/H+1upvwVVoqQVEChJGF8bByXG0rVDkqlsoCNOiAzhiAMKFmL8tI/HUZYpcDmVEsBHSXN8tNOo3PaDB5/6lmiUolAR7jcEihQLmPu7Ol88vd+iwXz5rBv9x7uu/s+6s0aF5x/NheccyaVcoVnnnmeg4eOctXVV1KNI44NDfH5f/03jo5OEkQRYVTGEUr1QZdRjRznn3MGQ8ePsefgIKmLcSoiDoriCCIfxHtSaSX9WikB4cI8xTYnOH78EFGQs3zJIi48/wIee3QDihCTi99TvV6jlYpHpbVWikjUajSbTer1Os2kISzTQsJsizWVeBo6ZwmwuCwh1tDbEVEtR5SwlJzMsWEUSTVDpSjHES5PiTWUo5AwUHSWIiqliK6OKn29PUyfNo0gDEnSnEpnDzouE1c7KFWqpJkUqtD+nqKUalesC31BCZA+7IwRBm2eE8Uxucnp7Oggz0QW53IZc3luBQT249tkKWBJWk0UikazIWvTPOdT37m36G1TMRVT8QsUU55KUzEVvwSxf8crtFqtNo254VlKWZbLjpMVyZX1FT+KhUTBhgAYGRklSzOpgJX7RS/4REqYEkEgEqMwDAnjiLhUIgi9R00YEJVi+ZuAM1LGHQUdnV0sWrpEACcnCxjtPSfarKVTHieBJUm+xD/p1QmPJHpy7M45pBpOLpVGfPqTpRkDA/1cceUVnHfuOcybP4cTYye46ye3sObss3nbBz9GMPs0srALR0hgIbKgbIhBY4IIS4zROUGIgCooTJ6wctVpXHX1VcyaPRsXJIj6QFgokjspSTVdIImoK+j2xXlqnnjySVaffnpbinZqqCLR0xAEyvulGJEKermX+CKFGEBHERbF4SPHSDLDjp17yTJ4bMPTbH5xK0sWr2B8vEFtfJKLL7yI0aFhWo061VKJw4f2c/1rr6G7q8p5557FjIFprD5tBevXrmP+nDnCY/DViyymzYbQYYBxhmbq2LHnIHfd9wC1VsqLW7bx/AubMFZM35csWixokfMyRuXT05OZzMnz9s/Ot4FW0KrXee6ZZ1FFtZo8J2mlOJ+sBaF4cuW5aSdkFKBpHBHHMXEcUy6LTFPM65topGpbEGhKcewZRcqbljp5f7nsE5bAMy+qIittJW0T0lK5REdnJ109vUSlMs0kQwURxp6s7hb40uKRB44KNmAhjcOfb/FcPJxf6Bc/K8APn3sLKOS/cQTs3LGbffv2cdWVl6O1w1gx4w914OuIC0AVeZ8mY0ybnePaVa2ELVHsVjsrQIcxuVSn86auWguUIAbKwlDSWtpPIVIllGbT5k3s3r2Hyy+/nGq5hHOWf/zHf2Do+HGuvvoqP7eIzE/rgDRNufPHd7Js+SpWrVolXD8tCaAYYIvEYv/eA3z2Hz/LvffexzPPPct73/tuXnvdNTJerIBpIkWS6k8ya3gjbg9O2TwXYEYVDMGCqeSBjKI3Os/q8P24kA3jE3WpvCVv1SoAJ8daACRFJTicgN7OiSSkeFbKa7yc/3vFFHLySrfHi1x/+d1inhDD6OIXHU6FWKt55JFHOXzoIG950xuIAjlu6+d/683kxfQamV89AIfzDEkjBtjSB06ppmXEONk5b4DsDNYZjDvp51f0Izlu/xlyBuDBfwGICrBM5gXn29Z5qXD7Wvj2KN7/KlAUjbOSAFuQSn82R2VNtjz/DCpPcNYQCt1NZOB5TitNqTdbGOMgEI+5RrMl3oQKonKZ7s5uSmHI6PAoAGEpIvdgUhiFbahNKpYKeGbMSQDUeANjrdUp5dWljaTvyf3AOnlN7r+WpJVgrADJhw8fZsH8+SxcuJCt27ZjM0Mjzeju6cFYg9HFcfh//h5ZtLajAAkV2vnjPeUhfeyUq+NEPpkRYFRMpdpFubObqFTBokCHKM+CVUqDLklV0CAkiEvoUObTOHCcd9Y6fus3P0YUhTzw8GME1Wlk1qHDEB0GUknMOYKozNYdu/jPG7/LroNH2XvkCD++6ycsmjuLJfPmMLO/n2VLl3Pw6BDfvumH3PrTexhr5VDuQKsI4wIyNBmOKID5swZ491vfzKply6g3mhwZPIYOA3BGerlf45wylNvjGecw1hLFMeVKlfHRYYaODbJr+ytcf901HDqwX96uFdYic7QvgGKMMPCkHzuMHzcKmQs0xUCQ6158eKBlvOSZBSyRN3I3HviWayXjQPvrK/1I5iZhvlmcMSgt9zapRigVKiPPIiqVKwBtNl0Yhd40vdh4kPtVEIYEWnwH5R4mle0AAZCUIvPehc56cCmTYjDGpOR5Qpa2aLYa1Os10iwhy3Iuf+eH/DlPxVRMxS9STIFKUzEVvwSxddNGrLXeO0mAI+ccaZpgraGVJN535uSCXcChAK009UaD8fExcr9z6vyCqkh2wlAWFlEUiY9LLM9xHBME4i9RLpfF0DQQvxpJdmWx38oS1qxdC9p7ffhFuABGvMpD6VSmkvxcQKgi2T01+fBrYO/pI+ckiZtPs7RIqKJQ09fbxbp1a3jzW9/Kh379o5x16TWE0+fTCjvIVYByloAchSw4rTKgQdkYrQ2Rp3xrJSz6DMWRoQnu+Onj/Pind7Nv/whz5pxGR0eVNGt6VpPIUmTpKotAY4W9EMcxDz34IGeccYYADv5c2tEGmpxnR0iC5ZzFOdmpjyLx+Nixex9PP/sCYVTmllt/xNNPbWTfvoMYq7jo4kup1xvcfc99vP1tb+fooX309/Xw0uYXWL9mDYsWzOPKyy9jYPo0Fi6YT0elRLVcJtABJjHEkbBIlA5otBJq9Tr7Dh6iZ/p0aq0W//i5z9FKLbv3HmDVmjU8v+kFFi5cwMyZAyyYP5dAOZYuWoDGEip/zdvZZQGetHtE+3X5WoERSv0D991H6NlOeZ6T5TmTk5OSjISRZ+4IKFEAn1F0ElCKfCWmJBGWVaVcaXsYAcK48+PB+r4fxjEdHZ3EHizt7OzEOUeeSanlJEnoqHYQhAF90/ooVaokWU4rzUnSDLwnRp6L5FQpRZIkRFFEkiToIvlUijiOPfgrn18kzUEgbI5i4a60SH5EliR9PsuEuRXqkFdeeYWR0WEuuPB8wkhAubDYideB+HNoTZomaD+2tfLmw06q81hjRTKjC78quTpBAWZZSYxlrHlAyZfwNnnuGSnCakLBd75zEwMzBhgbGWXZ0iUEWnH1lVdw4QXnU61WATxjS5ObnCgIGBw8yoYNT7Ny1Urf7lCvNdm2dRszZ8wkCiLmzpnDta+5hmuvvYb3v/99nHP2GQSBIgyVZ0yJrEh71pBSWpggnuEjLB1fDrtI2DyYIUCGACeSaAqoIum5vJcCBEKhCAABjtqgvBUWUcFUEqsRYeY45X8fXvU3pef7nykA235dnj2YhDBh2kmeaNPkuPwYiqIS99xzDzZPef3116KRMt8KLcwyDygVxydZtXi6WSdgYhj4uZSTYFYxDxbglxyXlBrzabr8c1LC3RkjmwjKA29Iklw8S2JdzJFFCABavL/w1JOE1zOePFNJxoeXNVmHCjQOiAJwSZ3nnniUvFHDeE+XJBVZ0sT4BFmWE0YRXV1ddHZ2CdBjLc16jXpucErTUaowrbuHzmoHk7UJMidsKOcgUAEBmiAMwbP0Aj+Gw1Ckds5Z4jhuA7EF2FDci4u5wXngLAjEu0hrGdvTBwawNmf//gPMmzuXlStWsHPXLkyaUKtN0tXZgQ1KAqTJwPR+fGLKLf1DtSuFnuoR2A7f39pXQEFmwBJgnfhIaR0CmsAzZnDOz8mKIK6AkqqLQSBgcxxA5FJ+7f3vYNb0Hr7+H/+GTZv0VkJmTuukHFiyVGS0Ooh4YfNmtm7bRqvZINCOtatX8/sf/13OP/ssas0WG7du5yvf/i5f++4PGak1IIhoJRZnA/LGpICbWqMChbY5XVHA+pUr6IoCVq86jfHxYY4OHsGpEGc9UOo3rlwxlp20hXPif5c6RxBEdHd2kjTrlCPN/r07ee1rr+XYsUGMdWS5JctSwlCTJImA9lFEEIhsuADri3m86OvFNS++DoIIpSHPDZmRsaF1gPMScuVJVVhLGAQC8KPIrCMOAozfVLHWkqWZgHqlElpr8iyl2WiCkxGutSIKQ5lzs4w8yyiXy7IR2GZuClgmmyCxH4cByilsnpMlCQpFnolHWZa2MHlGlrbI0hatZp00aZFnCc1WE5PnNFsNXvO+j726703FVEzFL0RMgUpTMRW/BLFt80ZarQRrLa1WQpok4q1krfgJeOPF1CeyAgTJotA6x/Hjx6nXG35RKwsdSbPEUyMM/a5VGBLHJcIopFwuUy6XpVyyB5XKlTJRJECTyaUiDQpya1m9dg1hHPtKK6825Q68DK5gIp18eBDpVODBJ0zqlPxDByfBMhBjycDLJgIlCWYQSkKkVcSBo8d5+Mln2brnIAuWLEMpKwa9ymGUJlMBBkWeWYzV6EB2DpXDA04Bu/YO8v4P/ja33nkvG1/YxCMPPcsD9z/J6173WiodiBDEau/7UsgPdKEWwlrL2Pg4PT09dHZ2vup8iggDL3FRch1EIlXyi82QRqvFc89t5KlnNnPs2AjTpw8QhjGVSpUFC+eT5wlLlyxk+/atnHvuevqndzFn1gCLFy/gnHPOZMZAP11dXT6p1FjjCIMSUhVY8/LWbZSrHdx9331UOrv4zne/x849+2hlOcdPDDNv/kIe2/Aks/oHGJjWw47t23jNVVcwb84sVixbwqyBfhbMnYO2hkAhXju+AdTPXcPiup76vyS9hmq5zPMbN9Ko1aTtjKHVSqjV6oRhSKlcplrtwBhLGAaUSiWqlSqlUpk4iimVK4Sh7MBa6yh7+YZSsuNqrfWm1xHKy9+cHxtFFbg4juno7CSKIhRSHcd46UdHR5WOzk50GJFbR7OVYZUGVcgG5O9KQixg0KkgkoA8IklIPehkvQGqJCVe+lOASd5Uv0ggtNKUSjHGGjo7OzjnnLPpm9YjAKktEnoPigYaa8WLR6YAYVAo396qzQDxZdqhDQ7INycvl8Ino0jC0/6Zv7DFGF69ejVLlixh7tw5lEoxWkEcRZRLZQ8MFAbr0h4AixYv4e77H+DRRx9h69atbN68mR//6Ec88MD9XHXllVTKZXCGjs4KlWqJKAoAg9aOPEtBCeNIzk0ktm3gsjgnmUlACAeeOXRyDhSfpVPOs2AZeGDllFOWUNIQ8rvOz0seRGrLCE++V3mQrgDtCqCl/aG+HYXfeMpn+fnRCiKDUuJ5hJNEUHtvHGMcA/39vO2tb6GjEotXDAqTnZRiai39QnqAZyMVCXYx9/qk9+T1LgAxD2J5IKr4yvmfF20caAGD5b1KgB8vfxMArzitk+0jTeFkQ+HnWtqf9sl+qrScs2dCGicm/aUwwLZqPP3Yg5A0ccaQZzmpB5+r1SpdXV10dXUShVH7XuSsQTvLWL1JmhswOZ2VCknSoqenh4napK/WJQwQ6b9SXTX04/vUNszSjCAIPUvJ97fC28yfrPYySGkhAWzzXJiptfokQRAwPjZKo1Zj9cqVdHZU2bd3L2QJKChXe2UTRymsErcrlPR5kbz5/uTEW+nn4+TtU45P3i5tEQcaDeKLFQig4Iz4hknFV1/lzhq0l4lrDQE5/T0V3vuOG0ibNUaHh3nbm2/gHTe8kddccTGvuepiLrngXEqh5pWXXyJwhp5KiSsuPo8Pf+DdXPOaq5k2fTpPP7uRb33/Nu5++CmODNdEzoUlT1PQiu6+6bzr9VexYFY/jfoErUYd8hbVSHPeGesYOnqYQBlWLF2EyTN27jtCFIXS9kqTGWFUF41QAKO5c7gg8IQzTUdHB+PjY4yND7N7zy6uvPJyBgeP+Y0I2RyQtiwAz4CyN8Y2xhCXypjcs/0KPNiPMenLJ/t2bsUnzjnxKJSQ8an8PdAphVKhSE7zHDzrEb8BkbRasg7yQGylVBI5ml8bhWHQZhvKxp5sEqj2XCj9UNjuRuR+eQ6FF1iWYa0lSVsok+OylLTVIE9bmCwhbTbJs4yJiQmanv0XaMVr3v+b/nymYiqm4hcppkClqZiKX4LYteUl8jwXyr41tJpNgLYxqCkkbT5R1YGUQDbWkmUZhw8fkoWU8pIVIAyj9o5bFMWEcSy7b2FIGEWUymXiUgmlNc5YbyYpP3PWEgYhxgidX0cB8xcspLOrC+XlW4HWbWZIkbjQ9lLy+6ungkuckpCdCkg4qWIjMiJJTIoFerFgslg0DmMdI2MNXnfDW7ntx3fxiT/4A/p6u6SosQJDgNElGjkcH5rgyOETjIxNYJWhVC7L7q+zRHEnf/t3X+Ghh5/h9/7od/j0pz/F4OAwG5/bjNIpl156luzeu1CqWSkj8hr/T3t5Vk9PD8eHjjNjYKB9rsVJFrIsgB/e8kP6+/vp6OgUaQ2yE71hwxM8+cRTnHvBRdTrTQ7s30+1UqZWn+CKKy5l3txZTOvrYs3ppzFr5jS6uqr09va0K/E5HEEgu88ozeRkkwOHDjM+XuPBhx6mmbYYn5wky3Oe3fgc06ZPZ+26tcyaNYetW7YycmKY11//OkoBnHvWOi664Dx6uzvpqJQJEMlVGGrZVQ1DSSJ/Lnn8uSzyZO7od+wDHeBszomhIXbt2EGkNcZaJibFUDgulShXqnR2dmG8nOdVoFJc8iABBIGAoQUzBQ8AGF/5JgqlglLuQaUsy+nq6iaMpLx4Z1en9Fcgz6X6mtaaadOnEZdjlA7FWyMzUjXNiDQuy4S5QgEsACb3JvhevqM96BTHMXmei9eZBx9DDyQVTCvZBRdgOMsyMXBFY52jUinT0VnFOvGuiiPxdJLEW5PlqYwvz0ICAdGkYo8kknKICl14BHkJks+1PMBQ9Fd/BZ0k+QVYASfltdWOKt09PZRLMWFYsO2szBUymsGzUCK/M16uVLjsiivo7e3hxIkh8ixjzdrTecc73s7c2bM9c8/RaNbEw0iL5C3QIhUF5NlL9ZQvxa21lGBXvn/hpXVFP5S+IsdfTDnKJ+e4Yo4q3t/mDrXZCPhkzWHbbCB5FGNb3i+gimeW+DYtkkyvNiw+vA01tIeGEqP1QjpjncIRCHuo3Zryt2fPniWvK6lIJ2yGSMAQHQiTywMcKA9e+vGhAwFN5NxPfjZFElp8jzBs5Lx8AlzM5UpKn8sxSRvj5+8C1FLSrP5c5G8pn+NLu51Mttt9TnngBknerfOgmCqAKA0mg6TBM489RN6ogbMEUURHRxflSrk9xyoP/GgtIEmoFBiDUQHNZgtrMnKT0dfbiw7l3tVsNAmDsJ2gOz9OtNZkaUrkWbwmN5TiMrkxhB4sFrBMztsWMjjlwMq9Qfu/KeNVPOFqtUmiMKBeq1GbmODCC84nTVoMHj9KVq/R0dFPHEUQKIxWGEXBLyt0lCf7xkkE6b9E0b4AGEPowSTlLIFW3putkHFKPynmK40l0HLvcjiyVoM3vf461q5aQaVUYv1ZZxOWKuw9cJRXtm/D5gmnLVvEheecydrTTuPMtafzvz72G1x00fkEgeLZFzbxL1/6Krf++KfUEkgp4XSMdhC6lHVrVrF8+TLqjQY3XHMxq1cs5uILzueM01cz0NtNa3KCFcuXYG3Ol//1X1m37gxWr13H8GTCsePH5Xw9mCJ9qTh33z5akWQZYRjL5pAO6erpodVqkeUp2195hXe+/R1MjI2LxA2ppuY8mCiSOAFRgyCQPhCE3rjbf4ZzwiIznsXkx78AxQio6ceLApwROS8ojJU1jQ5ColA2nXJ/Taw34c7STComak3gx3krz7DGtKuxxSVZ22VZRuSlbjjxlmu1ZCMyaUmlSZsb8iwl9z6drUYdnCNr1EnqkzQmJ8gSkYY3anXqjTphGJHlhjCKmTFjJhe+5Vd8O0/FVEzFL1JMgUpTMRW/BPHic09hrSXPDUmSYI0hyzJhJ6WJUJq9VMb5hbssCB0nhodJ0lSSF2fb/jRKB4TegFtpYSqFUUSpIiVro6hEFJcAyNJUdmuDgLgUoxAZAs6R5TlBGDJ9YDqz58wl94unQvImu6uymC2SkMKbQhW746cALkViIj+XBVwQSkltyW8KUCwkSSUBV1pL5TQX8A+f/zfuvf8R/uIv/orLL7mY0OWEKIKwTGpDXtl9kN/+xB/yb/9+I9/53m388PZbuf1HP+a0laezYMEiAu3ARdx+y8M8/8JLfPrP/hdr1i1Da83P7voZPV0hb37ztQLeEaHRYjSM7AAa71/igEqlzJEjR5gxY4ZPjCSZlUWpLAyDQPPkk0+SpClLliyRBM0n7rNnz2bpsmUsXbqUjo4yq1Yu59xzz2Td2tV0d3VQrcTgchQWazKSpIVxIUqL34+xiqGhYV7eto0jR4+xZds2hkdGGBkbYWR0GK0dOlTs3LmDJYsXsmDeXFauWM7AtD5WLl/GqmUr6K52sGDuDKTeUpH+KsIgBCXU/dzB5pe20N07jSh6delrfMIIr5bE4GTBb/IMmws4sPHZZwg8q6fZbBJEEXFcoqPaQVdXlyzIjRVmkFYCzHi2gw6kn4m5qpd4WYP1crogEGmY87It56SCXqVSoaOjg0qlQndXl/SjXHZtrbN0dHZS7agQRTHWQTNJSbKcJDPoIMQ5n2xrf9E9E0qSWS1gKPJZgWceBacYqBbZdAFKxbGY0hcJnTrFw8WBtK/kfARBhDOSoGglrDcBUDwbx88JBUNQ/nbxkfLeQv4YhpE/DpFkhGEEKOK4RBAElOJSG2wJPICIr0DkEC8sDcKMKpInxN/JOgHywijyo1uAnlK5xOIlC7nggvO46MILWLnyNPr7pxGGCmszlJZ2tR6YC4LAAwqS3FnriH1lMO0TfplHpE0A4lIJnMwX7fYspIVaGD9BEEiZbif6E+tABxFKBe1r7Ilpcl7OEITiQeeRHgFxfeKJ0pRKFd8fRDLUPj4PFioVtFkHAgRJlSr8nOmQayEJqJfInGL0bLwhfG6k8qEcmgKlpSKhFuCruPbCSI1wOOI4JowicALqFnO1fIa0XXHdCuacMP/k+sdxGYsT0NCdnLUFxPJzhO/TQRD4cS/JtzDpTvZtOEX26RlO8ru07xvGWJFnFb5YUoOPwFny5iQbn3iUwOa+WmmM0wKomzwnTcVbKfCSLeXEbDgKNQ4BAhqNOgbxxKtWOqiWK2inaTSbvj1lTDlEBio3IkiTlCAQqRVOWJHSnoUXjtyDT4b3c3MnGXsoz7zyc0G1XCFQcPzYca64/FLqtUlOnDhBcyIRX8NyTOosLghQWtpWeR+lwnKraMNTH3DyuXhoZwmUeOfghINWzE2ZsegwbPffNE3AWTQQRBHG/70zzljLooULGBkZ54e3/5ivfedm7tvwAs88+xwPPXQ/03s7WTCzn5n9/VQrVU6MjvGdH97Kf373+zz29PMMj9WpdHRhnMi8tNbkSY3rrrqUt7zhen72059w7OhhXtnyAksXLyICjuzdw4rFC1h/xlqicol6lvHQY09x8Ogwi5auZrLZZOfOXcLkUsIwE0m5n/xcARQL4CrFDQIsGoOiXK1Sr9dIWi22vvwS5551Js0kZXR8XEBNZI40xpDlGShFGERyTys2vfxlF8BaAPliflUeKMavbzJfkEErAaeVEjBb1mkCPsn4Pinls4WfXyb+SjbPiP1mRFyukCYtWs0mQSDy5yAM2pJA55mL1hoyb+ptjciInclJmg2wRu7NJiNtNWlOjGPTFGsMtclJ0iQlz8V6odlK6ezu45LLr2Dt+rOYte6CU/r8VEzFVPyixBSoNBVT8UsQO17eTLPZxDkx+bTGkKap9xHx3ibFDrpfzTjP0BgcHGy/pnyyIQl2ibgkfjRhFMluViy+SkEg71EKWmlK0mhinSMulaRcbZahlDAD/IqJSkcHi5cu9V7BsrDS2jMAlN+J80CRUviddklSimf88eGKJEZ2weX4PePAIcmVtbKgR4mZtVXsOXCCj/7O37Fw4Qo+9ck/JkajrSUMY6zT6CDinnvv4Vvf+E/OXL+W97zn3Til2LxpJ1u27OZ1r3sj5U4FKuLBB19g2/YDrD5jGevXrWLrS3t5+L4HWbRwJm9583XgJUYSvpoKUo63aO8oihgeHmZgYACUVNOSNpB3h4GYoK8+/XR+fOedpGnKPXffw2mnraRS7SCOS3R1dVEqa/oHepg+vQelLFEYiKQQRRSVyVJDs5HyT//0RWbPW8bBA0fZuWsvjz++gaETwzzzzDMoZZkxMI19+3djXcq6dauY0d/LqhXLOe+cM1m9cgVzZ82gEoWUw1BKHVtDpBwGh1G+6o/TjIxNsu/AEZqZ4fs338rXv/ltBmbNJbOOWQN9qFNNPU75st1cRYqmFVEQiPGoc7yw8TmMyWk2mjjnxL8rCOjo6KRcrVKpVrw0RRJd6bclAi99E8NcGR94LyBnxQfImpyOalWYLsZgrPUAoKKru4tqtUpfX58k99ZinUUHAX19fcQexGomKTqMqTVbIoXzjARbeGmogiXjgUNfmbFIRNuJpO8b7lQ5lpXPOxUgxoOnxu9eu6ISlQ6AgONDI5RKFcJADFrR/ngku0GpgCRLUUpjHKSZJFdaC1DSSpI2KJjlBusgKol3inXi9mNRjI2Ncdutt7Fg4QJUEKKUB6o8cJbnMg/J+XjAGekvDz70MEEQCCiovaTIy8WcM0ShJPuBuNgSeRaQDpSAg1bONzeKRrPJhg0bmDdvHsYYX949E4aI72eF504QivwlN1bOpZB7aUWWSaWjNMslOUORW+f5jprxiRr33Hsfew8eZP6CRZhC2qUU1lnCKCY3Ali6UxJM8cmJaDRa7N6zlxkzZhEEUiHPWMehQ0cYHZ9gslZnYrJGlueUKmVOjIwyPDLGZL1BK80IoxJKB2S54/jQMBOTdUbHx8Tjq1LFZAIwFucB4tNic2E1tJlwVphFgff+kfuEMCCcRYoVOGFOZMaCZ8NZa8mMweJBch2SpjlRXCbLDWlusE5hcg/wRzHOONJUSpMLeCHjN8+lymYxfzsnoKrzkjAKiZ5n2eIkaccnzsoDnraY953z1ecUoXbYpM5zGx6BrCmgt+/neZYLGBl48A8nbWQFwMaKn1woJjZMNmooLTK73p4+qpUOJibGvczMEQUCiAa+IEbBDiruT0EYehZeTm6MsHyVSA89uijvBxkbCpyTeUEwKTlfrTWLFi7m6NEj1Go1Lr/8MoZHRhgbHqVRG6dULaOjEBWGbXBIFR6DzrWlb/KTkw+5b776UQAd1oFxCnQA3jBfxmpxr5Jn2ZAKMCrAqJCwVGLzi5vZs3s337jxJnbsPURmHDprsnjBbD7+m7/BFZdfQSu17Nx/hH//1vf48te/w87DQzRMSE6ZICij8hbV2LFm1WJGh4+SNid4/3veSTkMuPvOOykpzUSSc/DIIGtPX0M51Nx047fZf/AgtTTHRJ08uWk744nm8aefZ8/OVwi8IbUOAvDgbLv95VLI7OYcOI1VMvatUuTG0dXVTZ5lJM0mL23exPVveANKwejIKNY6sjxDa432VUeNESmjc/i5t/BYkrEpY6L4XAGi5R4hYHOeyz1J64AwKgmbqACr8cVX/GagzDsFKCUgZZZmOBxRJJsD5VJJGLtWzPitNSIB9/NCmqUEOqCjWiVLEuIwpD4xTtZsop2Mj6TZIEsTGo0aNs1oTNZotVo0my2aSYIKYxYtXcG0WbM5/+LLaWSWDU8/x6U3vKt9rlMxFVPxixNToNJUTMUvQWx+9ilareRV7AaTG9JMgKUiWRXPGW+kqRTDw8NMTEwAAugEXu5WLpeJyyXiUolSuUQUx5RKJcrlMpVKmVJZJEXWV6pJ/GeX/O8ov+NqjFTRUoHswC8/7TRJNv0Om1KygCp8M3TBUjoFSCoWW0r51wuvHeeNcLWYgWtdVNESKZ4k7hBGJTIDo2OTfOQ3PsGhYylrT1/N7bf8kB98/7v88OYf0tPXy/LTVpDnCcuXLebySy/iQx94H+ees54rrriSo0dGefDBDUzWG1xx9cXUm44nn36RV3buZ+PmZ9nw0HPc+9P7GDkxxG//1q9z5hkrcTZDe5NdWaTKolQYS8KcybKUo0cHmTNnjrARwlDYJH7nW8ACSUrPOOMMkQyFIUuWLBFwTfmkQVtf8UqAkxc2vci06f1kuaNWb3H//Q+zbdtOGq2cNLPs3bsPh6PZaKC1Y/XpKymXQnq6OzjvnLNYu3Y1c2bNZNaMmVTKZTFf1cJaQEk/0jpAhyHNJMEFmkaa8oMf3ML4ZJ3de/aS54bR0THGRkdZtHAh689YD84ws79PDrutdDuZUBWhFH4nVpGnKYEScGnLyy9Tq02SZ55Z4CWUcalEpVqlUqmQJAl5nlGtVokj8TJSnARRbZ5hrcjb8K9ba0nTlM7OTrQHgfLcYJwcZF/fNDo7O+nr7ZX+qUXaUCpJ1bcwkN1udECaG1pp7pNxJUaoeS4Ap5OKPsZXfcvzXMx8iwSuff4COrmispUfA66oBOe/Vp51CBBGobBMKiWsVVTKnXzqj/6E48dPcM4556K0A3IyY1BKkp3cFNXeApIkQ2uR84gsNkcHAhYIUzES+aeSsfYP//CPLFm6nN7eaWRpxvj4GAsWLpT3IcbuTqn2tWp7WPmkyiKJ3Oe/8AWWrTiNuXPnCXvMn7MkPHJuQRCQZSlxHJGmUvUvM9bjgppAi1dbs5XwT5/7HNdf/zpKpbIkV06YUzj88UuSHMUln3gVQLWYGRevoTTGSTsFYYxDWEvogDt/eheT9SbLlp/G9p27+elPf8olF1/k2QcaYyQZRElhAuuTwyCICKOYffsP8vQzz3DmmWeRG0sQRgyPjPLXf/M3Ai4dPsz+gweYqNVZvGQZf/zHf8JkvcHRwWO89NIW7rnnfi644EJaScYXv/hlavU6+w/s5+mnnuLYkUHWrl0r/UVLlTOLMKuck75ULseS9PoxpLwHk1K+kmcgIE1mFF/7z2+wdt0Z6FAq7inPdHIeUKJgxFgBG4p+EkbCZFNo8kwAdpk/PNPCeyG171ntKeCU5Np3GK0KHyY/73uWkgCrng2nNFhhZYgUSaFsjm3VeP7JRyFtYk3u50svwfa/b4w33/efJX5fMZVyTCkW8LaVZjSaCU4FGKcoVSr09vXRajRkE8UzPmJf1bHYLBHwUtgvWS7jPgoDjPXvAQIvdZJh7udDv8kCgk9ZB87PS5MTk0yfNp1DR46gtOaKK6/k8MH9jI+L51JnZxdhEKPQnsNySrx6qm2H+h/YS9YiwJlWBIGAXWDQLidSlsDlaCdsZFXMYx58Us4RKsvY0CAmz+ib3s9F55/DR957Aze87nqmTRtg85YdfO7LX+Ouhx7n4PFRiCsEcQWlI+qNFmnSoKxSfu83P8wV55/D/IFpHD90kOuuuoLR4SGe3fgcjSSFqMzYxAS7du5kzemns2bdep55YTPPbHqZl3fsRYUVMuuvOylaaxYsXMj06f0kSUqSJm18r22iX3yP3I8ccjGUl8NWKhWMsdRaDbZt3cqsmTOYMXMmY+Njfp0VYgrzcM+MdM5RLpcBkWMLkFtIEmW+k0+TDlHMRw6RG2YePNKF/5czWJMJWO9BbOX9mcSTS+TieZ6TG4txsgpxOErlEsbIOjFNEv97ArQqz5h2fhMma7WkAiyWtNkgbbVoNuu0GmLGXZucYKJWY3RykukDM1FRxIKly1l1xpnoSgcPPP4Et/3kZ7yybz8f/t0/9Oc5FVMxFb9IMQUqTcVU/BLEyxufQbVp3CL5ANltKpgNBd0+bFekcezZsweloFQqtwGlyJsSR3FMXBJAKYpi4likRuVyCR1KkmitpVavtUtOa62J4ohSHLe/t9YSxhGT9Rqr16wh9B43xaJVgWcnyW5n22PJv0aRXPhn4yVLFAwO5whDWRzlWU4Uh4A/10iSwTCO2fDERv7pn79MT98MBo/soVEfIctbDI2OcvPtt7L+rPWsOX05gVIsXLiQakcVHYTElRLTB+bwox//jCeffpZm2uL737uZ++57SJIA1eTQ7r2EGP7kf/8+733PW3A2IQxAluOSPBV+LOIFI4s+ayxjY2NUqxUqlQr4Mt7SFl7ugUJpYaTMmjWTZcuWoZRC+3LO+ITKWhgfr7Fz116efeZ5evv6+cHNt3HgwBF6+/rpnd5PZhyDx46glGX+vDlcdOF5LF+2hKVLFrJi+VIGpk+jUo6JgwBrHBCSpBlKRTRbKbv27KPS0c2xEyPs3neAhzds4L6HHmb+ooXU6nUOHz7C/Pnz2b93P6U4YuZAPyuWLebMdWuY0T+N2TP6kfSJUxbQ0guKBKud9SgEbPS7qYFWHBscZPeuXW22XBhGUvK5JBK1aqVKHJekwpt1pFlGGAprJje5VKnJhd1yKqjkvASu7KveOc94UFrAya6uLnp6epk+0I8OZZxkeU5HZycovBmrgAO1RkIzyciNRYfRKcmzVICj7eEjZtW27StTyOLE1Nh4dtOplaROPW7lWQSBl01meY5BdsMh4LlnX0DrEk899TQXX3whPT2dWCdVltABJ04Mc/jIEbZte4XDR44wbXo/RwePsXnTi0xMTtI3bbqwjoKAXbv38NLLW2mlGX3Tp7N3336+/4Mf0t3TR0dnF9Om9TF84gTz588nCCMOHDzE088+y+DgIDNmzCDLczZt2sSMGQMopTkxPMrhI4P0D8zg7nvv44z165k3fz6jY2NsfH4je3bvoVwu09PVQ5qkbNr0ArNmzUIpxbHjx9m9Zw+zZs1h8NgQmza/xMGDh+ns6iaKYu67736uuvpqXt6yhblz56HQtJKEbdu2MWPmTHQgJeWNsRw6fJiXX97C4LFjTO/vZ7Je5+Chg4xPTDI0NEwQlXjxpZd5ees2ms2U3r7pbNn6Cnffez/9A7OYv2gRz218geeff4FqpczceQuxFja/+DJbt24nCCOq1U6cUrRaGY8+toEDBw9hrOXEiWHOOvMsnBOQNkkSfnrXXfzBJ/+Q8y+8kNPXrGXZ8hVkueG22+/gwx/+dc6/4EJWrjqdHTt2EYYlenr6eGXHDn79Ix9h7drTWb5kKV/7j69z2aWXCZAXBuTWsm//AZ55ZiP79x+iUimzZ+8u8QrzDJ+du3aRZjkjI6NseOJJ9u0/yIwZs9jw1DNseOJpOru6Mc4xbXo/u/bs4YVNm5iYrDG9fwCU5vnnN1GvJzz97HMcPnyUmbPm8Mr27Wzc+AJ5bpg7dw7GWspxiTRLEYKOI/f93RUyOM8MtIX87dT5oB3yHmF9CHvHWYtT4hlTMDYcEGmwrRrPbngYnSZE3ttNABzpA1makWXCoCp81cIgoFwuEYeeMWQtTgWMTzSYbCVYHaCCSOR0YUB9YoLcQVwSvzbxpPEsQmtEDuhlrXkupsdhKN6D4hlVAApevieIgpy9IDXQBiUANFma0T9jgL3796O14tzz1nPo0EHqk3WyVkZXRw86iNvsmgKo+r8Kp9q3Lak0mONMgrIJZA0il6GyJiEZuRWgECeslyAMIE8ITEpomlx/7dV8+EMf4qILziNUjld27uMb37mZr994MxOJI1UBRolcVAPKwnve8Rauv/pS9m7dzObnnubMtadz2rKlzBqYxoy+bkpRxBlnnsXi5acxfOIE9YlJJmuTnBidYP7S5ew9OMjxkUnSVHzVnM0JsMwc6GPhokX0D8zk8JGjtNKENM3a4BEedGm3gUM8EU8BmhRSRKHSUSVzhrwlnoZnnXUWHdUq9XrDs4oECBcQUzz9BBwtvI+88baVdVpx6YvNM/yax3darJV7VaiVyD1NDtaAVuS+aml7w8kb1xefZYyAS85KpU1ZrwkbXRXrR2QdFscxxuQkSYsAkb01apM0azWajRqtZpNWvU6jWac2OUkYl5i7YAFBHGOU4jXXv45qTx9Pb9rMD+74Mc+/vA1VrjJvyTLe9au/5jvYVEzFVPwixRSoNBVT8UsQzz3xOI1GA+13sCLvfwKc9FFxhZxKfFwajQajo6MEfkdNay2gUhxTqZS9MXfxCNtAUxiFZFlGs9EgTROMsVTKZQGSEIBKElv5/CiKCKKQRqtJ37Rp9A/MkEWTfzh/jHDKLqn2LCX/Gj4JKJ6tdZ4CDkNDI4yPNwgCOc5CWlUsEI11QESzZah2VPnIR97DR3/93Xzow+/n1z7yIVafuZ4f3nIrx44P8ba3vQ2TGUbGahw8fILHnniWf/7Sl/jWTd9i8MQQc2bP4/FHn2TX9h28861v5o/+4H/x+5/4AO94y+v4yEfeyyWXnEUYWEKtMFku5+UX8g7XNsItADMx7gzYvWcPc+bMlV1CfVK6FgTCDFLeRyHPc8bHx5gYn6SjowOlNENDJzg+NMYDDzzKvv2HOXp0CFTItu07Oefc8zh6dBAdhZwYHqHRqHP5ZefR2VFmzuwBFsyfS7kUi4GnA42mHEuFGoiwLmLzS1vZ8MQzJJnlO9/7AdMGZtJIczZt2cLeQ0e4+PIrObh/L61GnSgIUTguufBCZvRPY9H8uQxM66GjHBJri3Yiy/n55OYkoHTqj6TtnDeq1kCz0eTxxx+jWq0QhQJ+Sr8sEcclKuUKpVKJWq3O4OAgrVYL7T0/nHVkWYaz4k/RpjsgEhVrxCRb2AvFGl7GREdHB319ffRN6yOMQhTiP1Qql8nyTPq4FiZavdnCOEfimT5a6zazS85K5HXF9bTtMtNe7oMkD8oDptofT5FsF4lG0U4OkZ04JWlQGMbUak0+989f4MO//hvgHI1GnfkL5oDKMU4S1B07d/GNb36TgRmzOHZsiNtvv4OR0REGZs7i0UcfI7eORUuWcP8DD7B3337mz1/IYxueoFyu4BQ8/vgG1p2xnhkzZ+Kc5S8+86e8/Z3vYveefXzzW99i2fJlHDt2nFq9Rn//dG76zne4+JJL2kydw0eOsmr16WzYsIHTT19D//TpfP0//5POzi6UUnzjG99k7enrCMOQG799I5dcfDFhGPH8pk08+OBDnHXWOXzpy//GqlVrhFVmDL29fdx7771ce921fOfGG1m+bAXd3d0cOnSYrdte4YwzziA3Utny/vsf4N5772PhokXs2LmT1Et2//nz/0Icl1iwcCGDx4YYG59g2vR+fnbPvfT29lGpVjlw6DDVjg4WLFzE8eND7Nu/n7Vr1rJw0RK++a0bmazVWbhoMQ8//AjTpw9QqXTy1X/7d6KohAoCHn/8cbTWnH32OWIurzSTtTr33X8/a9auJctzRsfG0UFEGEb86Mc/5tLLLqenp48gjBg8dox6o8mCBQt56aWXWbduHUGoqFYqPP3k05x++hqmT5+GxbFz926+9e0bWX36GiYnmigNY2Mj7Nu/n5WrVjEyOsqf/tlnOP+Ci/jzv/gLzjn3fGq1Oj09vYxN1Nm1Zx9Lli6jv3+AQ4cPc/sdP2Lp0mXs2r2bJ558kjPOOIO7776Xp598hsVLlvLSy1v4/g9+QBiGdHd3cfMtN3PaaSvp6+slzTJAkuKCuVEAqnhZtO/+7ShYSuJtI1WslJeDOifsJR0EUgHr1MpVKJTJyRsTPPP4g6isRRjIvc9aS5KkZJmYc0eRAElRJBK1QImRvVZSycw5AQVVENHMDfU0Q3vwqbujgxDNZKvpNwsszgmLyjoZ95mXN8nc4k4CFG1puifGOCe/39Zi+TlKC3POb8HgrPT3VpIwd948du7aRf+MPs4+6yxe2vQSJslpNhM6OnsgCMXtTsmD/zr9/g8hEnOtlRCPsNisQUnlvPbKi3nXm9/ADdddxeuvvYJLLjibamcXBw7sRbkc5wyN8VFWLJrLm667ive/482cc8YakkaDn917P5//2k08/NRm9h4ZRcVdoELSLCVLW5TigAiLS1NWzJnGtRedxdyZ03lpy8u8tG0rCxYtZNHCuSiTce8993DkyHFmzl7IOetO54Lzz2HmnDk88uRTPLt5C4eOnsARkqcpK5YuZPaMXhYtmE25o5N6vcH27TuYqNVoJWkbTKIN3CHMRpSYqBdiX+ewRtoHrTEaKp2duLRJlrZ45ZXtUoHz7LM5cuSIB4cCD1wq2egIQnKTo5X2ZtmWPMtPHoGXcsoaxq8Z2tXhpO/Y3KCVJQza9SjbA8fiCP06T/qXjDn8PUcrAZcUWjZmItkETL23plJamO++0luaNGnUarQaDZJmg8nxCfI0IU0TKtUKPb3djI5PMnPufNaddRZzFizi8Wee5fa7fsaG556n3N3LvKXLmLN4KWG5g7e98z3FmU7FVEzFL1D8HO91KqZiKv7fGs7hfZRk1yqOYyl17k2Go1g8WiIdEaiApJUSRjFah+ggpFztICiV0KWYoFQijGMCL9FKU1mAt5pNhodOkLZSent6mdE/wIz+fkrVKp29fQzMnEkQRbKrqjUEmrAUo5WmGpU4vO8AWig6InVTIl8qkmj5p1FOyfQVhEBASEjgLOVygAssJiiz8eX9/MlffZmrrv9Vzr/wbfzd33+dyUZAmsdYE6NciDOGUmQx+QSnLZ/HX33mk1z/mrNZs3oZCxbOoWtaJ6vXnY1tldn80jH+5u++yZ/+5Zd577s/wWUXXcfv/fbv8sQDj2Em6rzrjddwy/f+lUcfvoUnNvyYP//z3+Ti85cyd1oXy5f1MWd2l5ihEmBMjsMRBBWUKqPD0Ff1OcnI0VrKwA8MDLB37x4xO/dVwIw1OOXIbdYu1b1v3z5uuum7/P7vf5Lf/cTvMnT8mJinWsPzG5+hq7PM+eeuJ0trKJewdtVSDuzexrVXXcQNr7uad775tXzs197HuWes5TWXXcqalStRzhvLomk0U+665z6Onhihnhp27j3Ay9t3snX7brp7+3h5y8ssXbwIkzQZOXqIjgAuPnMNC/p7uPyCc7nwrPW89jWXc/EF59DdVWL6tC6UMhiXkztLjpOKRP9NRuP8v+JrfILoxEwE5xTWBSxYtATjNKVSJ3FUJgpiOsodRGEsPkdKdv47Oqs4LMeOD3Ls+FHq9QmytIlWDuMMxhlyJ4wBvORF+0pqDtBRKN5E3purlSSUq1UxAw4igihCexlpHIUEOqRU7qTRTAFNkqSUy2XyPG0nk1mWEhRyH59IFyBvASAV7KQiitcLoEtrTZIk7Z8pJWbkWZpSCmMiFaFswN7d+2k1E+bOmcl111/L85tfILMKqzrIM8Ao0iRj4YIlvP71b+L1b3gj+/Yf5NrrXs8FF13C1ddcx8/uuZ9WC+78yb1ceOFlzJ+/iCsuv5INGzawdNFi4kBz5rrTWbJwLlGgsSogzQz33Xcv11xzDa+56mre/ra3c8lFl3ifpggICcIyDvFOUkApFt+a7a+8gjWW1153PVddfQ1vfvNbufe+e0nSDKs0lojMatJcEZW6MIQ0k4yoXGX9mWexevUq8NerXKpyzTXX89DDj2E8c2jFaStptBLy3NBstLjjjh/x1re+nXPOOY93ves9nH76WqyvdnTDDW9m6dLlrF2/nrPOPZc58+ax+vTVbNu+jYULF7B44TzOOWstq1YsYd2aFXR0lLj6+tfSyFImm02uuvZaZs+byxlnnsX2HTs4eOggc+fO5b3vey+vv/71XHPVNZQiYQKgIDOGPHdkqeUf/+Gz/Nmn/5S/+vM/58TQMNaAs5qh48McHTzGC5s289TTz7By1SpUoKk3mwweO8aJ4yM8+ODDTNQnmDVnBrnLQMH4+AQozfRZs7j69a/l7AvP58zzzuXA0aMQhDyz8QWm9c+ku3caaQ7T+mfymmuvZ9ny1Vx02cXMmD3ABZdcxKy5c7n1jh9z9nkXsHTlas694BLuuvdBhsdrJMZy6ZVXcMnll/KGN72BHTt38OY3v5nXXX89l1x8CS+/vAWpJSjSQ61FCqm1CHGU94+Rce8EevXA6atfLzy5xE+mGBfFDCKFDiBQARqNs8ZXI1NYLEma0Wy2cM7SUSnRUY2JIkccWjo7QsoxhNoSaIczBpPluNzSWY6ZM7OH2dOrzO6OUfURakODjA8PMzpeo6d/gEUze0kmT6BsSqBFShlEJYyTjRWcRVsjLFDvhaZQRFEsc0kUEcdlwrBEFJaAAOfvoVprAkArD0gpSKyh3mwxMVFj7twFPP3My9RqTd75jhuoRC1M4zDjx7ajk1FClyKfCkEUYMlweAmwc+AMihylclBSbcyhyZymZQzGpKAyAjLe/sZrec/rrmZOd5WXXnyRhx5/ChvFvOmyM/jQ26+GdIQZXSX+98fex6c/9itcfvZ6mlnATx95lj/683/iGzf9iGMTE9QSAfRKyhBnNc5csZDrrriIrDVJntWJgxbPPnYfR3ZvZ+WKpdzw5jcxPj7G1/7jPxg6NsJE3XBsPOO2+x7jr7/wZT771f/gy9+4ke/84FayzEkFXJcThrBw8UJ6+2dgiDlwdIznX97Blh37mWjmtDJHbiH3ldSME7aPcQ6DlXuXg9wqeZ+z2MCRK0OOIrMRrbxEpX8RQfcs8rDExs0vcPTIQVaftoxYK8gNXZ2dlKtlOns6cBgqlQqVSpXevml0dnZT7eiiVK6iw1CYan4JFSpFFGh0qCAEF0IeaOrAcMsynCgmXYU0B5vlWGMxuaGZ5tTTnEyFpDqiSUAtcyQqYLzVopYkjIyNMT46ysTICFmjTk+lQugcabOFUopWq0FSHyep1zCtOo3xEUzSJEtaTExMMFFrYFREubOft7z9vcxdsJSnX9jCv9/4A265+wEOjddZuGYd81auomPaNAgUTks/nIqpmIpfvJgClaZiKn4JQuQxAWmaMTk5yeRkDetsu3JVFEWEobCNpAqW+FzI98KMyXIxEG02muRGtPhKaSqVCuVypW0KPX/+AubOnUO1WsE5R71e58SJYSZrNfr7B4i8j40OxOumSJLjKGJw8KgALn63rdhVBg82qFO2qZUBlaFU5l8KgRDroJGk/OEff5qvf/PbrD9nPSvXLePL//5FvvTVr5BZ1wYwXKBJciMSgAJMSDRHjxznlW17uPNH9/N7v/179MzoRakWX/zCZ/nB97/L8hVz+f3f/w0+/7m/5babv8N9d/+YL3zu71m+eBbLl85i6dJZdHUGhGFheKzFbNdZao2Uw0dHGBqp0UxzstxKYujBC/GMkjLMsoupqVarNJpidl5UgMO3kfPeC7t37WFkZJR58+ZxwQUXsnHjRtI0YcbAAL29XSxcOJeeni7e+Ibree9738mll1zAe9/7ThYvnk8pUpRiTRTJrnsUi9Fvkma0kozxyTr7Dhzk6OBxnnv+BZ565lk2bnqeifERTpwYJIoUl15yIddd+xrKpZA1p6/khjdez5WXXcziBfOolCKiQDw0FMIqEJaWJIJ+H/X/KrTSvuS3ry4VBsycNYtZs+ZIFcJSmWq1Kiy5slQgy3357c7OThYuXEij0WB8fIyxsVGyLCVJWmSZAKRyWCKLsNZifMVElLAjwiAgDDVgybIUh0OHAWjZ8a9Uq4RRJCypUoksl/HU1dVFpVwRcBeR4+R5TikutaWoRTjvH2T8eGvvLHvQqP3s+wLgQUD/+/5vBN4jTcZ5wBNPbKBaLfM3f/PXfOlLX2D79lc4PjREK0naAJdUFNNigu79zMqlGOXls6MjwzSbDWqTk+zatZOXX36JE0PHOWv9epwTo3OTZ5hcqkwWEq5Dhw7TP326gGe+Wl0YhFKhy7eH8qyrwBcFAMXw8AiLFy1qG5kPzJzJ4OAg1hkpj+3L2NfrdaIopKuzi1/9wK+yZcvL3PidG3n88cc8U0WAuLPPPpsXXniesbExNr/4IvPnzyfP5RrX63VarYTu7u52u1arVcIwYumSpVTKFbRS3HffffzsrrvYsWM7IyPD4mkWSJU1rcCaDI0TNguOiYlxTgwP8dJLL/Li5k2MjY0wd+4cWs0mlVIJm+fgnEhdcURRICyFXOY4pTV//Vd/zef/+Z/53Of+DwP908mzjDRp8czTT3Pvvffwve/exPve+x5OW7ECaw2TE+M8/PBD/PSnP+HgoYN88pOfJC6JObczhrPWr+e6667juWef5Ytf/AIPP/wwc2bPYWxslEOHD/Pss8/ye7//CWbOmslnPvNnbNu6lW9/+1vcfset3oPopLn91i1b2LVrJ089+STbt2/n7W97qweHFNWOSlvKNW/eXHSgyLOMjmqVpNXEWO+t5cFQfN91TqSmxffyM/neFl/5+4QOAvFLUkJzFcN5ME5AJQGpvBm779PGGOq1Gs1WkzAM6ahWKUURCkegFOU4plqV6621JjeGJE3JjCEMY3l4j6WuaoW+rk6mdXeS1GuMjY4wMTHO6PgocSmmq6uTWm0S5wzG5sL08OcWeW+l3ORe9uolfwjIFoaRmHlHkcwrUdQuRqE8WUlYl2KQjZfoHj9+nNHRUY4fG2LDhifQWvPOd70dbEZj5DjDgwcJTQttEgKXYvNUbi/+hls84317JGQeV85QCgPCQJNbR6Wji/Xrz8IZw6bnN/Kdb3+bu+76KQ8/9BCx05x3+jr+9bP/xD/+1d+wbu16Dp0Y48vf/j6f/ocv8LXv38Lx+iS6GhNGGmcm6e6A2TN7qNXGef21V/PGyy/iw295PbM6Slx+yaW8/9c+Ss+s+dSaOWtWr+Waq69hfKLOnfc/Qlbq4pJrX09X73SqpTLNNOP4iRG6e/uYM28+Z551NmvXraPRaNLd08vLW7Zy/MQIe/cfkHuyZzEbIyCS9ENhvxXPzp76mvPFCcBhsQgAZZzDOkVmNR0906l292NVzH0PPcLOPbu44qrL6O3rRCnxiHNG5NKlOKJcjsWnslylp6eXuCSM21Kp5L0iC1azlspvQYAKZVNDBQEGRSuz1JOMzGkyp8iscKqyPKeVJNKXsxzrIHeORpJRb6aMTUx6me8JTgwNkbSaNBt1sJYwUDTrk5gsIUtT6hMT1Gt1arU6hw4fgSBk7sLFLFu9hvXnXcD8pSvYsHETX/vO97n5zrs4PDzGohWrWLX2DLr7pouHmS9QMpWUTsVU/OLG1Pidiqn4JQgpn+2XO9aRZSktvyuvg0CkOiVJfo0xoBytpIm1lvHxcRxOWDP9/cyaOZO+3j46OqpUq2VP6ZcS2a1Wi1p9klqtJjtVE+O0Wi1aSYtGo4FTUC5XMF6aYH0p5CiOsM6RJim1Wg1cIXlDKuWcmkD7pa1SDlQGOvXgRIAjRAUhe/bu57mNL/Du97yHL/7rP/OP//y3LD99BV/4ylc5NDhMTkhiFLWmpdaAg4dO8OAjj/KVr/4bv/eJP+Fd73wPl158CZ/4rY/z0vPPMXdGJ9+/6Su8tPlxnnjsHr74xb/h05/+Xd759jexbs0KZvb3UIk11VKATRO0gzy3GKcwLgTdgVMROfD8S9t489t/hb/9h38hQ5HYHBVEgDcf9it3D50BsHr1auq1mkioTkk2ijenSUr/wADDw8MMDh7jrrvuYv+BA7LotZaLLr6IFaetoNpRoW9an0hEtMKYXLx8tJQMTpKEejPhth/dyXe++32++OWvsOHJp9i+YwevbN/O4sVL6O3p4/jx4/T1dvPkU49ww5teywXnn8WSJfNZuGAOZ65fy5w5M4lCjcZhTSrnhSTFqkgWTzm/NvOgAAz/H4Rz4ol0asKjg4D1Z66X0tklWZCXyxUCHYhRtQeInLMMDPTTP306jUaDRqNBq9WSaoQOynEM1pGlGXmeMzE+ztDQEOPj434hL6BY4MvA1xt18WKxIk+MopjOrm6UDqhUO4jiEqEvtd1qtSQBsZYwCknTlNhX4CrAnyKZboNCWpNlmYwFDxI7z1oyvhIdvs+EHrTNvAF2qyW7yrnJMDZn6MRxsizlU5/6Iz74wV/hN37jo7zuddfzkx//SCQVVtgx1uQECvI0QXnGW6AVcaCJtCJtNujt7WL27AHmzpnJpZdezLp1azjttBUiF4pCBo8eJctSMT73V3zNmjU8/fTTTE5OcuDAAe6+526cc9RqNYZODJGkCS+88DxpmpDlqZczOZYsWcSWLS/TaNQZGRnmoQcf4OKLL6Srq5M8T5mcHKc2OcFP7ryTOAqpNybJ04S3ve2t3HDDG7nvvvvabZumKVorLrroQr71rW9x1pln+naTRozjiJkzZ/Doo4+QJC2OHz/Gjh3bURqpzpVnBKHm7rt+wiUXX8gVl11K//RpmDQh0BAoUE5qwSlnyNOEPGlSrZTROFadtoLrrr2GC84/l9NXr6J/+jR27dzO2NgIWZawbdsWWq0GxmSAmOwrJYyRNG1Rr0/S8ma41mRo5bj+tdfy/ve+h6WLF/HoIw+RJk1MlrJwwTze86538qEP/iq/9qEPMm/ObFqNhpeNGVqtJmtXr+J973k3V191BTu3b0ehuOKyK/jWt77J7NmzmDN7No16jVIc8va3v5XXvvZatrz8IlEY0KzXqE2Mkact3vG2t4I1XP/aa7n8sks45+wzmdE/XSpIZSlp2sJZQ7NRw+Y5WZ6SZQnGCCswzzOskzFqC4mXH294xpLcxwSkUwXQ4a+bVL+S5FTGhJh0v3pe+fl5xomJf7nsQSsIQ00UhZRLJcrlCqDIjaXRbKF0QLWzi0q1A+PAeKZkoAIqpTKdlQp9XV10lGPqk2NMTowwPj7KZL3F4iXLqVQ7aNQbKGuxeUYUBORZKkUHjBRjKM5DpOcBcRQJqBUEUpkwCIhC8Y0rNoHwoJd4vslcm3uA/PDhw+AMhw8d4elnn6Onbzpvf8c7iUsR+cQItRNHCE0T0gYhRWW6k4CS8yyy4q5U/CTEoa3IslQQU2/lHDg8iHGwetUq5syejdaaEyeGQcc0GhnPPfMiP7nrQT73b9/kf//tP/H45m1Mpg7CGEKNUw6bWebNmMbHP/orvOMt1zFnzgBf/dcvc+LIIdYtW8zvfPTXuPqKy5hIDN+4+cd87dvfo1ZLOPfci7jymtfxyDPPc9Mdd3HrT+4mN45KFKNUwNLlK5gzbwEzZ8/GKc2xoWFSY9j00sucGBnl+IkTOLzk0LMa2/3RnNxckGd/L/H3WHkuPLxe/bDWCtOJiLDURff0OSRW8dzmzTzxzBOcec46qpUSneUq5UDuFdVKhd7ubkpxRKValntZpeyruYqFgA6kgl9BKAOp7mYsEIToKMKgqCcJE62UZg6pUzSznDTP2wUXis0MhyLLLZmDVmZppjmNJKXeaHBieJjx8TE6Oyr0dHbSWSlTLZVIGi2SVsLgsSF6+weYv2QZiVOsPuscFp62iu37D/Gtm2/h27fezq6jx1m4cjXL1qyls28aYamCDkQmGijPtis2EadiKqbiFy6mPJWmYip+CWLbpo0kiSR3mTfndlZ200veC0kr8XLRnno/7qu+dXV3UqlUiGMx9wZJeI0xUmnJg0PGlwWXBYoszpOkRZIktNKMKI7p6+uj2lGhUq3SSloYI4adhZeGcZaZs2fT29vjjYYFSNLtXTn/vUL8hwKHIkc7MdwO4girLUeOj/ONb3yP177ujVx6+Vl09fTx+IbnOXDwOKVYSpPffc+DfPvb3+ff/+3bfOFLX+Eb3/wmDz74ELWJBpdffilvfcub+dAHf5WP/+ZH+eTv/y8WL5xFd0eJ6X0dKJ2glcIZpKS0swQKbG6YHK/RauTs2XuYL3/l60zrn8vAjNliahxF3PSD27nrnkfomTadG976RpQ2lEsVnDFidOq9PoNQQBAHVCsVjg4OMjBjRhtA0L7KWpEkdXZ20dPTzTWvuYZ3vOMdXHjhhYRBJLvrTqo74Xf3RV6iSdOMkZFR0jRjy7ZtvLxlKx1dvdx3/4MsX3Ea519wIS9seoGjR48QRRFr162lu6eb9WecwapVK7j4ovPon95HGCpCBc6mbV8J8QURY9aCISCGoD6h88lecV3/b6MNQgny4pNJi0Kxe/cu4igiikJKcYx1jiiK/Y6+9KXCCPfI0SOU4phyuSLgWqDBm52OjY0xNjJG0mzhrCWKInq6eyTxy3OcFQYRSrN6zRqqHZ2UyhXKlSqVjk4qlSqdnZ0C2EYxPb19lCtVjp8Ylspx/jjyPPdtdfK8lGfrRJHIUq2Vc8PLegopnJLGQNLuV/++8UbH1kmSlJmcRx99jOnT+zl99Woin7BMm9bHnT/5MevPWEtHtYKzlqODR2k2G5yxbh1Yx64dO7jwgguolEvUJscZGjrGVa+5ijPWreXJJx/ngfvv5cCBfcyZPZvurk5mz57JHXfcjnOOGTNnsWvXbi666CKWLl3Czp07+elPf8rBgwdZt24d8+bPo7u7m7t/djfPPfcMlUqJvr5elixZxPYdr7B0yWKWLFlEFIX85Cd3smHD4yxdspirr74KrRRd3V3cfPPNbNnyMqetPI2u7i5WLF/GQ488zCMPP8Se3bu59pprmD5tGnv27OGiiy4k9MUEbrv1Vt7znvfQ2dkhckccpTjijDPW8fKWl7jvvns4cuQwq1avRGvFoYMHOPfcczAmZ2BggNtvu41NL7xAFATEUcDqVSs5fOgAM2YMMH1aH6U4ZN++fTy+YQOnr17JmtNX89M7f8ydd/6YsZETzJ0zmzlzZpNnKbfcfAvPb9xIV2cnM2b0s2rlad5IHrIs4/HHHmP7K9t49pmn2LTpeYaHTrBixTJeeeUVzjrzDDqqVdavW8szzzxFT083fb097N27mzWnryJUijxLicPAm0tLNc5Dhw5y62238bO772Z8dJSrr76a/oEBpk/r53vf/S6XXnIpixYuZHDwKLfecgv3P3Af+/bt5bLLLmFgoJ9Ws8Edt91Gq9nkhje+kf1793L3XXexc8crdFTLLFwwnx3bX2Hh/HnMmjmDZqvB1i0vc83VVxNGAUcOHyLPM5YsWYySKb89J0iyfJKF5/z4cAjTyHf9tqeSvE3eWwBHMkU4kVy32aBa5kGXo/IWzz/1GDZpEmqRq4aBphTHBKF43WRGKoaWSmWcEg80KQufk2YZzWZCmmRYYwkCX1FSa2r1OvVmHRSUyh1kxtHV2UWzKfc+hZP5xnnvqCDA+fHtEIPxwjA59943Mm14dmLB1XLSHqfeI4t5oT1vOIMKAiZrder1JqtXr8aanMOHD5HVJnAKOqtVjAOrZZOjuBoU/3tyqUKhnJIKplpkYYRSgn7X1pdZNmeAObNnctZ553PpFVdz/kWXMDIyxN0PP8bNdz3Ipt2DHJmYIOzoxBlQmSWpjxNqRaAiAlWlNXaCgd4qy5fMZ9682dx+2+0MHjnK6tWriEshGzdv5Gvf+QF7Dg8xOVnj6aefZdny1YzXE/6/7P152G3HVd6L/qpqNmt97e63tvZWL1mdJbmTexs32LgTtsEYN9gYOCQkN8lJIA2c4HCSm+TekBCSQIDkHMBAwIDBpgfZyJ3cSbIlW327t6Tdd1+/mtlU1f1jjJprfVsyOOfkOc9V9A09S3t9c82mZs2qmjXeesc7Hjl8jKOnznB2aZm6ajhw3vks7tzJjl278CFSVQ23f/VOBsOhZq6UEH/vIzbLOzakvK/EUltM7atrkzofmv4uLTTtqx9jiVFC5IqypCx7tKHh8ccfox6PeOPr38jp46epRzXGyAJb1HaBgd6M6PNForD8YhDwL+p1UxlTebuSAtbhQ9TsbgHrLJlJAaeygGek4WCsVXaV9qspYfy2baiqMWWZMz8/S+4ynHHUTcvq2jrz23Zw+dXXcs0NL+DrDz7MH3/qFm7+3BcYNC0HrriK/ZddQTG7AC7H5sLwI0QckDtLL8+oRgO+673fn0q+ZVu2Zc8gMzGNhlu2ZVv2P6197Fd+ifX1DdbX1xgOhzRNg7OWmX6fufk5yqIQWv9oTF1VVFXFiRPHWV1dI8szCYHT8LhMv087s0VZysQqRrI8I3NyzHg0YmVlhfVxRdnrccMN10tInXX0Z/psbGxIqlrNvtW0nqueex033ngjLpPsZYGUflsmzc6IY40xkvQGjzMFPhryfo9R6zl+uuY73/4+2tbws//h35Bn83z4J/85Dz/8COPhGjCmXzpmZ3rM9PpcdvnFvPglz+cVr3gxV195Of2erFxnLmVQEbaX6FUEDBnBW0bjMcZClltMhFs//0V++t/8DL/0f3yEe+9/mPd+8ENceMml/Oav/zIXX7qfaOEHf+h/5bOfu40LL9zH733sV9m7s0ffOWJTk1kFipRRIaBJxFjDvffcy9XXXEOMAjS0Ku5qDDgrLJgQI76VFVSnoWExRsatASMOUtu2jMdjHnroIY4ePYpzjtFoxMMPP8y3veY17Nm3l0998lO89a1v4cCB/Xjvmen3hO3mvdQ/YEwgyyaTa6IIWucKksg+Bt9MUpOjLBuTspZNTdrFEjTyzW3yypJJf9LeEYcRTp84ye9+9KOa9SbSK0uaNJk2BmLoynjs+DHuu+9erDFsW9wmDBtjGA9HLC2dJXhPnpc462iDADT7LzhA2e8Lw4uIyTJmZuf59u94E7PzixT9GXbt2cPM7KyW0WNCIHcZtfesD8c8cugJNkZjghFn0VlhHqRwnO7ZK3sp1VmqnaggGlqfIci9JWZDCIHRaESv16OqKlwmOlx5XjAe1ziXq3PqNGmUsBdd5jSLkzivNoklG3F8i7wQ8WJjxCnvFV3mIjQcJMZA8JEiyxkMBhLKZQyNF+YUqi3cek+e5xR5TlVV9Pt9qqoiRKnn1HYTQJYcm6Dpr8uywCJgS5blVFVNVFFy6xytF0HkEDyZdSI0byWjV4yiK/K1r32NQ48f5Ad+4EOMx5U4+MqAcZlcH9Sx07IEDScMXrL51XUDU7pWwgqV0L70zKqmUWdV+mUIgeilHwvDLVDmBcPRkCwv1IOX/uVVN8yLJi4hevJcsgXmTkImU/2I6HMDqtMViTgr4s/OCtsp+oAzkv5dMnc57R/iUGZZwXA45OzZs/yjf/gP+cVf+iUW5+e7+2qaRq6tmQkTwBmjod/rQ4SqrhQME2c3aPhmUKZHatdEGcOkjYnOX1PXRM3yNvmkcUNDZOxkfBRASbbLNtnXWtEjC8qKjc5hozjREUvAUNqGeuko//n/+2GyesRcb4Z+WWCJjOuKtm3p9fsUZY+NwYgYBexvmpbxuGJc1/i2JXMZszNzGGupQ2BtVLG8MeTk0jKnV1apIpx34Dns3LWb+fk5VpaXGAyGuCyXT14QosHlBXVVEVFGovYRgPFoDKDMv0jwnnE1om3leUSt1xijaO7FgG+EiRpDJM8FQrCZvDte+uIX8bpvezWf+PjHuf+hR/CmYMf+Syi2ncfIzRHJiDFTcClibJwsGCioZC2i6WcMrc3w4w2uPH87//CH3k1uIkfOrHJkaZ0nj5/g7vvu4vTaEJ8tUsc58qzBNhvMAPu37+Edb38To9GQj/zGR6ltH+cCha344HvewcX793DPvQ/wsU/8Cfv2X8C73vV2di+UfOzPPsfdjx4nt05CaOuaGFvKXk6WZ/T7s1x44SWUZZ+8cNx33730Z2ZYWVkhRmlDbduSZRnWTBIeiOSjjHkuk75ulDmd+nSaj8h0REFO2QWjgM20hSgDX+4cJrTYWNGOVlk9c5QsNJy/azdvf8tNPPLQwxw9eRIfI03TEoHReMT6YANjDIPhkI3BgLquqUcVzbimbmphHsWg8JJkGIzey7hn5P1oQktuA3NFxmxuKE2kMIYil7DTPBN2r7GB2Db0nKN0hl5mmJ/pk2eObdsW2LFzJ7t27WJ+fpEQDEvLK1xy+RWMvecb9z/A3Q88xKNPHqYxjvMvupjtO3bibQZZhjXCyLYGcmuwuiDngEOPPcrxY0e59/jGprrbsi3bsmeGbTGVtmzLngV28IF7yTIFHoKsYfnWixCsTnaskZTJmTo96+vrjEYjAZGsal0gOhUpjAhlLDV1zXg8Fs0ZpY/HEGiaho3BgPWBhAft2LEDHwJ1XWFAwg76fUbjMa2GMmVZwSWXXqITWduBEWkShzoZEYO1GSYKyyqaANaxPoz8/M//Cnfe+Q2OHj3KZz/zOf7wE3/AoYMP8yN/8/t54xtfzetf90q++7tv4gd/8P380A+9nw9+4Hv5tle/ggsO7GNmLqcselgTKXLwzYgy70l9tZ4jR4/QtpbaN/zAD32I46dOcuNLXs79Dz7C3/yRv8VNN93EG77j2xlWDb/8a7/BsInc/Od/wstf/gpab/m9j/8Br37N6/janV/jVa98Ofv37aRXGGLrIcgEXkyBBWPIMsfy8gq7du0CdcgSi8lIZWA0s9/hI0f4i7/4CzCGPbt3Y53j5k/ewpEjx1heXubgwUOcPXuWe++9j3379rGysspzn/tcrr32Wq644gr27tnBS178Ivadt5cyd/R7OZmFzIigrSXgjAA44rWL05u0HaKyp6xxxJBYUbrEje6nk2z1J6fM6Oep9vTLH9P7CvhWliUHH3uM4WCA0zbtMtEoMVZSNOd5zmCwwcbGBtYaCS10EjqytrrMYH2DGKNme8vIspyiV4IxFL2efpc6xzn27jufCy++mLmFRfbuO49C00IbZdllGn7ahkDEcOLUKdogs31rnFZjIChAkBxt9Pl2QFoKjZsK80nXSPsmkCllscqyTBxxl6Ld5fwT0EGejWidCXPCaFZG6yzOWjKX4ZQhaK2kZsdEfGzJMwEtvJfvBgnXM9puQa6drqWROjKeGHGCXabglTVkmWjCxOC739M5ozJNMidAojEJ7BWGWV7kU+1MNHOclXt1CaAABoMNfud3f4fHHn2Et7/jHczNzYrThWRStFb6lNXMmAYBbqW/TcoutRnJMkdmRUvJmIhJjJhzzmmNpkMHcS71fMQoadZVv05OHYhRQ4s0xEWyk7kuJC4GuudijPzutMxOU68L8B5xFghBs19qeKU2q8ylhQBL8IG//NRfcvNf/Dnve9/7uPyyS2V8DV5CPrWurZ1cjxgp84Kg++R5hokCMCbx6FRnXbuIUdqLVABEeW9YbTvCnpDnHxRkkuc6GQuMhr8Zawhewkklk2KqZdnfWCsC4HTNA6zFhJrYDLj/rtuhqWnrRtszlEWPPJfFlrrxeB9oGk/TtgwGQ8Z1LZlPi4IiLygyCZ8UBhK4zJCXOT40jMdjqlaef5FnbFtYoN/vcerkSWZmZrDOAdqfrbT/NA54DQV0up3UHrS/oECSpLaXOu9uUUHhiIBQ1mVEDZE6fuwI0Te84fWv4ciTj7O8vMJoPMS6HFvMdIykSCQq0CLvJulDBgjG4EHaTTQ0ow3e9103cWDXHG1T8x9/8f/gy3few8Enj9NQ0piCYKSvFO2Al95wLYPVJVbWVrjqqou4+Pw9XHLh+dxz/zeIRY+xh4cefohrLruIA+ftYmVtg/sfOcjps+tcedkVzC7s5u77HiYaJ1qJIVCNx1x/zdVcf83Voou2fTsnzy5x8NBBhsMxG4OR1LVIGGGtjL9MzTOkHie0n278VVZQt23q95h+1y+x+67t2wio1wZZNAoR8qzH/Owio8GYjfVVjh55nFe/+uWMxjVLy8ta3zLHKns9aVvG4jIBGq1JiTsCbZAED/JelUQHqR+EKO+dqKCs942CTdLHhP2soXM+SFhdnNQFUeZsTdMQYqRpG9bW1zly7ATbduxm53n7ePTwYf745k/xua/czun1AXsOXMgFl11Bf2GR6BxGNcOcMzKOEenlGfiWJw8d5MF77+Xs6dPkWcbf+of/m1Tslm3Zlj2jbAtU2rItexbYQ3d/nVbTk2dZ3jFWmkbC16wKpFp1UL1vWV1dZTDYABWLFtOZkk70ffAEH0Qstm5U4FhEK2OMorG0vkGtadXn5uZEkDRGfNtKitoY2bFjB63+vTEccsMNN0j4l2bsScCSSYuB6og45yCUWCsE8EDGLbfcwT/58X9GUeb8s3/2E7RNxeUXH+Bnfub/zfd+71t56Uuv4xUvfx5XX3U5F16wl10757DGY4KESEVjqKsKiKyurOlqvDA7Tp9d4p3f9S7OO/8Al195GZ+59TM88NDjvPWm7+HD/+xfcvc99/JzP/+zbNs+R9V6Pvq7H+fq597I6RNPcMcdd3Dppc/hM5/9DH/37/0dPnXzX3DB/vN5yYuvxxlPaFpisGBlIjm98ul9YGNjg4X5eXVAZBKbVlOzPMcg2cl+9SO/xq6dO7n/vvvYsWMHu3fvZmV1jaXlJe6//z4MIvx7440vYt++83jlK1/OhRceYP/+fZSlY7aXycplDLKeHyPiOgRM9FjNeiYPRBxAcfgU9Ov+ZfJdPJSJqRP832PqPj11m1E3R8NinLU88fgh1lbXyLOMPMs7HRKIEv5mDGurq6yvr2MMnD1zho2NDUajEU1VYa2lLEQUNddMbiEK2wlrRGBeWRDBGC659DKuue569py3D+cy0TjpygwGae8RaH3g1Jmz1F5Wk53LuhCX7r4SAKIetJkCloSFkRgbwvYSZo5kTCx7PWIMlGWJbz11U2uInQiDiwCwAE7S36UvNU1NnktGxDzLu3BWgoBBVh9Y0MyMIXgFiKS9ioOiLUD3FVBGQSwFnIwCWgJKZNqWxXGJyjYTdsmExWaUwZUpW84g541TdZP6goRAqsOkTpnRenOaVawoC170whfyile8nLm5OWUriO4WCrhM7kf+jdonDYpqaHhMcszE5NppnJq+voCpAqQaABUNl3OxqW3HGIhBwitlgw67ygRLfcHG1OMSwBAlLDj93gFdupMUh3RZa8XRlcUG0ekiwlVXXcWrXvEKDuzfj29b2rZWppPck1FgLQF/NgEeQcom5Q5Yq+1Fnw3KMhLmUqpL2S51JCU3qKOuDnJirZ1rxlh88MJ+0OfG5Da7kNKgTn93dik0uYNYbfCVz38amorZ/gwL8/NAZDAcUtWNhA75wGAwotb3nLGWOdW2yaywA9u2phrLe8MYME5DaaOwMs4srWG0n6Sw3N179nD02HGKslRtJEnUYPV+E6uNKMCN4BhSVzJ2JIbWpE0ICJBAuAQKyHYfRHeOGGnbhuWzp3HG8M53voO77vo6o40NqrpmdmE7/aIUZqrLJCxPq27qH4JzNDoehRBxeE4dOcjLXnQdPkaOnl3hyeNnwOa0Iccra6YdrvOdr30pr33pC3je9dfw8KMP86WvfJarLr+UC/fvZXY254GHHyOEyHgwYOdcnwPn78NkBXfefT+rg4a7v3E/d9x5N8EYySKbO3bu2Mbzrr+O7QvbWDqzTH9mji9++cusbqxLOBmmA5FC11akZUzajH6LU/WpNgGU9GcmwGz3bzq2O0Xac+p4wOAgOEzMmOnPUFcjxtU6n/zUn/PmN90kGpQ6LnsFnIuioPVBwjCjAN3o2BajsD+N6i7SvT/0uvpO6vp56gcGjJVnLCxpHZISoG6EMRc1/K1tA6Oq4uChxznvwAWsVZ5PfuazfPbLX+HsxpADl1zORc+5krlt2/EYcBmuyHHWkFlDZqF0Fkfk1PFj3PW1r7G6vEwIgaIsyVzOj/zoj0tlbtmWbdkzyrZApS3bsmeBPXj3naATirZt9N8Wi0wqUshNlmUY/XttfY211VXJRjY12RdTD2UaK1CHsHMsgbZpGI9G2CyjKEpmZ2dF/LhpOwZUkUvIQ6lZss4sneGSSy5hfnFBJmIKKqVJcmK6RHRVOxSgYRY+5PziL/wmjz52iB//8X/A93/o3bzpja/l7W97PZdctIuiaMhcI5N7ZBXdN2NMAIJjbXXEvQ8+yvbt2zh8+Bg//Df+NmvrFS+68UY8UPRm+YubP8Pq2jKvf8NrMS7jk7fczvkHruUXfvEj/L/+9t/hzW9+FRApih6f/8IdrK55/ssv/lv++A8/wadv+SyXXXoJH/y+9/D5z97CZz/9KX7w+99PbmXZ1OCmltJTPcvcr20ahsMh83NzOjGW/QRwk3o5euwY99x9N3v27OHkqVNY63jOc65kYXGWubkeL3jhDVx/3bVcfvnF7Nmzk+3b5rA2Ai0x1FgTcQQFjoSJZpJTzMRhTa1BcrXolgTuTO3R3cW5oNK3aGmibvR/cv704znb9SfrLMtLSzx+6JCCF8KgyouCSKTUEJvllRXqSvTF1lZXMUZYTv2iJC8k05LLkt6GOFWtF2BoZm6WEAO197gs59te+zouufQyWQlOkFtUoCQESBnkQqD1gTNLy/gQyYpCASjVP0qsrgQYIs5PApHEyZ6AHD6krEMC8KKaZjFG0WAxRphKwHhca7sJXR8X31qulzkVGjfiVQgQMAGuxFmSNiB9UhpmDHKvzgrLxanYuNyDljVKW5LfBZCSzi2aMAJYmA6gQtu8/HtuWzLdPiBOoNRP+h1Q5z2GoMxLBR5i7DKfSQOSgxL4FRQUcTrGpPZm2JzVJI1xURkkRsE2k/AKY1S0HSIKHnW9YvoeNwOJ8rOR7FHRy7HpSBVPloIJsKuwjJ4gfZE+anV3dEyWfXRDlAOEBSOgRWqz0nZafCMZ56wyoOTUU/0/IqGder/yt9ZnB4IKwBKjlNUaAWJF1wwNg0lsMKkz2VfqJrXNpHFzrok+jBP2B3J/IUaRmknsEb1do8/J6FgZIjjjcX7MvV/9Ci40EGQhpGrEeR5Xkv2ybQPRCHjf7/U1Ox/UVUNdV4zHI2IM0geCAM/OWYoip8gcvvG0AerxiMxZ+v0evX6fqm7oz8wyGA70GCei5TGSa6bHLBMGWXc/aqk2IgIoCOgrjLZNe6RK0JBV38ozK/T8q2trzM8v8LrXvYZHH32EjeGQ0cYG/Zk+ZdkX4C4GopVwycnZDcFaCaFU9mRmIqPhCkUeufDSS3G9ee5/8BHqcU1hHa2vRcg+NFy6Z4FLzttBYT3nnX8eDz18H0ePHOXyyy7nogPnsX/PbuJoxKUH9nPD826gxXHr7V/l7PqQ4ApGrcFkwhg9b+9u9p+/h20Lc5w5dYb1jTEPP3KII8ePy4JCBiFKH4oK7QgwNAUedT1T2uDk70lbirFTsZL2rSdK59FTKUDeVT4xIgxv7RMSemcxZBiTYTD0ZgqGow1c7jj02CG+/du/naapWVlb7cbg1HfapsU612UPtMquMzrnkrnEZC3HYHVAkEWCKP/Q+kDQvhaVUQqTUGM5p2hdWmPBOgKwMRyzb/8BTq9u8PWHHuGJ48c5cOkV7L/kUua276C1jmAMLs9l0cQacgulM2REzpw4zsFHHuHU8RMQI/3+DGV/Bh8tq4MRf//Hf7K7/pZt2ZY9c2x6nrRlW7Zl/5NaN9nXFN1lKRlG0opo3TSMxxV1XdO2kjY9z5xoMwRPjF5SdwcJayP9y+SjvnHndEqq3dABEb5pqUZjfNPSVDXDjSHjoaQkHw9HDDcGNHVNv+xx6NChzjkUEEkmRGlbApEikWhaQB0wE3j+C66lqTaox2vM9mBxzrA4l+FMJCOnrSC2GU1jOHFimWPHVnDZHCEYTpw4xZvfeBO//Mu/zsK2vTx++DR/+Ke3MPYZo9ayNmhY2LGH3/jox1hZHXHxhVdx4sQKf/vv/ChNcPzLf/XTfOLjN1MNakrn+K6b3sI3vvQZLrnofP7zz/0s9XCNN7/htSzO5lx12X5o11lfWSJ6AWgiIsaqc9FuWhsjzC8scPLkye4no4CBQdIJEyP7zz+fXbt28cijj0KEF77wRaILUhZcdunF7Nm9g14vo8ydaFE5ILYQW0JoVDNDJ9F6oUAkGgmBiDiCcXgjk0aZtSbnPH33ROOJJui/nrgJKPsWrHNQ00fNdP/bZKpXStTU4hdceCGj8ZgI0ob1MGctZVl0oKqcKjI/N8fc3DxZlpGXIiCaZRlZlgmolFmysqA3M0NvdoZxU2PynOe94Eb+0T/5ca657joaZdCEqP0ltHjv8W1D2zT63asGjoCkKTMQSNmyLJP7mQKQEqCEgr7pdxDGQ57nlKVkbyzLsgOjoop7ey8MpZmZWcpSs+E5x6xqPiUWST2uyFTbqW1FI6fLAhUlXMMTCQZahKEVva6WB3kAU5iQsiikOSdwT8Abq6F2UkYBndKBE0aW3EdykuX39BsgWZaiwRiHRJQoY6grxwQASeA5RsIfo2Z1ilHC/qx1qgM2Cd2bBjGmr7vJjACIHTijx6S2OLGoosrdrchXdUijgocB8QItRj/StwU8itrVjDCUvlmRunFSjupgJy2rVMhET8nYDIzFIvfsnIRrCrBqQUNdjTIUp91tawW4a73vQEqUXQoCNICAqxgBZaV+ZT9A2ll6OFGAp8QCTAyqb2YmaUlpvQdlzRht1865jnHxdGaMoW0lpG00kgylddMwHFcMxmOMyyjKHsY6euUM/V4fl1mGwwHr66u0dY2zlrn5WfIiwxPIi4zZmT79IqefZWzrz7BvxzbO2z7PnsU51s6e4vTJE5w9c6bL6BVioBqNaKoRWSYAto+BopCxKjG1orKKXebI8rwL2c3znLwoRBNOQai0GGSMMp9sJgsQyoITkMlwdnWd2756F08eOcp7vvfdzBYWqhVOHX4EX60S/VgWGFLH0mFBurzHmog1Uu+tsbRZn9/781v4p//yp/mPv/ALzPRyrr/yYvKwSsmQ2GwQfI2xkfF4ndUzp7hg507e9Z3vZHllxL/7+V/h3sdOs3vXHt76xtfx2le/ktVhyy/9+u/z9YeepDEZrszYeWAPsTC85nWvoRqPmOv3OXTwcY4cO8Gjjz9Jm2XU0eJxVFVLCKJP5r3qDqbxMUj2zOn2NvlM/k77hBAIKQPc9LHd/pvP4b1mjvMylwo+EL1miiMwbitaY/C2x8Kei8lmd7MxHPLhn/ow+y84wGWXXUqvV0KM9MoeJkLmHLO9GWb6feYX5ymKnH6vZKZXMtvvkWs4rk0hwEYSaViDhPmZjBbHOBjWx57VUUUdoPaRNsj7olUR+toHYZrhaLAsrY+wvVmWN8YcX1qlsjkveMWr2H3hRWSz87TGYjNpj0Wea07eSB4DSyeOcestf8lD993HYG0di2VmZp7KG06vDnni1FlOrIp22JZt2ZY982yLqbRlW/YssPu//jXNWCMrn0EZS9VY0jmnVdwYBBwyGIbDIUtnz6pQ92SCksKHjLOquaJsECvaHiGI42GU2TEej6nrml6vJHOWVsMp2la0Juqqkgxq6jT6KFl1rr726s4JMlZlL6fCawIGi4SrGNMSaSUrSvA8+NADvOJlN/K866+BMMIBJlrGI8/XvnYP1uREDB/4wPfz+ONHeMMbXk+MLdt2zPOJP/hTDj1xhO99z/fx0MOP8unP3cruvfv51Y/8Fv/lv/6f3P/AAywtr/G2t9zE1Vddw2/+zsc4fuo4f+tv/w3K0vHRX/tVjhw6yPNvuJ79+/bwC7/0H3jVq17CK17xMt78HW/kJTe+hDI3XHHZAX7wQ+9jcXaezBbq+onzJaZOsmpUFUXB2bNn2b5jBygbICgA1bYt1lq891x00UXs2L6D5z//+Vx88SV4DTUhgrqOWGPJXY6JBmczMissFaLWdwJppHaVgZM+E4aSuqkTL9mo02nUiTYJVJxybv8aezoH3jBhIk0c5u5HcZh1QwyBubk57rvnHkyEmZ6sthtp2DhrWVtdY2VlWQEXATbyLKMsyg6oyXNJ2Y0xWJcxMzuDzRxZkfOSl7yEt910Eze+5CUU/b6EAVoFYUGBwSiAbPCaWjrQBE/rIytr66Kv1IWfiXOctJJMqnsNgUl1kpzo1AeisjggZV2Uf53LaDXktCwL2lYEf9M+yUENQcppVEPJa4YpEN0br06RVfaRsKKEeRNjxEQJ2+s0njoAYMIWEdBZgGYUkkDTdSe9p/SBKDpc2s9tAndSenktW2LCmE64WYW0o7QMg2hUJUAuQSFGgVCpR6mTGAMxSh8JIZC5fMIgipMWntqQ3Huqf62PKWZZsrRf6kwSrjd5brrX1D8JPJL7TOF/0jrsFFNJw9mUqTQ51eR7um4SF+6s+1PKkEAHg4a7GHEmjTUatmVAxYxTO918Rn1uul/S7Upjjkmi2c4JGGYkTCqdRcSRBcDuzqPtM5Ut/X1u/aKtySoANb0/6VlvMr1PdIAzlsx4QrXBFz/9SdrRgOgDxjqMy0SgPxPA0RhL0zTUjQpzW0uWWZwVNmMMAesMeSHvSqKGwIGEVbsMp+9RjGV5bV0EsyP0Z+aYnZvHEKkrAcJdXnQAR7o/tB6csia7d62GFLpuVUf7U2J9ab0E/dVlhugbATWMwbiCpZUVRsMhFx7Yz/XXXcOdX/8aMUaGVcvs4nZilusigjRDgTwN2ECRG9pqjHE50WZ4YzDOUfuWSy65hPe+651cdfF+rrrqCs7bvQM/HrJy8iSXXLCHA/v38fW776NqM86/8BKizTl49BT3PHGCg08+ydfvf5Cv3fcwt939EOuDlugj/Txj37497Nl3PvvPP4/MGo48eZgjh08wHjeAxSNjrckcbQCsiPoTBUySvgN0ixfyvWvPUz001fvT/ZvA68hmplKUBj11PgFlpaELSB8JspBjAj40mCyn9ZZ+b45YrdLv97jnnnt42ctfzs4dOzh8+EkJT+uAfnmgxgqAX2QyfndjoZG2kNq8ETq2fHcZMbUXI0zS6AUgDL4l0/cMMUjbsg4fA3nZI0Qoyj4r6xusjRsuu+56TFFAluONJTphr1kj4W65NZw5eYJH7r+fo08ehhjo5SV5VhCNZW0w5vTKOivDMTUOsoIPf3iLqbRlW/ZMtC1Qacu27Flg9955B633NE0rKZKblGFHnOygGXLQyYC1ltF4xJkzZ8jzXERcdeXLWPlMsyyQuZV8ErvIiP5J3TQMhyPquqHf72EweN9SVRXee9EM8EGZUYE6iA7MddddR1GW+CTSatQJSo5BtBiTQKUAeFxm2b1nF+94xzu5+uqr1CnVUB+bc/fdj/C2m76Pvefv5drrn8sXvnQ7h584w9vf/hZ6fUMwns987svcdvtXee/73suOnTv5vd/7fb5w61fI85y3vOVNXHDB+Xzt9ju5cP9+XvNtL+Pjn/gER489zq/96n/hA+97JytnTvMbv/6rPH7oUb7n3e/kRS++gedeeyW7dmxjcXGBssgkBMBFFuZnKfMeeVZgjKHXm2jfwMRPTM5x0zQSUpHnIsjZTX/l/y5zlL2S/fv3s7htG+jqvdGJsDiJ4tz5EGhbjzMpu5gAg3Iu001H08QzlUl+k2uKq6Jgge6SfpswNdQFkeal9zQ5lxyUHCJJ9a1TfnWyp/+bcDikWDphN8nZlomwM7CxusbS2TPd6j0gIVAhsry8zOryimZRauXMVurFqXiwdRkuzzthbh9h/4UX8q53fy+vfPW3sW37DrKswNlM2z0KUKgzESTsLSpAEGMUkCYoqKQZ6Uihb8rmcZpFbLpvJcAwgTepYaR+kZxLk5wBNaNOPTGSuYy6rkVrybddGJxVAEXAKGEyduAYkBeFhv3JNa0VHZvMZeKQqGB8lmV4de6jUYA6NR9tQ4kFlLa1vgVku03AcWJoKWCUymFVjFmOl+t2obnJee56gjwLCSfyWCcMLNlVnHCjwJT3Ul9ZJv3AOQlHIZ1LnbdUHqIAMOhYl+q9Cy1MTp3qzEhoiVzXKKiCFHlSN2rpXoKyHKTtpL4n972p+6TtcrDev/bXro1M9jNG+rVskjpMO0W9vrUW37bCcLBSJ934kM6plexDAGNVJ0+OnxbKFvFx/W0KyArTzxgJi0SfsVxDRxGtM9uxmzZbumYMAra0TSuC6tofpP0IaCXl1+srGJURCKN1bv6TT2B9Qy8vKIqeMhVz2lrCtyULW0avV0AIlHmuGlzCxiiLHBQgLvJcNKWCCLY7Y5ifm6Hfy3HGULcN6xsbjKoaNJ39TL9HmWf4tqaqKxHLTiwsDe1M7csqeGvOHSOMLMykdpMAY7SO2hDIcyessaR7aBzWWbIsZ3l5idFwwPbti7zwBS/gvnvuo21aBoMBc4uLYF23qJDanA8Nvm2wGJrWKwvGSbZD61g6c4bY1Fx2YB8z/ZzZMuOF1z+X666+iv5MQTE7x6Gjp/ny1+7h0udcxb4LLmIcIk+eXKL1nlHdsj5uyMs5LrnoYnYsLnDxhRfQ7/cZjMY89OBDPPboY7QtBETsPGCIJuJyaXdNGzAmwxoJSRP2tKByqX/HNGikNtoxJFPvTC82+dfocenAyfG6GRkbAOJUw5X90sKMvDsFvG+JONoggNPsbI7HUNUNf/onf8IrXvpSrr7yco4ceYKiyKnqBuukjTZNpRkt5cJJbB8j4bmSEU5LlsZJDbNO30H0mOpWQjczDZ8TlqT0wzSmuKxgYzji1OklDlx2ObO7doK1+BglQ3BeUGYZuTWsLZ3hrjtu4/DBg/KOdTlZ3sO4go1xzanlNVYGFQ0Ob3NMVtBGw099+J92dbZlW7ZlzxzbApW2bMueBXbvXXd0aZ2tFUHnFKMfvOhVdGLdGi7Qti3Hjh4jc46iECFREjumm1NNAQ46dwpB0li3rVDDfRsYj2vOnDlLr98ny3IBNnRiEyNkmbADfAy0Uaj5z7nySvozs13WFJPC4PRSMrmOwlaS5VOyTBzzX/7lj/BzP/dLXH3t89i2cw8mM9TB8//5N/+Zu79+lv6i4Q1vfj1nTm/wRx//Mu9+z5tYXCgJEb5y5318/Rtf5Xve/V0c2H8+H/nlj/DB97+Xf/tv/iWvesWLWJjt8Zu/8Ws854pLecub38jtX/oCD9/3dd7/Pe9g1/Z5rn3uc7jh+dfzgQ99gN1793D55Zexc9sczsiq4mA04NDjT3D6zAq7d5/Pvffey86d23SVUFa80yp/V6k6ubXO0TQNvbJUh0uehDwCAS+MQUMB9W8rv6d9dXlV69DotilPUa+ZjjFa3+KOykeeSADTynW1mMnhiFhZCTUWcLgYJZ13V4Z0HQG5DBYTHcY4WmuIKXRD4CMMBhMtJmlRRMmchW07sWgTPSY05Hil+kcee+wRsJC5HN9KNjciLJ0+w9rqKngVwU2Ah7XYzOEjmCyjbj02L3jRS17K+z74/bz0Fa9i7/4DBOOIUcIKZDKfRI4FpIo+SKhD0jzyonOEAR8jZ5eXdc1Y6sho+FtyhNGJvFVnP21zWdY5AwCmy+gmIWZGRZOF3aRp25PDqedLzCajjLUOFEmgorIRQgxyPX0WHctEwYbk/KdjvDJS0DFEyqP9VseIiROctruuHSTHyBijWlHT4WTiJIu2ldSF6XSU0ngkzlPiJQm7MbVtuR+0XUNy8FLfkJ2sFS6fgIAKlipjJ6JhYMpo6sqh/SV9l7/V+UwXQ5xFY6ZCAjXs0JgEik0c3qSTFqP0+VQL3fOJ2tdS+1BnOCLnk/FSyiH3qe0FBWCsiDVPtyUUwBPNnUk5BfCXRAVG27sPUULmVK9MsFFpi8YYfBsUBNEa0exrKACUHltq1wmESoBJlglIM6lHZRrq/Uj5IhIgKPWKChcbbcDWpNBBDQ82FmPBG00PHyIueGI94s7bvkhpIcfSL3vUbcNoMIAYmOmVlGVOkRsMkSLLyKzt+n4qc2g9BI+JUX7HYEwQzTrf4JoxWWJvxcjGeEyjIbj9fp/cWfpFwWg4wrcihu+03G2MlOWMskkTSC3365ykvHdWANT0TDtQTUFMGd/1eSuAG31L8C3OGZyBldVVhsOKG669nl07tvPIg/cRfU3wNYuL2/HRYowwXG2MolOkQLGzURd3IpgMazLKLOf0iZP4tubyC/aysnya3/yt3wRn2HP+hXhbcuj4SR564gkefvxJvn7/Q5w4cZJeaDFtiwUKl3Hg/PNYXJyjN9vn0OGjnFlZ59SJ03gvTKtohB2TdJ9Se5A2YbCJQSsNlNiFz6a+NPlXXmYWoo4vEWJI47yCS8rqjd2Sir4Z07mk0Xa/BSBGqyHkaDi4jomeiRafAW9gZDOKmW2E6OjnBY/cdzcX7NvJ8264mnvu+Tp52SNamTMJA0vHJcBlOT5IJsQUut6qhp2RwUWTb0gSjhgllNmbjAZH1Ub6JpI7J+XxrWi4GcNwPMZkOUsr6wTjuOg5V2BKWeQqXEbpMgpjWD1zhkMPPcCxxw9CM2ZhJifvLeBtj8HYc2Jlg+VRTW0KfFbiXQEanmmd4cP/20/Is9qyLduyZ5RNZqRbtmVb9j+teR9Ug8ERQhRNpUyYBqhD2jk5ypzIs5yiLMTZ09VkmchLilofA4EkFCxhMq0XQdPGt8J2iLAxHLCyukpRFgwHQ538trSajS6EQNtI5remlgxyTVWxvLSMVRaDuhfJN1LHLWhWMglhEgfEYsjp9Rb59Ke/xJve9E7uuOMBgsl58sgSv/Ybv8P8jh633PJZfGO58qqrWR+c5eDBowRKvM+47pobMaHH2vKIPTv3cu3VV/HQQ/dRlAGX1Vx99YXs2FGytnEcHzf4G3/r+7jlM3/CxZfsw5iW8/fv5aab3sbePXsZj2tOnTpL25S0bY/HD57i03/5Zb5+54N89fZv8LnPfYnDR45TlD1JAdwJ4k6eHclRC4HZ2VnRtdJt39Q6h+2cE/0PtEiGZxbPDIE+MZaYmGOiwwVL5iH3kTxETMyIFMSYPjlEp2BgJJiWYGuiGbFoamb9GNeOiL6hJVLbSO1a2ryBfESwKzRxldY0+Dgi+DVoV8ibFbLRKdrTj2FXj7Ajayh8Bb6lbmqcczRtw6iqwCAhaEBe9ujPzbN9x07m5heZnV9g2/YdvOVtb+NHf+wf8s7vehc7d+0mL3JCG7ApY5a2/aDhbekjwI30k5Q5x2i2q+TsJ3CCjumSQqvEGUyMQfFmhJUQOo0kYQZJONuEJSPsQ8NoJNosCQQKIUhmRjU7xU6UMUGdkCDhIW0HLAg7TrYnUEYhjil2FEzam9MsVnL+CZsi3U/6RA2rcppt0jnRhknXSHXhlZ3knLC1BICQMU32RVw3Y8SdUzYHiaWnZUnlSOUV4FbKmo5FQ3a7MieADrGQQL9zwrHSOactlT89v/S30XpIfVjqjc376bNJ9YQRYCYqi2m63tMxcgoZj9N5037pmHStGAX+lbaqQJ+ew+iiglXmU1HkklkwgWmbnnkaelPdyzaTMvPpz+kYCa3TtoeAZ1afgbPCtBFATY6xRhFtfZbpHiQ0LF1MfpeHlEA02ZzYnJ0Z1KHWP63FOIfLC4KKKW8MNmjrmn6vR1lIGFrqO1mWkRe5DFtWwr/rpmI0GhGjgnVa1qZtaOqa4D1FWbKwbRs7duxgx7Zt7FhcYKHfox4N2FhZ5sTxY7RtYHZ+gZ27djGuRqLNo6GVvaKkrkYCSKUxA8hyAZmzPMc4yV6YKfCcdJayXBZdrBV9qfScBUS2kNiFMWKM5cixI3zhti9x9XXXct3110PTMD51ipVjR+j5msxXGFqijRijiwXCD8JGCeLMsxJwRJvjbcmnv/RVHj50jF17L+LFL38tX/zK1/nlX/0tPv6JP+OuO+8lcz3G44a11XXqumUwGrNz9x4uueQyXviiGwHDYDDkjq/eydmlJQYbA5pWWHKpTYtNvsv2SXsngWxP80nvy5jGc9WQTAzTBDJPtic24bnjvozBMWh7nf6kY3SclusoYyyI1ltahGjbQOsj/Zl5Zue3U+P4vT/6E+65/yE++KEfYHZ2BkKLUxZ2URT0yh5zs3OSWbDs0ev1yJwwh5xqixnt09LfJAEFuniTLGBYrj0rTc2w9Xjj8MHQ681grWVjfZ1RM2bQjPHBM1P2ybH0jGXt9Gm+cftt3PGFW1lfWcW5gt7sNsjn2Bi3nDyzxPFTZxmNK4zNhMWl/T+xFGUZacu2bMueibbFVNqyLXsW2N1fu01YMOokee9VY6mVCY9ONOTlLowgay1t61lbW6PX66szKEwgQBwydT6iTvTbtmUwHLK6usrp06c5efIkg8GAXtnrrj07N6sTWJ1EmIn2hw8BH8WhXVxY5MKLL+4c3DTvET9DVoEnzqT84LKcuomE2ON3fuePyPIZPv2ZW3nla76Nr3/jIW6++TO8+93fxde+dhtve8tbufyyy/izP/tjbr/tNt72treS5SU3/9mtfOUrX+SHfvBDHLhgL1+49fN8+cuf4z3veSc7ts9SFJbXv+51fOfbb2JmdpbtO7azZ8955HmJMRmnTp3hL2/5DEeOnuChBx/lwQcf4bFHD7Fv334+8Qd/yKiqqNuauq7Zvn2Ryy+7mF07d1DklqapZYJPmg9PHE6ZDELbevq9nmyemkT/P20m0jGQbBSVJRuZfFfHzgLeRLwNeBMJRsSegzJiurA1o5mufEYIhogTNoSBEGpMrMlMQ24qHBUFI3pxnV59hmz5MTYOfpWz93+RU/feyqkH7+D0E49S155x7FEHQ5YXQGQ0HrG0vERVS4rpLM+xWU7jPQvbtnH1Ndfwile+ind+93dz7XXXMb+wCImlYy3WKFgDylASpyM5CEE1xZITLM9O/jbOUTVtF/5mjKRxTmwDUp0Zcf5SBjejAIf0TemrPkhYlzGmA4+sOux5XihrTfpGCi9D9W5Mygp3DvBgjKFuGsqy2BQilsCNBGQZI0yk6ePlWhPnRP6W9hmULSHnE0AolderzpvspwCHhidJP5fjQlBhaGWWpe2br6fMEXU00/c0diVHcAJ8TcAoAeeE4ZLsqfc3GSfTNdI2kHFpqgrkqxFqUdr76Y5PjLSu7FO/WwUb0zGpLTyddeXUc4DcWrdNbfoaUg/yPIwRXaXEahVWqoR0eS8Z9IyWNR2bLjL5LoDjNLBkEKaX03PKvlMOfSqTVp6wZ1OmuEndGATMIfUHZzeBi+kWE+uvq38AY/GhwTpH8FEYTMHTjDf43F/+Bc14CD6IcLuC+0aBm6IohHESA03TygKLMu+SSx4RwFfCyxsylzG/ME9/pt+9N+vWY50AQBHDuBozHI3IshzvI0VPRMGDD4yrsZxb7zf1YZNCMeWuiFpfAspNnrfUh1SugEmpfiMmpne9ISrYJyxGySJ5ZvkMhMhrX/s6xqMxJ46foB6NMDEyNz9HGzwmyyEKe89qNUvbsDQ+4rIc6VMZNit48tAhduw8jwMXX86ZpXXOLK0xGNUYWwizNVqKosfu3Xs4f/9++jOzFGWfRw8e5OSp0xw9dgKXiRaizD1SJkvte1Ptr7NJk9/8hzSMyS9TfQOkqlKPld+ijPW6n1SrAk5MANzUjuUQeQ902ztdODmWKSBLdwc9J0aYubFLcmBo2obDR45w8NAhvvu73sVdd95JWRSaEEHOHfSdgI6fXdbAINdL99Pdb7q3NGwZeZB19FRNJOo7OdM5Y1XVNN7TxMDMwhzn7z9AkRUsnz7Nfd/4BkcOHWQ82GBudpasKMEVrA1rTi1vcGZ1g1HVEozB5jnYDKwTppsyHo3quv3kT/wTKd+WbdmWPaNsC1Tasi17FtjXvvxFcVhCpChyYRW1ja6gyUqaSSFAgFMNpaqqGI3GVFXVhSBEdeps0n8xIup95swZTp8+zfr6Ohvr69R1TVVVKhYsoFJEQpBSSmZx9sRRAZnI1U2NUc2fF7zwhRPtAzXbTSKTCLQCTsbgXE7jIcvn+cQf/BkXXnwZddPyuS/eyqFDh+mVfT7wge/id3/rt7ju2mv5tlc+n3vv/QZf/MJXuP2OO7jtttv45f/6K7zzHW/lgx98D72e5eKLLuIHPvR9HNi/hzwXNtf2bTuZmV2kaSIxWh588FFmZhdYXd3g9OklPv/5L1IUJQcfe5xeb4bnXHEpO3du5y9v+RSv//bX8qpXv4oXvOD5XHP15ezevVsFzGU1XOZ7mye5EXEM2qaV7EyqF3HuZJjpybU6a+ee63+UGcBqRigzPUVPX8TLEKfFtER9XrKLEccGYQ5MDjO0bWJmIFmFTM2Ma8j9OmWzigur2PXjjE48wumHbuf41/6SY3f+JcNDd5GvPsHs6BTleJWCyOoYhm47wyZS9npU2iZXVlcYjcfUTcPs/ALXP/95vPHNb+YN3/EdvORlL2Pf+edjswyJ8hEGT4ySNchlmTiym1awdcU6RmEpqX5SchhCEKfPhyAZl5aXJXTEWAlFmSJcOBXSJ0q4F+n5G0NVVdikryQblfGnfxOpqkrBn0kadgl5SoBTLu0msVoQRz12zr4AVkb1cRLgZfX4oiiInXjzZgAHBc+mTRxqOZfUY+gcoU7rSu9JwI0JYDLtKDqXwsUEfJLrnbufOMrTIInclzrmTsasoHpwEv4px8tx4mRZBDSbtnSv6doJ7Jgu46TvyXNP10+/Tf+e/rYaUpzqIN3XucdFZZWlZxWVyTO5x8n5n+7aUc85/cy68+o2P6XbJaCQgBl10yiwP2F9ZZrGfDLQTOohlU0vAgnwUbBD9pFjU7kmdZbuXe5ncn+yXfbV7xoS2Z1QTy5Z5gTI0bMSo/iwUsdO3hu+pRkP+MJnPoWvx5R5Qe5cd29ZnnWaUI1vNSsilL0+zmWMx5IxTkA4Q11XAOzYsYOF+XmM1lfrPXXVECLCyG0bmkb6z3A0Zn1jgMsLYjSUvR6Liwv0+32WlpbIsoyyLGnbVpJseMlcmdq5tY7WezJt11Jnm6vEdgCh1ntqLxqmGkPAt16YVgYigRMnTjIajXnrm97MmRMnOH3iGHU1IsssWVHi0fFr05M3pOUE62ScDFESPdhgOHzsJKM6cOjJowTjMC4nYHGuwLmMq6+6mv37D7C+McQYx9333ce4qvExkimbTMLtJoBLaito25Hvk23JpveTRid1IdUi7UP2kx1SH5GdNbxZzyP/SVuQ5j/5no6NUYEj2Ti5nvYX+XcacJLtAZlTSMZNKXNRlrg8ZzQacebMacajId/3/vdy/333khc9ItJ3c9X6whhdGJA5n3MS7ooCox3ApX0TEoMt9VlZ/GlaeZp5ltE2rZzCWtoQmJ2bo9/r88Rjj/Pwgw+A9zgDZVFS9mbZGDccPbXE6bURVbBgc8hyTJZjXC6ZJxNbboqpZK3ln/74P5ZybNmWbdkzykycjJxbtmVb9j+p/fJ/+ndYY+iVpU7IIoPBBuPRiLqapHCNIVDkBSij4dSpU4zHY44ePcrMTJ8YYTQaAVFWVKNMcJPTnSxoGE01HhNiZPu2HZucnMXFRWZnZymKQoCsFBbjHDgwLgNr+Yl/+pO4vKDRsDq6iSOa8S1ijUzGMZAXPYbjyMbQ8IHv/xscevwo//TDP8k/+ckfZ2VphQ//5E/wnne/iRue+3z+5v/yw/y7n/4XnDx1gl//9U/w5OHDYAIvfclLecfb30TZc4CnbQO9ssC3tYbpFMSQ8YUv3caZpWVm+jMcO3aMqqo4eOggf/fv/F2++MVb2b9/PwcOHGDbtm0szpe4zHL02HF27dlL04iDMNgYcOLYcdqm5nk3XEf0LcZIavM0uZX5cRJEFibMxOF96vDdOZb/Dw/twsdJWdhkgjopQYWNHhMdNlpscFihKakWRiCYICujfgPnwBmIvoZ6gB+cYXj6STZOPEa7epwwXIbxEOdb+n6DPI5xmg/Qeo+nYM3u4FC7l8fifk6NIrboMRoMGI/HlGWfffvO58orr+SCCy9iYfs2bJbJHNsI9yDEgDUWH8R5dSpgrHiPhiG2HVNJHAk07FPAmgQ2CQhrwDpGjefg4SM0ng5YSuEH6dlNP8P0HBMYkH4D0fMQv0CYIOl37wO5hrOJIyoZ6OxUpqwY1csRb73rWDExDpR1ZadSsk/XTSqXgDQCNDgndQjJOZN7kHoVlsXm3yZglVVwOQFm6VnI8VactFRT3RiQ6mICrIQgwEyqOwGUJoBZOm8qW9qWzmNSn9t0fv2uBevKJT88ZV+Qm5zugUZ761P2U0vlT88yTIXgmW9yzWSpbPEp5ZNzpfOjzyuBV2nbJkvHRdHpCVGYXal8RA0rS/edjjPpDoWZllhlJpXPyDknNUEH9sk96WkQZzp2IYY65llZPEjPbFKe9LC60+q10jXkxBFDtF73s5iYYZoRfrjET/yDH2HORbbPzjKTO3Krfa9rt0lIXvS+6roiRtGdyTOHU3AyyzLyXPuA9v22lVDvqq4FnLMWYzNGbWRlMObUygYnVzaoY8b2PXvZu28fu3fvYm1tg7X1ddY3Nih7fbJMGD22A/wUBIzyrnaqgxhCoK1rBRpaYZc0NW1o8b7FtzI+oWB3VG1F3whruShzMJ6IZWFukZe/9KXccO21fPQ3/xuPHzlOKObYduByym27GVHgTdaN9rpMAEYYKK1eyzmLrSvQa8k9gG9b9u7dy3nnncfs7CyDwYAnDh9mOB53rCnbAUdy315DzLqx5ty2+DT9RL5vbuupucguaQxIdyBj1mS7ni8dq23dGNFekuYtcxA97Jz90rlSKP9kHDMkplB6CyD1Z4y0q9CSG09OzfryCfxwBduO+KEPfQDnSv7ylluJMVLVlQKgkcFoiDVGFk7qmsHGEN+01HXFeDyirmtp3104rTynSBS5qKTt5ltKAov9koV+Cb4hBmHj5XkujMQI27YtYjNH4wOjqmZlbcCgbgmuoImGYDMyZYdiphhmRjWwurqS8Mn1ldOpJrZsy7bsGWRboNKWbdmzwH7l53+mS1gt7ADRTRmPhoyGg85pqauaspBMZG3bcvLUSYL3nD59hqWlJdpWUhEbY7BZJkKhmbCaxAmK5HmB9y1N3dB6TwiexYVFsjynrmt862naBmssi9sW2b59O1kmWhCRSF7mjKua4bji7/3oj3LhxZdo2ICAWJCcV3Xkg4oDZxIqUNURH0r+3j/4x/zBH/0pN3/qLxgMx/yzD3+YX/i5n+XCC3bw8htfxne84Q38+3//bzEu0DQ5YGm8FzaDbYmxAROxRlbpvv6Nb/DiG1/Mvfc8yNEjZ7jr7ru46NILOHTwEBdddCHz8/McOLCfyy67jBACRVkAojVFMNRVRVGUrKysccdXv0bbtJw5c4bt27fjjOG73vEOYmxwrpbp7vQq5/8NS5O1ZDLi/xXnfZrryuR5slUmxHJeY9QJnmZxWFmtJl2pkudtnCNaS0B0h2xscaEhiy02tJjYYM0KcbzCaPkkayceZ3DyCZqVE2TtkCK2FCaQWYPDEL3HNQNMaIjGEKyDEGijY5ht5yjncf9oO2ebPnPb9nLB/gs4cOAAe/bsYXZ2FrAq7pr4ViB+rK42h6jZt1R/RrVcpL9A09ZSX12GHdUaQo/V5+isgEo+Qh0ih44co2o80WQEBa2SFkoKT+tAJK3DqOyP2CEuwjCScDTpf07FukEYEXnSUfNS9jzPaZqmAyrilEPWti15lglQ1bFlBNiQVXAJH0yMidjpJUXVdIqbvseogssKkAS9R3FiNDV6AooUG0h/C5sp6dOIUybnnIBr1grAkbSp0hgUFDRL55XzpWc2zeJIIJSMJ3Kcas3o78nkelMMoa4Muq/uZ0xyFjf3OVL7ScfodafPKYdJRVgF6lKZYxDR8k3X0ueUyhGS1k4CAOWEm44519J1u/pBnoMwl4Q1lureWkddy9gk7WyS5c7ruCllnoBg0j4mLLaoIFPUKpI2JPp9jWYfnH4ueZaJrpACg1HD6rqyR7lRAc+k8FEXNaSe5WIREUM2VvVwosGRY9uawcoJ/sHf/gEWS8PeHTuZKzJyI4BrUDZdlueMqzFt62lbCQOUZx8wiJB50imUthchBGElNQ0xRoqyJ89Sw7xrH6g8nFhaZXlYc+T0MriCnXvOY+9557GwsMDGxgYnT53Cupxef0YzsBnyvFCRbxE+b5uWLHeiwxQCTd3grKWqxsQYaNqWuqmom5q6qokaXmhUwD4o2BS8xxDJnaSdd3nOtm2L3PiC53HNlVfwK7/665w8u4F3s+y77GrqcpHKljgnc4oQJNtdGjfEtC/GKIyeEOgVJS9/xcv46h23U9cV5+/bx6nTpxgNh+R5ST3VYFOdPZ0ErLaEczd3Nt0XU6bQaZNnde7fkohCt3RdOfWPVBrZd/KZ7Jc+6bqplNJYTXcubbXnnB/A2pyoY5W8mTw5LbkfM1w5ga3XOHHkEP/+3/0HfuM3f5eiV9I2LUVRUNU1o9EIl2UMhyNCiAyHQ+qqpq4q6rpiOJSFwaapCSEIM1V7ZutboklZAj02tLgYmJ8pKAzkGHp5Ri/PidHT+Ia816eNlpXBiJWNISYvJZkFwsTFSObOqLIK8tFxX1laUQFvazLWlo5rTWzZlm3ZM8m2QKUt27Jngf3iz/xriizHAL2ehKJ57xkMBtTVmOAlU5vVyY7E8LecOnkK7z2j0ZDHH38cjCHPMpxzFGV/MmGbchScE92VEAKj0QhrDAsLi+SZY1xVNE1DXctkJoRAv99n33n76PV7gKxOhgi197zqNa/lbd/5dpoQsAo6JXZDmsTFIE6MdbLAF6Klaiy/+dGP8Y/+8T/m5/7zz/HOd3wPvm1wxpM5TzOu6BU5eS7i2CE4jMnBWh599BAXXnge6xsr9MqSI0eOc+LEKQ4deozXvva13HvvAxx+4iT92R7PueoyDhy4gMXFxc75OH3qNGXZ48EHH2RldQVrLNu37eAbX/8GvV7JaDhix84d7Ny5kwsvPMDOnTsoi4JeWeAshFB1ntC54M7/NZtMeEnO2F9n51xbcAwJ1UEZOMSA1e1R/HsJF9MsftYK2OeDpw/Y2BJMwJsGqHHUuHaIHa7h15YYnDnF4OxJRitPEKoNTDsi82OcH1PQkpuIQ529EAjREUxGbjyYSBOhRrSPWpMzcIs0O69i9spXMrvrUlw2R+YyAVenREGDlj2BSkYdygkDSYGiKQe8mwgHL4Carp5HXe3dVH8dGSjShkgd4Iljx6maQMCS54XcjwrhOycZnWKMXWZGN6V/lACEGBOTQu5lGoxKTCXfSvmctTR1Q1EUkzCaLowpU1BArxmD6qEkQWTZx6ijn8IsnHO0bQsKOgnQJOCD9xIqURQivC1ls8oiEs2PoGCO1PHEUROWS9o3ATATYCk5ackbm4QBTeoFfU7CMJk4d+Ec9k/QZzatS2IQtMMwAdf0hF0IUQKDBCyZ2KRs55iCHdNlTGNwKks65+Z7nD5Hd8ugX43dDPZ2v02Ny5s6/zmWwCrt4LpRw+E6AGdSf6k9GNXUsrotgWCprmOU/4lWiogQW5tcdbkRg7D6rJHQLOcEIM2yTK89qVur94kCFqlsk2IbOa/2O5MEnFO9O81XGRqwBmMyYmuwvmHt7FF+5Affy47Zgl2L29i9OE+pGTObupFMWlnGaDSQomPIMgHV+v2SssjJnbB1pHzirKOM0tTubJZ146cPktSi8jD2kWNnVzh+doUzK+u4ss++/Reyc+dO5ufnab3nyNGjuLwkL0pslhMQvTVrHU0joW+JcdQq0I0CxSF46qqiDZIMo64rgpdsYCDtzQdP0H0JARsirihoo8dmlt07t/O2t7yJzOX8wi/9nwR65P0Ftl98DXUxR8CBhgnKU5PMYvpUAEk5j4aghtByxeWXsbK8zHg8YrCxgXUWQ6T1EVwpN/CUPrW5LQvAc27r32yT41P/fmqf2HyNCSvJKGCZvqPXnPQvRZDkjw6YiVHZR3IxjILVcp4ETiXQKFk6r5HMc4nFo9laSxspYoOtNxicfZLCNFx0wYW8930f5Nd//deZm5tnbX2dsux1/w4GQ7zO7SqVMaiqisHGBj54WeRLiQmMlD34QPQahocnRo+JHkegZy0zecZcUTLX6+Fyy6AesroxZH3cUkdDcAUmK/S+jWTMBAmVTEwtM5ExSP3UWIt1MrdcPnWkq5Ut27Ite+bYlqbSlm3Zs8Du/MoXlDIuk9xM2UXEiG8l3bmxKZRgsso8HI1oVUh3bW2d8VhWa0FSXaPnksxyEr5WFGU30RqNRxRlwcL8PHmedw5VCCIAKRMsw/rGumSrycTJtFbCjsbjiue94AUY57AuiYRPmCJClpZ7En8m4kNL8JGdO7dz09vewotedD1lluEIFJnFWlnJdpkct762zle+chtt2zIeVfzaR36LublZ/uiP/ojDh49y6vQSV1z+HAl9yywvfOELefCBB7nmmqt50YtexOzMLM45BusDVpbXuPXzX+TJJw5z9swSddVyw/XP4+yZ0wwHGzz26KN8x3d8Oy95yYu4/PKLWNw2Q6+0BD8mz8G6Kb2D/4GWJsbf8pmnJtOoSCwpnEsZM+IMaxp6xImMwRN8gzMRawKEFkugiKvkrJL5ZbLxCVh9nNHhezj69c9w4huf58yDX2Z05D7i0iHm6jOU9SplO6CIFbnqVQQsjSmoXUlte1R2hipboM7n2HDzrNkFlligmTufxUufx/7rX8nuK1+M23Eh5cx2ymKGLMvJspxe2aMoS3GuNCubNQI2Re0PMQTQ7D7Bt8rcQCbewUuq5SkQYxIyId8hQpB95VjRPvERhuMK7QE0KpovoanilNopYe100mkwImgopMuyqcxUuV5HHP7EHpHnZcnUqU+/pTEggQRt22JEPaQLXbKquTJ97cm/0LZNp5kk2wVQSucW0CkBXQJ6TUBhcWLS+dKYk8CnTvtJmqOA3h2DKtV1Apw2A0vofabt6Zjpeu3OfQ6mYpKe0jnHkpxBBfFM1wcm/aRjFE1t+2ZmNENXKofXrH4pjMkqC8pPMXjQujBGQsRSGVLdput+K9dnajwwU5XQPQd9P+hj6pxBadrSRhKglKxjrHVO9SQMTT1LZR3RXT0xw4zRTHApK6LeQ5YJeDndVo1JoJe0w8mzVGaVZtHK8gxrLFVVizh7yjQfwJkcQ8A3FR//vd9mNNig3+sTfIuJgapuFF5IGRA9LnPMzPTplQUz/T79fk+1yrw47/oxxgiL1zmiCtN3DSxKPSTQPUZhpvnWYw2srq0xrGpiCPT7PWZnZ9i+fRtPPPmkMnQtWVkwriqcy3GZAEpV08iCjxUdqVbbUwgSxivX1/YxBcZ1bQANXwuGtpXwJ6whBM+oGrO6ts75+/fzmte+jttvuw1fjxnXDYvbtmn/NxoSj2SF664mZw8xUpSFsPWM4dSpUzRNy2g8Js8F7JY5hQNcauldtT29bQ5L+2Ymt5ruf7pUafu06d+6f6qfSbOWsTE1axmJJ4Bm2l/+St+AqI1vauyZ/DvZOxIhGKKR7LppewgREwKFNdSjDUJo2LZtkTe/6c189at34FsZ033QsFUvGlnGaHtoBDxKY4dTQe8E6svjlqdmBM2S9mkMggxZWh9oGk/rA+OqYXl9wPLGiGEbaI2Doofrzci7TReh5COSBsZK4g1jJm3QWYtxFuvk3ZxlGf/4x/6+1tyWbdmWPZNsi6m0ZVv2LLBf+Lf/UhgaxlIUOXkuWkbWGsajIRsbG51TE4KsDLdty9mzZ6kq0Y84deoUx44dI89ziqKQrFnO4pxMZFGHRBwlSWG+trbG4sIi2xYXcc4x1hj/uqqoasl0lhzVPM+Zn5tjpt8jKwqqxoNz/NiP/ziL27aTlYVMvoOCYOpcGHKcQXUgJH17RPQnsjzH+1oZWI4YJfRqeXWFpmn4whe+gG9EgPXCC/azZ/de/uLmz7Fz5wJZbrnyyqvZsXMP55+/D5dFfKhZXVkhy3qMNioeefhR+v0+TdNw//33s76+zhve8EbOnl3CGMNll13G7Nws/RnRZxoM1pmb6Wt2IU8ILXnmCL5F5mEOg7A70iT1v9c6H27TXNmkqe23bjJP1uPkZOmUEcBYosmmVjJbMuMpMoj1EBMaQlszWF9jtPQAzfKTjM6exq+cIRusUfoxZWgwxmNcJJpIS8TbshOATeFirS0xvQWKhV3kC7vIZ+bJsj6l6+OzgljOw8w26C1is56kCDcZTchpbIEzDhshegGKhGUBvm2EZTXtEHQi3MLaIUoaaKkGQ0RFuEPoGB1BQ5vkdSphPmmiPu2kBwxNNDx+5BijuqXo9WlagZessitS3xPHVECL1mt4wrRItZYlgQoCFglbJCoglM7nW0+hoW+JpZRe/clZT32qaVvyosAoM2hz2zEUhZwnRrlPplbuU19O2xPo0oEBqsdkFPgKWnedg9uBRR3G0bFOBKCQY6ct3aOcR8O21Ik1RoCOc9t+OkcCpBLQJScU8Xhh2UzafURAozhVZ+KYTYMam8uWbHK9CaCWWErTv3c3nY6b6n0JRJq+1lPKN8UOmf79m1k6V6rfbu84KdO0NlK6hjxzuY/0tzUKbikYZow8a5KzavQM6Yb0eTOlExdTP1Eh8BDkWQqbNN1bcuDTaeQ+o3Q66BhtExAqy6RvGBdFIy1aLDk2eNbOHuOHf+A91INlts3OccHePfQcEh4bA85CkWXd9zzLyLNMFjGshDVL6GhOlkmIaNQ2lLIc5nnWgSkxCpBcN57Ge6KxVD4wqhtOnjnNidUBZwYNiwuL7N2zl/37zycay7huOHLsJDPzC5JZy8g5U1ty1tE2jYJ9jTYlEfcXFlNL07Y0VU2jDBVhqSiwkAD0AMFH2mZMXjhcJmB71bRcfvnlvOY1r6Eej/lvv/ZrtLZPNreLnfsvocnn8LYkRGEcbYarZDEntTcZb4RBhuAVZFlGXTfaBqUNSTtMp0nnm+pvyPP/77Fub5MW0XSr/qDQ8dRm0Q3q/k7tGLp/UxHkX9XPS6dMFwwy/km200nZ09Xkm7RfR6Y6g+l4i2kDfWfI/JB2/RSDtZPs2bmNf/FT/5zf/u3fZjgcMhyNcVlO8AkIlbaY5ndt29I0DYPBQBbRxmOapuqY4zGxMaO8WwLyDowxgm8hCgPNRsitaGGKAqQBJ+CQwIlSbKuLNRZDsEhIX5S2YXVcyDLRz3RZQV6UZFnOE4/eq5W2ZVu2Zc8k2wKVtmzLngX28//mX0hmlwgzM33yXDKDZM5SV2MGKmDcNKLP4qyl9Z6lpSVGoxFG2UQHDx6kV/YETMoy8iKXLDvKCrDWUBQFuWYqWVtbZ2FhgfnZWfIs6VIIDb9tWhrNeJac0dFoSK8o2LZ9B2V/hhb4wR/+G1x6xRXkZUlWZLS+UedZmDLOFEql9sTYivgxBXneIxA4s3QSZyMHHz1CXs5x/NQx7vrGvcwtLLC2vsbi/Cw3XPsCti3OcNFF+/npn/6P/P0f/btkmSPPSkIQQdCqHtLrZ3z0o79Fkfepxw0mWubm5uj3C/bs3c1ll17Mtu0LEsaRW7yXrElRM+Ylp885S9M0lEVB03oJI9HMWt7X8tD+L4NKaaKbZrP/90x8tQTiyTljjPgY8SZS2EARxxTtOtQrMDoDZw+zdPRRVk4eZrS2TB5qZnNLhie2NRlRVrOdI7qcOiArnXmflaaHKWeJriSf3cbinguY3XEebmYbxdx2bDGLjwYfDCEWBOPwxuKDAKLGWHKXY22m2ZoM3kqoWGIeyUQ3QtJCMlLXMUZiMxFKD5rZTab7wjrq1JOikfNNagqSiLFu8arDZJ2mtMdQBzh0+ChV64k4sqKU0LRcwMSgYWlWsyt6n8RuhQWSWBvJk4nK5kjZ1ayG9hHl+lnmiEGzcakj1yr7pa7rDrhymYTwjJsaO5WVMSoDqe40msRZF4dZyptYiN6LxtI0S8gogERKwW6ElROn0mX7qTC7tvVS5ilmVFQHXbbLXZ/bvpMTLQ501BAlQ9sKY2uyj+xvjJXwQtUP6gAeBMybZv8kwD39bdQZjHrC7u9Jcb6pGcSZjMrYTMBUur7X0CRjJvvJ8xSHb/NzmQbc5OpdWIle768aD7pjpurZWamXxECTehcGaTomKhjngxeGnDKLrLWTkLou7FHqM3b1l8YUYVSk8LK2ben3+xIyncrgnIRuarYzoyGLCTyS6wnIK21WNIbStawR771pGsmqmASIcQRvyYiMB2f5vve8nXqwSmEM+3buYOf8LPPz88zO9LEEfFOTOUuvyAUsiQI8j6oxZdmjV5bSb6OCA7FD5LEqdF+puLcPkeAFMBdFJgjGUDU164MNTq9XHF9vGA4G7Ny5k+3bt3HBhRfT689wZnmFw8dO0p9fIMtLQojkmkExCVh734rTruBe0zQS3hYEVKiriqauadqapm46pgoaCuqjjFF5bAnNmKLIhKUSwRu45pqreeub3sCJ40/y27/5MUaVobf7ADN7LyHm8wRbSJ9I+mhGgAbjBdCOSF+OUdjRxko/bdpWgTfIrIxVSBfoAKUE7qR2qz/K92/FvoVdp6BV+dsY7KZrMgHMpnbtNJs64EmK1403aPZKPaeMYfKblZNOjonCVIomClNIQaXSGPrWM145zmjjFNvn+/yrf/Ev+PjHP4FvPcsrK5JIApmHra2tA0a10KQ/tm3LxsYGTdNQVRXet4xGQwWhAj4EvEkLI/KcomZqDQos2Y7lasDkZJJVA0KjgFEaE5XNjMNbTzQRZyxOw9+sgknWZWRFSVH2KYqSB77xFamMLduyLXtG2RaotGVb9iyw//Svf6qbzOR5wcxMn6IolDEDq6urDAcDWdnSNOJt27KyssLGxgaoPsPhw4c7MESYSm6SxlYnElkuLIf19XWapmHfvvPBTLJENboq1tQN7VTmuKZpVOtBnBaX59g85y3f+Z289R1vx2YZZb9H3TQC0ARxdiU1LRh0cmwshgxjMjCGP/vzP2P3nh0MRw233volrrn2aq68+hqyLMdYw+zMDLt27MGYQNNUjCtDXmR8+tOfZveuXRw/foLV1RXqasTrX/8alpeX2LF9B21TYzHs3buHXr9Hnkvoj3UyOxS9HU3JHqJOVyfAUnLkZIo6cUIwMhkX6zae47HqpDRGWc0EmYDqTybK6qpBJuLWZpBYInrdkJw/1XtI+iY2hRIp0AVCgW9jlDTSmWT2GTnLcj2iOvYoCyceID95P9nGEdbPHsVW6xTUFLk4gAUGqw6dzRytzanIGFMSy21kc3uY3X4+vcU9uG0HyPtzlP05TDEDrqQlQ7hQDh8SmUiE2ZOsqtFP27Za0+J8m1Q3UVbkk3YRumIqYBKgoFKYCkPyUwyk5AjIY9BJt55r+hzizEldh8S0sAbnMhofGbWew8dP0gTwUbRGogIzvm26cifwwLetiOEbS1AGoFGgRkKFBGgyGoraaGaeBDS1bbsJjKnrhqLIdXvehaslACC1xzzPO/A2dPpLEk4hYW8CvEyHtYL40wl4AtMBOr4VNlVQhpcPQcPz1PHSLiDgXQIJJiyqFFqXGDLJIZPfUl/S0NZO8FkAIzowSQ4yHQuLCbtpKnQqOeRRQZqo15H9U9+caElN9xebwsbOAXykzJvBn8TKmQawjIIhMYFIev3u2l2FTcriU0r5VEb5UY8Sk7Fn0v/T/XVtO0rblmsLGDI5Uk4aFCRMZq2IQ0/vZ6YYSul+hEkjDmYayDrdpCigkLQZraeup8nxzolOmLQLGfuN1rdTwFbArE3VI9fRdi8+vTjIUlYHbc1wfYnv/7534ccb5A7m8pzzd25nbnaWbXNzZAb6Ra5AkogaxxjxPmKtZjbTPo+Re7R2EvzVNA11Xcl9JZ05D03jNZuZMh+Vkbgxrji7PuLk0irjENm+ew87du7mwIEDxBg5fuIka4MRs/OLWFtgrPRziNQKfqF9yOt7R8Y0T9s2NLVoGrat/Js0dSZjmSFEILRE3+DbRsB/I/qD1hpuuOG5vOHbX8fnbvk0X/7KHbSmpFjcy64LrmBEiXc9onHS5kKQzF9BQRJ9tqkdxg6I03aGvrjU5FmmHrD56/R+ybq+cs52eGqf+KYW0/gy6U+Ty07AIIO8X6VJTRVMMaLuY4wCUToGmNQGJ0VS2FuuFYUdFmIkmChagMHTs5HMjxksH4N2xP7d2/mxf/C/8pGP/Bpl2SMEOWY0rshzEe2OMTIYDDombNs2DIdDQpA5lywm1gyHQ3mPWEPVyngUdFFE+vGkXSUWqDCrrSwQGSB4AZ20/esdysdGrDNYY3HOUuQFLhO5BOsc/f4seS6C9F/+3CcndbllW7Zlzxjb0lTasi17FtgdX/icrARqiuPkGLgs67K3japKAZ3k7AWqakxdV2AMTdtQVWPatiHLM7LM6YQ6CThHDEa1XSLD4QhrDdt3bKc30ycaFWZ1jkbLYK0lc5muWKaJC+SZoywKhuMRRVHymm9/HUEBCXHgZHIu9xGJqAaErhKaqTTod955F9c893puu/12vv+DH+DKq67kwP7zWVyYZ2FujrIoWF9bYXllieGo4vNf/Ap//Cd/iveepqk5c/Y01193Dddddy17du/iwIH9LCzMsn1xjp0758lzizEekPCIGGVihdK70xxZalwnpMqMkamqfox8ksDp5k+acCcTSrk1Oiu18pHJ7bn7QmgllXZUB07q2uBjUm3Q7GPW0LSBaC21jwSX09qMOu8xKnucifD4aMwXHnuM3/n8F/nYLZ/mwdtuYc/Kw2w/ex+z6wcp21VmY0UWKtp2DC7HY2hsxoicDXq0s+dR7H0Ou658Kedd+xp2Xvda5i56IfmOywkLB4j93bT5NiozwzgUNJL7hjY4AhkhamaZqKyFKPWGAkBaRdIyYpBV8+DF8YwKXMYgBP9uNVa+y6Q50DQiQh2VXROChKnFKTDJe2GZiUMpQEDbNAoGpNCOCfPFxwg2Z3llTZhKxmKdJS/yDq6Sok90kUSQV3QxYrrX5FBbYbkY1RBq25ayKIgxdoyPqF5267XPOUvdCFMJXdHuUp2Lp0CeC+iUmEQJTDAKTFjrqKoxRVHQqKZTAoykLiNZJmBTAvkyJzofAlZ5cgWy1Ovv/m1aAcUkfCkBXdKvE9DkVbsm3YM4PVL/CVBK924UgO76YQea2q7+nIpOT99HGl/SvadzTv9tFDDpgKXE+tIynPtvug+pS+mP6bOpvArwpO9MgVDpHMk2nSsxlaZ+n94vnR8FvaQeEnicmD+hW2yIUbX2dOyw1hFR1ttUSJ5JzyVI+HG6F2tFhNsqSMdUHYICeFNaefKblM0pUy92jC4BIKUvyP0kQCcEFbVHddESiC8X1X4o4Y7yXC0htFgT8W3FJ37/9zDRYy3kmaUejdi2uEBmDTO9AnyLbxpQgeyIZkfT94xTcX15l0od1W3LaFzhYyTLS2FXRqhbCXtL5bbWURY9iqKkV/To5xku1kRgeX2DUdUSrKUoCspCxL6Xzp4lcw7rckKU90yIXjO3yt/SV+UZtb7tMlAG1ZtyWUZAn4PXEF+jzCoj7/IQheEZQiTP5drGwOHDhzHGctNNN9GMRxw5/ASxrbHO0uvP4HHYvEeM4CxYXWA59/2XRjwTwerHIIsA35J9q/ud02e+NUvsoemRWf6eMKfSmzktT8jbPJn8uvm6UgvyvygVsakuooZ9C8w0ec87GkIzpB2vMt5YxuE5/7w9POeKy/jc5z7Hvn37qeoGjKVpPU3bUpQlbfT0+pJ5ULJxJuBdki9keUbrRSfJKLNTAL80ViXNNLlPAU0dVkMUJahb2bkmAacSGid/awY4a2Qh0jrKsofLc3q9Pr1+nyzPyYuczAng9L/8wPfrNbdsy7bsmWRbTKUt27Jngf2nf/VTXdiAD56iKJmfm2N2bhabZxDh5MkT1FWNVd0S7z2rq6usrq5iVJthdXWV1bU1epo+2VqJiRenAMCQFyU+eJaWlun3e+zfv59ypo8PgbaRldKgK2BpduWVlu1bz3g4JM9kkrExHJL3enzktz5KFT3GWeq6JrOSaWYyhVNnCdWEMpYsKxmPa26//Xae/6IXU5a9jpFR1zUnT57k+PHjjEYjHn/8cYw19Hp9rn7udZw8dZwrLruMsiwpy4LF+TliaDtwwFqjwFFauVdHUFfwJqZTyqebz06Rk5IZIFPn8Nxjzp2wpo0RWSlNUFSqh6g/GCKYFh9bcf6cw2togjUOr6mpMyeTwTEZ5AV1NCwPRxw5s8yDx47xwMmTPLx8lieG65xsxhTecUHjeSWHeMfsSS4ZPMp2MyBaBwE8jspkjO0s45lFejv2sX33BfS3XUg5vx83sxvKRbwtaYKE02GNhJdFcYhiDPiATErRDE7RdDXRkSmmTJypKedcQ1U2g0fKLIoynZdrpRoWICGxR5xzmKmwtM7JV7aNtUZTeuegAIIPvst4FWIk+FbAlGgZt5Enj5+k9pFohV0ijrfoTWQd80BMgJNUvgkTJznn6XknECiVMQEdqc0HIsZYqmpMWZbd/sJYkj7sW2FPyHUl5Ml0ItgTbaKYADUFUVJdC9OEblVbQABlFU6BGnaKWZTOl7ZJfUwAmnTO9G8CFqxq/cixk/4n7EXZP4FS1lgBHafKkP6d/g7f3PmcrtvJtTbfv9WwrajniQoQJ4BKvk7+TeBKAqSmf5e2ObGnK+v09rRYMA0qTdfxufdlFBRKlvadjOVPPeZce9rfp+rZKkjlXCb3oywHAcgSuKOZATvR7wR8SZkiwly1KjpvFCQ0HTNMzsNUXaR3Sgrds05AFzmf7B9DwBIYrS3zwfd+D8aPyaxnJs/JgfnZGfbs2M5cr6CXZ2R63roRx904izMGZxNjUrLctV4CZKVqlO0YJOQLfT7OObIskzFtqh01TUtVjanqirWq4eTakJPLa+Qz8yxs286uXbvYu/c8sqLkrjvvIu/P0ZuZpVBWSlGU1HUjIYONMIyapgZjcFZYKt4HxuOx1k8jTKqq6t4DVplNMt75jpk1ace66NPr8fKXvZQXPP95fOx3PsbDBx/Hmx4L519KsW0fje1hs0KAsyiQEto09WzSVrQJGkyHEYVvFSwywjb9liz1u+m/p/pY96uBGOQ+YTNrSix246BFRK2j2QyEybEJbpLvk+1Sbou08clOyu4xcqRzTpg/oSEznl4WaDaW2Vg6QWlaVpdO88//95/iD//wj7A2Y8eOXViXUTctGCfsOCuLCZFIPa7xrYD8dV1R1yI+36rOUl03tG3DeFxRNQ1eF6KMkRDYzab3GlP9p/qSf1M/lXE6Ae2i52mdI89EtHtudhbvPb1eD+ccZVlSFAWf+eSfnXO9LduyLXsm2BZTacu27Flgd3zx84QQqJtaHNIuREFWqsqyxFrHxsY6TifmybFOjIfEDqiqijzPsbpCO+2ERCTNdQiB4XBEWRbMzs7KypaxstqpDmDSZ0lC31YBjyzLyPKMvCgoipJ77ruf7/qe76E/OwPO4tuWTB3eaRNnQrLqeKVvZ1nGtm3bKctZbv7kp+j3+zz++BP8/u9/nGPHjskEOZf06c9/wfN5zpVXcOllB7hg/z4WF2aYm+uRWwi+xhCwJkL0ZMrkknqagEmiHfLUSe7TOl8wmZx1ZghGPh7TaW5IemFDUDZSlCQ9tE6p9EYmsFaUG+R7lMAwEyONbcGJw2A8WG8gWCIFtckZkLFucw6Pau5fG3PLw4/xX27+JD/7h3/I7911J187fYZH1gacaQNjcowpKaNhoV3lxcUZruutsp0BHktdbKMqdjLMdpPvvobdz30tF7zwrSxe+jKKXdcQ5y+mKfdSZwuMKBl5GDY1dduoAwneixPmfdBU1FMhQMhE1ojX+ZR5f2IcxajH+1YElqM4mSF4BRzEwZ2AReL8CbNGwZxpkCOBCvpbBNpGNLO8avN478GIU5Z0lGRyrQCCcfhoWF5dJVrRgXKZgFYWI/rkUUODpvphVBDHnAOGoOE1qT9VVUWvLKlr0UUyIHoaRvpFjIGZmRmapqUoSryybMAwHlfCmIoR5zKqaoxzjtFoTJYJcynPM9VDmYA+UvvTDpU67XECfiHRR+qUGoJPrIh0DjnOKghnUmaxqRC4pJGUnBb5Xbal5yQAg5SjbUXDJdU/06FxQZ4niGOUNOHSPtP91VlZdZ8AGhNgCS23sNkE2JH6VGbRFGtp+j7T96hAS9onWdpHmreADmn/6bKlcbnbpk6yHHvu2DIZh4yR/uS0Dpzef5wC96bLmSyBX2m/xMJI10rPs9FMZKk+ojKiEogG8p7wyjZLgJJXVhtG+kBE2mKWZVPXlHYkbXoSCmmUTegVEMnznLIs8V4EqjEpQ6Lsl7sMEwPteMQf/P7HcCaQGUum76DxeCxhqVnevavk/WYoewW5E6FsHwK1OuZNo4CituO2lXTuMYDRbHBFUWiWU82iaQy+aahGY2JoKXLH/MKcCJW3NXU1ZnllFZvltD7Sn5lldWWVnTt2sLRyVkDttqHMS8bjMUUuWSR9kD4yOztD8K1kr1N2StM0ZJmT/jP1/IStOPlbHoUAgOhCU1mUgGE4HLK0vIIxlne/+3u47557WF9fY7y+Tm92lqIskaHb6jtMw8TQc6Y/MPqZpvQ+te1+c0sH/XUfuW73d5QtcdP26Uvr30jbmu7v6XdhKk0shbVNQ13G6JhuZFHEGLm2SecDQtRj9DdHJDY1NtaUpsX5MRtnjtFsLDGTRerBKr/8X3+Rr3z5y9z6xS9xxRXPkfJoCOW4qijLksFgQ9q/inb3+30JMev1MAaRQLCWXq+vfchgnaNtg2h1GSPznHTfOiakj03zDqvAvTKgU19N4KlkdXP0ej22LS4qO6+g7PUoi5I8F5BpZmYGYuRDH3j/VK1u2ZZt2TPFtkClLduyZ4HdessnCZphJznTaZLQpSnOMkajoaw+GaG++7ZlOBx2E4W2bamqSsLm1GFMk6yoq8oSuw9NU+NcRlGUZHmGc6I3IRN0mczmuaSQTSEQ1gnNv9/rYY2lDTJBuuqaa7jgoosgib8qtX/a50nlsKobJZP5yJ133smXv3w7jz36GFVVYY3hqiufwxVXXMbVV1/JRRcd4LnXXsP27YssLsxS1wMyByG0tE1Nmckqu4AYEgqVwIyoAtyJ3RE089SmmeamiehfZ4aI01XLBA8ZoZqnCb5OgiMazhEl1bDVlMPOyK/dfyYwipGY9ahwVK5kVMywZHIeHzfcdvQ4n3rgIT72pdv53S/dzm9/6St8/oGHODqq8TMLtP1ZhjjGGBoE7MIY5vyIA+0Sr1ys2csQomOU7SLuvIKFS29k3zXfxrZLX4LZeyX1zHlU2QKVKWhNQRuh8V4yELWyEo6ykERrSwBMwT1VfDcKMCQbVVg26GQ/sRpUE0nAJI9X9luMgej1HKrNEhVYSiBB8JoBSR5DByB5FcqWlVsBKIwKjZLEuDVETsAm7T8akhP0d+cyAtD4yNrGgDZEjBUWUedYa3hKmowbY2hUZNUAVsNsEtBiraWuKg2FkXC5uq4FJNb+LZpHXjWepJ4FfEhMIhHuFgdcwoy89+S5OL7CYhJwpG1biiJpKE3YTD7pUDkRtU8sqNiFCE4YPUHDL0MQBlnQUDM558SZdVMi5ZmTekp93ihgLB6gtHapjwk4ksY6EBArgTwxTvRc0L6Z2o5JwNZUOFgKDeuOTeOMjn3pHo0KUqexNd1X+s2oA5YcM6aErO0UMJ9Am1ROM8UoStefLsd02ePTjTVdnU60mtIeqQ35VkI9U52le5N2Pak3Zx0hatZDBVvRMsslJsek+0zHJqe3q4cUgqUMnrRIIM8myDupS3uebmHz8zMK4Mo1JXRmuj6lXUp/lZBo0RZLzDlLpBmP+IPf/10yoxmttH2BZTQakRfCQBTnWIFmL8LXAWiDgEeSbbTAWEvTtKJLpIwTl+WiHaNtq1X9wBgDMYiwdp45ekVGljuauiYzkaILyzSsrG3gFXzYtWsn/TInmsDZpTPMzMzou1REj9tWwB9jjIDqys5M/cha24nhyztb2xLCCksdzShgYDR8NvXRuq4x1jKuagbDIXOzfV7/2m/j/nvvZWOwwWg4ZGZuDqPJCYIxREGV9fnre2walFHQKZoJe+mvtae+av8a0731uAgTpEu6yDn2lA2dpV/kX2nvm4rdHar97Sn3lMCn9E6PmBiwtDhfkdFgmhHV+lmGy6fIQ009WGXntnl+5G/+MIcOPsYnP/mXDEcVl15yGVmeUzcteV52faksCxknY6RXSgjcaDSi1WQP4/FYFwgNdd1QliVGwx5dJoBzWgBIz23Sr+UeUp+W7dL/sixTULegLHvK+C71e48sc9pmpXxZlpMXBUQJx/7A+9+zuaq2bMu27BlhW+FvW7ZlzwL7mf/9f6NtRc+k7rI4ich2f7ZPr9dnZqbPYGOD5bNnMMbS1DXjquLUqVPd5H1jMGB5eVkmDQkM0plYUOfeqjO8vr6Bc47t27dR9nvkWU6/31cASSb4EgI3CX8TVkikyDKiD6yvb3BmeZlvf/Obef+HPkiwmiWmnWSYktna5hV8gwBb1mU8/NDDLCzuwljLju3bOycbEwmhJRKE+UTA+wbnwBhxtCfaFCJ8HTScom1b0XeaYiyAOG3iVHZF0V+eOvuNCoQIIpImoYZoJAsXCchCNC6SdSuczmEzEUNN28BQtQ3BRFplM3lgzZWMTMbZtXVOrq5x58OP8IW7vs5jJ05TZTnZ3Dwhy2kitJmV8MI2YKOEefgYyDIL0VNYQ+ks20dLvKhY5x07W/aZAft2n8d5l16H27aPxs1QtwVtW9AWBVVUlhyBwlkRgK1riIa2BawIwXovE+sYBXhI4EqIkYgAA8k5lgoTFgxTc/bEOEJDPYMKQxtdbU6fBETJsepMAS5XrR/kd+ecrvTKs3fSQEDPk/ZlivmRnPJJSJL0Dx8trXE8ceQ4lQ9EI6y81P6zTLhmUcWio2bj8urMJWAnTeTl3JK5zVpxghMYk8rvvSfLc3V2BXBq2wmAlcKHmqYm01C5FEIGkuq7bT1GgZ7kkMQO4NjsjMlvAiwVRS710AhbzCrzCGUAJbAEBYNDFLZCqwyzVN8JXHJO+p6IOk8EYYV9FjodJ+c0lEQ1mpxVBZDkPE8DP6jD1IEfCg4qi+jpAKhMmWrpHN12ZaB0zJsEGE6BM3RdXdrHNICTQAeXQBHV8UpliCnELgE3Csy0Cgqlsk9bKjtTgFUqB1PsraAAq51iVk3vt2nfLlRt6vxd6Kf0E2HDaHsyon+WdJHoFgfk3uTwqft3CfxJuRYjRgWwp+tb/hVAyRjJRmeMsCZSH7C6WBGihNnFIGC8MwaHZ2PlLN//vndT2iBsJSfZ5oo8xxJwRC7afz6OyI5tC8S2oW0a8swJm1RFnWNMwKiMP85aXC7vwhhBmposTCTmVqk6MjF4CaF1ojvjsgyCp6ob1oYVR86scmRlyNKgZtd557OwsMAlF15AcIH1wYCjR4+zsLADYwpaH7FOszTGwGg0ZH5+jo2NdXkebXr3Bc3CKgBX09RUVSXMRwV8E/CMZr70wVOPxtg8o1f2CIBzlgv27eXG51/Plc95Dj/9736W9bEn9rex+6Irsf1tVGS0RvqkhIwp40zPHTlHR0nH4m/JznmvfjP75rv9Fb90PxnVUdpcLhNVoBor7OHp3wC6NBISAijvd0M0Emou5wg4Ag6PiR6HJ/Mj1leW8NWQ3HhMqBmur/L9H3gf73zH2/mtj36UL3zhC5w4eZpdu/fywhfeSFH2NDGDLsggc6nWC5PVt5N3yHg8ln5iLcPhiLquCUEWJLwPjKqKqqo1S2BDVdV671ohUZ5ZB4tNj23GdFIDeZ5RFAIcpesJK94yOztL0wj7NSiz0Cq76eY/+fikIrdsy7bsGWNboNKWbdmzwH7uX/9zmqambSSTlGSUcvT6ffKioNfrMTs7CzFw9swZmqamaRpa7zlx/Dhe2R91XTMYbDAeVxR5Ls5aChNSB8BYR5blLC0tYa1lx47tlGWPfr9Hnhf0eqVkcitLuYaGJiTvNAIZonkx2BiwsrbORVdczt/50b9PpsLAxlhc0lUyylxRk8mNfqKKjWpulW6SqBNESQOcjtXvKZ1aZzZ5BJPz6lRYplYTM93/Jnau0y2WJmGiQ4OW21pDGyZOe4yRzMq0VO5HwqQAiAZrXEerbwHvHK2zjAis1RVPnDzBE0eP8aVjpzg2HHNiaYkz6+uMjSHmOS2OaETbQ/SXgMyTYcmiJTeiRxLxlBaKtmamqinHNZfMOV5xwRxvumQf+3dup5zdxigWjKOhNhm+MRTktKGijuocBk9sG6JvMVEyDUrWo6jing5nLDGKto9zDmcdLpswteiYBAaDOE5oSAvKFpNJtKzIO+dEVyLKmrCZAgJCFECRxEyaAp1i1Ienz6abOE/t6+xU2JKWL2hYpFUGUKaMGh8CbTQ00XL42EmqxmPzEq9henmmmkVTK+cJcIhxwh5I9yngqN7zlHZSAiqCgklRGTNVU1MUhZYpJ0YBYZyTcoIABE3TkOci9p3C9pLTnhz55GCIQ7+Z3WOmMnylY6wxhFaAiJBCqEIQpoo+iwRstL7VykzO+uaQrKez7pzdPuk5JxbYBKhJzzeZtHp1kpSd8TQdtruXdI3N9TFpI3EKqJoGsdK/6bgOuJpqY9/UdAxJpZ4eH5yOv6IvNNVepso8OY+WY/o8CpwRBbiJiVnBpB66J37OuaWOJwwzO1XH05Z6q9TtZEzULXTt+pzBUqpwAuo9xZ5GVG1TWdT5lfYh5xK9NgF6bRRQ6UPv/14KG8iMJ88kW6cPLSZC7ixlZjlvz256yiYqnME3rejHJSFjI/Xrg4QOyTgm1/feq6C2XBfAmkiRZ8JJNaIF5vQZxwgmSp9so2Vp0HDw5DLHltapgmHb9h3s3bObbbsWGdUVTeNZWl6nV86Q5T0iVt7z3uMyydBX17UCdzLOeN/StvL+FRZnZDgcUFVjfBBgIt1P0mgKwXdjaWKYxBjAtzzn0gt5zatfxc4dO/hP//m/sDRsYGYHO/Zfhukv0jpJrmCihajg+dRz3aRJNDUG/tUWp1rzX21P14Skqf311+r65jnAkkGAZ2sdxloF6x0henJnMYieHgR6TkD8QEaDJRp5N+EbctOSh4owHhCbIcOVk9gQCG3FeXt2ct21V/H6172eI0eP8sUvfYlDjx/mtC7u7d61ixc8/wWUZY/RSLK+GWW4BqQdD4ZD8kzG9BjB6xgrwGukqipilHDuUTVmXMmzHo3GjMfCbJLQcQkfl25qFFRCwteMLBRmmQBJIOF2mYrXOyds+LKU8MnEfpW2NHkf9Xolf/zx355U/pZt2ZY9Y2wr/G3LtuxZYHd84VYyJ5neZB4lKZozl5EXJU6BoCzLaVpZvYwx0jQS/iZMCdWriJGmlrTmMkkWp1Im0MJ6aDVMznvRbjFdOmrIc9GUyDIn2UmUeVEURZeNzmWOzCkLxxqqpuHFL3kpRU90YGJUJ8WkFcSJbXLO1HGxVibuAiJ5XV1LWUvSalvUyaztQJYUgiZTp/TRE4Mco76jmf55yp7qK4qzrN8E+NAwlxgDNtS4GMmcOO0+RqIxeMBbS02kAmrjqEzByOasZznHmsC9yyt85vHH+bVbv8RPf/wP+ejtd/L5I8c4uFZzdHXESuNpsoKQ5XjrCAbJgEYL1oMN5BiyFso6MFO3zFYN+fIy5ugRVr5+Fy9cnOc7Lr+Em258Hq984fPYs3ge3s7R2hmGdWAwGjMYjRkNR1TDIePBKs1GRRi2tOOG0HjquqWqG+qmxbctoWnAt9C2jKsKAGeVBReFRRST9pHXkDUNXzNpchx1gq+iv20r7Bi0HQfNRNa2rYSCrI3ZlwAA//RJREFUdaGK6tpqM/JtEqeV351zXShAVOZPB2JMr9JGcR6dMugSwASSfS/LMqq6oao9o3ElYSrKSErOkYFO5yRMAQYhAbbnhFMlh356e7q+U22foODNhMUj4WwJlBJnU+7dOVlJTiwh70XUP507gUcCXkzArLadMHI2OYpTYs3iSDyVcZPKj7IUXWL7KOtE7lMBj6fxDM/dLl+1bWi9SKiTMqG0Ho0yWiTr1aQ+EzByrk2X1xoVZ566l64Su8Eg/SnnTm0j3a/RZzN97un90z3JuDppZ+m39P2vsq5u9VpGkBXQayYAMu07vf+0Rd2/awepDPqbn9K/Qu9huozyPT0reUjSP6TdC2NOjt9Up0i7SOypp9jTlDWVP8ZJmNzkHoUZlVhx1sBwuMHv//7vEnxN2SuE5SbRtdInJcUmrWqK5coKDJqlTv6V30MIlHnRhesaY2ibhiLPlenaYg3C+gzCisqV0WGsMK1ClD5aFDlFWRJiZFiNsfr+Hgw2GIyG0oeLgl6vT5GXXdbJLJMQRdTZT+9sYY/VlEXJeFwp2A3Be2WQTfpuVAw7KmhitO/L2CTjWvBS1iIvCN6zvLzExmADZx2vePnLueuuu/BNy6gaMzc7I8ycCE5Za0YXS6JUb/qfvs6f+ly/uaUT/HWfp5o0laf7bfMx0qZS+5PvERRgkTDmNDa4zOqiiceEFounLCy5idSjEVnuRHsoejLjMe0YU23QbJxhvHqadrCMbcfU43XecdNb+OEf/BC9ouA3/tt/40tfuY3HDj3B+nBM3p8hxMhsf4Z9+84nRsnuZlQzK2pJiyLXBYuJTl3qm/K8E8AtmWB9K4sRKENbQMipWtH+Lws+0pf6/X4X3tbvJ5aSMNONhsNFbdcxRnq9EucEYDIq1t8re4CEkn5wK/xty7bsGWlboNKWbdmzwO76ypeJEazqGsWgrA3NXGOMwWWOPHNkmWM8rvQF3zIYDDrdihQG07aiAzFt4kCIcxRCoFIK9dzcbOfAJMeq3+/R6/WwzpEXOa1vsdaRFwU2c2TWTlZ6I7g856JLLmbP3r1EIkVeqA83BSpt9uUmE0ODrKbKNHDq93OclG4ymwClcyaVRs616XPuOWDTcU9nndMTNN29njeo3k9pHeDw0eKNo7EZYyx1VlLlJQNXsBbh4HDMLYcO8Ynbb+N3bv0Cv3Prrfzel77MzXfdzYOnl9hwPap8hpHJaU1Oax3eOrzS9I1mmnNtQ143lHVDf9xQLjWYpQ3q46fZePwoq48dYvD4QcZPHuKDb3odb37JDbzqeVdx+YHd5DHiW0tTw3hc04aG4XhE27QEH/BtSzWuME2D8Q3R19T1mHE1pGlqYgi0TYtvPKEOhDbS+EZWgMWr6ZxQcXCkPQT917cS4tI2snruW89wKLpgfkq0NyoYFDUrlOh+JYFmeS4xCXJbK+E6KiSd0quHIEBUmpDLQVKR0k4njJr0MUapB0aEx5vW4/KS1fUN0RrpVnylaRoFalAwy6sAuJ1ioDjVI0PbUprkJ0CkmdLLsJqdMYRAUZadyH7aVxxhcURJda736lW7TMCt5JQLMGy7LIgJZNrcVxL7jo7NJM5HqpNpxyY5/Oh9JFFlud/E1up2EWBgqovJtomTlLAHAaKErZSed6rr2JVTn7eCut3B51jXZ6efvRYm/d1t1/3QPpa2e++7kL/unqdYR+lZdtuNiOam8oUU8oaUc3rfaUv1kL5L35lcBz339DWDgoOTNjvR1EmfOAWehVTfun2aBZauP10+YwRkTe1HAIVJeyOBPV29TH6TsqYR6xx7ujqIkyUAtH/FKFp/KFgbkxaegaYe8/sf/xij4Tp5LosZNsrBMd0jUbKrZXl3H2VRgrIdgw8CAuW5gDTGaOinlCcEj7NpEQbyLGN2ti/3awTYCdqfXCZJKrCW0agiRCh7PYqyEMHtGBiORwxHI0I0FEWP2dk5DVcfYQw4N1npcE6E+EW43hFDCtOU+kni+8IwTG1w0g+kH6U2rb8b0bkjysKMy3PaEFldWyMauP7667jgggM8+PBDtHVF8C2z89vkeSBzDiGnOoHStX3Yc/rRX2/f+r6prU9/nv746W3yfbpMsRuApH+IgPtkLMmzDItkFrSxpakGnLd7J694+ct53/vfz2c/+2kyGyhdxNQD2sES47VTUG9Qb6ywe/s8r3z5S3n/+98HwM0338xf3HwzJ06eZm19A+MyXFZ0/XNhYZ69e86TdpMVtG1650nZhNkNzgqDKJVT+pSIdTOlHSjvg7xjuQqzNROpgql6FH2/SThbluUURS4gZ5F3epryb6GhcCUzM9Lu5T0kCSayLKPVBciiyHnv976rq+8t27Ite+bYFqi0ZVv2LLAHvnEXTV1LmItqozjnCDp5t+pIW2fpl+WEFh8jGxsDnahoZiyddFZjYZQk/ZUQAk3bUtc1GxsbLC0tMR6P2b5NdYx8wAcRTp2dFWHRNLnoz85QN7U4qpkjs47MZbK6GyNZUbBj1y4uu+IKBWKS1hFgkrMoE780WZqYzp7PtWhU1yBNLtPK+NMxFWRiLZ/p70+dqKbtT2fT2023+puOkyxTTXDUNmNERtubZZiVDIuSE03ggTPL3HLPffzXT/wBv/Snf84nH3mEh1dWOdq0nI5Q9fuMswJT9jF5gbUZucuVfm5wRoCkHpZ+gN64ZaYKuJUho8MnWTt4lPWHn2R4/BT12RXYGFBWFWb5LD/yve/ijS97ETdefyWL8zmGFhPAm4J6WFGPh4yqAePgJX1x09DWtegk0dK2FXU9pm5rmqamriXEsqpqfNvStB4fA2VfqPMhBFp1tnyQlXHvA771hDax5hSU8sJA8iom2zSiexKjaOrUVSVZmupaWEcRer0eeZ5vEln3PlDVsq/4DdKuGmXu2RSyoFnXMtUoiVFW3q0yFuIUQBWjIGMuc4RoGNc1a4MhrQ8iZDsFRkHEWmEQxKmsYMkRYEozJznum9paErCOUdI2J6aOc4xGQwoNH7VWACtrk7ixXN970Z1J1036Y8JCEk2jFC4XFeDqAKpGnQ8FmVJfcE4cWavAWCq7S4yucz5dhijtEyHIc5/sI78n385sAjGerh8a6d5TGlrT10ZBtJg0kbQqp80kcEOTHKR7SWPn9PNJ4YbTxwpGoUBNus8pAIYptlIqU3ru3vuOLdKd65zzoOXTA7vfgpYlnTOVMSgrKuq2BEp2dTLdprpnMTlfAqWsgi7pvZA5yayX9mGqjhK4iNaRlF0vpc8rahhrVKDKaJ1PsyU22TnlhAkTyXtPm0SpnWQElXfVZDkkBM9wuMEf/uHvU1UjIoHZXg8bg7ZDyb4pHA7D+toaczMz8vyBpm4o8oK5uVkIktjCWg1xi4FqPCbPxPnOM0dZ5PTKUuqpYwZFnJPkEnlRYFUo38eID2kMgiKT8aVpW5oQWB+N8cHgbMbc3BwLi/MUZcbhI0/SV8fdWIf3kvUuhbI6NxlznOrF9UoJi00sxmlgJQF60makbVkrunImetq2IWAxLicay8rKMjF4brj+ueSZ5dFHHqIdj2hCxvz8vLQJY/Egodt6f9Nv4qfrg9/c0lH/oz7n2qRtpr+7b1be4fIukjYbvcfGQFuP2Fhb5gc++H5+8if+Meftv4Df+q2PMh5tQDNi/fQx1s8cIYyWqQcr1MM1vvudN/GPfuzHCDHw67/x33jgwYe4865vMK4bGh9wmeoTpXEGmJubZ+/evd27Mc+KLrmDcxYfWi28AEyZ6tRl+n6QBZqI0ey8xkzeB2mc6MYHzfJmNWtvptkMkyC3MXJNEaWXd1GWuU4wXMbNxHJN45S8i4uipKrGGGN5/3u+p6vjLduyLXvm2Jam0pZt2bPAPvpff5HxSAQZfZCJtgBFAuI4J7T+ubkZer2Ctmk5c+Y0TdNw7NhxCYHzbSfwGELg4GMHJUvNVDa3CHgNS6pVEPzA/gPMzMx0K3rWWnbv3sXs3Bxlr0euq1o+eFl9NTCTl/SLEt+0DIdjxm3DRVdcxve+/31UTY21mSQBwyiolIYxCTvYPEHcPFGUeXxaHf0m9hRRTlnt33TAOemEzzUZWSfnMKhzq3+BOGthKrSptY4l22PUtpxeX+fBI4d54MgRHj11mmODAaeGQwZEGgwm5OSmBAPRGoKNtEE0EvIsw1kgZYOLFlqPrQN2XNMub9Asr+PXh8RRjR834CNEjzUDgjN4IyvyvablfW96I+947au5+qK9zM1CE8UB8x42KotdH9COB4xjxcAH4rimMBBCg/eOOtTUbYOvJaNbZjNlwbRgI1npMLmEc/RtH6LS61VTaeJUqsOmrc1YS900OCu6SaTJ9pRGj2+ljTdtIyGgzlGUBb2y1zGX2lYyxdV1LU5oLuFi05NpObeykDTLobHTYOZke2I05VmuDjcSDhoNDY4zK2sEm1GreKqAMQKSEcWBT8BOct6Tg562JwchXTuBEsLEmoS/NU0jjmoI3ap02i9N9BMoYBIIpaEuQQEicS5SD5f6F4BC2GMJ6J04pLJfBxxovfhzhKuTk5scGKdCz9rb9PgESnBOnxQTp24CxqQyyPnlem3TgoZ/iWMzBZLoddB6TN+nTZqcAjiKhKT6lp+0FUyBPOkapPMCrZdkCSh7qDu/eq1d7T5NGZgqX9rfGKMA6ObQwlSWadv09KZ+6+45ipPclb/bY3rcUtM6SHU4Xa4ENJ1r50Qpgz4rOVU6TwKeNtfhN5ulGmXQnWvdc0LqwWp9BV1IkF8ixJbBxgrvf++7qEdrEDzbZ0oWe31CgFZZWTFGnDW4GCisZd+u3fSLnG3zokPY+haihN6C9Jmy7GExxOgF4FXwTfqULKYo+iSfroxyvTYamlaTDERhvrTA8rDmyNl1Tq4PWVoeszC/jV27d7D/wvPJcsfxEycYDEdkRY+imCPLehiTEaLX7Jkpa5/UuTVIlkwNGU5jVRLtrqoxMQr7uPW+K6oPAXwlYL7NwZUCnGVQmMCNL7yBV77yVfzFJz/Jl++4i+B20tu5l227z6N1JW1WSDa7aLHRYCMiah0lucT/P5kxiTknz6trP8jY1vpWGFgxUA2HXHTB+dz4wufxzpvezNKZ4/z5n/0J9z9+jJWVFVZPn8DWGzg/xLYjDuzdxUtuvJFXf9ureejhR7j//ge56+57WFvd0EQTkbxQoChGyrJkONgges/M3DxXXvNc9u49j4WFBeqqpl/2Va7AC0hjBehp26ggo2p16cKA99Lvor5TYoTheCztoWlpNGS8qippJ1MhwAksTe8VkVCYZN3s93vECDMz/S5RjHNpYUbecXmeMxgMyHQeGkLgTz6xpam0ZVv2TLQtptKWbdmzwO6762vkRS6hPOqIFEVBULpz8J6YVq11pcn7QFXVVFXNaDiS/doWEw2ZtRw7doz1DcnwVnSso4I8E1qz64QZexRliXXCAvBenMayJytbUTUpyjxnbnaWalBR1TX9mT7GWQLCPNnY2OBlL3+ZZIYCAagM5ziaplvz3OSITDtYRlZIUVJSMIIxRWMQZ1RWZNMnGgEL0nqqMRnW5JIOOQDG0fqoaZMtqLMZWo+LkEWoM08bPTYaaA3GFVQBapcxdBlrNuOxwYAvHz7Ob37lbn71k7fwqzffwqfufYD7zi5xdFxztvYMPLRBhE4lSk90kExscSHQA7KqYcZDv4F83GI3KuITp2keP8Hao0+y/vgx2rNrhPUhfjiCpsXG/x97/x1u3XaddYK/OedKO5xzvnSDbtBVloNkybKx5BxQ2xhjA8YWCo401QUNRTU0BQ1dVVA8RVHdVTxFbEyTTLCxjYJtyYXBQDlIWFaybMnKN6cvn7j3XmGG/mOMufb6zv2ubIL/uH3PuM+55zt7rzDXTGuOd77jHQlrEg5xLAs7o4wW17V86Uvv4nt+7zfwojtmXNqd4b3Hq65Wv1qzOTpk6Dd0fct6vSGGSPSyGI1IiEPwgTAE+q4ThyR4fBhUR0S1i0yBxRG9OBYgu6IxKTspSnv0fU9U0NIaTRueREA0JgFmDBBTYOh7AUVUDFT6dkVZluKAa4hn3/V0veiMlFWpXUYAI2MlJb1X+n/U7E5exa2HYRgBrRgErPHBk6Jkn0sk1icnkr48BEKCVdsxhKghIPKM1jrpMxPtGqPliBNNo6DlcEUhzqERdk/WZEEBpcEPGA1/y0Cyc46+H0AdAHTMi3Mh96gnYXLZkUopZ/QS0E2ysImuGhNmngAAW2AmOyzWOobgJdNdFDYURjLL9X0vYvDK9kqnh+st15bvMig1fjeiHuL85fC7XFcpCcsqH58y8CBDXi5q9Epaz9P75gIZo2COfh9ixGjZtcvKvVS41kdlMJzKqJbLL2WVMNHTINBpCyFIaJYVjSqpp215GfusPtukbYExW5tVJs94fH5eZZdNgT4mmfCMsuCChpQWk3C5fH+bw/uUkRRGZquypLQuM1vBaxZNaxWIMkZZbspSkkBYbaRMTZM/5VJS3hw65k9l08sATlIg1Vq5V/CDMCmcYbM65iff+Q7adafi0YZy1uCTvJuskfedTSLMH7wnkrB1TVUYCgsxDJACdVWws5hTVwX4SGEsDsP6ZEUMPU1TM5vPKMpC50Zh6qzbnrbridYRE3TdQFQNGjAY5wjJ0A2RsqywKVIED8ly/eZNoonY0rHc2WF3ucsd5y5y5cnLLGZzqqqi7Vus01A9I+/OCNpOCtxqiOoUYJ62vfcCVhsrAGQGujEyP0KksHLlGCKPP/EUxydr3vSmN3P1yhUOnrpMe3RIUTnqnSWbfsC6kqAZKK0DTKSoCnwUIW+Z22ScTkfHOGwnn/3nMgO4ZCTbaGEJyYPRzIXy4AQiVFYE1oNnVhiqtOH4+hP8F9/3Xfyl//bP8KIH7uHv/f2/z79417t54uoBVx/6Nfqbj1MMJ9jumGF1xBu/4ev5i//9XyRF+JEf+XE++qu/zqc+/TkOj48V3Jf+dvHiRdarFRjDerVmGDzWldxx513ce9/9OOckG1+MYA1tJ6HPdd3gfaAo81pPNx2UqZqSALsZYLK6STNfLMdNsKSbHkbnAqcsJ1c4qrKgaWqapqKsSsqiIERP1dTyrq0rilI0vuazhQJVqp+kIPZ6vaGuBXwqywJnHW9+03eebpYzO7Mzew7YGVPpzM7seWD/9If+loT6GAkn6HsJNXOFYxiEoYHuHJ87tytU5Lbl+rVrHBwc8PSTT4lD37W6Q+X47IMPcnR0xHw+ZzabiRiwk8WyOK4aHpMSe+fO0zQzdVQSy+VCQ+AqqqpkNpszn890R9dxstmwd26X4AeGYeDw4IBu8HzfD/4gL3jhA3RIVjTzm6QenmxW3/r5rX+qyTLVjplnBFySrDSZpQBp/F52r5MurGVXUdgfhoTDgOpR9MZgbEWkZO0TV7qWx48O+OzTT/Gphx/loaeu8NiNm1xbrRlMgS0rorMEazB1QVLHKCVwSHp0ZxKF3sclSL0n9Z646QltT3+yoT1Z4dsW20VclN17o2KpBmEPTCSpJCObDYQhURG5uLD8mT/2Nr7kJXdy77ldZmVFN0SO+w0pBGLbcbI6ER0c1TrKWkZlVWKMZg3ynpOTE0goG8iw3myw1jKbzVgsFlRVJU5pRJ3nHFap4rPq7GKMaLiMWiV6D0UcsnOcnV9jDIWGlpRlRVWWVHUFGLq2ZdNuJISNJGLxVoS5xVEWlsPgBwWvdJFdCsNH/FzNMKiaS2UhIXXZwe37HhM81hj6ZDjpPMddTx8tphCW39APWAxl4Ri8ZGg0CmCgjl7Wwwjei3CxutveB+q6om07Si3X9LXedT11Xd0SpsqEyeNVM6MoSkKQLD95vMiOstgwDKOT6Zwbz8v3SqpVI6K/+f5yoRgDdV0LY8iYsRy5jtExKiDUhI0DYzhrdoDk2nINcwuLZQI+qBaM9KetePrtbXuOMSLofYvdhlU0Pp/JYuzb8uQySfNtWUAj603LIfUvqeXNKdbT7cxoP5i2QbbsEOZrTj/P595ap1KuaXmyWQUus/5THnfT46SttxpLafI8+bx8j6TMqQxqManxfK8Uo+qbbZlPTK6Zn3csQx7ruT0mdRBjBpXlGhn8MMaQooDCWSPMmcTNG1f5vre9lZPjQ5w11JWD6Dm/dw6boqSCDwFUON4aGHzPpTvu4I7ljMbCvKlp6oq6FO0ZP/TilCfRNHKFIxlhaghDMxEx9MPAoOGpGGET2jG8MBKCbGfIs8g8FmNi07YcHhzx9MGGaydr1n5g79JF7r3nPi5duETsAzdu3GTddhR1g5s12MLpfBEpq4q27QUoMEYylKlGUt91eBWg9t6z2bSE4On7TttCQPWEzL/ykzP3Sb+PKtx//vx5vvZrv5bf8eVfxo/+w3/Kxz/9IKGasXf/S6jP30WwNV2Qk3LIoDGOlDShyGT83/qe0u9kaP1nNZP7ZxJmY0I2B7CJEAcKJxsgaUi45Fkd3uAlL3kRv/t3fzNf81VvYP/mNX7sn/8oH//Yx4ghcnx0LMBJOCANG/Z2d/m23/UtfP3Xfi2PPvIo7//l9/PgQw+zf3Ao2dsUBFwsFtRNw+Hh4Rj63WtSBWMMy+WSu19wDxcvXeLuu++mKEpd48mcX5aSQCEzN6O+l6uqpOtkY0aGU55XLF0n68BN12Gtk0yAIeK9hH97H2jbDWVZEaNkSjQaElnVNUHfU8Y5QgxUpWzg+OCpipoYElUlG5AylvKGisgvJCTk+u3//B+dbpYzO7Mzew7YGVPpzM7seWCf/OhH5OVtDIvlkqA7U+KAW4rRic6L9EThCrq+p+86bt64ATDSvK119H2PD566rqkqcdatCm9KJpBanU7YbASMyplznLMCQKnzEUOk61t8CMyaOVUtAINoYYiYsPeBS3fcyd333gtWNJVudYeeaepPiKOYkAWQLhrtM36SHieAA7pTarK4szVK0TaSntom6qaiLIWpVZUlzjhcUZJwRFtg6obeFoSw4KHH9nn7z/4CP/Su9/BXfuRHecdHPsLPP/wInz5ecSUVHLgGv9ihqKw4AaVqH1iH8YEqwcwWzHBUEeY+sRjAHrecPHWdmw8/wcljT7N+8jqbq/sMN48p1gOlh9qKPhUJAaGc22bh2W44y3ObRFU4hpNDvvdN38HXfPkXsVM7ZmWB7z390DMMHb7vaFcrNm2Ly/ocfS8pg9XZTjHiCke7aYXh5D2bzYZ2s6FuGs00tmXhFIWEQs7mc2IIDF4YP0YBB5uZTcYACT8M4ogpeNP1ovPV9z37+/sM/UDbtlR1xWKxlD7qZEE7DD3r1ZqjwyMBg8pSQtq0/8t4SGw2G3VqC3wINE1DjIm6qqQuemEqtW07XiMpoOq9CJYPfY8xElYQMQwRkrVEBdkK1UGKIQirT+szKNsiM0RQZzz3e1c40TSJkr45hDCGxfX9oCKp5QhyeO+VgSSOmoQiCDA0DAKcmTGTnITAyY72FiCwNrNYMqtFQtPE6d+GuAnwIM5ZBp9SSpSlsJNKzVSUQy9SUtBQx63cYwswGU0CkMOjMogwBYRy+FQGImXcCnAlfeaZlq+Tn8/IzWGcC7eW68ZqGF0Yw/625yfNwCXPLqypDIIaBQyi/rssyxG4KVTrRJ77mbZ9XjGr4OH0qXIZpn/n5873HY/TcWMmzKzpsUnvkUGqfL/893ivEUjbbiJM73/a7JRRpM+Vj81lAQGOjB5TlsKqG+tetZtcURAUhN229a1AQ/73tG4ySG0NbDYr3vXOd9D3ncz6VvpsipHZbCYswZxhUlkzaHKAeVPhrOXc3p6wA/ueoe9GR7usK1xZyI+Td6Mxhq7v2bSttrswe6NmY01J2ZhJBkKMSHi69hWr78UYIp33+BBYb9YC0juHcyXnz1+gqhsefexxrIb7FmXBMHhhW4WtDprTLF4pyXyaWYN2wkicjsuYZHNFmjazjOT7DFwU1jGbzxj6gYODA1xR8l3f9Z382sd+ncOjI7rVmsViB+scgQTGCaiIIYWkY/xWu6Un5T+e2b2e1XL/Ov3zTEuEKO8dEBH1BGAjKXoqC0XXw6pl//IT/Ik/8V/y3/23f55z587x1/76X+fv/8N/yM3r11kfHXD9yUcowoa0vkH0HV/1hjfwd//OD+H9wE/8+E/w3ve9j099+jO0bUevGdvOX7hA3dQMmiRl6HvartO2KpQlVHBub49mNuPcuXM0zYwQRM+rGHXtpI/HmHSzQMacU4HtruuYz+dj6FnbtuM7C83ga7TehkE2CbPmUg4xXywWOudJ9l7vhVXezGYsFks2mw11Xct7wjjqShhMGRzPjF6bNT0VZH7LGVPpzM7sOWlnTKUzO7Pngf2Dv/5XqTWNa6nOSwiBTduOoRRRd2Lzzn7TNMpWus6nPvUp0Y7Q8JeyKDg6OuLg8HAEj4pCQKIQxVktihLvB4Z+YNN2hBBYLpecP39eMuVUpexqqRaL1Ux0d911D4udHaq6pG03rI5P6DpZdN37wgf4zje/GVOVCKx02owudrNfKNObRXfJUyJpBjiD7ngaYe/I0ZZANdFUiiQjLJbMXBJPKAspFxSulHA0U4EtuHa45sbxhkcuX+X9H/lVPv3gQ3zqN67x+FM38LOKdqfmwqtfSro0py0GEZf2koksJMkYYxOUyVBhKEKk9Ak7BGLb0x2v2axWpHWPWXf4fhAH0Ug4nk3CtrAaPmYNDCQpogJJshBUEO2URQIuDNx/fsFf+rN/nHvPl1xc1hRJQvrW6xUxtKxWK9qNhH2BZoSSGAZAQptQhkvfdWzaVthKwGazgZRY7uzQ1DXL5c7oVHd9jzUWHwKbzYaiKKg1K0xZSfrqGCPD0KtzJYK8ko57m90txkgzE+BqubMr+l1lSYqJru9Yr9esV2tiiswaSYmMsk2KohAdJ92tj6rzkx3rHBqWnajshFkFt5wTceoQA8EHHAKabIaAN442GigqfBKA1Q8DVSGZoyKMbA80RCBlEWl1OIsswp3EqcsL/wzsoGnat2CcMHZQLSRrjTgphQr263M4Da/K5lVnqq4bnNOwzolwcmYlTX8yMJKmTBVtjwz0yD3le+eshHNkQCADJblrJnT86Z+nQIjtF3m0C/AVNeQvl+N2DqRiInpNmTuMMgFkrthaPt8oICOOpoLVWXNLmVoCypnxmjFGiok4+nidzMCZMGvkOs9cliXVhMpz99Smbcbk2jm0OH/G6WtP/21kPs3ARX5+6csiUC6Oo4DDGWiQU2+t27HOFWgYrzO2rRwfJrpeIYjeDwosxRzWpvfPIYe5b+UyZpZXvsa0nbLl70HGdg7ddDaxf+PayFSyBqrSSXBYDCyaGU1VKis2gjJ1rNN7+5YX3vsCdhcLKmcpDSyaagxTxAmTNaZEHAYGDeO11o6gLUbYlSnJGPYhYHXuxBicivk7WxBSGlkmIURWbc/1w2NuHB9z/XhFOd/hjjtfwKULd3DPPfdw/fp1bty8yRACxayhLGuKopJQXg1pK6wThhCQksyr0jYSUjwMfkzc0Q+yyRSCbEolTUOf23IYBgH5rKFp6rH+7733Pr72676KF9x1D//zX/lfCNFhZ3ucv+8B7M55elszRIM1BXaU7BZLaft+nlo+4jZf3dakOzz70XkoCCAYCNFgC0cIA9YECgpMn9gcHnH/Cy7w5jd9K697/Zdx+foNfvzHfoKPfPDDOGNZHx+zPrgBcU1hehwDf/BNv4+v/bpv5urVG/zbf/NveOzRR7hx44bMhUVB3cw5Pllx/sIF/ODZbNaEGNls1sScIc1Jlj6r7N5z584xmy+4+wX30DQ1e3t7uqEgYH3fdwoSScbeoihoWwk/n87ReU6PCqIlkmQpdY71ekPXttr/ZHwJ6ATGWIwshCjLkr7vWSwWGGPG/iVrgETTzDDIO8ca0RPL85KMxy3gZYzhHT/2w9OmObMzO7PniJ0xlc7szJ4H9iu/9AvjCxtNI1tquJEs5Bl1MIzV8CIDVVmRUuTatav4QRazVp3nFMWBn81mlCrWnRcTdS0AFhqGEpVx0rUdZVHIjldOCZ8kLCsvZi9cuoOyKpjNGvqup91sZGcswbrt+JLXvmZ0rm51ZRidOHQRmR07yTIjQuFT/SQyfd7kMDYwJmAIAiLl1ax1eCxDsvhk8ViMm9P1BbgFB6vAv/2lD/Ij/+Jf8kM//BP8pf/1b/Pj7/63fPTTj/PkjQ1tKIhlRagqfOVY3HcXqXYYCxWGKkDhofQwB+bRsktB3XqGyze5/tlHOHnsaY4fe5r28nXi4TFu3VN6cDFhfKRIlrqoVARbFuMxidaTK3QXOEaIEvJgx4qa/hhwjrA+4tu+6av4ile9lN0SamfZbDZs1htOjo/Yv3qF9WpF23u6rqXvB4IXDaOh70X4OgTRXep61ps1Bjg8PKRt21HgXfpCRVSx281mo31Fwga6dsPQ9zhr8IOEQvZ9x6AMurYVra/NZsPJ8Yk4Pcqg8wpUZCZdWVagIrSHB4ccHBywXq+F8aZhNoUrhNERAn4YJMOh9vOYwaogLIa+63FWGRPKqDAgbAMV9M6Z6YwylwYf2Awe40rWXU9VNWOGKucExLIKKK3Xaw3T2zJGYozjzu+gDAJjrDi6CvRkFtIwDGOYQl3XWwBDAZaqqtQRlB3uDJTVdUPXdXrPbQY4O2GqCLiwDX0RgEGugTrx2XERk11uENDaGEscgREBK0Sv6Vb2i7h4co3s9KDAWJ6LRmBozEyVmUoS/iHlyHPBadsCFEbBpQxIpglYk+suRmn7DHwYZaWNDqneQ0C0oMKzwnSR4aVMpQlAlEM3873Qst7uJz9zVBB5akZujJkAVK7YtkGagGv539Y5AWsmTKVcvvyM0/MygJqPM3q/pM+27Qsq/qzlnPaFXN/5OreY/j0ymTLYpGXJn2c2RswsvokOUC6H0XMy0GSthKsmdYJFpwza9Zp3vfMd0ufV+Y5j+JeE8FhNGGBUoDpfL0aZt4qiYDGbMZ/NRBcmh6eaxLrbsOlaoo/aDy1FoaG+QT/D4r2844oy6wxJ//IhYpUluVqtBIhwUn5rodR07EMIrNatZJTUNt7Z2aUqS27u38Cp9mEWi89tYowZmcuFKyT8Vsdzrovcpvmdn3XrUh6hExBZrpfnC6jriitXrtAPHef3dnjTH/hO3vfzP0/fSVhdXde4osTHhMmMJb2++bzxbXL336pJ18qz9PTnmZYw2AJCGCidpfCQVmsOrz3Of/VHv5+/8Bf+LPOdPf7n//Wv8u73/BTXnnyCk+uXObr8BGZzSBFWVDbwmi/5In74n/5jkrP8o3/wT3jvL76XBx98UNoxRlA22Hy5w8l6NYaarTfy3rPOUip7V/qNbN7NZjMWyx3m8wUJYalKeLNszmWNMVmfidZSBpSEuRTHUOkQAlVVMwyDsEWttMHQD2TGrTEGH/yoh9c0DSH4kaEcdAzIvwP1bCbM2Rioq0rLlKiqWliCGuY83ZzJvw2GN7/p959ukjM7szN7DtgZU+nMzux5YP/ob/01UJBhZ7nEFcUori2OuMTMh+BJRjNb6UIs+MAHfuUDHB8dyuJBM3as12tWqxW1hutkB9W4gnPn9kgpjbuc65ONOLkaprBYzNk7t4dT4UfUGS7Kktd86ZdRNrLoXa9WCiwIW8Qn+H3f/d3cee89WCcZxKaWHSuUqUFmfSDYldVMVvIcmSaufJ2UgIRNAXD4BNiCgCVgoajBGq7dOOLylat84lMP8aGPfJyPf/w3+Oivf4xkLbZoqOdLKBuiKUiulB1PZ6BwxKamXVTc96VfQFclIoHCe0qfCK0n9p52/ybDpqU9OiauNlgfcSFgI7gx+kJZQUZ0MsTBy2E+iNjEWCGyo5jDjORz1R6SvUaYrN2NK4hHl/lf/p//Na998R1cWpQMfcfBwSHD4FkfH3By8xoYw5AUDNGsf4Bm+pNQj81mIwtSH9i0G9q2JQbJplaWJTs7O7ILq06i954wCFAVgziopWog5cVsduZiCIQoabuDgizZKbVWjl0sFiwWC2azuWbQGTg8OuTw8JDj4xPqumY2a9jd3aMqS2E9eD/WRWYbGST0MYMm681GjxAAxQBNM5N61FAyPwijoygLnGYIOml7TD0j2AJXL/BJymowoNexCs4WheizmAkjAwWLChVK9SqE7ZxjGDxFkcNUtmFacQxXEgaTOH+WECQUDnX0syNuEHCVSbiRmQAR2YGUXeg81rbC0/leZjIOjQK8aaLHZJU5kssUlfmX+6mcLwXJ2MPp5YrVLJZW2VfTcqQJUJMd6O11xU5fDx0ReV7ZPo9+otfO142CEmjY3a2gBhNQKgYBHqf3z8dZbd+YwZoRXLqVKXXacttOnyeXM2nZc5mz5fubCdsq11f+PF8nP3vK98jnaT1my6Fy03PQ8uV7TOtsamP/1P6d7z+t9/z3WO5pXzXCKHMaKoqOx3xto3Wc7y9gnzBOnXMYAgc3r/N9b3srR4f7lIUTnZgkekHOiM5ZVRQs5zNMSvihpywKUgw4Z0jBc25nwV3nz3Npb4e6LEjR431P27ckK6L6la0xCPMoafhcCNuQQXlWwxACKeuSpQQI8yPojwDFuX9LHzxuB26erHni2k2ONz17Fy5x6Y67ufuuuzh/7hz7+/s8+MjDzBZL5ssdAYvrGcMg6eadhh8NQ69gr4J4Qd7fEj4VJlnhRJMxBK+gqtRXULaZSTD4gbIUECSliA8tX/yFX8g3fO3X43vP/+fv/D2CqajP3cHF+17KUC3wriZgsVE2uaQKsubYOCuf+r3t389mUrfPHE2ZfZpD3Jz2mRAlm5+Lge7kkDsv7vI9b/1uXv87XsfNG9d55zvfxS/8/HspHRztX6M9PoBhg0kDjsBb/uB381Vf8zUcHB7xL3/2X/O5hx7m8Ma+zKcKThdlSdU0LJdLrt24QUyiR+g1A6m1jkKTC+QNgwwqnTt3nvlc3ml33XUXYNjb2xtZskXhJIRyoocmbZTncAFvyIku1PIc3HvP6mQl4NIwYLOAe66fIEk3isJROAea3TMDXKvNhrquCCHSNA0+eGySzcjMVPJBdBgLZSrKK1DG7k+9/Z+NZTqzMzuz546dMZXO7MyeB/b+X/g/SIg+wOAlPt4otb6qawp1ZEPwEvMeBMQBaGYzVicn7O/flEWLlQxafd/TdZ1cJ7OgDNR1w3wxH53OlBLWqNCyhsht2o3qPJT4YaDve0IM3Hvfvdx9z70Mg4Qn5B3Ruqrp+h4fAxcuXeSue14w0XbZ/ohzI05I0vJn58EQRQ9JF5fGGKymmHdFKWFHRUkyFls2YGtS0dAOjtXgeP+HPsH/9rd/mP/tb/9D/vbf+2f84gc+zmefvMl+G6jP34Fb7FLtnsOUNaZqwDicccybBoqALS3BRNys4u577yb5HtoN/bWbHD76JAePPc3m8nXMtSPSwYqqDcyjoQ5QG0dlZbfcWifhF04yzRm7zaok60R1AMf/kPZWwEnaaXusOJ7bpXkMkUXh+a5v+ybu3muYW4PvB9q24+jokL5dE/tetIJUvNp7cU6MMZRVxXq9JkVl53Q9xyfHoiESFPxR8GlnZ4cYI13Xqa5WR9K/kzqGrihYLpYAWGdZrzd4zbiWYmS9kb/zQ/QqOn/h/Hlh4xnLfD6nU9bb/s19Dg8OcNayt7vLYjGnriphPGR6f0oCgMVADOKEppQknHMQnabNZiNOQmaCGcNmvabve9brNV0vYJe1lr5rAfAxMYTIfGcPV1XEpGwQravCOsLUwdexFULYsgk0DC5MBKitipVn52HqhIcMUKkjnp3quq4ZBhnn+djMvMljP99PQna2oJDcR7pRdlS8D6o5JuMyt0kGunK5vPdjiEaeh6yyT+Q70WETMEA7pY7XW38EJBPGzpYtND32dBlzXaJjYWpyDvLdqeuQJDw19/GQ2S+TlPb5+nHC5swOWw6XysdNrx1CwEyArwyCSFG2zwuM989mbxfepw9ttP/IHCnXnwIsmWmU2zQfN73++Pfk2NPHmEkZcn/JbZ3vVei987lmwvTJ18iWtIzTn+nn5Dk913fYAlf5OyZ1M/23zP4TUCxF+q7lp3/yJxn6Tvt4Hg/q6CbJ/Fg38p4kigPtgzjZAEM/CAsoh4n5Xt5FVt4t1hYUVrTNQozyrnEFWIvXfi5Ab5SZuihGh74fcoixsAuNsvystTSqPTgynoylGwaOjo+p6poYAjs7O6qnFTk5OdG6AGcdfhhGJlLWNLJWsnZltmfuGzIM8iBTNt+kP4xtkGSuiDmkSjdzqsJx7dpVZvMZr3jly/n6r/ta/v1730voPTEkZsuFZk81WL1+BuGGwWto9e3s1EA+Zaf789ScAp8g4yap3lYKPX69YVE4/qs/8of4y3/5z2MLz1/+K/8j7/6Zn+HRRx7h5vXLnDz9BLbdkIYWaz1vfet387f/zt+gDz0/9hM/wc/+7M/xmU8/RL/x+KFnd3d3LG4WYT8+ORm18wCcAnGFk401p6wyo0CTJDWZs7Ozy3K5lH7QbDN2FvouajTc23sBBPM8ntuzKATc3zJU5X0w6Lxd1bWOAwEIrd1uqhSFE03ESjTFYhS2aYyJru9ZLJb0w0DTNFK1ynit65qgyUzy2DbGUCkAZTWM+21v+S5toTM7szN7LtkZU+nMzux5YP/gb/xVyACPOjzz+RyrYrFVXTEMA13fCZV+GEQXwohDcOP6dT70oQ+yWp1QlxVVVdMPPfs3b8r5lQBEw+Cpm4a9vT1IsiBv2052RBGafdu1GrYUNR3tjJQiu7s7fOEXfREvuOde4sisiaIZ5ANt29H5wAMvfxlv/NbfpZLbz9z9zs9I3v0HTOwwJomYaohgCjCFpLuPEKI4ANFYrh6tePKpKzz6+NN87qEnePDhJ3jv+z/MwUmLLWeU9QzjCpIrGEBTHidiEu0lawwYi4mGwpVEH/EF4uBFqOYN5W7D/tENkt9Q9gPOS1iaiYY6FqDi4iZJumrjJPV0AkkJbSQ6j1FHZmvibJ/67NSBI5FpXG/LPxKAsezaE/7qf/df88q7dljaxGa9Yf9gn2vXrrI+OYRBdYysYRgE7GiahqaZCXPEWbq+Y6MC3f2g7B8FC4pSKPyZeYTukoYQWB0fkx37ZjZj1jSUVTUuQP0wUJTCUsvApnVOHUABLS5dvMRiudAyNYQQWK/X3Lhxg+PjY4Z+YHd3l8VyQVVWzOazkT0TVRg+RclIhS6i0fsJMCv9eDafjzoSUZlWG2Ux1XUtYXCkcfe5CxHKGYvzF+mjwVWykC+cHTPy5dCl3DhGw/GyA5ud96gi0TnTnAj+ypiRsZ5BJHHyMqCSf8eYhVflmOw0uiwwrrvcIYgWUpywgMwErELHXAZ5oopkT5cWcq6CQFOwZQIM53tPQZ9p2T6fcxhV52kc+wqMybUlJETON7mX32J51x62Ea9Ty/fO17SZVWOlfPJZZhQoIyC3lY69XPp8rdxnMtMn16uRhpjcXfpCmgJN+vu2JujCLeNqWy9iuR1/q5bvd7tzcnmn4FLuO0lBhnQK5LmdTds3H2f0WdOEtZU/G+sk19ep88fvJvfWoaETZ6IoDAc3r/OD3/e9HB7cpHAqup7vJS2DIbFUfSVnZHPGaChd4SyFBZMCL7jjInXhWC5mI+DjvYQJWbOF+GNKxJDwQXTgiiKHjSaMhslKVkEVitb+nR91NpvhMHRDpyC9xSfDjeMTrh8dc/nmAcEW7O2e4/57X8gDL3wR+0cHXL16nZP1muXeOcqqpihF9yiDGmN9x4gfBOBdr9dYJ+Gcg4YXhxBo21YywiVhmiVlKyVJsYf3XrKCgmR4rUuSkZDyL3vd63jjN30Tn/jYJ/mJn/gp+ljQ3HE35+69n97WJDPTeavE2QLvowCCRubTW8fws4yDU33qduM+syJz/wgxYvzA/RfO8aY3fztf9mWv4onHH+Onf/pf8ivv/wBVkbh+7TH85hCipw4J1/a85W1v4bVf9qXcPNrnF9/3S3zik59idbxi6CPLxQ5DNxB8z/nz5zlZb2i7niGDobq5Y530U2H8bOcIp+u1oqhwzrFcLtnb22M+n9M0Dcvlzhi+PM4pKtKdNLOaMaL1VxQFfS/gUx4yQUNapf1kohq8ZJszCHN2s15Lfen/U07MMHkXZLmDlCJ10wjrynuqsgR9h9WawRR9P3ZdR9M09L2w2oZeNpze/a4f1RY6szM7s+eSnTGVzuzMngf2yGc+TYyaPUrDZfq+J6VEWRQUZUmhoWg5O5azwumJqlvx5JNPiiZSWarmkuwqjSyIifM4XyxGRzyEwGK5pKwk81aMEeNk97vre05WJxwfH/PAAw9w1913sbu7BwYJAVKRVqtOZoiR3nte9+W/QxZAz7DsTG29uJQkfXMyJcnWdN4QqAm2Ibia487x5I0Tfvpf/Tz/w//7r/Pn/spf4x/96Lt430d+g088+DiPXr6JqeYU9QxTliRj6IYe5xJlEcG3FCZQmkjyLSaFUZsDYwhESAPGD5QhYbqBzf4+RTdQ9ZE6WEywpOiIxoGJmMKBc0RSVncaQ/hAYtVMknA4q/8el8/ZSVXwKQNImMnPKZO1d3YoAvPC8y1f/waWJbgQuHL5CtevXuHg8AYnx8d0naSa7vpOGDLqmLTthqEfGAbP0eEhm/WGRKLtRKg9qC6IsIAkRbL3nvV6zcnJCSfHx0TVe8jgSj8MrFYnBBWKNciu+3q1ZvCewQ/EIOClD569vT2Kshh3cf3g2d/f5/HHH+fxxx7j+OSEohRdL4xh8MKUy4BQ8IHNZj3u1A+aVvvk+Jj1eq1aTKKJYZ3DDwIwxSiZb3oVlc87xNZYTZVtQIHLsplhVTulKESDKapuU26QvPjOzp58LL8zUGCUzVBVleogZeaJjLOiKKhrWchnIEc6gOxMxyCaME5DXTKgZIyElRkVWw0aZie71cLoMmOIW3bapZzZQcvfifMiwI6I/25DMqZlMkaEXLMwee6oJjN9bmuTEDIAzdQodZBZU1I+AO9FTyYDVfkat/w7//OUmQmIsXVEt45pvk4GqPJQReeg/Hmul3zN3M65jMZIuA/qxGWHDyasoAySZICLbZhaBkLHPjK5NpPr3focW/ZSOgXQTM/L18nnZ8v/3ra5gDa571pNHX76nPG5Jufn+0xBqUKFgI2CbqLlIv3QOTeCF8WE7cUkWUAIQbJ5TRhdUk+RdrPmXe96B227gZgoFeARk/5ggBCDhr1FSue0cSSjadIEAW3fsdjZ0XYD4dwYTNJsmNouPkSG4Eemae89m35g00tCA2HyWbquJ3gBcKzqoFVVje97Bj8wRHHgC1cQ+h5rJNQumcR6syGECEnuf/78Hve84AU8+eSTtF2HcyVFWRCTtJeMSQT8SqKh45QdJNqK235jNCQrrylyq+bv8hhHN3ZEMF42cWKMPPrIw+wsl7z2S7+Uatbw2Qc/h+87nDUsZnMGIyHRTd0wDJEUJ6CwQd6GkmVjcvdn2rS/yUvy1h/nHImogLCl7Tb8jtd9Mf/4h/5H2nbDH/9jf5Jf/+gneOTBh7j2+MNsDq5hujWEjhRa3vbWt/AX/uJf5NrN6/zcz/0bfuY9/zuPP/I4RJkb2q7jwqWLrNo1kFhtNrR9T9u2pIkwtdXwXZk/pN8aBZiccxRFyWKxZHd3j6ZpmM1mVFVF08yo62o7LkZQXgEiHYvee8js9JHlV7DZrBUM2oYpy9pQ9JUwMnfEqOGBmjnOWglh65WpntlO8/kcgNV6jTHCMBdB7kThHF3bUekGUVDNxVJlGGRciDbaW998xlQ6szN7LtoZqHRmZ/Y8sE997KPMZ3MSQkXPTv3W8ZIFtysKrJOUzUap4SaHNK1WXL16RVPBC105JmH/GF24hygCtMvlQp03cWx2d/cIuisrlh0OWfiVVcVLXvoSzp8/hzGWqqplgWstwQdSiMKAKQrWbcdLX/4yqrpRkGVrBvGHQtg6asZabLkkmJrjTeDp60d89Dce5F/9H7/MP/6xd/NPfvyn+X/9tR/i53/5V9lfR2Z7d7DcuUSiIkZHDEmAkrZlWJ8wbI5xqSf5DcmvGdaHFMOaYljzgr0F913Y5Y6dObE9plsdYH1LMgmHwaZEihJi5ZwleI+NYJIDU5CwOCtln9bnVlhcdh1R/SRMEtBIHzwvvMePpkvu23yYv5O1txE3NkZid8Q3fe1XcGl3Rup6To4O2b95nRvXr5JSou+3qYpjjARtZ3HoYbNZ0/cDXSdMpZigbVvaTTsCOEwYBF5Du9pWdBpQkGEYBg3RkBAUay3eD6QE682aFCOrtaTTFkdSROLLoiCp4O/+wT7Xr1/nySefZLPZYJWlN5vPR+e172UHPqXE8ZFoR+XasVa0RtpNy3qzpldB+aYWlp08gwBKx8fHrFdr+r6T+lDRccmC2NP5QB8ii909QpLsbdkhSCnhjBUgUDu2sN6kHGni1OdzogLEMUZxqMnhR9A09Qhs5fq0VkRV5ZkkfXgORcjgVlmVo/CqMWYUnJb7b/XP0lh2O47jXMb8nTxG0tAer2wLqS8mYUwZynEqECzPKeebidaG9O+t5TnMqOaH3FvmuG37bdlQGWzLNo6XPB5MRoNub0lBDqNMJaMMKKlbyeS3ZVZN2lGBslz+/DvXV647ub844vm4aZjatl4nTCitpLFuJqye6Xdje+nnRvtXnLRZ/vftbFrmbKJ7MwGmNN346efKdXaLnZq8x/Jru07badrOIOfm+SBoyKRRYDs/ZwaUcr25wgFSTpKKfDtH1675yXe9E4v0odwHT1tKMHQ9TVWTVNSf/MzIKSEG0Y9xjsIq8yIg76/gpV2VfRc0rG7wgbbvJZRY68x7mfvzGJw1MxbzOTFG2k0rdYshGEM/eExM1IWTfmZhSIEhRo6PVwyDAO5NI9ktL126g7bv2bQt1m03lJKCcTnBgWQbExA2jFkLc9/WPqWcmjSpZwCT+/14HPQ+UBSSGY8QuXHjOuvNhm/8nb+Tp65c5urly3QnJxjjcDsXSFGYW9INJv3bIHeUATCC27f7ucVuQ0Gc9uXMMu7aNR/54Hv54X/0wxQpcvmxhzm8+gR1GkjdGnzPt37zN/On/9T/ndlszo/9xNt5/698gKeevowfAs46+k42W1772tews7vksccexage3uADrixlLjWqM+Qs1iLzoPYRAOck0UROhpKZt/P5nLIUMKksq1FDyai4uoy/7bxnxrlfxpTM31GvIfpeOSxUEjdIqD0GvB9GHbA8rkOIdF1LVVaQFDwywuQFKKqKqirBSJinMbKOqzPjWP+TsGDR7UwTpurb3vLdY7uc2Zmd2XPHzsLfzuzMngf2cz/1dlnQDAPWWrpWBDeDhrAURUHhCqq6xDjZzfJBRJANQEx07Yaf+umfFLq1c5gorJOExRXClAjes5jPOKdskaQ6RUUhO1n9IOFKMcru63q9FrApRl7/+q/g0qVLzOcLFsslg++FndJ1NFXFer0hWcfByQnf+u3fzotf+jKShr8JG0cldp0jJkPwiU3bcXyy4jOPXuXt7/xp/umP/ChDhHMX76JZ7OKqGX0wRFMQorB0KoIwN4aBg5s3MCnwqi/6Ar7iy1/Ly17yAPffdzf333cPOOiGjvXRIeujQ2wItKsTrl65wtFqha1rfv03PsGHfvVXOSl22ISClApcOaNPnrIqiD5gQsImizGyiAt+Q6HaBV6BO6NOBCAZceRxb1kom6Rg0pS1pH8Hq+DT1E4fl//wnuHoSf7m//TnePHFOdXQcvPqFZ584lEJf/Ce1UkvO5xGdLiKQhwsVFS27bpRmLgfegYfRDtEQ4WMtZRFwWw+x+juadZryCCSs4UKHAtzY7GUY1MSkKLX7DSDsoLKqqSZzzi3d05C6+qarm25dv06V69cIQQRC18ul1y4cHFcrPd9T4iRoZexEXxgsVgIWJOBLA0JPTk+xlrHcrmgKAvOnTuHU+d16Hv29/fxXnbvm6bB5YxLXsra+kgqau5/6cvxpsAWkoGNhIQJaOp21FGzEzHmlHWK1GEW7TNlaihbKQMrWeRctDCy0yVhZ07ZSLLj/Ey9FKshO2g4TtbrMBNHPUapdwmfE1AJzezGRB8IxAGNyiYS0HEr6op0GYxmecvhgtsyS7nzdcXM2FdzX4hjdjpucaKS6mDlMm3P0bE0CRXNz4ACLreYkQaJGTBRNmfSEF+SAkBO2D5TUAhEU8RM/s6/mTDRpt/p7UgTRz1b7gvyjAqSTO81+dsgoVZJwWkBBrb3TJOsdrkMp+832gSsypaf1VkrIIiKTk+vn8s5tdvd45bn13Ot6holfQbtqNJtJnV4yzPrubkMKIPJBy+iz2bbf+qqYP/GVb7/e95KU5dcv3YVayzWCntDry6TaEyYFJnXNXuLBSkGkg8aWmpJRIxJGJM4t9xhZzajKUqKBIvZjCF0WNW78SHQ9gMhBkJMuEJChNCMqwbwGgq0WCzG95E1hqosWZ2sMECxWMo7L3hcirR9x8F6xVHXcdx5bh6tODraMJvt8IL77uPe++6jKApCjDz99BVsVWOLiqLSe3pJ+W4x+CDju+v6cYNoUM2olJIC8SLa3fedhgYLp9YogMKkj3TRYFKkskZCx5qSCxcv8EVf8mq+4Ru/kX/8D/8xn/z4pwh2RnX/F3Luwh34YDBWkl7E3O4kTI79NkbXANu+kNts0jvkl9mClPlbZw3BD5ptLmENlCYQVte5/vQTpNUhpIHKJFII/P7f//v4wR/4QT77uc/yzre/k6euXuXazRvSFs5ysH+TGAKvfc1ruHjHRT7wgQ9weHyEMYYwBMqyxliLD8IytQrWlIXDbSc1irrGqKC1hLnNKIuSvXN7CswbdnaWOGUxpSShzLIZInNG3phD2eJJN2+sNXKOMmuHYaCqJfubyWHNZUXbtbJeVIacV7Zf1HGYRc0FRJZNsLoWZlLXdzTNjBgjwQuYOmsaBt24saqhl2UXnLKY8nz0nnf987GtzuzMzuy5Y2eg0pmd2fPA/vd3/XOcK3Th4IgK1pgs+mmcLggSuEhRzuiHQOFKfNfjuw0mRX711z7Kg489Qtk0xM0xYRhI1S6uOQfJkLoNZdhgU89ybxfKivnuORyygMnMCVmI5hTxEtbwqld9MXt751gud1gud3DWEIOn7VsRBveeISaOj9e8/JVfwNd83Tdgq4poIJDY9IEbRys++/DjfPbhp/nYbzzI05f3efLyDT7z8KPM5nPRHcBgLCREQ2EYBhIwn83YmxW8eM9x4fwer3jZy3jta17Nffe+gPO7S2Z1gbOJ5HtiikTfEn0HURdWmuFp3XYcHR/Rdj1PX7nCw488wr/4uV/msf0OX+0SbANJsuSAIZgCk6DUPHODLpInPpPaMz54ls9uZ7/VaT6B7/GHT/OX/vQf4Xe84l5cd8SVp5/k2rXr7B8csel6/OBFHNYYrJFQEoMwbQY/MPheNThUcF2ZZt57MIZCd8jrZibaXcogCTFC4ShtCUMieQGV9i7sUc3KUTB0s24hWU7alhA9RVXSzBuWO0t2d5ai6dH3HO0fcPP6DU5OjiUFclFw7vx59s6do3Cy89sNA+2mxav4snOV7P5OshKu1iesT7aZDhfzOVVTMVvOiCmxOjlhdbJivVpTFiXNbMZisdDFfoXvWyKRde+xzZwXvfwLWJ6/xGojO7sxREoNIy1yivQMAKiekplo8KCOelTdirw7nV/nRVFMhFslTXgObytUkDyDUNkBd07Sh4vlNPBb1hyAMRKmIfcSodsQJXxEvhcWRgZ2shmka2WHYst8uNVSEqQzgwZ5dfLMsbD9PmqaawFYnsloytewqn80ZQ09+/JHxl/akgZu+bd8oM+fgTJ1lHI7GAV00PJMy4Q+a/4s/87n5RudPsboSJ4en79LKYuWT+CQqBnekDEaJ+yf24FJ07bJAOQIEGWtlqSZ7E6VN6WtflK+ZoxbXZbxWT5vpd5q03OMhvbFCUB5uk5NPkfHRtIQVWO2/SSRQ6jAEjk+uMkPfu/b2FvOWK+OGHpPNwhTyFpHiElCeEwSDRkiy8WcpiqhbymNsOGEgSd14Czcef4cpbNc0t8mQtd39CEQDUR1xMHgbIFVVlpKkWgiVVHgXCFh6dZikiEM8v40QOkKvKvoQsAPPUTRYYpJAMRV33Hz+IQbBwccrVpY3sM9d9/Fi++7i915zf7NA564co16uYet5qSUmDU1XbuRMDpX4IOnqmtCSGw2a2HNJjSrayAlT9uuISZWq2P6roPcT7PGUhT2akqW3g9jaHhZOIiBF9x9F294/VfwJa95NX/zb/5Nnrx8g1DsceHeF1LtXKC3Db6Y46NsrDigiAFLIhiDN0ZbfmoKEmUAKiWsKwgx4aPwq6y1WALGd9Q2UoQWvznmZP8K/f4TBJ0L77zjTt7w+q/kW77lW1hv1nzgAx/kwx/+EO2m42R1wmw24/j4GGsMd919N3t7u1y9fo0rV64p+1XmCYyEsxmdu2WjaMvWRf9dlCVl1bBcilbfbCbrllJ1CI0xAjKV0j+CjyKy7WVjIUVh5XkvGW5X69UYclYUokW4Xq8FZDeic1kUBUlD4DI7vdN1Vwh+lEzwPmtv2VGfLCbRSER1/PKGQd4osJpx0TqZE0IUNlc254Q9m3Q8zOcz3vVj/3T8/szO7MyeO3YGKp3ZmT0P7L3/9mfo+56265nVM4IyEYw6T5u1Zt3qW0wBu7vnMK6SnccUCX3H0HccHh3x737xl3BVzfHJCaasKebn6WPJY488wnr/Gq966b1Yv6IqLfPlggt33kVhC4IPmp44jOLOQdMUhxB48YtfxO7uOfb2zrFYLKgqyQYlsf2SannwkU3XM18s+bY/8Gb2154nnrzCZx96nL/79/8JH/rob9As9jh/6S6Sc2AtyUgGsaHvcSbRtStWh/tUDl71ha/ga77y9bzogft44b0v4MUvvJc79uakFIjBE4Nn6DtSHAhDR/A9pbMEL1lzYohY4yhdIeAKwjjq/YArCzZdx/Ub1/nEE/v85M/9Eu/90Meh3oFRXwIiAsgURAwBfwuodHqxvLU0/u+03Q6Quu2Bz2KW4egqf/jN387v+qovwa5v0B3vc/XpJ7l8+QpHR0d0nVDtrREWUVlIimARa+8JQQCiDEakGAh+YFAQw2qbNE1NWVayIAUJEXHCukpDorAlOztLlns7VLOKwXthKPnI0PcMQ491lqquqZqKZjbDqjbPerXm6PCI1cmJZJ5LieVyycWLF5nNZhRlBcawWq2JyhhICWL07CwXWGXsBD+wXq+IMYpArnUsFnMREZ/NOTw6ZH9/nxAifdszm81YLJcSyomRevC9CJcPAVPP+IJXvYZ6uccQDWUh4SUZ/chOfXacC9WMySCSZLITJliuY6ehQSmJNpNzjnLCXBqGgaThpBIGIZnaBhXjPQ3GSFEkhEJCGqTNykp2xTOQIudI2FdRFHpsvkYWiRWUKE3BMX3G2/XKhGgohRCFAaL3Ob1Uyc+bgQdx6sXTuaX/J4QVNXm+z29mHC9mAkDczkoF6jPQYa2EfzkNW8qgagabpjaWezI68zNt2+HWfztrRyZQbvMRyNHrJAWHphaVYVUoo9BqmEm+nzUy/swoursFk/K9cr9E2SdpAt7kY5j033yuUVAJZcLkaxeTjITTMscJ8JUd7jTJUJfrOp+HljtfK5chl4exTiBGRNg+SOh1YWF9fMj3f89bubA7J0VP1/UcHa8krMwYolQM1hnC0AtzMkV2lgtmzuAm4KfT9nAWSmO48+IFlosZs7oiDpIAwGrShbbrwWp2s96TQhS9QmcpldGUx2Y/DApiupFx6qxlCLBeixZU01Q4I89nnCUYy9FqxfWDA24cHPH4Qculi3fywH33cc/dd9HM56w2Gz7xmc+xc/4C4CjLivlsxmoljMzcXhjDMPQ0TcNm02q/tIQ40G42Mga85/jkiBgkiUOKAuYIcAhdv52LisJRlQUpeIrCcv/99/HAC+/njW98I3/mz/55QiygXnLHA6/ALS4y2DkDloiwIq1mcxWGkXCXwIzJLNDxIGF48tMHATOyZpuJHhs9LvaYfsX66AarK08BA4UR1sy3f/t38J3f+Qe4ceMm73j723n8iSe4cvkyVV0hSULk2i9/+cs5d+4cn/zkp7h+44YWQN5DhbK8CifAi9F3ptF+m8F95xxVVTGbzahnc9nkUwApxshisQAVPa/rWsaBkTZzhWMYhjE5RGb/xBSpqpoYg2x4VCLmPfQDs9lsZLKSoB+EaVZVlbCLh150B4FhUHBMQ0NjlIy+CQgpUJaFZAosnIS5NY2WwWo4nWjqbdoNO8slXddRFKVsRuiYGQZPXdf0fc+//Mmf0FY8szM7s+eSnYFKZ3ZmzwP7pX/zM7ooR3avViuaphFWf0yakjgRomfTrpkvdzCukFCe6Il+oOs61puOj3z0Yzz65GX2u0BvZ/Sp4PrBmvXxEY0ZeMV9F5jFNTa1vOQlD9DMGgpbE4M4o5mthOoq9b2IkV664w7OnTvH+QsXWS4WNLNmDF3pug6sxYfIuu2wruADn3mKX3voKp/5zMNs1oGyXFBVc6HJm0jbndB2J1y4uMed58+xXMy59wV386oveiVf9tpX88C9d7Mzr5nXBYUFayKOhPc9xgjMEWMgDAPedwxdS/CeYegEcIqyUK6rmqZuIEFdKk0cEUyNKbFuNzx92PHwU9f4Fz/9s3z4Nx4kFnOCrUhG9YPGXVUR5t46xs/u0abxf89i6rCKfb4Dt5aAZApMv+Ll95znz/zR76Vsb7L/1EPceOoxDvdv0nUdbdvLDqQfxh3YlBJk5gYiyhyUtZJ3NEPwo66DK5yAO267yx9igELCoGy0OFex2NmlrCuC+A34YSCFSOh7DOKcSqiZsJ+6rqdrO46Oj1mtN3J8ilQq3r27u0upwrM+RPpBNJ6Mkd3jWVMKCKbZedqNXMM5R93UIkLvCubzOet1y+HRoWqUichv3TTs7O6yu7s7hga1m5WEimAJtuA1X/566sUu0VZSPylBBunUQc6W2zC3YAaKUKfeafhb4RxBnfspu2kYBspKM/BE6dNFISF5VoW3M2MpKfMnhyJyKlQKtqCHABFbgCM7+1NHP5vBEL1ozaBO/vT76WcS5iJlyQwoTl0v/53SNoRu8s0IKk2XN+IUbcMJf+t2O5BWrNAQu6Ai9BnomQIsZgKqTC2lW1k+hokQdwaL0lYTyRoBKK21I0MqFywpKJPbXdpyG0ZoJ8yebb3dyhjKQFNuwynwk4/JZZFib8s9nV1y+c1tmEqnLV9j+vzTz3Ofut05p81MADGj/TYzm+QcYQUlRAsrpYRJgc3xEd/3PW9hb9FQFiJgfPXaddq209A0EfRPJKL3OAto1rcLOwtMijKehgFnLc4Y2RaIgeV8xu5yzs5iwbxuSCrQ7cN2fjHWUhUVpQKRKQpYkuvMB4+PkbIqR0DRx0Df99hkaaqawjqcQdgrVpJohJTYDD03Dw+5cXDIY/sndEPizjtfwPkLl3jRi1/C4ckRh8eHrDcdVT3HmALrHFVdsdlsRuBa+rOCmiFK2F6QMhgLbduRQqDtJCNc13Yyl0cBfYyBtvcYZYzFGCmdpapK3U6IvOiBB3jDG17Pi170Iv763/hbXD9Yk8pd7nrhK6A+T29KvLVEqVwwiTJGXETBpMlbVLu1QfstKNNM6pYUsKEjtiesD2/QHlyDfg3Rc+HiHm94/Zfzjd/4TXRdz6/92q/xwQ9+kPV6zfHxMc466rrBOsdqdUKMgbvuupsbN64LUIhoFBVVhTWGoixFD1JD2PPYyOPSOkdZFJRVyWK+oGlmGAWYUkrs7e3hNGS5qRtQTav5fEHf99RVIyBNWcirhCThikFYa1ZF8jOjNYM/XjcWg2ZrDT6L3kvyFQmPFiBo1tT4IOHrcp6lcCUhRspaGfBoggHVZnPOiWaklfuDZAVFw/FAgEnvPaVmEM7g1XvecRb+dmZn9ly0M6HuMzuz54F98mO/jh88Xd8xm89BFzRVVVNWFUZTjtdNDcbgozis1lmMhaHvCClRlDXnLt7Nxz/1WX79oStcXRkOOsPJ4EiuJiZD4RzLuezO3nXXnbqz60QfY/RNZHdX1nuyW+WcpSwrZgtJlVtUlToriZRERDwk8SBjTPzr93+cTzx+iCuXNPM9rC0IQ8/x/jW64+t8+7d8Pf/lD7yZ73/z7+UPv+X38n3f9W182+/8Kl77yhdy3x27nJs5Knrwa0zsSENHvzlh2KwI3YbYt7QnR7SrE1ZHR6yOj+k3a/p2Q9d2bNYCJHgVce67nvV6pc6cZrrKO+YpUVp45ctews2bN3nyynWSq4i2GMEkcTC37I3fDFT6ze3ZneHPZxFxmk6O9nn1F38hi8pyeP0y66Ob9KvjMTTLACl4DEm0KYZBdu1jwBmDSQlnZD93CANenZEUk2RCSkl26TV9fQ6ZS3HAKhhTFE4cQ2vpB8mWNAyi3RVTACOAaIyJzaalXbeEQbK1bTYdwyCOZGETdekonSx6w9DTbtZ4ZeBF7ymswcQIwdNtNrSbDf2mJQwDFsNisZCFMwaTYOgHyXC32dC1slsfQmA+n7NYLjl37hxd1zEEz9H+Pl3XEmIiRHjhi19KPZszBGVhFJqBJ8RRN8l7Pzrs2VFPWVBb2SkZALDKqrKawSsmdSwUGEAz5omZkUXknKPremKUHeoM4kRltuRrGA1htMocKsuSwfsxE9wUgDCnQIf87+nv8d8Z2MjHAWgZ8r1Pn5ctX9+M88oWzJC/Tx+ffz/zWqdt9EMnh8p5+QNhX5kJAJiBpAyC5HbRPz7vfdMU4FHL9WOMut0T0M7nMTipu7Eu9Xpucu9cN2N/UV2fXF/T/jU9N/e9W8LdpsfHrVZT7jP5mcfjEOAkxihMG80iGKKw3UzO2pbrYfI7h8nk6+a6zn9Pf6eUqLP2S9Kwm1tAskBKCrBpPy2sxfued73j7dRVQWGNsB7LmtXJifRpHStyjrC0iqKQrJODZ9Y04qg7JxnmSIRhoLBOsrblLF8J1us1w5DbDsniVVY440hxq61mFDyW8D0BuxOSEbXte/qhxxUFs7LCkajLgnldQYqkGKiLgrIQwMkiekDWGbquY3//kJAMrqq4cPEid999F9euXJb07vVM9HZgzAprrZVsnFH080SguaSqJGTKaUitVQbiuJWRxxASHsgtou65r8g7qu96jo6OaJqGdn3Ct/2uN/LeX/wlQj+wXrfs7OyOWcQkOUUiGrCaX0/AJP3REMexHEbWFwUBlwYqE6A74fDq46yefhR/fB2GNaWNfOs3fxN/+k/937j3/hfy7ne/h1/8hV/k4x/7OBud39Gw4OVyh8JJWLFzjsPDwxGYt1bqAyPaRcYaULBF9LqEpVvoTzXqJjUsFguWywWuqCjLUjN3JgrVpUQ3ipyCTm3bjeHGZVkyqGamUzZqUJA5A0uFK7CqEViWJdaIEHjfS0i/Uc2ulGTtEpNohn3lV34VJyfHbDYbQDKDBh8wVjYtYDsXyDwnQDu3zIfCaNx+fisA32rWQ4C3vukPSNud2Zmd2XPKzkClMzuz54E9+JlP0PUiuCkvd1lgo9lCZPdJFnxlVVOUkimmqkuss9RNTd3MGHxiiJbjdcenHz9gY3YIpgE7IyaHNY6+benWa/ZU38YaJ7o5GYjQ+6COh675ZPFUldSzZtQ/slYWMFUzI4SEKRxYw6ZtuXw48InPPM6sdrzk/ku87IE7eP3rXsaf/GNv43/4c3+c7/g/fTVf8vJ7edGde+y5lhktdeoo6WDYYGJPDJoCvpfsX0PfY/vA+viEoetpNx2bkzWH+4cMvaddd7SbAT8EYkx0vTjkJiWGQbShhsETfBB9mpRYHR/jN2tivyYNLRcvXuAjH/8UG28kDI6E1RC/ZDKl/rSPOf0je8vP7qRubQos/ebnGcClSFUYiAMnxwfcdXGPg+uXWR/u4/uekAx9NPRBWFUBCEkEpkOUrDLWGlL0WCM7w6LzYSicpXCWUn8solOS4oA1CWvEOYxBBD5TDAxe2E0+RPquo2tb6WNdR0BCWfwQ6XvReeq7nm7TMvQSopiIWCSrnbAYJJtfCJ52vcH3HWHoGboOUhRNlW4gBMlGNwwejMOHRPAiqhti4vjomNXJMX3Xj1VbliXLnYWEybmCbhBnqduIIL33kWgdL3zRi7FlTZiIPwcfRqaS1cV5dtiN6vPYnLUtO+mTECgmO+BmEg6Unfu8eBem2DZbmmTnEUc9l8UYcSTzbjagWeGCamSIwP8IZI2Og/bb3NXyzjzbz5xzI0CVLWUQYnJOCNKP8rWfaXKj02wmeV6mhdDvLGnCfjKnQJxsGdAgH5PkVrkep7+jAhjTes/n5TbiWZhKTO51uiw5HC0P3ttde1rNRo/Px9kJCMREyyrmcNQJOAlbhpTLTCm99vj3pHx28tnIilKtr2ndjP/W6zNhveW+nC1OziE/Ry7F6bqZnHfL8cpUmpbBjQyp7fXFeRZQxxDp25Z3vfMdLGc1zhkBUwpHMsLSME7eQSgIhc5RGbQyQFXXW/0sNMQtyD27vpex0vf6Tq2pqwrnCpwRsCmmiMWMoUtSPxJ21ntP33caRivjb940EjpsDU1VUJWS/a50hroSgNoqGFRYmWuzM997z7rviUbABxthOV+QQpJNEdV7EuFn0elp2w1VIYkTyrLAWg1VVjZY0rBbYZ5I2JP0i23/loSl0jZWQZas+SXAtxwbg+elL34hX/zFX8RnPvMZum7DanXM3t6OCKGPrW+BgmhKgnFE40jGEbH63TZphSFSxRWxPeLo2lMcXX6UeLJPYQZ2FxXf9PVfzQ9879u48447eN/73su7fvLdPPrIoxweHRKTgqERAbATrFarMclIZrShmdhy6KsxFqv/BnBGwMWyLKmriqqqqDWT22KxoG4aDX907OzuCru2ktDwEPyopzT4gbIQRm5VSQa4vGGXgdvMIpvP50TNNpvD7Lxm/4whkhDB9aqucNZJ+JqyyatKQjFnsxmvfvWrsdby5JNPEqOAt0Y3wGwh86qbsBqtNRp2lzcZpA6s1l9V1xjdHCTPRzlLXAi87c3fpW18Zmd2Zs8lOwOVzuzMngf2yOc+TVWVzGaSQSsLLlprabuWoiyYL+S7oqzYPbfHhYuXWC5l5+zihQvMZnOqega2JCbHL/3yhxi87JISvWgUpAHHQLs64ML5HfZ2l7IAAWFCuGLMaGatAE0Y4en0/UBRlZRNLeKUdQ26M7jetBRlhbEOYy3L5ZLzexf4utd/Of/XH3gTf+itv5ff/3u+jjd+/Zfz4vsvsZwVFE7ywiR1qkKCPkQFKcSBDsNAHDp815J8B2FgvdrQ9x2r1ZqT4xWr1Yqu69hsWmHKeAlvszm9fZC6jFFYJsMw4PuedrNhdXzMyfExm9Uh+BaiZ7FYksoZn/jMQ2BlZy7GSCRhxyxqt5qsS2Vhlsb/bT/7zS0v7vlNzklE349luHlzn1aF1Ne9ZxMsrZnR2wVdMcNXc0K1JFRzQjkjFg2DLQmuJLmSaAuCk5AKp1R/q9ncrO7gSxdQhzJBHwqMEQfGWujblhglpMD3PXHwmOBF6ysFfD+IY+aDhGlu1vIMccARKIwCds4RMfgg6cj7IdAPHh8TEUTAHtj0HZ0f6PyAT14AM802ZApLiIF1u6HrWvquFQZSEH2t3d0dFosls/kM7wduXL/BwcEBq5Nj2vUaH6UfvuRlr6CqZ8RkZMfWbgVMUw57UpDKKGCQ2SI2A01GWIH9MIw7xDK2VS9NwQU01bqxkqpcPps69dv+ZhSQiTGzWIQtFtWhVQ9tdHScE2cwgzhyzaxDZMZrZyc838PoZ9n5z0dHLad01G0/zWCVOCmy856ZNlszY//OQML28y1gke+Zr/lslkMy5Tx5FplLxGkyRkCAfO1pfaP3uZ3lctgMDE3aO7et16yc2Smz6oSDAkBR+vStzy9mjdSfUbAmO/HTOpDnv7Xdb7ERgLlVy2gsewa9siOr4u+5vvJP0OfIYTAml23SFtMQqzDRQsqhlWaiSTUtfz5/WvbMBMlhgPl68q6T8lgVErbKmOm7DT/5rncyryusMzgNjZs1DevNRsOFhHkiHWak2GKMjCkJp819U/qF9BfpM10/bDdYVJesLCoJJ4uR6CWpweB7YeMWjj54Vps1fScaRoV1OBLzumZRN9iYKEqLK6TfWwfGyfvUGAFxvO8ZwoC1hlnTSMZIPCftWhJ1JMu8WbC3c46ydNzYvyYgvJP2zO9up0BsofpvMSbJUmcl5NZay9BLiLD0N6nzmLXijIQcGh1XRkMEozJXEonCOcqq5smnnqKsKu665wW86tVfzK+8/33E0HF8fEBTFdRFSWkd1uv84ZywoZFwRpsGijRQ2UAZWxrrMf2K4ysPcfT0o4TNMfQnlCbwDV/zlfz5/8d/w5133sW//Nl/xS9/4IN86CMfZd22tF1HTIn5YsHe3h4nqxVBM+D1w4AfBrwy4ZxzOH3PGSy2cGNW0KhzX1FWuKJkPl9QlhW7e3vUdcNiZweMvAeWO7tShyDh0zncVdlgIJkky6rCGHk/rNcbyrKkH3rt0wJqCjtJwL4Qwig8PpvN8N6PbOGhH8YwucwedM4QNcTyJS99KS960YtYLhY89tgTbDYtIWznglxeYwx1rSCXsvTqulagV8Ls0HnDDwPWOZqmHrXzMnuRxBmodGZn9hy1M02lMzuz54H9/L96t2gBNI06CNmJceOCJQF1VbGzuysLWyvinCkGqsKJXoApiaZm00c+/tnH+PTDT/DQo49z9cYh682Gdn1C6E7w632+4CX38ZL776YuoCkK1U9Qp9eIA5CzhARdwCx3d7jj7ju56867OLd3nrKQ3dy9c+eEvVSVYEX3wrgZxtSUpcW6QMJjTGLoO7l2FPBsGAIRyQQUvZdMI8GPGXOcQRx+L4vvTTuwWW8IMeIHL4vIThbMvWrrFEWBKyxNXZMmmir90I9irSSE2RMCJg4YRGi82LnAYyeG/++P/wxP7LeYohGGjzqMvzmopDoy8s3kqM9n2QniNzlHdoJ9CBTOYNJAEXvOzQrmhcGmRO8jvU/4FEkmURaOWV2yaCqa0jGrCgqTqKyhdBbnDDYGbJLwEWOYBCckCdlQECAlQ4oFJg7Y1GFTL2KrtiBGw+ADpIizCWsTPgXKoiIMkl3OWQk1lIxDAWMEmIq2Ihqh/otPKCAgtzAkRAsialZAcY4EuHFWdEbKsmToJWMhKeH7QUEGS9PMuHTnnZw/f55o4OjoiMPDI45PTghdK7v8sznVzh7f/G3fQbNzjj5KRquEpkxX5tLUiU5Js3rpv2OU7FtBf2dwpa6qsX9OnfO+74UpMwp1S6icPN8UBJG2SbrrbpQ9aNXJFuaQ6Gzk47Njns/NQIy1tzKlYhA2n3Vu1AYS52WrtZMzdcWk9IJTJocl7b/bugHpT/kc+UzKv/1byia/t8eM4+IZ5+un42fyuXMKmiF9iKSBNhMgZXv+9FridGVHLP9OE7aGOGNbICvXx/R3vv5YwlzAyb2cHpsLnwGWW9ta63ysGx2PUjnjfTLDaAqihEkI2lhmfYYM4KDnGmXM5ed6Njvd3Eadz3xu1gub2vR5mWiNpSRzWGZD5WsYIwCPsErkPBMDJ0f7/MD3vo2LewsKZ2hqyaAVUyImePzJpxgGLxnbYhQRbQR4tYhQtyWxs1yMYb8mRWzuUhFIkZ15w/m9PaqyZDGfCzMpSMKBGAJFKYxBnyLeSEbIGDylc9RlibOWWVVJeFySa1IKKccgrJyUpC/HEBj8gLFGmUUOYypunBzx1M0bPH7tBlf315zbu4u9vTt48YteQjMvWHcrrly/DnZGIjFrBBxvmhneyzzTdq2yiB19P9APPVVV4vuB4EUvqm03eD9IMoW+F1aTApxRBpNsCsSgYJQkAdjZ2WG9XjOb1bzuda/lgRfeh7WWd/3UT3Hl6gGYmmb3DuaLS8zmewxFiXcC5FljcBaSH7AE+s0Jvl3TrU/YbFbY4QQTReD7jd/0DXzj130NKUY+9OEP86sf/TUOjle0XY8PAedgsVjQ96LpaIyVNUGQrIAGyY4nIXnbhBUZMMtAm3Nu3Dybz+YUZUFVVVRVzXK5wGv4XNM0MLIAoWlEpDtbUZR0XSdrKAVrU0pYK9ncyrIcw5uHwdPU9cgajjGKFhNIiLaGoLvbvBPyu8UVlhAkvPmNb3wji+UCP3g+85nP8qu/+lHJOhcETE664RF1DpDyOtEMS2kU8baqC1XonF/VNZv1mqDJJySsXsD+d7/9n43PfmZndmbPHTsDlc7szJ4H9u//3b+mrArNxOGYz4WVNKhAcYyJqqq4eOkidVNxcHgsbI6+py4LYhgoXMkQEq6eM0RDCAIsYJ2ADDHJIrNvGdpjKhOZV5ZCV7vOKQvHaIiBigFnBkvhHLPFXBbJxkIS6KEuK0JIuEJWz1F1HAwlKVlluiRikvTFPgwkzeQlAIIhZIc8eAmrCpKtxvcdqBPUtQIsbfqerm1FzLxu2Gw2DN6PDr+IQjvJeKZhg1VVc3xyLGKTfSf6QtbSrjcMXY/vN5SFZb5cUi12aavz/NCPvYdff/QavZ1JvWpoWDzlPG1NHdHfRlApAclIe4QwiF4SidKJc5pCxGAlcx0QTZKsd0ay6ZgUiL7HxoAjURXCMmiqUsIwCqH/l66gLGWnsrCaPUz1HpyHxnpit0+VNrjkMckSYm6qiEkeED2nhMFHg3UVPko/C0nAJ4MwFCQAbhqmJSCjkQ4CCKBnjKHvp0wf0e2oyhJjIAR1nAYRz7VWypxSYu/cHhcu3sFsNmOz2bB/cMDBwQHrzZraCeuknC1YXLjEN/+e76CYLRmS7GpLNj1h84VJhqw0YZpkBzn/HSZZtlCnuiw1RC2HM2Un32xDnOR7YYxNmRzy74JhkHCdoCyTDDAISCRhQ2gYXVFMBZgzCCO73NlBSjkFfdSQIdWomT5fBtFiBlDG/nprVi9hQEiKcvlsu3yZOmH5uvL5Vudj+/2IuUxMGVQj80qEvadLpO01FUzRHft0Czi5tem5+bvp7zzW8/m5XvLv6Wf5+re7Jggoh4Z85WtM+8ko4j0FnG6p2wmgNXmefK2goV65H+W+F1UwfFqu3H/ytfP1TluMccxumDVhCtXnSfo9WrbRJqBaLnNUptPptsqfyTNIu4v4tjJqiKyODgRU2l1QFIa6Krf3T3Cy3vD05cuYLPqtM2iMoh+UAZ5ZXbGzmJO8xxptD2W1ifZP4OL588xnM0prsQkJtzYy7xvNkBUVWLLGUpUFdVlRVwWVczgU9EsCyvRpEGC/rKjKCj94NpsN3nvmizl1XWnqeUffR1o/8NT16zx+5Ro3TzqOV5GiXnLPPfdz6Y4L7OzNuXz1KtdvyLtsubvD4D2zZk5RSvjU4AdllgnjCt0Y8sOgGzOW1eqEEILoOLYtIQx0Q0+MSeZewBpGZoz3HmsMu3t7dJ0k4nAu8ZpXfzEPvPA+HnjRA/zdv/v3uHrlJqQSUyzAVNQ7SygLFamWWT70LX27JnQbUhhIocdZMCnyute9jj/1J/8kTz75OJ/65Cf52Mc+zqc+81lsUeEjbLqeCxcucHJ0g+Vyh5OTFagWVu5vVtcrRhYq0h9y31aQScB42Whomhpr5b3XNA27uztjprOiKLDKIDUGEek2Mn8C41qj6zq8l3NkTnAUhSS4iFHWAzIuhVGaFHTvewmRc87Rd7LB1TTNGAKXFBQP2pcB6rqiHzpC8HzBF7yS173udaKtZCwnqzU/85734FyJ96KhNNVmGzTU01rRAev7DuecbPjoZkdROEhQVhWFPlveTJPNlcTPvOtMqPvMzuy5aGeg0pmd2fPAfuXn/60CBbLgmDWzcQFkjOi03PWCF2CsZD/btANJQR1DInnJLoW14BypqDBRwBnJcmYIyRASiHhCxKZI5SQLji1rASx0uikLidfP1PAQZdFinME6IJkRVCqsCA1b3frNC6ZoHN4nLAZjkjKQAoWzpOhJSYROSTBoiFrIVPAgu3UhRLq2xWtacO8HhmHD6uQEPwx0raQWzk5vreLB8/mCfhgoyooYg1LQJf1z27bC6GlbDLA6PmZ1fExVS1hhM1vgdi/xrn/3Af7Nhz7FutzDJ4M1UFpxZJ5pE+eR315QqY8C+qUkqYBjTISUMLoramJSMEc34REWSoqin1RWohMl6ZwFvEk47UsZMJNrgLBwrJbNAvMEl3YcX/7FLyScXMENK2yEFBIhQCRiTcQSST6QbIG3FYMt8KYg2oKYlKkAGGtwRLKqTYzCAEgxgyLSF3LftFGBvRRx6vAVzggzIEZAMul4P5CsOBplWXLx4kV2dnY4OZEsQYeHh9LPUqJUZlE1XzLbO8/v/N2/h2K2JFoRX5UwClmYW82Okxf9siiXzD3xFKgk+hkSnmMVJI6jOLeY1XtnDSOjekUSriN9Yerwp5RG8Mh7DV8KAj4LUyfrMkmbTYGD7fkZZBCgySCdy0wYOBnZsadEo2/HVJJD5VoSejFhxYwm38eYnlGupM59LqOUT886PRx0eBntO+j9t2Moz5vCDhlPS9m524JLp5dXMvy234+giRRYr7FlCOX2n4I/JgsiZ0Ax6ZygNgWHyBnoFJzK9oxyTa4NCLA5httsmVICJmyZcNP6dzls7RQwNS3LaUuT+T9fV9p5y4DiFBvq1AXkHvqnUYZSvm9+TuekP6ckDrTVsjqTBFT6nrdycW9J4aAq9TvVTksYbh4c8PSVK5Q5DA5JUpCQMCObIo7IfFZTFQXu9JiKAsyHYeCOixcprWVe1aI1aAzOWIyVsDGRnRHdmrqqpN2ivNdMSpLNMmpompXXbYyJfpCMcoUrWSwXwhC1Ot+lwBAj3RA4WbfsH624edLx5PV9jjYD5y7cwcVLd3DvvfeKrlPwPH35CnXTMJvNwVgiRudVCbOzxtF3rfZBAQNSDHR9C4iAc991eE1g0HUbhiCZX5OOkxRlPeJVR2rWNLpxYDAmYkzkgRfexyte+XJe8bKXc/36DT7+8U/w0IMPc/PmoYwZhFWNgpsGKJwl+J6d+YxXffEX8opXvJwv+MIvput7fuUDH+Chhx5hCJ79mweiyRcjxhbs7p0jpcjN61dANa5GVqWONxlH27FkjIT2WSObLWjIsHOS3XQ2m2OLgqauQNmdOzs7ChwZ1S7KwtqRuqok05+Oeaei3JvNZgyzbNtOwRlJYJKihLwFL2Fuop0pc0ff98JMKuQdjM5rOQuc0XBh6wT4DzEwDC2XLl3kG7/pG6m0LDIGE489/gQf+JUPygalK3CFE91BoKpkozCPvWGQZBNWn8H7AaO6Sej8J5uKVpiwRp7np37in4z1e2ZndmbPHTvTVDqzM3se2OMPfo4QA7P5fNxFRrOTxJg4d/78+NLvh46gGbWM0YV+DsHJWhQGHFAXJc4YChCaflVRuoK6qKiKkqooBfQpRAvJ5kw4Tn6DLKBjjMJcMhCSLDqtsVgcJhmclbCYEAIhBdEfih4bO5Jf40zAGA/Jk6JkBhtC/okQBlLwE6ZSIPgBkqSJ7ttO9HpCpF23IsQd8kIZhm7A6n5zYQq6TYcfZIEcU5JrpqjZfQY2qxO6TUv0slPbdS0hidh0WZZUzYwBywd//ZOEapeIVXlRcWLUpZ38PJt9vu+eaeLnfP5zEobCJGwK2ORJRGEJJfnOErXuRVzWKnhTOCf9KRkihpAsAUuwBQkLxhGNFfEPK6KqCSuOXoIQwYfEkBzrzYp777lEaXrqwtC3LW3b0fU9Xd/S+17p+o4+WYaiwZcLHr52yNPHHVdOBq6eDFw7CVxbeW6sBm5uAgc9HA1GfrzjyDvWqaI1DZ2d0ZoaW81JVQPVHOoZsawJRU0sG2JZ0yVLlww4R+WEibWzs8NsNqNtW06OT7h5/YboRhijYsdSgVXdUNQNL3nFKynrmYCwE0aMgArZ2ZZ2yqyJ7KROnfU4pvtWNocCEtZa6qoe9TQyoBBCpO877ERjJ4eFJUUz+74fARjFOtQ5F7AJZfKI7pKcm6+XHaHshEh5hXVhFFDKgIlVYCyXzxhxRHO5bgV9hOEgTpboOGUAYmr5XNRhyWBUDtmbHKm/FShiG/6WLV9aHLEtMLW951YnKltmYZ0u19Tyd9P6moJI45lJsgIKeLgFBGOQOpS+kkatmhFAscKgyNeLUZy1EdTTfmYUgJmCWDYDUpPy5M/yc+X7xKhsvwx+TvrUFBzK/fV2Nq2L/Dtff9t/bgWOsiXNQpjvZSfsN6cMJacMWNmIYOxTMcm4sUDftaKp1NQa7poZjSpEjqGZzThZrej7nkId9kTEmOyUC9s1BE9VCIska9aAOM3WyJjp2o7FfIFVTbTCSUhUqdkXy6JgZzajKQtKJ3qFQ9/R9ZKcwBWW+XxGUZcQA8kHwuAhJhbzBbs7OxSaZU+AcHnXRRuF4WJK5s0uIQkjqg09q24tmfEo2N3ZZbNeEWLg6OhYdJQU3Jsvlqw2a61Hq2sGYVultM3sJSCezH25j1ur2wpRIFDpktJ3M3gbVIMp+DCGbJ0cr3jiiSepq5qmKrn/vhfwO7/pa/jGb/xq4rBh2KxoV0cYorCB5w1veMMb+EM/+IN8/w98P6985Ssw1vIrH/ww7/337+fjn/gk67bHR2FXxyR9y1rDeiWhcsF7hq4jIiwwA5KFz8gaIPdtq3Nt4QqKUtqwqkqWyyXz+YJmNqduZtRNTakSAFUlCUiaphnnkxhlvTWbNdRNwzD0WCtgTZ4nm6bBe0/TzKQfFgX90MsGgSDLBA2jtCoKHlULr6wkbLuqKjbtRoCqWphnZSkZ6mLQhBrAzu6S17/+DSyWCwwi2h507bKYLxiGwNHRkYZby4aGtZbBSya4oR8IXoBPCSeUsdz3g44XYTMWRQFJNi9STNTNjBQTb3nT79dRfmZndmbPJTtjKp3ZmT0P7IM//+8kpj0JmFTXNUlFRi9cvMiFCxc4Pj5mGDr6XlKfGxzWFrKbGAPOyq6ZK0XXyGiaGOcszlpJr1tWRN3hMygZKkVwFjST09TpilGc55zuNibJ1mV0BxgMxEnMvmYSw4JNkQIk20whIRQi+lgQYlTGjyxgUhxIMTL0gyxgkmTZ6VXzKAxexbhFpDtGzWYDImhqZGdv6LZimPPFnMH3GGtxpdNsMF4ylK3XSsWXtNNrH3GFoy4dFy/s4eY7nNgl/9MP/TM2s7tYewFl6rIg+CjP/Sw2shL0+Z5pt/tMnefbfTWxhKAIJkVS2u4yRuNISZhlIoaqYSBGMhTJueK06RJ3dAKTbiRn51y+0PJIC413J4HHUccVL7lU87qX3kEzHDKcHJJ8z9DLolUcSINxc9amoKuXPHTtkCdvnJDcjJisOAs2gTPgA1YdYKMOqTirWkDEobXGUJlEYQ1F4WjqkqYsKZ3FDz3B98yamr3dHXYqyzKtMCSWS3ESjw73WR0dkYJod2QnMTseVd1APeMbvvU7cPNdkis1BE8AR6wj+GEMbRgd6ok+jJRZGjOldIuQtrGWGCWMLZ8n5wobKDsa2SmS8wW4iFGuhTKljGokoaCvVUA4O+7TpUMOS5NrPrOfSV/JoVjiXGb9DLQ9ojLHRHslAw25/FIXMr4z2KCOqdZRfp7Tdro8tx6XQQ8pn3y+BUHyufJ3rvjtPV0G5LT8+fpWAT4ycCRfjN/n31PAL5crfz6C7pPnP/2M+Vr5XvnY/Hlu6+mxUYHIHLZ2+lr5Gqj+Tb73FEDKfSaXZSyrspoy0JMU2JkCPykJkIXZstZyPeR+9mzlz9/n++Z75Pvk4733lIXozOR6E6BUntXHIGxZk1ipptKlc0ucSdS1sC2k4QVUAlhvWp548kltH53/rGQyNCapPp+hKhyLpsEYyfgl7EYoSieEmr6nLix3XbpEVVh25nNKBZaMMZTOYZGQsBADUQWvjTPMZjPK0jH0PW27kXegcczmc5rZXMKhNBGGD3K+NQbjLAMDJIfFMXg4aTuevnmTp27e5OkbB9hyzsWLd3HHHXdz8dJFdnaWPPi5z3F8csLe+Yu4eoZPhoSARX4YSEhyitmsYeiHsS2GQbKixhAYBk/XtaTgGYaBTt+5cQy5lXb3wUuf09AxYyU7XVEUWCdaVfN5wwtfeC91XbJcLHjh/fdTlyVegVbnChY7OyyXO+zv7/Pwww9x5fJlrl27ziOPPg5W1xUKkHVdp+93AcW8FzBEhrVsZoG8C7xKBYg+VR6zYAsBLgVQqnGqkVTXtTJ0alCwtyor7Y/yPsxAYu7bIQSqqh5ZoUaBdmfl/glhsxUaRh6jaAmWhYSOZrbRoGGImaEk40PKnOs+z2shaOibht3NZjO+6qtez3333UcIgWHIWYPzvCjM9l/9yK/y8COPMng/ZnpD54+UZA2Qx7LBjOLv4yA0gvKGGCkn4dY+BH7mnT8ix5zZmZ3Zc8rOQKUzO7PngX3oF/6dpHF1klXGFQVFVTFfLJg1wrDou05AlKGDyYIgeE8/DKMGQN7Vz4sro844Sj2XKcVMnDG1yc6esDD0u2eQBNIt4RwgujbiYOZDJOwNXcBEdXTF2QZnnWg/eC+LJSTjV9dJOJsfBkjQDz1917NpJctP0Aw8MUb6vqfdtMIU0XNiEPBLGF4SHtYPPb3vBTgx0LcbTo6OhSDvA33b0pkZVeXYmTnmjWX3rntZFbv883/1Pj7y4GV6W4MtMclQGFnIfn57tml7Uq//0TZWsv6eXu/0fZ/tXqePkwVttmkfueVzDN5VlH7Nblrxhlfew8WyhfaAyka6zRqixZoSWy448jDMd/nww0+y70t6MyPFEpskU1p0kWADNllserayiuVvTURLIj82SZCfRQR4RSPIsKwML7trhwvn9rAm0a2PSb7j/HJGe3KAJeCMsrhKEamvyoI2GL759/1BZhfu4njdUtuENYnBB6KrcXbrmGXHITvt2WlOqu+V034LiJTZOeJ4hBB0h1nCLKb6RzHK9YtC0jiPjnhZID6/OAiitSZskOwsONWHyvfLf6O7/XKcXEPmEAG6xLFXbR5teGslXXsuW34+mVu2oVsp5XA3YUKIE5adHHFEjYrO5r4ldrof8ox+t10BKW/iWbqJVfaH4iGklCRl+W3ALDPRNgIBW8wELLllXkQKkXRciBOmH586Nn+f5ySj4YIZuBkBoAwM6Tn5c5c1hoKEQ06PTRPgSNpFWAxy/JZNFjTTZX7GpJo4TllBUetCAAMnzzMByqQ/5jZU7adJCGTeoMghx7l+x99y8qSvZD0Wabp8f314ee9oHaYkQvyuKIg+UJeOg5tX+b/8n3+Ai7tLDJ66qkCIXQoeZMDScHh0zNOXL0OSseEKd0sfMzrTNVVFUxYUxmCIAjy5kqYqSKHH92vO7+5wYW+HveWSWVVTFqUwZIaeEAZ8iNR1M+rs1GXF4Hvadq1hvdBUJY2CF9nZ7/qeoqykPKOgv6PzPSYJ89EVjhDh+sEhT1/f5/rxmpsnLZQ1d959H3fedS8Xz+9ycrRPTIknn76Cm+1SNgswVvaIVGg7P721ksHVuZwIQFiPg9cNHQ0zD/oeHlSPUCtawis1S9mgoutFUVKWEipfVTUxycaQAOeO2azCqqbUfD5judyhaRqGYeD69evcuHFj7GM+JMmUaUTY+sL585ysJLtrVMZx7i+5z1ojDGsBRQSkketJeJsrHGUlZayqiqIUPS5hIVmKUkLbrDHMm7n0P80MaK0wvXrVPcrlbJoZXSdrEHTOb+qGfhiAJABT8KMuZtd1xCgh2bu7e5wcH49js65rDg8PWS6XxLRlgeZ6LpyGSRs4OT7hgQce4Cu/8g3MVCg8b+bltV1UQDnGSNd1PPTQw3zwwx+hKisNiZZkDCEEjJUEF+haMeq8keeIHP6HssH6vlMgOJ0JdZ/ZmT1H7Sz87czO7HlgTz32iNLOE8mI47RpW+bzBVZFXEeARjOGyALoVgfCmKymk50ddZLGO6mDZWSheIsDlx2qyTI8KRMBXc/l+2dnZ/pD3GZKCurUhkEckaEfxMnNGVB60UhKUXZth+Dp+k7uE2WR3w8SQuVc1vsR1hMG1u1mZG54r2FuuqAMwTP4nm7wDDFxsl7TbTYMfcfxwT7tao3ve1lQD55125LCAH1LaQKFNZTzJd7NOOoNv/Hg42BqyqLBWhGx/M0t1/3pn/zdfw6bXvP0Z7f7bmqnj7v1WOk7Y5eYfkPEYpKEM8bQc+eddwjYFAx9tAy2oTMVXTFnZRZ88omrXNsEWkqirTFp257GJDAJo/pcvxVLjJJe479xhmStZIDSMdTheOww8ODlIx6+eshTN0946toBrU9UsyVlPcOHRMLimh1ss6SPCVvPeeClr4SiEn0SlJViC3ov2ilZsDiPP2tVc2Jkc2TmRQYETrM6hGGUHQinukyoYw2S/jn38axTZKYhWZqePYQsXC6Z80T/Yuv0C5ghzrUASJnFJmCQhK3ZLRAzZogT0CMzrfLf8jy3DgI5dwuq5DGSgatcF/KZMLPsJORtWjdM5qRpOVKSULLbWb43+lz5ZxqWNv3u9L+f7Zg8t00Bp5TEMRv/PakPO2FA6cUwkzbLNt5Lf6ZmJnN41izK9TpeX++V3wNyzrYO7CQULp8njFMFBhVIZRImxwREmra3kY43/jtmYG0CBoUgjBtrRVsp33usmwzs6fF5k2O85rR+JllHjUn0XctPv+sdzJsKw5bRMT1fP6AoSkAyoFljZG6Y/gCQJMFFJRnbII2hm5KRUlgrvTrRuS7btqVtN6LlVgggMJ/NxLEPgb7vGPqOsnTUdUXdVCoCLfXZdb2whZ2jLAQY6zWzXAZ/iqJgPmtwdhuKWriCwXuSdWOCit4Hmroa2ZPrTUdRyr1mTcOgQIgxRvXWhL3lnGQ6k34hwBsKvBoNkY5RwCjpZzqWpJZkXGtfk74n8w0gIMQIvkp9+14ys65Waw4Pj7lxY59rV69zc3+f1YmE9KUEBssQPDFI0gKUObTZtLRdS9I+7absKCPPkttHWlY2rKqqYjab0TQzirJksViyXO5QFiVFUVHXNWUl2UJTlDnPTrLBJQVnZOw4zTK3BeOdle/qqhZ2kuolZfCpKisM0mfqusZo0oUYA1VZCQBGkoxxdSXaSfoMnTKvq7LCGHmvVFXNq1/9ar7kS17DYrHETsXi2IYnGmNGRllRFNx5513cf/8LWZ2s6DrZjDSI1iKjnpsdmWvZ8nwQgse5QkOunbSDMbzlTd85HntmZ3Zmzx07A5XO7MyeB/bUY49SVZXsIqng6qU77mDv3DnJbjZI6lzvPUY1DWTRLcLBRqngBtFeMdkxSrIclKXElkk0rq/VtgtzOTzJ6ml01vKCUpwsBZXiiDQRFRzK/5ZoA3FevKai9cqmyJ9tNq3qjYgTgKZa7tqOMGFeDP3AyfHxKHJprCyCrGoEGAwrDW2Thb/8DN6zaVuGoafbbOg2HSlEuk1H33cEP9C3G2IcCF2LiQN931FUNb2pCeUS75Z86Nc/zRANhcvU+NO19x9q/6nn/3bYM8t0+8c0YCQzmU+BVbvheL1huXeB5Gb0NAzlgk3R8MRRz6cev8lxKtiYisGUFOUMgmhTWQWUkhmVO07f7LaWbBpBJYxmY4oJHyPRGLCiDeUpGCiJtiBg8caRXMPBquPK4Zr9daS3c458ybXjnqdvHpKKmnK+w8u/8FUk43DWUjoz9r1kLCTRrhDAU0LnwGg4hIRpkPt9dnZuYXSIEyTOvQIFQF3XI/PHqMMprILMKNkyV8TZkTGdgSJ0dz1bdhIymyo7k9kJMxNgJ3+WUgLEIfFeQuGyYymMK83KNQV69BkzMGCMhMsaBXWCli0fl68RNQOkMZzSPtqCSts629bTBJuYmALbWlb03KiC5UmBlMyScVaYctnhz8ef/j0FSPJnBmk79Fmmz20UJCwKCfHN524d+e3faP3ZSZ2O7YtYvm8+PtdpP2j4zCngJpd9Wl6p662gtrNbTadeMzvlNOK5PopCMoHeUs7cb3JYoArPZ6BCnNCtQHlSQHMMxZsAR26aTXCi61NoCvS+70V0OyV83/Kud7yd5byBlCQhhY7/DEQbY0R02FqaWcNm08o708gcMZqCn4Ur6NqOshK9GmtFZDsq8IJEjtP3Us9931OVJYv5jNmsZmdngTPbjGqkhDOWuq5o6opZU1OVoocYY6LrehForipcUeC9l40Wa6mbmvl8ISG1yObM0IuT7zTT53KxFP2bYeDg4JBkLGVRsdzZY7GzC9bRtRvazVoyfJWliIJrFteUIkVRqqZO7lNbUKapJRzQB2EOS5iuAjxbjFigPp2fUK2qDH45Bc8Twpwjqd5h70mqu1i4EmsLYoQQRChariPNlNcW/TDQtS39IFk3M5sIBHC1RkEYBTaNEQFpZy1lWUk7NA3zxYKqquXf8xlo9jQpvWhmoXOkAI1ybp7fU4K2FQFuEcSW0GWnwFPQDHpFWWCsoaxKVuuVjEntehkgziCftQJAlVUlIXFa15vNBmNEy6nX9p/N5rzoRS/mq7/6q7nnnnv02KA6ZJlhaeTdMM5nsg4rSxGyb5oZ991/H3feeSebzYb1ZiOaSiGwWC5FnkDBtK5rhYU66kTN6LtOQF55GFJKvO3N36U94szO7MyeS3YW/nZmZ/Y8sF97//skbXNdEVOiamouXLxE3w+ijZASfdvpjqrqGuQdQ80YV5WSmjZnQ8mLA4M4kBmEIi/GJ+Fv2XkQ7EgdknyM/t6aZGzbLjW3IsJm4mimIALA3g+iFzV4WaxPhCu9H0jAoNmr2s1GtZdk19IPg2TM8kHOjUHC2Qah2EfNDte2LUPXyWI8JdBMcSF4uc8QiD5I+ELfQfIYRFcn+J6+l93Asq6gbCjP3UVb7PHppw9530c/zUBJVc/EERr3+f5j7ZbK/I+w3/orYepPfX4Th+A3u3bCiBaSSRjjsamniB0zk7i4s4NN0MfI8WbD2kMqlnhjaGMkWUdhC4oALknoWiISbOJ0+N3ns3hqlzbp7ml2SIyyOWLMYJX0B5PAGSPaKlZSjafoxdmxEfyaIvZcPLfkj/3RP8LFc3tE32MRcMXHBK4ietlJzuLdmU2X0lbQ26qDxWQ8xCghSn6SKS7viqM7/UXO6DVmlcshU1vgIynYO2X/yOdyv5x5TACPHMIgfWE7lqVeZPxnkGQLUMQxpE/KnZlVU5NnyveffBaEyZGBFwEMhK0UVeNNAKXtOMr31avcej0FHKyxI9Px2WxaHyQFj/SzW76bAkK5jFNmTq7TCVMoW24Dow5iLl/KYNBtBl1K2/k6H5vn3Pwd+qzksmk75mOYnHvaptdmOgdPy53bPm2ZQ/ndYNWJvOW5NAQvAz/jdUGzIW77OnrvkVmqz3IadBPW3JZtdbu6ijFqxqyIs3B08xr/xR/6Pi6d24EURlBAzs1AmvatwhFjYr3ZcPnpK/go75wtTCdVYBIk73EW9nZ3KIyhVGAyxEDdNFJ3wdMUlkvn9ri4t8vFvV1iGEjRj+/mpm7Y293V/h0w1pCQMLAQEj6IFllVi3bPMEgGSAEqKrAC2EbNehmGgaTnNPMFxpV0IfHklas89tTTPH39gIMuceGOu9k5f5GXvvwVHB0dc35vhwc/9yAYQz1bUs0XopeowEZQzaG+71TXUIC+qKG2ZeG2G1gpsWlburYl6iZXUmYSRgDzpCFdKUZsUYhGkQLfMeqmkDKhpLkE/BCWohwXRuFwh4/yrk9ZYF7DNXNYK5phVsB1mf+skxAua4Wl5lT7qqpqqqqkbhrRgyxK5vMZMUlm3U43sSQbmvTVpq7ZbDagIBOTeSlNwsqcCnQnvVbfi26jUXA8RGEsuUkoqTB9lFnqA65w9F2P0yx0KUkY82azJunc/5Vf+ZXcfffdNI0Ioufx45yDKBt1OugF7LICkIGAgybrJOkcndeFXdfz0Y/+Go899pi8gXUM26xFNr5jsh6n09BXWec553jPO390vNeZndmZPXfsjKl0Zmf2PLDHH3qQupZMHKimQllWsggHurYdWQyysNJdunFHTIQzky7K8+4dSZwJM+JCsryWv7fOk2giqcMxcR5kQagLw6TfT52apAymKNl1RABcMyAZI4CS7vRadTRGxlL+exBx53az2YYAqRD3MAwYENBoGPDe0/YdzokT1Pe9ZG9rW3wWGm1lYRyGjtImfN8xdB0p6I6xpnX3KrSKSaTZLoNrCNWcvphz9STy/l//DJ974hrB1biiQvla/xnsmY7Ub5fdxmd7Fts68p/PDIi4rDWyAy7BYaSiZjUkDtqBdbC00RJdgzclHs2rDdiUJJ035D1nzTx3+k6fx+ytZc39eMx+Z53sqKdIbROONIrYG+MYEpiiIdgKT0V0FQOOAUeysgj/yq98A8tFg0lex5IwBrq+p3BbgCWEQFlKmJpoGwk7QMaqOsiT401mY0ycd6/aODmDT3bAh0HSO+fzxLkXLSMZW3IPcXy2VVjVlTAZjYxj0UMSBz87C9PxJ06/XDPp2BaHKIfxiWMl3yNziJYxf84EPJLn3l4/g1M5xEieQ9khem5mV4rlFpXpxTkJOc3sJ6NsITl+++/xbyNZ9FISJtjU8vNNAZGowFG+fwZfzDj93ZptjYRq9Wj7KjBopBJHdo7UxxZAStrv0ykQzRoJKcvXF5aYsG6yTes7/52vm/+9rT/5frR0K7Vreh3nhN2awZ4R9FHL5cztaJTtNX3GXIdmouE0lun0/awkE8jlMEbFwBVoMsqS8cHjtC917Zp3/9S7mDc1IJp50kDaXtruMqNIKJC1lrIsWW/WSEB2fn45LibNymcFIJkv5hAGjAKfvbIQg6aRJyWcMzhj6LqWGAOLxZxz5/ZYzuc4K6wlZ+Wdt96spC6LgqppZO7o+jGMqqorCk1YEby88zsN2SNF6rJkPp9TVcKObTcbFvMZhZNxH4zl8PiEoqwJMXHf/ffRt2tS9OzfvKn1UOCcpoPX5BfOiZC1AErbeikUxItRNoKSspNTFKFmFMg2VsDd3J+dstSiiksL80ZCeUXvS/TtrMtgkozPPAdI2FbSUPesLVfgilJCdicspMIVWAUs0RDFoigpq5KqrGiaGbPZjLpumM/nNE2jYI+WV9u8LEusFV2l3N9jlHbOTDmj/acfBsqqAmXlJc3QWZXCZrLGMp/PGfygIf6GxXJB3/US+lbVwvAsJCRvtVqx3FmCJluQd5I8o/eyeZjH9MHBIZCYz+dal9t5W3qxzMcZZDMKjnVdR1M3DAoi5jWVdY7r12/wG5/4JA8/9BBFKfpIbdfSzOYKOkrb5HcUZMBT6qcsC8qi5M3ffZb97czO7LloZ0ylMzuz54F96H2/AMZQ1TVFWXDx0iU2mxY/BAE/vMTJYyAGr4srXUjo4j2qnpFRRxN1tqxRppJR6GjqYOTfmkUlL3DMxAEbF+/6P2PUEVIdI2GJyCI0h7xlACyEvIOmzBFjaNvNuEAKIcqCTAEea1TMtOtGhlYMUgciHjrQDb0UKcHQ95LNTYEkYSz1+NBjU6J0lr5rCd0gi+gomjveWHCOaC2msOynOesBTlYb9o83HK4H1t4ymIpgZTdTIIuUYbmxDv/D7T/lXLKr+5/ZfutlikYFkEFgNgNRN02Tco5cBDBEo/ow2l4GsAmMZimKRnRPVBEGOWv7/9vDeNPP5Mz8b5DryXJYIK/x2yTHSNnl2Ex68sbS+Z7aRmZ0/Pf/zZ/gzt0aF9TRswavoTEZhIFbnXdh4ciueczC9GpGxbDFuZGSRh0D+Xm2YFTeKc7jOB8nO+Howj878tPzxMHITMUMBk3ZJnKdW3EGaRxxBgUE5lSYWn6mXLb8G2UPyNiWOrAjg0ocSLnf6XaUeWZbl9tjn2lSvnzPDGJMfz/z+moTsEpuozDTbW42vXaaZCvLTh4ZOOP252eT0m7vd/q7W+bf0/9O2x6f6/k0KDQ99vS1ojKdUEAIvc54LT0u6Tvj9HVP2+nztu1+6zHZ3IRhNf18LO+kbrI2U77GWF4d9SZB4eBo/wZ/+Ae+lzvOb5lKBivzhjF6NQGnhG8nllLk6cuX2aj+XtLMYLnPWcAkmdMdiTvO7YAC03lYFs5A8NgYuHhul/O7S3YWNRd2l5SuwFlDGCQjWVk62eToOzCGetaALfE+qp6RpSicADsIYJY0y2nX9VR1ReksTVWJKHiUTRUwhAQBOFlvuHzzkIeevsH1ozXelFy88wXcd//9XDi3y9HBPvv7B2wGT7PYw5UlzXxGDAL4GAX+5Lp5bIsGWwpSTmH46oZN18m72IdRu03Ok5pOUtGkBMPQaxPL3zKnIBlmc9+fWEL1E/M8aISVVKiWkZx065okj1/nCsqqFCaTc8xnoj0pmkaJxXxOUZSYDKopeCRguadpZhJKr+HHcg8R+i7KQplIAuKXpSQ/6XoFa4ZBGJBRkouUZUHwkpUtxDCCRcEHrLPUVa0baQJyGytaS4UrJDRZNTJD8DgN6be6ZnLOMZvNueeee3jJS17MuXPnJHx1omtpMwNKn7HvJcFDVLZX7wNPP/00jz76GFeuXKHrepwT9hHKAM19wBpDVVUEBdBk/stAeUmKkX4Y+Ln3vP1Ua57ZmZ3Zc8HOmEpndmbPA7v85OPjDvD58xfYtBthLejim5RESyl4FcbMO+aaPUoXXiShM6MLr7wYy2l6kwJPTJwKY+Ry2+W5rOhjihJukpI4quRyqKMS9Pt8jpbfqIONglvDMEiGGRVI7TVEbfAizh1DUO2jgc1mzWazESBpGCSTUQgcH58w9AIaxRjo1hs26zXBSzrk1ckJfbsRxtLQE3wQTQwvO7K+21DYREqBkBK+aOiLBXF+gc9ePeZDn3mSR68fc/mw5bBPtFR4UxFtMQqni/4PIyDxH2//Kef+dtl/QJmMwmqjuLYlGkMwhmQNJINNRpw2ItZEbBIdpQwBSZ0a+X070zq/1X3NzSD3zXeX/irtIt/lpzFEo0worOghKXgxJpozUqZoJLzNWkthIl//1V/BTlNQOdECc5qFxw+daFWo45Cd7gxCeO9HYMUoE0l2iwc9T8JafMghc+KgFYU4GNnJLMustyHXFgFiiDEw9HItubeAVVI+AXZyCJJcX5xrYyS7XNSwMwFPMvB0K+CUnXuDtFEGwyADSuLAFEWJGUMytmwVyM6+NKNMR3lXffu9ONrCosr1dfoHmVa0jrdhWPKdfLbNdvfMvmQwyp6UnfrTlq+XHbR8jeyoZVAJvadomMjftzOrzqaxAvZL/ep4GUETuZb0222ZTz+DOMAytzMBXeykHFIvWzAsh09K/d4azpbrdOyz6tRPw/62dS59oZhoK6U8v5+6TrbpudNyjdfT86y+E3JZk44dtDzju0yzcHXtmvf89E+ymDUYEoVTkH9S3tw3t5YAw3KxYLPZiPOv5+X20NPyZIEBXFGOek8pRmwSdpJzjk27YTafUbiCxUxCknplEHddhw8CxtRNQ7NYEIG27TFGgAkm9eoKhx8G1usNIXgR/Z7PWCzmAGzWa2KQVO7GSHZUm4WkXUHQ7JNt29J1LWVZUFc1uzu7+BCo6xnHJ8c0sxmdMmgqDRts242ENTl5zq7rZL6wGXSTcNcMKAj7UNcJ4yyR2/5WVp+1FmusbmLJ+AwxEFMkTH9UmNxaR1EKQGTslo2U+2vSOrPaBq4oKIqC2WLOzs4uVVWxu7dHVdUsd3YwzrG7uydjQ8P/+76nrpWVZIxkx1MmZlnKHGatAFoyWcl4m81monNpLX0/EGOi1L4xm820DzvJrKahyyHEMWtnUzdbcewxe2dJ27YScl0WWyFvI8D84L2G53WUVc0weIbBc/PmPg899DBlWbK7u4dTkD9vKOT5Ko8H6xwpRo5PVnzwQx/ms5/5LDf390kxMZs1tF1LUFba4D1VXQuDW4W5u7alKAoGDe0LOSOkav+dCXWf2Zk9N+0MVDqzM3se2GOPPERU6vLuniyWQhAtA1lgS5hYGsNZdKGvTKCo+ghGF3ZGRa+T7nynDExZYSvJch2mIBS6aMif57+n/zAgAFMUJ0x+lJWRBLzKf2fKfQiifdT3Pf3QQ5IQKj8MCjh5YSB1negupUSri/UQApvNhhSiAEohMPQ9vhfB8r7riX6Q0Lm+xw89vpcQN687r1GFwpNzdMngyxl9ueR6Z/joQ5d57MaGzs4IbkYqZiTXEE1JMlkCXdeZ6oFIVYw18x9h/ynn/nbZf0CZMoCjfyazzbJkyAwA+bdBM41NICA5Xp3C8c5Th3DroN7ObvfNtE3yNY2RsuXjt+dtyyEfSvmzE1US+Iav/gqWtcPEQaAwY0gxUBWGELap38VpFodLdvIlY052nmOUMKx8PJNQIwF7sraPAK7ZgctMAGuF2SDaSALoVJrmOjt64rxlx1+BAAV2U9qGMmS2hDz0rYBSLtst9W4YnUcpUw4VkWtKWIWEa6Us0D8J19teKl9bppXMerIa+jKty3yv/JOSAGX5mkyYUXL+tozTFpbHkTnJWAUwJyDIrdff3i9b/i5/L+287aXTY6eWQahte4hDnJk7t9zr1DVMriD545ZrjOdrGfLfp58pA1PpNgAfbEGNbGPb3+bz6fXy7/x5vs547VMA0+3uk8+LY0jk9ruUxdK1njOLyVrou5b3/PRPMW8qkqaqN0ZDo9jWo9xT7pv5XpkNsjo50Xtv+4rJ/UDL4X2gmTUYY3BGtMlIUTKOKbNj0/U0dUWpIV3EhLOWWlPTV1UFxtLr+8dMxLBzeVNKDIPo/zlnWS4XLJZLsPLe6/se6wQ8CZl9paxFY4WhlYDohTFzcnysIETDfLFkvljih57Dg5v4EGnm85GVE5OED27rAsqqIunmkABAwhXLZc4TalR2ZK5Dqfbt7/ycEiK37StOM7Y5K0C3cw5rC01yoAkIMBTjJlju5WLGWspCtZLqmqqqqJsGaxyL5VKEuZtGdYwKYpLMhmZkcUrYVlHke2pSEyOaTHnYOWtxmeGj/ckY2VSw1lKWmgVN57j8vXWSoU8AVxHkzokdqqqSTLdjdkF5LlmzifZcZpCllHBWwK6i3IJFMj5lHrty5Sp+GLh08cK4uWE1hDrPB/I+CRwcHPKhD32Yp556mkG1+ZwrOFmd6HulwOS+qXOAbGLIHNb13XYDUwFAay1+GPiet3z32D5ndmZn9tyxZ98SO7MzO7P/v7GqbvDec/78+TH7R46FD96PO8QpC2aGSNTYfmtFFFt2dnWRrAu/pIufcWGbqeb6O44CnOKAbgU5t84Nxkx2K6cLeJ2goizOhfrtCYPXjHTgB0/wEr42DD2khPeDAkyysxu8gEfGbLUf+q6jHwYODw/p2pajoyMBkwZPHAQoGvoBYqRvO9DnTyEQg+y44QcqTd3rXclQLTHn72ZVn+dXPvskH/j041xvLa1ZQLkENwPTkFJJwmKS2TJsErKyVrbL89lMsgg7SX6SkZC2IsqPlW5INBCxiIqSI2GJxulnOZAwYlMYGUy/FcuZ307/CJKVHcuESZEieVwK2BQxKd5ynwTCsLIGQ8ThtSwRkxKkSIiqbWOMsJqSOCiZDZTZRBloySBJdpqt6u1MnXNU+yJ/ZlT0u2lm4sSonksGTvI8gA7HvpfwhbIUJ0wcCXGGUNBKrq9jKsi96lpCQwTM2oom513oqPNHdpakfAIiTZ8lOzGiTSLsLCnb1hnMOEWeRrYYg9SFNcKUyuXIz3H6Z3td+Z0B68zgkn9nBlaaYDIS1mF0zhSHabucyufma5NuDSmU8+Vnes54/Ckzes9CtWly/VnVEMrX/Xxmcz/Te8UYx7ZBr++KAjMJw8vPl/+d20Y0g8RJzteKOq/nesjXT0ky0GXmU/5u+r3JLBR9h+Q6ym2EliP3lVxX0+vlz+wEsLKqx5OfO0ZJApGvLfcX8DW/gz7//JvkhYTMBcF75rMZe7t7YybA7aFG+ouG4g4Jjk5WJGDwA0UhumykKMLHRUkX4cbhETcPDjg+OcGVJbP5gmY2oywqYvr/tXfn8bJdZZ3wf2utPVTVGW5yb24CAhEUBJlBhiAJUwuKdrcyKK0C6ovS7+vbSoMToEAAxRa0u9XW920VJ2xtXhER2+G1VQaZNLydgBCBQCaS3CR3OvecU1V7Wmu9fzzP2rVP5dyQQkjuTX7ffCr3nKpdu3bt6ez17Gc9C2g7jxCALC8wWVuToI0GytpOs219wGg0woEDBzAaj+C9jHAaYkBRFjDOom4atD5IQBtA3cqIqXVVYVxkOP/gJs5dL3He5gTVdBs333wER26+BRHAwYMH8XWPeiTKPMPO9jaCl23pNbhg+0L+cmPG6N/vCMl+dlkmdZCc1JLb81xfG2nxkOek2HOav9VgkrFZ/7AmgzU5MlfAuRzOymhw1momF6ABLplPnhcYlSOMx2NMJhOsTdawtraGIi+RaXZnyhhqtdj52toaECNGZYkYQ5/9JSPNyYh+xloUZSH7YAqE67kwHWfQ4J3V4Dv0fDYaj/WcJ7UjC619WTdyU2xUjuAyyTKU85zchMvTKJzGStAo1bXSQ6g/RxhgPpvr9pHrvCzP0NQNvPe47vrr8dGPfhSdji4aYuwLy6fj6vix4/jzP/szbG1tIdOi4+lcLqMByudJXSgJenu/uFYLQQYukeNdst7TeS0VDieisw8zlYjuAY7ecjOAiAPnnAOv9Qy8D+iabtF9w1gUeQ7oXUSjxR5jaqjpRV3o+9vL9beBFLkdXvDrS6k1pEuhjagUjErBJn1ParE5Iw0Li9Ro0CGEIW36NH2qLxCC3LWDNum992haDSzVjWQpNQ1m0ymqqsJ8NkOM0njOnMNsOpMub02D0HnMZlO0OvKO1FSq+kBSurtsYFDYCBdauKwAxpvY8hk+c8sOPvH54zjV5WjsCJ2UcYaDBaKBJojARQmYpawbya5xUpdj0UL+It1eo+iuckeXycCETMJB1sBrjW0bI1wEnPYrCwba3UwCShKacxqESvVQggSVJCqpmWD6KV+gAb5sT1BK251Gu7aZvhx4eshnShaVPBwC4CVA5IzH07/+CVgvM1gTEaLEEmPokJuIpgvIcmmQpC5ti8BSjkzvdstuIhlCklUjx0sIWltjEKiVY1MCPtItRbKK4qC2T1on3nd9gCdqA1yWRe5up2AT9DhMAS45Ryw+L43CljKFJKspZZBIAGexjJItlQISEgyQLrGLrJMUkNIsLCzOLcboOSRtY82wGloEhhaP5WnMIAMsLQs0UymtY/TnuHSHX7v+Ls3PpOfklz2/m9R9TH8ebqf087KUCZKyiIbbbTh9qos1ZPY0KuVFmzK3oCdxaPbM0vzS50G/d1pHcRDMWv4OcZAZlt43lBqaaR2bQdAv/QwNXKX3p+3Sv67vw+C7pHkMpx92S7RWCkDHlOFlgLap8Wd/KplKIaTR5ZzsQ4N1I5+ZcpR0fnpzYzKeSEZsK8WLF9HH9I/WdwseJgRMylLOFTHK5rBS1wguQ9dUyE3A2mQCZwwyK91b51UFHyUAUJQjuDwHohTWrqoKdV3DAP2oZJOxDHHfNvI30GVOCsD3XRfTtgXqRrqQG2tgswwbG+tYH49QlrnUOwrA8e0pkOVovceBzQ101Qw2L3FyZxd5lgM6OtkiczFlfckaKIoSzsl2ku2uQbc9mYC6vwQJvqDfxnoza/lfI93hZIS29JBudgapy5Y+rOzrxlpkziHLcpRlgdGoRFGWKMsRylGJoigxGknXNOdkneU68psE0bWmUcri9gF5IcW5DQxG45HupzJap+zDciMrz3O0TSN1vTTb1qc6ZcZgMhlje3sHuQZZxpMxZvMZoN1VrdZEQpSMpa7r+i50XkfEk+wfyaJL57G2bZFneR+gl+2SMh6lWHauwSHEiFPbWzDG4PDhw3JchSAZmRHY3tnBR/7+IwhBs8T1WIp6Tbbozq3nM2ulILl2tcycBNRMf6MBaNsWRSlFx887fBjP+VfPlmUhorPK4tYaEd1tdcFgOqskkNTKSBvWWhgLhNDJKDW+gY9ykWCshcszGCd3wvNShibughRJDXpFtGhMSEMmDSsbUoFMHWUtpLvMeiEPia3o6DSddL/RVO8uBnSIaINHGzyiNWhDQDBAEzx8DOiCl/emLkFaP6nVYJLvOjRti1k1x2w+x6yd4+R0C9N6ilk1w3w6RVfVmG6fAnyDptpFU21jd3YSTfTwoUFT7WC+cxK+mWNnZxtN1wHWwccIYyNaN0I1Og/12vm4Zsvjw1fegKtu3sWpNkeNEsEUMCZDZgwiAiI8jPEwJiAY+T7eWHity2NihO1HzPnnPFYhDaW9j7tW1HVkY4CL0vCCNspSwW4DLciNCCmNHgB4GHjY6KWxFiXcE5DJ+h2uodRo3Wft7fe47TO3DSUtPxZhQ4sYLYyRYJmBNGyBiMwYuAiE1sPZHE2AXOwHWb7QpW6n0ocidFLw1hnpmmqNgYkRzljN6ovw2sUzeumSMtudyjDVTSPFcjsZDrptpHGCKI38pqrlfZoZaI104fA6Ylzbyp1v7yN8FxCDBIBlVCrbB4MRZG0HL6NEyrB58s2hDZrUHSZlBg2DAOn8EXUzeR0hS94tTxqjQ9VDgrJWA9ZpHRhAsiujNK6kO20KgMgySFc97Nmm6fumQNYwSCHLtshGkWWQ855xGlhKmW2aOSJ7p/wctPE4zCwyqTGm50gJdMg3TVmjsoSSeZeWCRokGv5udJlSgD+tyxilC7LRLDVo4H058AHsDSANpYyqOAj6pG0GXZbYB2oW3ysxRvbf9G8KwiWpi3TQ75yyJNL8O+1+k35PDey0PP3nLwWyhsvho0en9XfS3zVAvof3sj+bKEEWn9bh0rqEhCpgYeHgJFBhpRvdeQcPahDZwznAWP18AHJrRqLHs6pB1XSIyAFbADaTgJIxaJoKPgJHT+5ie9bg2KkpTmzPMKs9inINzhZ6TokIXYuubVDPZ2jmFTJjsDYeYW08RuEsQteha2oJyBsLZwsEb+C7KFk8LkPoPJq6RvAN8sxiMipxzvoEk8xiczLCvc47F/e94BDue8E5ODSx2Lr5epw6fiuOnzgJW67LqJfNDPXWcdi6hg1BupM7h5A5wFqM8hHyAM0YjpLJY6RLlwR6DayVUb/yvEBZjCTAYQxCSPuu7CdGrzlS4MhpVlM6kcUYEGLKPpP3GYs+8xBGuu+WoxHKcoTxeILRaIzJeE1Gc4NFWY5hjHTlKssRYpCui2MNNM1mU+n+rgGdpm3RddIFP+37MtKZ7Jfz+RwGBnmRo64qubayUmPKZQ5ZH/SMmM/m8t2KDPmoRNU2gLPSRc45eAS4LEPTtciLXDLTmhouz9D6DqWOSDebz+FjwKySfyUrrUNW5Oj0OIg6SqDXEXOrtpb3VhVidLjiY5/AjTfdDJfn0s3bWkRj8OEPfwTb21O0bUCIBm3bIS8kmwoxoq0bmFQf0Fm53WNkhGHEKCOcZrLs2XDE0BAwmYxxwfmHdX0Q0dmGmUpE9wAnt7YwHpVYW1uX9GMdEjsEuRiSAt1S3NPqiCeAXMV5rVER9E6YPK/dKeKiQWC0YRc1KCUXeHpnXe90WbsomCoZT6kBqxlMMTXK5CJRglDSUOobnZAi323TIgYpXCnfSVKrm1Yyk3Z2duSiq67Q+hq+62ABdI10oavnFbq2Rde1CN7DB7lQnM+naOsKbVP3GRFRixl7GASXI2QlmmwDW77AldcewWduOIY2X8c85vC20CCGBDIsIoLRlbaHZg2kO7L7THH3scI30y5maX2kdy66oS1Pv3gsv6dfx182w088/cPoXVljtFD31z8Ba4WD6Vr4TjKQAqR+CqAZGfot5DnJAkgN5j5A0RejjtIQ7+9CL4ITeZ7D6FDV1loZWShGjEfSJVYOOjmenbGwmRQcNkaCX9LlSj4/HYfoG+3oG0XpDn46R6TPNwCgmQLSQJfGf9TPTI0KeY90m4FmlUiDUUSt+WT0uTgIYvTnJWWijkgpE0qwwVo93OTcJOee/h39z9LdTZZTpgUA6QJotCtLH5AyEuyRdZG29202/x6yPvRJDTwN12m/LjQzNEY536X1uZ9+XZu01wxeGwSk0rpyzvWBpmVpGjMI6kD3ubQ8/XQaHMs0CyFlXQy3/WLZtKujzmM47+F7YpSuPLHvnia/D6cbLl/QbIz+eQ0xDOcJRBgnf19clmmAx8AaoKnm+NM/eRcmoxLQmkC3d86QdbyYLyDZHsYAo/FIimAHLRYdpftkhH5f3Ze6VrI5hjXIQpSMF6PZebvTWV+svsgLGC0mDUgD3HcdZtMpEIHNjXWcc84BFLmMoOU7r9m9KWAZMa8aAJCi3lGy0mR/C7DOYjIeYTwqkWeZjEqHCOekxhq0RlJVVdjdnaHtJIR//uFDOGdjHRtr6zh26zFYJ9micBY2yyTQEuRmiddjNctz+fwo56ZUi63IJfNG9gs5PmVf0+uJQUZP2sBpHzByYOu20cDoIMBptMtZXhQYjUYYlSMUZYGiHMk5J8swmawhywsJVumgAykzVLokS02jtbV13T9k0IOikG1TlIXul9Klr6oqFHkh0xpgNpNC7EVeoPMeWZ7Ddx3artNBDiQzNRq5puo0OzvGiLIs9Zxv5NwFoK5qlGWJupFuazDo6zO1bQvous6cQ17k6Hwn9ZQyObaiZqVKkK3sd2cJuDtkLsO8muOCCy6AdbLH33DDjbj2uuvhuyAZtvrduq6TIDiA0WgE12esyo0IZzWDTbPSus7rtu+Q51LPKmpg6dGPegQuesLXyfIQ0Vll7191IrpbOvfcgxiNRlKgupPRlIyRbIUYpeB0uhBDupjXhqLpGztyQRei9NtPQ95CG5cpuAQjdZpilIKREkCKAOQiI90B7lrpW2/0LpjXbnkxDmoM6V3s/iI+1QLppItb5yVjqaprXUZ9XdPnjTEYlSOEeQ3TdmhmFULbYXvrFGazGbrWo2mC3MFtgdAG2K6R+kpdQOsj6kYuvHyMaKJFNzoH8/I8fOLGU/j7f7oON2zViKMDaGKGYJw0oPWiUzv66bLo9eXeWBLdY2nGihY4TfUxoI1+pwFYydSR4wZ6LAYN9KY6GkmWSbHX0GdWQDIHNNjktLEDzf6w1vbzMMZIA8c5PbblTnyavxTIXdQzMfpv1POFFK1d1OhJ84SRhlBa5lTHKQUEoEEVo9N1Wves6+Q7p3lKI1NeR1+0X9ehfmb/+6AmkmRWpgLXMg9pnKXQA6ShHiW4lpZbshuCHr9aE8RL8fBWz11+MFqZzH+x3k9LD3yjP8v31syfQTAwaoaRTHb7J4s9nzkIukjkTJ5O2yhNe7o59u9NGU0qbcs0f2h9HDMYCS7LMlkPg25q6e9HCowZDY4M99H0eWk9No0EQKwGQdu2ld81+yNlTgVd/2le1kgNmP2kZZLaONqlep9J4/L6XDJ8LYRFBpoxFpOxjBqWNpdJNcysHFMRBsZmqLsOO7MZvJGsKGutdKUNAdY6ND6gbj2OnjgptY7qWrpIx4jpdCbFs6s5xqMS52xuYH19AqufJXWNJJDV+oBG/1ZOJmMURS5ZM30QUIo9H9g8gMl4gsw5GEBvIHl0bQMTAzYnExw6sInzzj0AEzqcOnEU21vHcfMttyAvxyhGY9zvKy+Ukd8MgOAlY1F2ckQYjDQAEkNAOSplHUVgMh5jbW0NVq9JsjxDUZQS9CkKZFnenx/SPi3HSwo8ybqXoLt0gTNG88msg9Oi3ZO1CSZraxiNxihHY6ytb6AoS8kWyjN02tV/PJnAWYeikPNiVVUwMFhbm/QBcQP0o7eNJ7LeyqKEsw6T8ViOmwipg9S18J1HUeRoW7npVZYy+mbnJXMw6HaPAIq8QJ7nGnTxyIuiH1GvaRo5X3sP6yx8CJhMJmiaBqPRuB9gIUap95Xr9/KdZK1KN7gMIx0Rrm1a7eqsNyP03DyfzxBjxNGjx3Ds2DFYI9lP1157newbiChLKcAeY0TmHOq0bEHqP0mgSILjrd7sy7XAudMunVa7D9Z1LceK7/DQhzy4P76I6OzCTCWie4AsyzDdPtVfSMrwrnLnrWnkQgPaLQR6MRzTXWUsaodYrXUS9K5UalRGuW2lDQeJVRttiKYLFrlQ1TukOiw29G6kBJsWjZ104S6vaTc3zcZIjbmmadD5DlVVI4SApm0xn89llLeuk6GeW71AqhvU0xm6qkE1r6XhrZlNxhj4tkPbdNJloJ6j04YHIuAj4I1DLDdQ5+u47kSFv//UtTheWczNBLXJ0ZocwTh4vXtnoF1ytA25/9D25naadnc3X4Lv+SWYxV3FDBq1kqn0eKyXDnlq91stZNtnpKRjSb70Iuiy6Ha0CLZIECrPMrRdJ904Bo30sdZWcdpYH2ujJzXQvd7dTo02yTaREYyappHXtFDucJmMNj7TMlg7qCWjn734WeYvtc8W5wNjUn/GNK0EcNJ7+vmm4yhKVkg6Pxjtstb/vhykGWQASWbkomubLEN6H5YYDS+kr5QCwzLvtAwpkykFFtJ7bzu/xbKln/ULIQWW0ryH623odM8ne9e3LqdZVAPb89nyw+nnqeszrb/0XFq+9L4UzDG6jlM2Sfq7YPosu73BKGlEn/6eZlru4TIbDRjZQW0l6JZK0ww/o39Oyfw0Y02DVRZAu5Sp5JzUHTqd4ecalwJaMu+2azEajbCzuyt/rzR7z1mLGAyQgplWAgLWaYBHO8yGToNkBnA2Q1VXMJD6OSF4RN8hswbj0QgH1jcwHo/hrJXuWFpIWr6jgQ8SmHVOsnCKskRbywAWdV2jaWuMRyUm4zHKQhr78rfdw8cOCAF55pC7DJOxZNgEvbm0M93F7nSKrChhXIbxaIwYAmbzudQqzDLJfjZyXgIMGs2GDlECeovDXrpQxb6GXCfd2swis9Ba6V5q+4C2ZosZ9Omrxkg3N6PZjqnQdl5IgKYoC+SZFO3Oc3k4HVEvz6Wod1mOJICv59SiKFHkOUKMaJsGWeYkSJSKwGuX2BT4995je2cHWZb1I8SNRmMgRmS5FAs3fVHviFwz0eT8KLWFjAb3m7pGORqhbRoUeYG27fpgVJblMFoXsqlrjMYj6c6MCB8CykIypKbTKfI8R900sNagKHJUtXRz67qu/5vRta0MuOBlQAinNZqM3pS4//3vj53tHVx55ZWoqgoxAtW8knNLBCIi1iYTPT/ocaaHUKfZXFLsXLKyfPDInAxIEWPsr+9cluHfvuTFWF9fWxxwRHTWOP1fdSK62xiPR7BZjtl8hrZpUBal/DHvJMDUdl26RQvoXVwDSF2WqHeHARm1KjUmvDysdl9LafcIMkwyAPjW95VlEKTOSaqxZFLRZe/hW4/opX5MpwGvoBdp6e6r7zy6VkZla9oGMHLBEqJ0XavqOTrfYnvnFE6ePIH5fIZ5NUNVV6hrCSbVdYO6qVBXc1T1DLu726jnU3RNha6aw9c1gjaoEQMa71EjQ1Oei6PdCB/45HX42LW3YLdzaEyJzpUIrkTUDKXMub6ijtFgkhSUlgvfvQ+6Z1o0elMB7pRdkTJVhkEKq3fGU2M26wt1ayMfErCaz6UeR9AaMGVZwmujNoSAVrOD0vyyXDIAUteKrm0lEKF3rOum1kCRLEcK6EK70qXRkKI29FOXi2HAIQUDJCotjQ3v/aDbiJXurNo4WzQOpetbanCl+YnF/KHBjLR+on731E0rBUFSoMFaq91YJLtGT3p7AhFpfaXlTwGlJAVDrGYmQbs2LYJLi3ntZ08HtcH2jkuZSmkZsBzcGRgu937PpZ/M4HsZI0sw/E7L0nZbrHM9oQ3EQW2o1OCXPyGaPrJ0lguaqYa+rtagq5/OO223XLu/pX0udY9J+7esb9kufTe+4fLsI+jADsP5ArKQsk70fX0mzG3X7VDUGwduEEwtshzOWtzvvveF0YwsWeaotYMkGyUaIDqDndkMVdtCbtEAmWYAG5ehDQEmy3Fqd4pT0ymm8wpdiNjYOICN9XXkmUP0nXTTDh55Jt3pvA460XW+rxkUAFTVHG3boK7nMBbYWFvD2mSCPM8QvAQxvJcutJnWHMusxSjPUDqLg5trOP/cTdzrvAM4uDlGMzuFUydP4tajx9BoIfCubbC7cwrz6Q5i2yF6qZdonNQUKooCZVnAZZoJ5CUzMwV2jI7IZm2GLMtRFCXKskRZlBiVI5TlWAM9JfK8QOYyZJlDlknWZp7nUqi8LKWb22iM8Tg9JlKzqSy0K6vRzBog+IiiLAHN8PFdh7qWrOkU+Ahae+vAgXP0PCKjvM3nFUKIUseozyiNmM1mAAy879D5Dnmu3eP0/JvneR/ohh4DTguAN02DQs/L6VgxRm7QGSOZgE1TYzweY/PApmzryQTOZZjP54AxaFvJWE0Zl8465HnRBx8z5zAajzAqS6nFhEW3Ox+kDlPVNDhx8iTmVYXPXX01prM5XJbDOotzDp4rWVSaZRSibMuylJHiptMZ7KB8gvdBisa3Hbq2A/QmwbyaI8tyuMzhQQ98IO51AWsqEZ2tmKlEdA8xnzeYT3cASPe0EAKquuov5FO3l2GDQhozcsFuNHsiBumeZoD+gihqg8gZGQ9nOJ8YJeNHao8M21wawEoNMX0+xgCk7nTp7rc2GLquQ6vp5G3bAEa6onRdi9lshmpewXetXpjJELzee0Sv3WliwLyawvsW89kUgEdoa5gYEDsZAccbB2Mdos2Bcg11tobPHd3FZZ+6HjMzRoUMLh/Bw2pDQWpzIHgptp1uoErTTUNM8ttt7f/s3c+X4Ht+CWZxVzFYZCo5eDz1yZKpFNtGRmPrs5Gkfeq0LhL02PLDQK1mKKU6NtCg7nCUK+iIOhIUkgOrLCWQXNdSkNtqAyYd50G7L6WGT/+zkawBpOM8BTgikLlFIz819NN70vIPf06NG+skuBN1KO3U9SUOThAyL3nP4v2L3+W7aUAivXef4A+gGZOQBpnMZxHAkhdkPlG73Tm3+D4yffo3BcuAEKTmzHA5ZRsu7tIPGV0Xqa4I+u+4d32lz0oBieE0+xk+389HA236pPyjP8syLL5vel9MwTmcvgsZhtP2NX4W38Nqlkyaf/8e/d1rd7W03W7znfT3rutgtSaM0S5raV8evicO9seUXZL2d6TvDADWAFbq6sQoNV6MkUzSuprhf7z7TzAeFX2mUsosXf4s+aF/CjFK4zytW6T9zkhWyGw2lz9zQWoSZVkO4yx8lIEpOu8RfIfJeCwBKmMRYdD4AGOku2qMwGw267unra9NkDmLrpUugrKvGhjYfrCKLMuxubkJax1mszl2d3fRaNbTxsY6NtbXURaFnJNiRIRkKBnIujIWKPIMFkCZZ8h1FLeiHEm2EoCua7F1aio3TWLEuecewLnnnouv/qqvwo033IBS6xMZYxA1+Oc1SzkVtnaZdFVLGY82dZ3UY02+n3Zn648t2W+slcCX1XOV1KiS7CPnJICS51mfsWSsZB6lwJIxBiEAo9FYusjq+dk6K0EOPQd775HlUlTcWoOdnV3kuYykZq1kRVkrmVGyc8gJZXNzE00j3fIzl0GuYXQdA+mokG6LXjJ3Un2pPitcA+RBR/hMn2n0WPAhoG3luVZLB4xGUtdrsramx4aRgJbeWMjzXM79ejOxaWrJUIsRpXZ3znTUu9FohKbtMJvP8fnPfx7WOu2KajCbTeGcxfr6hgSJIuCDBMSsdquOGqCs6xpA1ECgnP9DkGDiqBz1Ge7/8lu+CY946EP6NUREZ5f9b38R0d3OocOHYI2VYp7auMy0GOwwKygFb0wawlsbsG0nqdlIRSQHd9ZCkMaiXichaEq4vF+iLCZlNEEypILXgJRUmpA6S75D0zaS8dTXOYlomxbVfA7vJU3edx3autGL5Ro7OzuIUQpnxiCjZDVVI6NneY+6aRGtlTvC1qDzNWJs0DZT+FCjbefwvoZ1MgB8FR3C6ACONw6Xffrz+NRNJ9EUG6hQINoSXTQwJsLBw4YOJrRw0cPGoHWURDQyatndl27wL/ig1CiV7qSpm4AcF4tuHxKATIGjJMsy7XqijXntvpAa3CF1dRpkWeSaiRQ0IDufz+G0u4fLMsymUzjtJpK6LYUQ+kZB0zSwRj7HB6kR4qzrh/BOrWtpTEkr0AyCE6lRZIwEmaMGy1LXEWhXNyngLVkAqUEmwRtpoMk8F+cPaVxqtzno82l4eh3JziwHBfT9fWBAn1x+TtZvCgIMsnSUNCJTw3aYjYU+YAVogHz40Lvyad2EIME06DKmZXDaLQuDTKW0Lvcu+0JM236QwRMB9AEk3f7p+wz3Ea/n/SRE7Zaclmsp88doRo8EO/Yuj7WSdbb8PCAFhGMK+ugxMJxvel6KS+vvg/05vY6UETXYx9PfGZfqNA0Cij5IzTJEwMDI3xVdP3GwreW7pg2i3zPtQ/pfkr5j1G2ZPj9FQSQgFzEej7G+vt5/jjUyipePEVaLgRsnXaZ3dqeAsRKgMVILyBgrXa9h0EWDI7cew25V48T2NuZ1A5PJaJIhRFRVjd3pLqyxOHDgHKytraFpGpw6JbUDjTFYm4ylG1smwaLgO8Tg0XXyNzNlWVkd9l3+lZEa27ZC7gzKzOCCQ+fgKw6fi3sfOoBJbnHq+DGcOH4UNx+5CcZEzKa7OHTuQRy/9Va0dYUQOzSt1NjJ80LPQXJuSusudQMLISDLcxSl1lwC+qwiyWyUDMvReCxd2IpCaiSVI4zHUnxbgkkF1tfXMRqNJOCT51hbW5NzrwGsc3BZjizPUJZlX0vIZRnyXAIrEjhqNRAJbG5uIOo1hnMOa2vr2l1Q9oOdnW2U5QhlWcJq1zPdYWC062/UQJBkKEkWVN000sVOM3q6zvdZpnI9tsjcK4oSTVP3554+a1V/bls5d69vbGA2ncIYySDtOskibepa9jvNlGrbBpPJGkIIKAo5lpxzWiRcRsIsyxI33ngT5vNauilq7H4ynmiAsEXTtvDBI88Lqd9kpAg4dLS3UVmiKEopOeAl89wY6VrnNcM9xoBveubT++OMiM4+zFQiuodwzmE6q1DPprDOoW1qLZAow/vKhZYEhvqLaB3Zw0AacV6zfZyVfvGp0RSCZBcZGLSdDFWegkdei3On4r8pyGStlVFJtOht3dRSuNIAbS0FLmtN2W+aBtV8jkq7783nM+xOdzGdTbF16hTqqsbu9i6C71DN5lKc2HvU8zlm2nWgbmu0bY22reDbFmZQhLfzASbL0BkHn69hGkt86uZT+Ni1x7AdRmhtgYA08pQBTAYXIUElxH54+9QMkTvdGjWQ8NygWTK0/7Nnjztx+e/Ej/qSixGd1ssoHPCMSy7CepkhQ5CAp97JR5SCrfIe+V9Mhbk1AyK9lA+LLi8Fc1KjODVMJBgiAeA0vdMGSWrcldrFKC9kFKbRaNQ3dFIj3WUSTJAGvNRlSlL9nOHyQIMj1i26RqXlkAKxi9o6xlhk2SLzRZ7ToEkaBU7/iZop2X96CqSoYcACur7k9ajvWgQN0ufvra+UXje6DRbzTMskPy/vlIvAxPLTKViUgm9IWRhpEt3OfWt6YPlzFsty28wjs8/z8pU0DW7wfjvIMEvvT480TdTgU5ouDLrrGJ1n//dCt4PcPNDVMAgEpvkuL78fFDxP00E/N+33w+VJ7w2DLpZRA0jDNdV/ppWbGVZHNEw3MjJn0VQz/Pn/eDcmZQkDyZ453dl6mdGsVP0Nst9IACnEgPX1dcxn0i0qQmowSS3B2HeddNaia+XvYq6ZWSYutgVgYTRDJAaP0ajsAypd22I+rwADlKMRxlrXZro7xantU4gRmEwmOvKr1E4KIaBrJWDstJsbIH+/yzxHkUtXJKcZRCaN9Kr7b55L97LYdYjRoG4b7OyeksC2dZiMJ1ifrOPgwUM4dvyYFHO3gPfytzZtS6mvJt9TsnU6DbzJwBjQ4E8EkOUZXKZZSJmcj2wmo4a5TF/LcrgsQ1GWyHL5Oc8LuDxDlhcIMegIbTLynNH9svMezkoXuqDXMrlzsjw60EhR5Njd3YW1rs/maZq6H12t8x0ObB7oywhY5zS4LUH5flsaA991kp2aBlvIMjRtq8eqBnv0Bp7ToF4Ich4HJOMtRqmz1WidpxhjX6fIey91mLT+UqqPFGPEaDyWbO+2BYzMo64qlKORjvxr+1FC5bMCmrpFhAx44qyD0RuASUijfurNkCKXbo1FUcJai7Io0A7WgRy3MpomtFtq5jJ887O/EU+75En9fIno7MNMJaJ7kHvd5ysQYkRTS3Frk2pCGElnt6k4rpOGZgr4eC/BpNQlJmUzGL2qTneB21bmIRf6Vrq1QBu3Xi4sOt8heMlKahu5w9Vp3aQYpPEdgsd0dxfT6RTHj5/Azs42qqrCzs4Otk6e7B+z3SlOnTyJ6c4OThw/huPHjuPo0aOY7ezi1ImTmE9niF1A6GqEtkZoG5hO6jwBFiE6VN6icSNUboJ5tombZg4f+OQ1+Oytu5jbMWbRwadR3SLgImBjlECRtOC0dpIb1E/SJkYMMLhtxgPds6RuG/Lzov4LNOiSGsZWsy2sFsVODTDnnDQ8BnVl0oV6yhTqGy0aOEpdhlLhbumCoEFiY/qRgoIGDJqmgdEAU57laDUIJplM0mjxnZcir77b00UqDr4PoMdE34CQ80zq4uK9fN8QpDEik8v3TIWCrTXIMulWIg0r+ay+cTbIiIla7yT9Ppxu8dDBBXSaVNA3LWNc6taGfph4eW0x3eJ7LrbpYprTPYbBwdTVJn3vYRApBKk5Z5ayslIGT7I8/7Se0/TpPJ4+JwWE0mel94Vh7agY+xEHrQab0vaBLlscZgSlkfn0b0DQLCFAg3hRM4KWaiANPz/9nD4//Z7Wk9U6TUEzWlI2XjoG+mXXDCHfdf13TM+ndSOfk4KIi6BnCgYN3zNcvtu1NF0KbRojdfm6tsOh8w5JUejMIsYA37WSWWIdLCxitIhw2J1VqHWodocIG6MUX9K/LybLcXJnF0eOHseJnV0cO7mFWVXDZTnW1jdhXYbd3SmOHz+O+VxGhjuwsY6N9QnW1ybwXYf5bAbfdRiVJUbjEsYCEQFlXmA8GksA2RhEL9nBxlgY51CMS8BERAQ4GzHOLA5tbuDwgTXc69wN5LHDyeNHsb29jRNbWyhHIzR1jcxZTHdPwXd1HxhJ+7hzGcpSuqi5TI/zfhtI0CHLcmRZphlHFuVIAhUhRhRFDucyjEZj7d4l2WES2JOuclYD4s5aZLkEXCSQJtk4UTPNUvcr5zLUdYPOezRNC6OZUZLtIwE2aBZO08jNrq7rpF6Q1mIqigLtYPTCcjRC1Gw92Tl0Z9HR+tquRVFoMM9laNtWR5+V+laNfnaeLUbpdM5KEW69MYDURVTPlf25Xkdc29jYhNWMWAmSSV2prpMRIeuqQtQgUhrhMmW6tl0HKZck3fSky6JBnmfS/TPPAQBlISPK1frd5/MZZtMpZnOprVRVc8mE1JsHTdNIUF3Pcy943rfqiiGisxUzlYjuQbIsQ910qKY70v1NMwMyl/XdUELQ0dz04jrdGey6rr/rljKV+oBR18E6jVGnrh6anZQuotLd7NSICCGgrqQYsO+0gRmjpET7gLqu5K5b26CuKjR1LdlKtdSNaFu5iEOMaCqpE1PNZgidRzWboaoq1HPJSqqrGbpmjq6u0DUV2qaB94BHBlOsIRbr6NwEnz85x2WfuxW+WENrMnRw2s0AElTSOhwWUS/IpWZS1K4L0ThZAQZIrxpIo3pxNTm033Nnkztx+e/Ej/pSs5qdYK2FQ4enXPQ4rBUGNnjt9iJ37o1mKqVgQOi7ikn2R+rKlgItVoNAcpGf613wRTaRHD8SXErPG22Yp2BUqg+SFwW898iKAnUt3VWCX3TTkMBQ6qIhNW+GmyTNF7qpUs0mpyM+mX7UtsW75K570IbgolEujRspYrtos9+2kT/8zPT7fgyMZLFogzWGNMS9NPQBqY0m69TAQDJbZH2lz1kEowDo+9Av1zBgcdtllSAR9PyXMnlScMakoGLqxgcJxqRGdvqeBvpBywYBoxCjZOIMPs/v040t/WtTwClKLa20P6V9MA5qEBkNWqbsIaf7atoXh/PvP0P/dgztWZbB82mtyfZK3aUHfzN03aXvk5YzhKCjjGnWbPpuaf/Qul3BSwBS3mthDVDNdvFnf/pujAppcEtW3d51LHvEfv/JlGk7pW8TY4SPQYreQ+r07E6nMFZu4siNF3mjkTcgAKjbFkWWoUj7HOTcEA00wGpQzWf9vrq5sa6jbgE7OzuYzeZw1mIyGWNtbYKiyIEY4dsWXdsiyyVAk+U5gna3LVI32XTzKMggGi6Tm0I+Bvgow8jLMQE4WJSZdqOt5jDOYmtnB3XjEYLBeDTB5voGDhzYQNs1qOo5JmsHgJQZqPtrqq0UtQi20SC2MalbYTpGpX5ZOh+mQEaM0j0u06yldB5ZW5OuWS7L+nNfXhS6nWQ+ZVn2y5NlOYIGhouikMLnudRVanTAgslkot10U+anFEZPweW6lsyldPMMeqim84Uxkq1YliM9V8j+m2kAv/OdBK6skeBS1wKptpox/U0/Od5SoFb266ij6Xov3faKogBiRFmWqOpaA2cRVVVJICoGdK1csxkjNbmsles8AwNAajXFCBS5ZHelc37XSTa59xJM8zqoS91IIKvIc8kK1HpaRSGZV+tr66g1kNS28ncK+nfq25/7HDzlyU8EEZ3dmKlEdA9z4VdeCJvJBTQi5GLGd2hbSYsOGiSKkD/4MUQdpUVqqgDynhSI8ikLKUiXAt9JnY4QpOubXBxK4zFol7mua9F1nQR+qhrzao6qqrA7lS5sTV1hNp1iZ3sHW1unsH1qB8eOHcNsNkdTN5jNZujaFm3Tyvtnc+yc2sZ8OkVTVWiqGl3TAiGgaxrErkXsWiB0MDHCGQfrCthiDW58DuZmjMs+dR0+fu2tmGabmMUCbZQ7as4aDSPJHWXAwCHAREggafBaCjClhqVBgD1tptLehguJOHjcXfhOG2uD7lxSD0YyMtJxBkiwIjX0U8M5ajaO08yRTru0RS2wj0HGU9PIqD9N0yBzDuPxGFYb9tZa1LUUj4U2hFMQwadGQ9vCWJlP1BF9rJPgS2rY9XWUBtI8ozYY+89Ir+v5IWpwJEq0ANBgVdd5yRKK2tDTLAPp+nbbOkUpAIVBFs3ppLvwMo0EmFwqIhwkAC6NqWFWSwpKyLJbnVaCFnuDKPohsg3jbZcV+vlpW/YBoMHIf8NtPfw9Tacfof/ba/hUCl6l9xitwSXrWgIky+sqakApDLo7Bg14Adq1cdANLmWGpS6QZk820N75p3ka2fn3fCaWv05a75op63WeWSaFjtNnp30/LQ+0ftJy8Ey2tmz/FLyzmpkbddCJVD9L6tzojZAlEYP+lukhLyym0Z+jZvKm140xWF9fx9r6mgQvvPxNahvpmhRSl0fr0IaI3ekMsotIRsrinGHRhQAfgaPHT2LedJhVDXanM2xvS03B0ajE+sY6RmUBhICmkpFOvZfh6HNdjzEE5EWOXIe5D33NreF+LkdYFwJ8iDBOghjyiIjBo3QG973gMO59+CDu9xX3QjWbYndnGzfffAu2tk7CWYu2ruCbBtVsCoSAspCuaTHI+SwNMOCc6zPSUlfUGOVGmOyTUmjb6Ah5eV5gfW2t349SUfe1yRqCBldkP5aR8dqmgdEguhsEUiUwKt/bWiOZnVaCOF6DoQYG29syyMn6+obWL5KgT11XGI9G2NzYgO9kZLO8KABjJDCTgq5Gsn7atu2znKTQf+gDe9CSAVVdyfWVZhulmwVt1yLPMhhIZlKm2y9lfxeaVVUWhXTf04BUVVW6PiTzzTmnQfYUIJdjqdMs1rSNg5fAqEuZ675Dnsty1XUDQEYKLopCi5tbeL2uTMss21JqTBX9KI6aAQvgQQ/6Grzke74TRHT2Y6YS0T1QMZrg5s9fB4TQd5VIF6/pwlvu5svdyZS6nQquVpVkEVXzudzx6u8Iy8VJ6Hx/gdW1nRQF9fJc0zR9Qy6lec9mc6mp1NSoZtuoZjMNHs1RNy2aukVdN5jPZmirBl1dY163mM4b1HWFej7HfLqDrq7gddjkrm3Qdg18jOhiB5gAqYNqYHIZ2S2MNnHN8Rn+v8/eglubAnM7gdNMBWMcYjRAlN8lQwnSYLbS1U1eGbY14qClYSEdGTR76TaPM8HyMsm99zvykEvtOyatlTvykBYV9q7NO/pBd7K0pb8Qa4EQpftEDo+nff0TMCksMgsEIw16awxM9HAu7zMy0vyjZmLE/s561jcA0r8AAM0esjr6DgbdnGz6jEG3JpMyT5wUs406Wo9B7BsviGnkOa1tpMXoU/BiGPiwgyyEJOomTQW+rRYXdtYh0xod0pCVPcqYRYFog0FAZxDoCYPzVmp0psZlCt6kYrcm1fDQu/AG0GN6sXM5bag6XcagAbDUwHZWivUGL8Ena6w0uNL61sDK6R520Hjrt5Wuu/RIr8XUpWp5un5d753HcJrT/b782rK0rxn5IyDPpQy5lDm1tLxGu2sOAztp+Yc/p2mhgQNpVOr0EFF/Tse/HwTEogZdUs2u/rP7zLPFfNNrw79j0ALoQhrM6TuaGNE2Fd79rndhPC5l3x50+Rt+12URUbKIoF0YdRtB15kBJNMG8ncxz3IplDyYr8ROZB5BNrAW8nZweQ7rjIxM6ltkRrNWsgwtDGpvAN/BtzXWJmNsrK2jzHPkzsJqw9066fblcguLiCJ3GJUFXGbRde2eLrbRAAFSGDwaizZE6fqU/hYGozdOHLouovURWW4xLjPEpgVaybQ8fuIEgjPwucHa2gTnbGzinMk6jp+8BUWRwcLCe6MZmhF5IV198yxHjBbOZmi7Rs5f6dxhraynEGGsjEqWTo4uc1Jjqq8xJwGntO2zTGoejUZjOR9qMCuGIDWIOsnYMkb+Yret1JkEZPRBaGH6FBiVG28Bk/EYUYtn++DRtK2MmuakLmXbykhrXdfB6TKk0dOyTLr2ta3Un0wZqOkYz5yVIL8Gvp1mh+Z50deozHTwlK6TrKpUYL/tOu1aLIG0CGA8HiMGLSqeshA1uNh1LTIdgVT+rmi3RxiMJxNU1VyypJx0SW6bBjDoi66HEPqs9QjJYOqPTT3Woo5Kl7LjZf+X117zqlfg8HmH9MghorNZ+ktLRPcg5557Du7/kIdrtoSOSuJTFpEEgqTWUSuBoU7qHBlIw2pUSmFHxIimqfsaTV7rMFVVvSczwnu5Q7e7O0VTNwjeYz6bS92k3al2baswnc6wfWoHJ7e2cOLkSclIalqcOnUKuzs72Dm1ja2TJ3Ds2FGcvPUI5tvHMdveQjWbIoSA1neY1TXatkHwDXIbYEOF0DTw3qAzIzTZOZiPDuNYWMMHrrwOV3zuRmx3AS0C0gB2y8ygAbRfA0PIBe3dQfq+t/dY1fL7T/cY/O+L/7Azjl5gm0VlXwmgaDePlC1jDdpWhoZOmUnWSlejdhA8ihp0gjYY0vMpaBRCQF3XfZeHFGSKkOKsgOzHqX5PCAGt1mxKx3Grtc3Sa6kBkRrEZjBqV/p8771kHkS5g50CJEYb3dCuS+k9MqR6qmcid9UxDGRo4z9N3wcs9ntO35uWL53X0Acx9uxlUq9mSAMrXhtsRrvnZU6yOk0a4l6XK2VtGmhXtaWA0WK2t30uScsf++ytwffTZU+NsqDdENMyDteNTH76OkCnez4tW9quKQjnl2o4Ie1zg2ymtOxWu8yl16IG+tJraf7Df9PnpjPmcF4Y1IdKv9vBiG/DR9rWaXqn+97weaOjWKXvkD5/sU50v1naJW5vuwFy/PZ0VhG63W6zziWj8Nxzzl1s18U7gMVeiQjg1O4OuhAQABjnYI10IZXvLBlDOzu72J3NEJ0DNJAh3dkDEL0W/Zdsp0y7gVkt2ty0DUIEMh11zQepK9SlWkFa+yjqMSBZzF5qB7UdjHYZc1mGLM9x3qGDOO/cAzh88Bycd+4mtreOY+vEcdx6663wPmBtfRPnHToPJ0+c0GuJFtZK3bemkfmlzJ2ua7Vr2aJbm7MOeSajvhktZu2D7HPWOjgrhaJjjBiNxmhqGSEtZWIBEnyPOlIbtHuWczKaY/AeTVOj7VpkmQTjcx1xLc8zyczWgthdJ8sbNLBdFAW6TopjR8jrADAalRqMkSxU6UYWJSupr3GXygBU8JodDkC7pDkAkg0oQS/J2owaZDPafa7Ugt1lWaJuGpSl1JcK3iMvCmRZhqZp+jpLcgxK4NY6hzwvUFWVvC9qRrpmMlVVpSP1SWatsxaNZmgBsl9Ab0Y22s06lU/o2k4KmWcZOv17ItnqkgHVdR4v+6EfxEMf/DU6PyI62zFTiege6sA5B1DVHtV0B50W0YVeLKdGReoKYIzRCx65e5+6uwW9Axuj3FkP/bDgUpC3qippFGkXIKkX4/UitYFzGZqmluKYbYv5fNYXAU6N2aqqkDkH37bSNa6pEXyHtp7C13OETrrs+a6TLhDew5god52N3H2LbgSU64ijA9jqcvzTjSfxieuPYScUCMUEMctluWOEMYs71beld9juxswKjztq+X2390iX/St9wF1kedlv7yENXyCLHk9/8hOwVjjAyzDWSBkZ0SPLi75BmxooRu9Wp0a/HI/acB00lNP7UqPZpOKs6U64do9LgYBhsxd6DEcNZmVaBNZoo96n+kipK5Z+rrXSKEsHRjoXpICTTJeye+S8Yq3tu1ZZJ6NfZVkGYy1i1ECXBiqMrpuo3wtpnepr6bum74vBdGn5UzePoRQUMEYDfjrfoaB39NP3SZ9h+qwU+dx+OffJRFq2/JxNWTSD7ZgCcOmR5p+WoV8WecdtFnz5M04n7T+y3iUY5DVoFAa1u5C286CmltHlCksBtfSctZK1ljKM4tLPWNqeQ1a/9/K6XZa2+/B3aLAzHSsRsQ8IyO/QWj2SfdrWFf70T96FybiEifL9oBlzBuj369tYXueQaYfH5XCJjbEyaloE5tVcX1tkZaaZGACIEhSeTCbSXTuTDJcYJDsudY2qqzlGZSnbzllYE5FZKz877TqqGSxZOna1jk/atlGL1NdNg6aRwHKWaZaQbiNjNFgA6bYEoK/9Zp1DluXI80KKSoeAndkUVV0jczmKosR4PIHmbOHU9ilYKyOISTahdDlMWT15kcMYufZwmWQIyiaQAExRSC2ksij7mkney2iV6Th3mWxDWYdSgFyWWQcPMUbn5yWL0ABlWSLLNLPIOe3+KwXBrXUySAFkuqDdi6EFqLMsk0BX5zEaj9C1cn2UZ7kE7q1kHsn2lRFys0y6vEWtfZRG1pTPX3Q1NH19M611qStEMoPScQQ0TYOikL8d3ksB7qaRzKCUSVmOyn4+mZNAHIB+FN6uS1mHcp0TIzQ4JBlMMURkeSbL5CX4bq1D1EBU17YoSimmbrXGU1VVWo9KstE6Pa+/5PtejOf+62eDiO4+GFQiugc7eN4hND5ivrMN32ktpZBqWKSGgFycpQv2lNFgsAgiWWtRzSutf6IXI75DVcsduNlsLrUBNNupqiW7aXc6lcyorkVVzZHuoLVth/msQlVVMADmsym6pkFdzRF9h9lsF75p0NWVdqtr0DSV1n1x6EKAzQtEl8OWE9TFAZxsHD5z0wl85sgWjlVAna2htSWCyQAYZEZGiYnLGQyJufsHlM4UcsmvD21omX3Kmnw5HvK/Ly0LIGi3gNwGPPXrn4CNcQYbpW4MtBtb7iw67WIljb9Fxod0h1hkfmRaALttmr4uSdAsm/QepEKvKXCRuuYM5p2mTY3M1NAZ/gwMGzfyszTmpKZOGBT+TtlGKTCdGukYBBZsylga3HVPjfC0DVKDXBq1i41iB3VohuvDYG/wKy137LO69m5YA201aeAhBS5MCojpOS5lXkXNFoI20CVoIcs3XEeL+UN23iV7pknZNEYyzNJ8Tiet0+VADpbmu9/vp7M8XfqtXzZI0ez03HDfStL+0zRNHxDab9mCBkWG70PaLwb7V7IIfOy/XsxSIDXNr+skSJmWNeiAETIbqZ0TY4SzQFMtgkrQvx8GEmiQ41A/a7BukuXt3ocaB8vb/6w9Q0fjcd99PL0nfY/0ecYYdFrAuiwLGAM47ZIEPdYyK9X6dnZ3MRqViMFjlDusr41RZA7Wyahx0GCO1dHQ5KaJrKu6aTCbV5hXNYIGdvKihNeub33g2cox4kNE20gB56jZzamOlXMWZVkgaO3Eum5RzWt0IaIYTbC+sQnnHNY31nBqZ6sPKFmbIc+kK5UxUQ6ZCORFoV3FUm01qbMmwWRIDawgBbyNMZjNZigLCbB1rRbT1tpHsm+2yItc6idZ6caVOQlKwUi9SJlWzrVZlvWBl7Zp+hHohtnd0pVLg54AsjxD07RwmQShIoDRaNTfhJM9SNazBOpk9DTZ7+WkV2rdIaPBv6jdQZ2T/TnLMjg9z8l707l6GHyWeY9GY818le3V/ws5NWU6z6ZpUeQ5yqKAdbIevA/IMqd1m+QaUAJ/sj5dlmn9PTnmZJtIsKptpfZTp/WWUoDXe4/RaIQXv/C78F3f/m39MUJEdw8MKhHdw5178CCCdThx680SIDKSio4oNUbk4ktqECACvm3hO4+mrlE3MrJIVdd93ZCqrlHrI11IeO/RdR5VVWE6m2I+n2F7+5QGiiQw1DTSZa6qKuzuTrG9s43pdIr5dIbZ7g6qaip1kpoaTV31o5MgRlgEGKMXV1mBmI8Ryk00xQHcWgFX3LSFa07OcKqzmCNHC4cYLQwcnLGAN7BwMHA6ivPgQn9PZgJ9uaXGW/8wBkZr4NwZj34hvsRSdkQWOzzj4idikluYKFl50qUlwJqIPC/lOchFOrBozGMpIyRqw1vWjjbMdQSnVJMkeN9nOKT3YZDFk2vtpdTty3svx7s25t0gOykdC2n6PM/Rdl0fZElBmuEyxyjnlBilwWwHWUpZptkOadQxQFqUg651qYEVU/aLTpEamilrJi2nH2Q49fPVQEf/5qWAAQbLa/qAlwYiNEsKfZBl0Y0rvT+tl/T+9Nx+hp87XL9Rt3Va9vTov/PSNkjPLxt+7umWIelf12Bf1FGk9vsew+eGy5ga2NCaLCnYJ9tdpukDZ/q5YSkwZZbWXdqXpA5Myh66rbR/pfdHPW6WyXw1uNMfLYAzBk0116DSCIg6Cmn67rqt9p59FtL3NkD/nvTc8s9I3xER48kYs+lM9qM9s5bgBLQrW6tdivLMwaRjPsg8EIFojHST8x3K3GGUZ1hbG8NJsolm4RgYI+83kAyYzksNoKqSv9+Zdi2zVjLVUvfKmAJdMBpoM/AhSncvHVEsSswJxkS4bBFcrKoW09kcXYhwRQkYi3PPPYC1tTGOHz8KIMK5HM7maFsJ0AIBIXo4V6Caz7G2vo4QFgXZnWbfyHEvI6XFKN3hrAZ3QvAoygJlUWoNSAkYpW518rlp2qgZRHLMp31SRnGTfcHrv3Vdw2uGUjr3IEaMyrIfec0YCTp1XYu1tTUEL0W3nRYaT4GfoEXwrXZH9Gk/10L0AJBnGar5XHeeKPWfgnSVln1J5lHkmtmVArNeBjwIIaKuK1grWadFUfTZ4RLAk/pQElBf1GKqawkMZ32tOqBpahR5IV2wYZDlGeq60YwwOX9YvfERNfDVaq2q9D1DCMiLAj/0g/8Wz2OGEtHdEoNKRIRzzjkHBw4ewtaJk/Ct1DxKF1JZLt1gmqbBfC5p+zHIqFVt06AoSkQdGjx1bcsLKULZ1JJCXtV136+/rirs7myjaZq+e1tT1zraSoumaTGbzTCb7aKta9SVjPTWVBW6tkE1n8M6qxeiUri0iwbR5Yj5BHG0gamd4PNbNT5143Fcc2wXWz5HhQxtkNHZjHbjc8ZKBoyRO7hyQT9oCOxj2E7Yzxdox53xBnGBL8p+6+cLz08b/ftOqM+l1/vp9pt2NWlZlz922M67vccdXQSjNYYMImxs8fSLL8LGKINvaqm5EQHnpJhu1MZO1EZpalD3/2rhLwlGycheRh8YNPi993L3Xet6pMZ9aqClC32vdZBSYyA1zv2grk56b5q3GXRvM5qplDKW0nPDZTFGChenu98SwFhk6KR5y3cComY/DoMEaboUQBguW/os6DpJj34ayD5jjZUuH1GCJ4vXAWmoSZHkqDWTUqM13fmXRqdufSMZL+m96fPS7xgEPYbLO+wUlb6LWQoSDQNNRrdlykZL3y0OAjNpPzH6c78sw2VK+kyFvQGflGHUb3ed/3DZ0u8pwJU+y1kJOAy/r0nH6WCbdJ129xx892T4vYJ2q5J1vDdbrv9ZFkAy34bTWCminhq8Jh0LbnGMhCjL74x0IXv3u96FssjgDKQ7jyxSv63i4D8MvmNMwUD9PXXblr+Hex/BSwBJtokEc2fTGRBlmSV4qfv/oMuX1/fluQR8rTGI0cNZA28sIgzqag4TI8bjEgZAkWeAkUymiHSsy7eRv7upi7l830wLW/sQ0HU6El4ArNEsISddU0M0CD5K5k2McNpNzjgj5zZrkGc5MpdhXlUI0eDkzg5aH6S7mrOACchzi6Zp0dQdrNHtbIDOy5DzzmZ9xkyh3XedBqAlnibnqpTt45xD2zYy6lqMMMbK4CIxIi8KhBhRlqP+fJdnuQSOAayvr6FtJLiSRmEzGgCVY97AuQxGA+IpINM0DYo+Myv0xcGbuu7/OKTgdF4U8t2hx+3gvOeyRVdNGMkET/u5tRblqOyzlNpGRnyzRs6VWZbt6X4XNfMzaLe9LMulzlaUAtpybMtIn1H3O2uM1peSDDavtZjS+U6CaNrl1Urh96ZptQaTHB9eg+3OOdlO2uVveG78qq/6KrzuJ38MX//Er9Oji4jubhhUIiIAwHgywf3u/wDM6wY7WyfkAkQvbmrNRGqaRfZRo6OAxBCkEHcnQ+WG4DGfz2CNhQ+ddKnTYZbbtkVd16jmM1TzOar5HHUl/3Ztg6ZtsLu7i7rS7nJtg8waGaVHu+ClC35jHaLN0MEBozWEcgNVtoabtltcdWQLN27VmMUCPp+gMzlgpFuDgTaU0l1YIyPfRKT6FouGzn4GbVWkdtPwccctGr/Dx35SQ+TOoNfDX7Tl9XGar9Tr74XLNfVt1kc/H12s/vEF5ntHLc/nNp9zmkc/8R1gtSFuDGBji2dcfBHWSgcLLcarF/eZs/DaTUIu9nXENs3uMFrPzGiGUdAh6VMAApAvlBpG6eJeGpWaKaWNeqTMEuU1wyk10lLjKTWKC/28NO/UuJOPlBVhNDMqG4xOl7Kf0nJFbYSn4E0c3GG31mmmwqIouNNuflEDDen5ZDnoMHwtPQcD2c/0Dj/SdOkOewoYyarvl8no2aCfrz4n6yDtDHs/M62zZUbPOXEQIFxmBoGaNI/l7zf82ekw7CnglN6bohLL62L4/PIyGuz9Lv3v6XUNQEUN5KTnoJ+b1l3/fv2MNG0cdJFM+9GQnIsXv6f9zAyWof9+aV3psZX2CasZJ6k+Tdr3rBY1Xt4szpq+ptKolELEwy5Ne5YhPZaesxpQ63830l3QDLojmTSM+2DZi0KCJVVdyUiCg8CcNNEXNQ1jjJp9I7X/Mg2gemPh9Ut1TYM8d7DOakFrgxglyBN8RIgSsGg7j6Io9VhbbPMICTLJMS1dxNK+aqxD20iwsdWBBWT76Qhz2kUt+IDgPTbW15HlOaq6xWxeYVbNkWWS0bO+NsH6+jrqqsZ0OkOWZSiLEiF45LkEk2CsDAyiB1lECsqZvm6Q0cLVXSfnC6m1pFmRel50zkrNJj1/FKUE3VIgyGhXSaeBF2j3fqlpJO9P87dGs5N0+6VtG3SkyKqqYDToJOc+SF0hDV5VVQU5FUlNJaOjytWaCW41Cy3Lc/hORo6LiPBeA2F5vrebs54XAamB1bZyvvVBgmZR95t07pX1lQZ+kEyolJ1qdLS6qMGoGOUmIbC4qZHr823boShytI2MgmeskRuLui5DSFmPqaA/8IJvfx5ex1HeiO72GFQioj0On38+zr/P/TCbV9jeOtEXapQR3DpYazCdzuCcxXS6i7Zt4INH2zaADjjfdR3m1Rzz2Qyz2QzzeSVFPLsOQYtqt22Ltm2ws70tWUq+w3R3B3VVSRc37RYXug7By2g01jnASgq/KUogH8FONtBmG7j62C4+fWQLN5xqMEOJxpRoo0OIBlm0cFFCSumCFNo1AAaINgJ2/64TQi5u+99uN1iSpr39x2nfrxfSy9PK0+k5yL97fv/SGHzqIvC2Xz2jfZbzdMtiNJy3/39L795/Fqex/O6V3rzPNrjNE7fL6PrZ89++6woIUbp4uNjhGZc8CRujDKFrEDT7KMaI4FvJCtAFSw1SaMMZg0BQ17b9F0gNnJRBGAcBiUXjZ5H5ElLXtaaRLCOtFWL1vZnWIhl+3nIwZ1+pgRpCn5GSglS+k8+3Vmq7+K7TrAvdP5yTxrVbfA+TAhPamD/dMqT5DlI8+vdBG+fOpQDDIqNpOJ1k36Q9Mu2Luk3189PzxkhjWmfQr7f0b1rC4bI6bTimdT/cHkNpO6fXUqNuOG1aLxrxkucG80i/D7/jntcG8xm+bgbBEQOZfVxaprRP9etSp9l3neq/ab3IMqcCzIsMruV1YMyedJ2FQXYWdJ2m7B3JpNk7v+FyQGc5XBPOGNTVDO9+17swLnNYra0T0/rU5e0Nfk+N9sVLe9fx8nP9cqf1ZAzGo5HUr2llhK+IKKO92UVgK70nxoBRWeo6MDKKWoT8TYwAEDCvKpTlCDEaGTHNyWiFBkDTdMgzCUx0qRYSJEsFGiwKup4CIHWoYOCD/Nw2MhBGXdeIRuoHSeDGSTcyDQKVZSnnFR8RADRdi6ZtsL0764Pno9EIiMDBgwexvb0tOWAxwLpcriAiAD3uYpTljIiSEaf7T9e2ElzRfaltWwkwal0sqTUUUJYy2mXw0q1Phrx3fc0fyfSU848BNINR1rv3i2NVzmESeAFkvbetFPX22sW/KEvMdWCRdC5sWymgnTKV5LiXYuLDoHznu77+UIgSZGy1fuViflI4G7r/xBgxKkdyE0+vi9q2w2is+5WX4JkUzZZsPWtlNDoYvdmhXeuM1mLqug5lOZJ6Slku2el9F1QjNxeidK3LdUS7rmsxGpUauJLRBouiwLOe+S/w2lf9KJ7y5CfKfkxEd2sm7veXkIhI765d89mr8flrP4fp9hacpqRnWYbpdBdy7a8FO7W2htyRW3S1ybIMbedRV5JpJMPntqirOaa7EpQKXoJNcjEodztjjIihgwVgUj0BYwHjkBcFumyCypQ4emqKz95wFDuNgc/G6GwB2EwaGgYwiNrQN3LBalLoq2859C0yE81thxrH3raNnDHlgnu5zbO6/Waw+il572n8tvNcZTm/QO+/PfZZVfu6I/NMDSitVrPkDszgiyDrLWWyfDlFtF0DY4DCz/DTr3o5Ltgs4UKDNgTJKMgzxK5GgFz49w0Z7RqRGvLSSFjq8jNoRMeUBZIa9br20vu99yiLoh+FJwUHnJUuI6kRnunob8PPj9qoTo3ioHf7oy5DHGQexUH3qRgkUyLNY7jsNo2MJF9EGpeDuj5pXiZtr8HOnOaV1snwOEjLJbOVjIU0AtYwQJXmO1yHRrvJyesyp/Q5MS66XAXfyafo+ul05KhkON8kLWc6Rw4ZzQJN7zGDWlEYzC9qF5q03tNr6T1Dy98xDn5O80rrYnnZ078Gi9H2om7jtFzD+fQPvQGQnh9+nzRPCQDsPa7T65lzUpNlMNJc/zmDwOny8kAz7rz3KEsZJSyGoPVx9Pw/OG9bBOxuncAPfN/34pzNCXIr9Xn6/Ub/HbrNmSitp/7nwclkuD9qzFN2YRmVLUapT3TzkVv0eEw3CjQIB/S1czITsbk+wcZkBBM9EDx8F+VvIoDoWyB6rI1KfMX55+H8cw/gvAObyE1EmTm0UQIX0OPB6DEsn7fo9ihZVlFqoEULH4EQgflsjqLIZV83BtZp93FrEAxQlDL6WWg7dHWHAItZ2+G6W27GDceO4ZaTNawrcPjw+Th08BDOO+887OzuYF5V2JnOMF7fRISDsVmfWQatu+Y7j7zI4X1AU9dwqYuqBq697/q6dN4HGTVPu2U1WmQ7TdN1cmMsRgmmpEzP0ajUG10dRmWJuql1H5Jum1kmteskmNT0XXoXmWtA10m2lRwDcl5YW1vDbDrVDNNFl7C0vlNQLGXZGc3azLQgeFEU6LRourUWRVFoJpYE2+qmxmg0QtO0mEwmiEGCi845jEYlus73WV+phlRZSr0peU7OLWVZomvbfp+TG4gWRSHbFXr8paCedP2VrKu0/3jf4WEPfRie+ISvw7969jNx7jkHQET3HAwqEdEdsrOzi5tuuAHHb70VJ47diuBbbJ08iSyzqAc1k2KQNPXhRVNVN4h6QdN2HZpqju1TWwhe0sTnM6mb5JwMO26hjUuXmnQGMBY2y2HzAj5EXHOiwudPtagajwYZWmQw+QhddAiApHobgxg8gtZtACKkCoVc8MvZT+YNDTRpuOl2LbVtv0j7B6X2OyPrtdx+TRpgT4Nm0TD7YqUA0HA+p/sz8aUIKi0v737zPP1332fifafb3z9/O+735tt+vjHQhkhEHub46Vf+e1ywWcJ0FdoQYJ0EQbt6BtgMTkclMpCiuqnxbNL60sZAClD0rw1+txr4sBo4Qt89Qe6+p6CANJikYZMaGdamGi+LIEgaESl1w4PuF8s/R22kpe4ZMUqWkHTB0e4WqQ7H0ufJd4MM9Z0yrLyXzAQNMqRARvpMp93XlvejvYwc2SnbUevfpK5Ti+CdBr2cFhMfBNOssTqKk0wv3fck+N0HiiAb2yztBXFwbKbPGwaU9iy77pTpPcvzlkkWjdAU/NtvORKjJ5CoayItm9GGotcg/rC4e5+ZNfjM9BnpPennJE2T9oPh/mkHGUbp+f3WQZpnel/6bm7wfPpuZinIlNbd8vdPXXmCjnom8wFyC+xsncAPfN/34NzNCXIH5Hmx571f0KAbaJLevXg2yjm8f1Iyq6y1CDFga+sUtk/tIETpytT5qO+xiAjwXStF/C1w8MAGcid12hAAayXjRrZJBwSPCw4dxOEDazi0sY4DkxKZAapOtqnL5FwDSLAIRrKajNWgQ+gQYgdjHLyP8D6i87JvRK1tFGNEXmQo81yOKwu0voPvPIwPcFH+pk7bFluzXdx66hRuPNng+IltbK6fg0OHzkM5KnHBvc7Hzu42brr5FgSTYTw5AGMcXCb7pdPsRaPnsKhZSL6TLp+6W0uGTdvJ/m0gRaV1tNmiKAAYhOCROSkk37UtikJrIDUNogav0p+5dK4xkHNq0O5nTSu1hCQLSG6YLeodSUaSBO6ke7LvZJnS52Q6clsKIBoj3ffyLEPdNBiVJZq2lSxSzRR1zsp6NUZqOGlGZZZJ9niqmzcejftMsnQ+kxH2JCgr51kJ0i4CunKsSmZcOk9JjbQUtPJ6LnAaTCvyQrrY5QUOHjyIAwc28VX3/0p8zQO/Go999CNwrwsO93s9Ed2zMKhEREREREREREQr21spkYiIiIiIiIiI6A5gUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZQwqERERERERERHRyhhUIiIiIiIiIiKilTGoREREREREREREK2NQiYiIiIiIiIiIVsagEhERERERERERrYxBJSIiIiIiIiIiWhmDSkREREREREREtDIGlYiIiIiIiIiIaGUMKhERERERERER0coYVCIiIiIiIiIiopUxqERERERERERERCtjUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZQwqERERERERERHRyhhUIiIiIiIiIiKilTGoREREREREREREK2NQiYiIiIiIiIiIVsagEhERERERERERrYxBJSIiIiIiIiIiWhmDSkREREREREREtDIGlYiIiIiIiIiIaGUMKhERERERERER0coYVCIiIiIiIiIiopUxqERERERERERERCtjUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZWdsUOmtv/WbeNvv/d7y00RERERERHSG6boO//3tb8eLv+978Uv/5ZfRdd3yJER0N3TGBZVijPil//LL+O9vfzt+9/fehj98xzuWJyEiIiIiIgIAhBBw4uRJHDt+DCdOnkQIYXkSAMDu7i7qpl5+mr4Euq7Df/rFX8Rbf+s3ceTIEfzte96Dz37uc8uTEdHdkIkxxuUn70oxRvzcW96Mv/nbv+2fe+n3/wC+/fnP3zMdERERERF9eYQQsHXqFELw2NjYQFmUy5PcpUIIuPzyy/Hbv/s7+MxVV+0JJFlr8TUPehC+98Xfg8c85jGw1uITn/wEXv1TP4ULLrgAP//mN+PA5oE98/tyizHiz/7iz/G7b3sbTp48ufzySowxeOjXfi1+8lWvxuHDh5dfvtOlgNJf/c+/Qp7nsNYiyzL8hzf9LB7y4AcvT05EdzNnXKaSMQY/8WM/jqdcckn/3K/9xq8zY4mIiIiIzkgxRlxxxRX4xV/+JVxxxRU4w+7Zruzo0aN42Stejhd857/Bd373d+P53/Ed+Iv/9y/PmO91/Phx/NhP/ARe+ZOvxqc+/enbZCaFEPCpT38ar/zJV+Nlr3g5jhw5gq2tU5jP55jPZmjbds/0d4ZPXvlJ/Nqv//o/O6AE3d8+eeWV+OM/edfyS3e6YUBpc3MTL/3+H8Da2homkwkOHTy4PDkR3Q2dcZlKSQgBP/Ozb8L7/+7v+ueYsUREREREZ5p/uOwyXPqG16NtW+R5jktf+zo84fGPX57srFA3NV7/hjfgso9+FOvr68jzHFtbWxiNRnjTT/80Hv6why+/5U517bXX4rWvvxRHjhwBAHzFve+Nb/vWb8Xjvu5xGE/G6NoOH/v4x/HOP34nrr7mGgDAOeecg2d+wzfgD9/xDlxw/vn4z//pP+G8Q+ctzfnLJ8aIX/zlX8Kf/fmf4ztf8G/wv33f9y1Psq//9ge/j9/+nd/B937P9+C7v/O7+uc/8MEP4vVvfAOe/rSn49WvfOWe99yZlgNKr/zxnwAAvPbS1+GhX/tQ/Mwb34jRaLT8NiK6mznjMpUSay1+8lWvxpMuelL/HDOWiIiIiOhMc9Vnr+qzX9q2xVWfvWp5krPGkZuO4DNXXYVDhw7hl3/xF/H23/8DPPc5z8F8Psf/uvzy5cnvVDfffDMufeMbcOTIEYxGI7zsh38Yv/XW38Rzvu05uN/97ofzDp2He93rXvjGZz0L//ev/l947U+9Bmtra9ja2rpL2xDXXHstPvihD2FzcxNPe+pTl18+K+0XUHr84x6Hq6++Gl3X4cIL78eAEtE9xBkbVIIGll73mtcwsEREREREZ6zHPPox2NzcBABsbm7iMY9+zPIkZ422beG9x2Q8xmQ8gTEGk8kEAFBV1fLkd5oYI/7wHe/AjTfeiDzP8SMvfwX+5Td/C6zdvzljjMElF1+MN/30z/Tb5q7y3ve+F1tbW3j0ox6FCy+8cPnls87pAkoxxj6g+rUPecjy24jobuqM7f425L3Ha173Wlz20Y/2z7ErHBERERGdKW648QZc9dnP4kEPfCDue5/7Lr98Vrjm2mvwll/4BVx1lQQGvvLCC3Gf+9wH/+vyy+G9v0u79V199dX4sVf+BLa3t/E9L3oxvvu7vgvGmOXJAAAf/f8+ive8933975+56jO49tprAeBO7/524sQJ/OiP/xiO3HwzXvea1+KiJz5xeZLTuqu7v4UQ8OGPfAR//w//AO99//z111+HT33603sCSgCws7ODn3jVK3H1NdfgsY95DM49d/+aSs45PONpT8OjHvWo025DIjp77B/aP8M45/CGS1+PRz/60f1zzFgiIiIiojPFfe9zXzz9qU87KwNK0+kUv/hLv4T//Qd/EFdp17cDBw7guuuvx4c+/GHUdY3nP/d5eOxj7roMrA///Uewvb2Nw4cP4xnPeMZpgxGz+Rz/7ff/AH/1P/+qf6SA0l3hf11+OW648UZ89Vd9FR7+sIctv3xGe/ef/ile/8Y34C/+8i/2rM9PffrTAIBv/df/ug8oQQuo33r0KLz3uOyjH93znuHjL/7yL/Dq1/wUPvDBDw4+jYjOVu7SSy+9dPnJM1EIAe9///tx00039c899KEPxaMe+ag90xERERER3ZlijPj0Zz6Dv/jLv0RZljh06NBpgx5nkhAC/vpv/gavfs1P4ROf/ATKssSLvvuFePWrXoXnfOu34eEPfxguuugifO+LXoynPvWpcM4tz+JO0XUd3vnHf4wbbrgBj3/c4/DNz372addvnuc477xDcC7DV3/1V9/m8Y3PeiYe/rCHn/b9X0p1U+M33vpW3HzLzXjBd7wAj3zkI5cnuV3/+Il/xBUf+xge/ehH45GPeET//PWf/zze9/734QH3fwAuufjiPe/5Unrnu96Fa669Bs977nPxnG/7NlxyySW45JJLYK3Fddddh8c+5jF7lst7jwfc/wG4+OKL+2n3e5x//vn4xCc/CWvdl3X5iejOcVZkKnnv8dpLX7en+9u3P//5ePELX7RnOiIiIiKiO9tlH/0oXvGjP4Lf/b234RU/+iN7rlnPBHVT4x3v/CN830teghd/3/fiv/7ar+GTV16Jf/eyH8abf/4t2NnZwSMf8Ui89dd+Hd/1nd+JsigxHo/xhMc/AU9/6tNw4YUX3ilBmNNp2hY7OzsAgAc84AFfcFke93WPw4/9yI/s+3jWM5/1Bd//pXLVVVfhU5/+FO57n/vgKZdcsvzyWePhD3s4nv7Up/WPBzzgAcuTAAAOHTqEpz7lKXum3e9xV48gSERfWmd8UMl7j9e/8Y23CSi99Pt/YM90RERERER3hTN59Leu6/Arv/Kr+K+/9mu44cYbcOTIEbzjnX+Ef/+Kl+Oqq67CxsYGfvxHfwxv+bmfw/nnn7/8dvpn+Ju//VvM53Nc/OSLcfDg/vWF7ok+85nPAADW1qQAPBGd3c7ooFIIAa9/4xvx4Y98uH+OASUiIiIiOpM86IEPQp7ngHa/etADH7Q8yV3mmmuuwd998APY3NzEpa99Lf7zf/xPuPe97w0A+MZnPQtv++3fwTO/4RtOO4ramcAa0y/fsWPHll++Q/7hssvwkpf+AN79p+9efunLZjqdAQC+5mu+Zvmle6xbbr0V7/u792M8HuNfPOMZyy8T0VnojP3rEULAz/zsmxhQIiIiIqIz2uMf9zj8x5//Bbz4hS/Cf/z5X9hTvPiudsutt2J3dxePeuQj8aSLnoSHPfSheIwOfnPve98ba2try28544xGI1x44f0AANdeex1m8/nyJLer6zr8jz/7M1x//fX40Ec+grqplyf5svrEJz+B97zvvbf7eN/734/jx48vvxXQwOBw2k988hPLk5w1PvCBD+Cmm27CQx78EDzoQWdO8JWIvnhnZFApxoif+dk34f1/93f9cwwoEREREdGZyBiDhzz4wXjRC1+Ihzz4wXdazZ474oLzz8f6+jo+9vGP48Mf+TA+eeWVuPyKKwAAR44cwXQ6XX7LGemxj3ksjDH43NWf67tP3VGf/dzn8PF//DgA4PFf9ziURbk8yZfFJRdfjDzP8UfvfCfe9LM/e7uPX/2//y/U9d5gl/ceAPC+979/z7R/9M53whizp0j22WB3dxfvee97YIzBs575zDttOxDRl9cZF1SKMeLn3vJmBpSIiIiI6Kxxw4034D3vey9uuPGG5ZfuUg94wANwyZMvxvb2Ni59wxvw71/xchw5cgQA8P/+1V/hRd/7Pfiff/3XCCEsv/WM8shHPgIPfOADMZ/P8du/89vY3d1dnmRfu7u7+PXf+A1Mp1McPnwYT3rSk5Yn+bK5+MlPxlt+7s34l9/yLXjWM5+17+Pxj3scnHM4dPAgNjY2+vd+8EMfwjv/+I9hjMFDv/Zr97zn2d/0bLzuNa/FNz/72Xs+70z3iU9+Ep+7+mrc9z73wWMf85jll4noLOUuvfTSS5efvKtdfsXl/R0IBpSIiIiI6Ex25T/9E378la/EX//N3+A9730vHvHwR+Dw4cPLk90lrLV47Nc9FhsbG7jl5luwtr6Gb3rWN+KlP/BSfO7qq3HkyBF88EMfwsc//o94zKMffcZ2hxuVI2xubuJDH/4wbr7lFnz6M5/BRU94Isry9NkudVPjv/zKr+DDH/kwjDH4N9/xAjzpoouWJ/uyMcbg/MOHcdETn4gnf/3X7/vw3uMDH/wgHvHwh+Mb/sW/gDEGH/zQh/CWX/h5zGYzfNOzvhGv/anX4JKLL+7f86SLLsKF97vflz0j7u8+8AFce+21eNpTn4oLL7ywf/4fP/GPuOJjH8OjH/3oO5wt1XUdfudtv4trrr0Wz33Oc/DEJzxheRIiOkudcZlKxhj88L/7ITz3Oc9hQImIiIiIzniXX3E5tre3AQDb29u4/IrLlye5S5VFiec/93n4rbe+Fb/7W7+Nf/vSl+JhD30o/ssv/hJ+/Ed/DBsbG/j4P34cL3npD+D3/+APUDc15vM5/uGyf8B73vdeXH/99YgxLs/2Tnfxk5+MF37Xd8MYgyuuuAI/9LIfxj9cdtltsqxijPjklVfih1/2MvzPv/5rAMAzv+GZeP7znrdnujPBP33qU4AWe98voPTDP/RDyLJs+W1nneuvvx5XfOxjOHz4MJ7+tKcvv0xEZzETz4S/EEREREREZ6l/uOwyXPqG16NtW+R5jktf+zo84fGPX57sjDWdTvEbb30r/vwv/wIhBBw6dAhd1+HUqVOA3vT9N9/xArz4RS+6ywMcIQT897e/Hb/ztt/tg0mj0QhfeeGF+MqvvD+uu+5a3HjTTX33OGMMvvFZz8K/+z//zzOuhk9VVfjJ17wGV/7TlXjDpa9H0zRnVEDpTf/hP+A9730PXvHyl+8pPv+ud/0J3v6H/w9e8O3fgW/7tm/d857T+cN3vAPv/OM/xrd88zfjZT/0w1/2LCsiuvMwqERERERE9M8QY8THPvYxvO/v3o+nXvIUPOpRjzorG83XXHsN3vILv4CrrroKAPCVF16I+9znPvhfl18O7/0ZFSz7+D9+HL/yq7+Kq6+5Zvml3gXnn4/vf8n346lPecoZuT2OHj2Kl73i5fDe43nPfS5+/w/+4IwJKAHAb/7Wb+EP3v7fl5/+oo3HY7zpp38aD3/Yw5dfIqKzGINKREREREQEALj22mvxoz/x49jc2MDPv/ktOHjwIH73996Gt/3e751xpSlijLj55pvxvve/H5+/4QYcPXoUa2sT3Pe+98WTv/7J+JoHPQjWnnHVPnqf+vSn8cpXvwpd1yGEgK7rzpiAEgAcP34cb/mFn8flV1xxmy6Gqzp83nl4yf/2Ejzj6U8/IwN8RPTFY1CJiIiIiIiAQVApyzL8/JvfjPt8xX3wX3/91/BH73wnXvTCF+LFL3zR8lvoi5SCStPpFMaYMyqgRER0RzGoREREREREgI6Y9vo3vAGXffSjWF9fR57n2Nrawmg0YtelL7Gu6/Cbv/1b+MAHP4hv/qZn4/nPex4DSkR01mFQiYiIiIiIekePHsUbfuan8SkdmWw0GuEH/4//A9/0rG9k1yUiItqDQSUiIiIiItojhICtU6cQgsfGxsYZN3IaERGdGRhUIiIiIiIiIiKilZ25wyEQEREREREREdEZi0ElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZQwqERERERERERHRyhhUIiIiIiIiIiKilTGoREREREREREREK2NQiYiIiIiIiIiIVsagEhERERERERERrYxBJSIiIiIiIiIiWhmDSkREREREREREtDIGlYiIiIiIiIiIaGUMKhERERERERER0coYVCIiIiIiIiIiopUxqERERERERERERCtjUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZQwqERERERERERHRyhhUIiIiIiIiIiKilTGoREREREREREREK2NQiYiIiIiIiIiIVsagEhERERERERERrYxBJSIiIiIiIiIiWhmDSkREREREREREtDIGlYiIiIiIiIiIaGUMKhERERERERER0coYVCIiIiIiIiIiopUxqERERERERERERCtjUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERERERES0MgaViIiIiIiIiIhoZQwqERERERERERHRyhhUIiIiIiIiIiKilTGoREREREREREREK2NQiYiIiIiIiIiIVsagEhERERERERERrYxBJSIiIiIiIiIiWhmDSkREREREREREtDIGlYiIiIiIiIiIaGUMKhERERERERER0coYVCIiIiIiIiIiopUxqERERERERERERCtjUImIiIiIiIiIiFbGoBIREREREREREa2MQSUiIiIiIiIiIloZg0pERERERERERLQyBpWIiIiIiIiIiGhlDCoREREREREREdHKGFQiIiIiIiIiIqKVMahEREREREREREQrY1CJiIiIiIiIiIhWxqASERERERERERGtjEElIiIiIiIiIiJaGYNKRERERJ0K5VoAAAAMSURBVERERES0sv8fmMka5W6CUN8AAAAASUVORK5CYII=	1	1	\N	2026-04-18	active	10000.00	EGP	fixed_plus_commission	25.00	gross	1		\N		\N	مصر		2026-04-18 07:07:44.577517+00	2026-04-18 07:07:44.577517+00	\N	2	2
\.


--
-- Data for Name: erp_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.erp_users (id, name, username, email, pin, role, permissions, active, company_id, warehouse_id, safe_id, login_attempts, last_login, created_at, totp_secret, totp_enabled, totp_verified) FROM stdin;
1	Super Admin	superadmin	\N	$2b$10$einJ5Vk3LoQd1YlptoPqy.iGduUOaiLRfMNgbynu56n/2hkjJDh7G	super_admin	{}	t	\N	\N	\N	0	2026-04-19 18:23:39.565+00	2026-04-18 06:02:08.865545+00	\N	f	f
61	اشرف السيد	b250	\N	$2b$10$z8FItHLXvYLnx5ljaUSavuiFfo1LU.WR.6Bj5UFbr5XnMHAdLji4u	admin	{}	t	60	\N	\N	0	\N	2026-04-19 07:16:49.665135+00	\N	f	f
56	احمد	250	m@m.com	$2b$10$M/4KIRPGQLLDGvBsVDlC9e4YZLVp3SFHVHW0xvOzggIfM.9h4xMh.	admin	{"can_view_sales":true,"can_create_sale":true,"can_cash_sale":true,"can_partial_sale":true,"can_credit_sale":true,"can_return_sale":true,"can_cancel_sale":true,"can_edit_price":true,"can_view_purchases":true,"can_create_purchase":true,"can_cancel_purchase":true,"can_view_products":true,"can_manage_products":true,"can_view_inventory":true,"can_adjust_inventory":true,"can_view_customers":true,"can_manage_customers":true,"can_view_treasury":true,"can_view_expenses":true,"can_add_expense":true,"can_add_receipt_voucher":true,"can_add_payment_voucher":true,"can_close_shift":true,"can_view_reports":true,"can_manage_users":true}	t	55	\N	\N	0	\N	2026-04-18 08:30:13.872489+00	\N	f	f
62	صالح القناوي	m1_61	m1@m.com	$2b$10$A2s/GkbM3QTch9SkrnQ2j.6ggy/h6kU/GY5EWZR678Y3qEeDGymhW	admin	{}	t	61	\N	\N	0	2026-04-19 11:16:03.813+00	2026-04-19 11:15:16.491646+00	\N	f	f
2	المدير الافتراضي	admin	\N	$2b$10$g7wKOH4dWjlCSTD/OKzAnO7Ec8x4sB9lgC1KeY2598jzwuXojAsyy	admin	{}	t	1	\N	\N	0	2026-04-19 18:16:06.872+00	2026-04-18 06:02:08.952491+00	\N	f	f
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expense_categories (id, name, company_id, created_at) FROM stdin;
1	ااااا	1	2026-04-19 11:47:45.766818+00
2	250	1	2026-04-19 12:01:45.881189+00
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, amount, description, safe_id, safe_name, company_id, branch_id, created_at) FROM stdin;
1	general	100.00	اختبار	1	الخزينة الرئيسية	1	\N	2026-04-18 06:06:10.96056+00
2	general	100.00	test	1	الخزينة الرئيسية	1	\N	2026-04-18 06:06:40.296669+00
3	general	100.00	اختبار مغلق	1	الخزينة الرئيسية	1	\N	2026-04-18 06:07:02.556137+00
4	general	200.00	نفقة شهر فبراير	1	الخزينة الرئيسية	1	\N	2026-04-18 06:07:02.63684+00
68	ااااا	500.00	\N	1	الخزينة الرئيسية	1	\N	2026-04-19 11:47:54.394954+00
69	ااااا	1000.00	\N	1	الخزينة الرئيسية	1	\N	2026-04-19 12:01:29.075603+00
70	250	1500.00	\N	1	الخزينة الرئيسية	1	\N	2026-04-19 12:01:50.755582+00
\.


--
-- Data for Name: fiscal_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fiscal_years (id, company_id, year_label, start_date, end_date, is_open, is_current, closed_by, closed_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idempotency_keys (id, company_id, scope, key, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_metrics (id, incentive_rule_id, employee_id, metric_date, metric_value, source_document_id, source_type, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_rules (id, incentive_scheme_id, metric_type, target_value, incentive_amount, incentive_type, calculation_method, currency, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: incentive_schemes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_schemes (id, company_id, name_en, name_ar, description, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incentive_slabs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incentive_slabs (id, incentive_rule_id, slab_number, from_percentage, to_percentage, incentive_value, created_at) FROM stdin;
\.


--
-- Data for Name: income; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.income (id, source, amount, description, safe_id, safe_name, company_id, branch_id, created_at) FROM stdin;
1	عععع	10000.00	\N	1	الخزينة الرئيسية	1	\N	2026-04-19 11:48:17.881531+00
\.


--
-- Data for Name: job_titles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_titles (id, company_id, name_en, name_ar, created_at) FROM stdin;
1	1	نصاب	نصاب	2026-04-18 07:07:08.845667+00
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, entry_no, date, description, status, reference, total_debit, total_credit, company_id, created_at) FROM stdin;
1	JE-00001	2026-04-18	عكس تكلفة مرتجع مبيعات SR-1776492292015	posted	SR-1776492292015	300.00	300.00	1	2026-04-18 06:04:52.017896+00
2	JE-00002	2026-04-18	مصروف: general — اختبار	posted	EXP-1	100.00	100.00	1	2026-04-18 06:06:10.989003+00
3	JE-00003	2026-04-18	مصروف: general — test	posted	EXP-2	100.00	100.00	1	2026-04-18 06:06:40.303177+00
4	JE-00004	2026-04-18	مصروف: general — اختبار مغلق	posted	EXP-3	100.00	100.00	1	2026-04-18 06:07:02.564665+00
5	JE-00005	2026-04-18	مصروف: general — نفقة شهر فبراير	posted	EXP-4	200.00	200.00	1	2026-04-18 06:07:02.643639+00
66	JE-00006	2026-04-18	فاتورة مبيعات INV-1776492247852	posted	INV-1776492247852	800.00	800.00	1	2026-04-18 09:18:23.89819+00
67	JE-00007	2026-04-19	مصروف: ااااا	posted	EXP-68	500.00	500.00	1	2026-04-19 11:47:54.406857+00
68	JE-00008	2026-04-19	مصروف: ااااا	posted	EXP-69	1000.00	1000.00	1	2026-04-19 12:01:29.364198+00
69	JE-00009	2026-04-19	مصروف: 250	posted	EXP-70	1500.00	1500.00	1	2026-04-19 12:01:50.76419+00
\.


--
-- Data for Name: journal_entry_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entry_lines (id, entry_id, account_id, account_name, account_code, debit, credit, description) FROM stdin;
1	1	1	بضاعة المخزون	ASSET-INVENTORY	300.00	0.00	\N
2	1	2	تكلفة البضاعة المباعة	EXP-COGS	0.00	300.00	\N
3	2	3	مصروفات عمومية وإدارية	EXP-GENERAL	100.00	0.00	\N
4	2	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	100.00	\N
5	3	3	مصروفات عمومية وإدارية	EXP-GENERAL	100.00	0.00	\N
6	3	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	100.00	\N
7	4	3	مصروفات عمومية وإدارية	EXP-GENERAL	100.00	0.00	\N
8	4	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	100.00	\N
9	5	3	مصروفات عمومية وإدارية	EXP-GENERAL	200.00	0.00	\N
10	5	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	200.00	\N
98	66	54	إيرادات المبيعات	REV-SALES	0.00	500.00	\N
99	66	4	خزينة - الخزينة الرئيسية	SAFE-1	500.00	0.00	\N
100	66	2	تكلفة البضاعة المباعة	EXP-COGS	300.00	0.00	\N
101	66	1	بضاعة المخزون	ASSET-INVENTORY	0.00	300.00	\N
102	67	3	مصروفات عمومية وإدارية	EXP-GENERAL	500.00	0.00	\N
103	67	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	500.00	\N
104	68	3	مصروفات عمومية وإدارية	EXP-GENERAL	1000.00	0.00	\N
105	68	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	1000.00	\N
106	69	3	مصروفات عمومية وإدارية	EXP-GENERAL	1500.00	0.00	\N
107	69	4	خزينة - الخزينة الرئيسية	SAFE-1	0.00	1500.00	\N
\.


--
-- Data for Name: leave_accrual_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_accrual_history (id, employee_id, leave_type_id, accrued_days, month, created_at) FROM stdin;
\.


--
-- Data for Name: leave_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_approvals (id, leave_request_id, approver_id, status, comment, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: leave_blackout_dates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_blackout_dates (id, company_id, start_date, end_date, reason_en, reason_ar, created_at) FROM stdin;
\.


--
-- Data for Name: leave_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_policies (id, company_id, leave_type_id, entitlement_days_per_year, accrual_method, min_duration, max_consecutive_days, probation_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leave_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_requests (id, employee_id, leave_type_id, start_date, end_date, total_days, status, reason, rejection_reason, submitted_at, approved_by, approved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leave_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_types (id, company_id, name_en, name_ar, code, is_paid, requires_approval, carryover_allowed, carryover_limit, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: monthly_incentive_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monthly_incentive_summary (id, employee_id, month, total_accrued, included_in_payroll_record_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: overtime_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.overtime_records (id, employee_id, date, hours, reason, approved_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: payment_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_adjustments (id, payroll_record_id, adjustment_type, amount, reason, approved_by, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_line_items (id, payroll_record_id, component_name, component_type, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_periods (id, company_id, name, start_date, end_date, status, processed_by, processed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payroll_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_records (id, payroll_period_id, employee_id, gross_salary, total_allowances, total_deductions, tax_amount, net_salary, advance_deductions, incentive_amount, currency, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, category, category_id, quantity, cost_price, sale_price, low_stock_threshold, company_id, created_at, tax_rate) FROM stdin;
47	3333333	HT59075670612	\N	3	0.000	20.00	35.00	5	1	2026-04-19 09:25:56.943571+00	0.00
1	شاشة آيفون	IPH-001	\N	\N	9.000	300.00	500.00	\N	1	2026-04-18 06:03:09.529057+00	0.00
\.


--
-- Data for Name: public_holidays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.public_holidays (id, company_id, holiday_date, name_en, name_ar, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_items (id, purchase_id, product_id, product_name, quantity, unit_price, total_price, quantity_returned) FROM stdin;
46	46	1	شاشة آيفون	1.000	300.00	300.00	0.000
\.


--
-- Data for Name: purchase_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_return_items (id, return_id, product_id, product_name, quantity, unit_price, total_price, original_purchase_item_id, unit_cost_at_return, total_cost_at_return) FROM stdin;
\.


--
-- Data for Name: purchase_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_returns (id, request_id, return_no, purchase_id, customer_id, customer_name, total_amount, refund_type, safe_id, safe_name, date, reason, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchases (id, request_id, invoice_no, supplier_name, customer_id, customer_name, payment_type, total_amount, paid_amount, remaining_amount, status, posting_status, notes, date, company_id, branch_id, created_at, tax_amount, tax_rate) FROM stdin;
46	607558b3-35b9-4dc5-ac0a-7938adf717b1	PUR-1776590797017	111111	1	111111	credit	300.00	0.00	300.00	unpaid	draft	\N	2026-04-19	1	\N	2026-04-19 09:26:37.018473+00	0.00	0.00
\.


--
-- Data for Name: receipt_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receipt_vouchers (id, request_id, voucher_no, date, customer_id, customer_name, safe_id, safe_name, amount, posting_status, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, token_hash, user_id, used, revoked, expires_at, created_at, used_at) FROM stdin;
1	fe39affb5d4d1fbca50598641bbe9055221cd650bf236f3c080c74768234a6e2	2	f	f	2026-04-25 09:12:26.144+00	2026-04-18 09:12:26.145875+00	\N
2	60073a3a06e80dd813a81a9795824b6b261fd8ed589b97251ab8bb626e7ec6ee	2	f	f	2026-04-25 09:15:05.312+00	2026-04-18 09:15:05.312617+00	\N
3	c46b5367f88ed9e285e54c4479370bcf94824fd01212da688d3380032353f4ea	2	f	f	2026-04-25 09:29:59.13+00	2026-04-18 09:29:59.131334+00	\N
4	9a2ce8d1b5d4b2beecc10120197d258fe9e4fba93c4f445e0821d1bd05ebb1b4	2	f	f	2026-04-25 10:41:54.802+00	2026-04-18 10:41:54.803226+00	\N
5	5af9f8dbf51ad97ada61f166af87a9eeee7a47a4c6a607f0720316269280c5bc	2	f	f	2026-04-25 10:52:04.459+00	2026-04-18 10:52:04.460413+00	\N
6	ae668a18e5a41aec37ba6d046114991306b2c7dcd0d62e2a28c7c340dc41a6f3	2	f	f	2026-04-26 04:51:35.691+00	2026-04-19 04:51:35.692449+00	\N
7	7332e6c1e048f02f370a399d54d0126779b5727a11e7c0b8237b70a1e2dd3ff6	1	f	f	2026-04-26 05:00:42.649+00	2026-04-19 05:00:42.650366+00	\N
8	8592bb119bd79680f437c9df26a6e5fb9138547a9ccf8ec74577b20025fb73a8	1	f	f	2026-04-26 05:50:02.889+00	2026-04-19 05:50:02.890831+00	\N
9	96f5692fc313d8d6bf9755bea6aaef044f786998e9804e7db1b5e9d2e4e59161	1	f	f	2026-04-26 05:58:53.921+00	2026-04-19 05:58:53.922104+00	\N
10	56f27de1608dcff83625ac25f3fe942a265feb0b43966f2a1f3459af14d6aaf9	1	f	f	2026-04-26 06:22:10.259+00	2026-04-19 06:22:10.259841+00	\N
11	8d76dfb2e302e44992d4d8a06dc14c3222eeea17f89c06b60182554d126856c7	2	f	f	2026-04-26 06:39:51.688+00	2026-04-19 06:39:51.689774+00	\N
12	5d6298154a470ba73070ec46afb8a3c357d5b513f71a7c3ea900058a5ae9ab8b	1	f	f	2026-04-26 06:41:04.564+00	2026-04-19 06:41:04.565509+00	\N
13	d65240e813c3dca2eaae59436d9967a4142a3e232aceddf9fb90a0a4bc0fb081	2	f	f	2026-04-26 07:42:47.2+00	2026-04-19 07:42:47.201508+00	\N
14	dca1e96e0fbcdd370d93bfa624a9a2afe82a2cbc2f199f1ddf21303718665e31	2	f	f	2026-04-26 10:30:24.213+00	2026-04-19 10:30:24.214352+00	\N
15	b066a067a734ba05a53290b53dbf5a6767de7a435a4e6406d21333a03fed39ec	62	f	f	2026-04-26 11:15:41.352+00	2026-04-19 11:15:41.353257+00	\N
16	b8480e94a35663de8cc6053adfadac768fa5629720dac3f3fa8dafcd22b7fc4a	62	f	f	2026-04-26 11:16:03.813+00	2026-04-19 11:16:03.813805+00	\N
17	be52c41f0190ed6dfe551b4d9a9a422b7426cffc4d772cae25991c94b087acc1	2	f	f	2026-04-26 11:16:56.986+00	2026-04-19 11:16:56.987383+00	\N
18	422c87002b5bbb69045642ba297b57f0b01b72e2a3cb04c0bc01685b921760aa	2	f	f	2026-04-26 16:00:18.045+00	2026-04-19 16:00:18.045533+00	\N
19	c0dcf147b958d017cf036ebb7d43541f8305d64a3d9c4d3ae7e2a1e020ec8daf	2	f	f	2026-04-26 17:16:59.391+00	2026-04-19 17:16:59.391838+00	\N
20	c9064c77b23d79fb72469d3e66f53c9e0537044588aa709504e3cb22b10c747c	2	f	f	2026-04-26 18:16:06.872+00	2026-04-19 18:16:06.872951+00	\N
21	417274c5006829beed8adb1dd3a2372509eca2a1812e105cc8a05ae5bab82d9f	1	f	f	2026-04-26 18:21:12.958+00	2026-04-19 18:21:12.959402+00	\N
22	d95d453e0ddc757262d7339417cb34f6726797b0bfcc440b1f48833f40886184	1	f	f	2026-04-26 18:23:39.565+00	2026-04-19 18:23:39.566289+00	\N
\.


--
-- Data for Name: safe_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.safe_transfers (id, from_safe_id, from_safe_name, to_safe_id, to_safe_name, amount, notes, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: safes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.safes (id, name, balance, company_id, branch_id, created_at) FROM stdin;
2	الخزينة الرئيسية	10000.00	1	2	2026-04-18 06:03:34.476599+00
1	الخزينة الرئيسية	12000.00	1	\N	2026-04-18 06:03:09.473379+00
\.


--
-- Data for Name: salary_advance_deductions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_deductions (id, salary_advance_id, payroll_record_id, deduction_amount, deduction_date, notes, created_at) FROM stdin;
1	1	\N	500.00	2026-04-18	دفعة يدوية	2026-04-18 07:08:27.088181+00
\.


--
-- Data for Name: salary_advance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_history (id, salary_advance_id, old_status, new_status, changed_by, comment, changed_at) FROM stdin;
1	1	\N	pending	2	طلب سلفة جديدة	2026-04-18 07:08:07.72589+00
2	1	pending	active	2	اعتماد السلفة	2026-04-18 07:08:09.960681+00
3	1	active	completed	2	تم السداد الكامل	2026-04-18 07:08:27.095009+00
\.


--
-- Data for Name: salary_advance_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_ledger (id, employee_id, advance_id, ledger_type, amount, balance, ledger_date, notes, created_at) FROM stdin;
1	1	1	advance_granted	500.00	500.00	2026-04-18	\N	2026-04-18 07:08:09.963097+00
2	1	1	manual_payment	500.00	0.00	2026-04-18	\N	2026-04-18 07:08:27.088181+00
\.


--
-- Data for Name: salary_advance_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advance_settings (id, company_id, max_advance_percentage, max_concurrent_advances, min_salary_for_advance, repayment_tenure_months, requires_approval, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_advances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_advances (id, employee_id, requested_date, requested_amount, approved_amount, advance_type, reason, status, approver_id, approved_at, rejection_reason, remaining_balance, currency, deduct_from, safe_id, created_at, updated_at, company_id) FROM stdin;
1	1	2026-04-18	500.00	500.00	personal	22222	completed	2	2026-04-18 07:08:09.956+00	\N	0.00	EGP	fixed	1	2026-04-18 07:08:07.677968+00	2026-04-18 07:08:27.088+00	1
\.


--
-- Data for Name: salary_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_components (id, salary_structure_id, component_type, name_en, name_ar, amount, percentage_of_base, is_mandatory, is_taxable, sequence, created_at) FROM stdin;
\.


--
-- Data for Name: salary_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_history (id, employee_id, salary_amount, currency, effective_date, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: salary_structures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_structures (id, company_id, name_en, name_ar, base_salary, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_items (id, sale_id, product_id, product_name, quantity, unit_price, total_price, cost_price, cost_total, quantity_returned) FROM stdin;
1	1	1	شاشة آيفون	1.000	500.00	500.00	300.0000	300.0000	1.000
47	47	1	شاشة آيفون	1.000	500.00	500.00	300.0000	300.0000	0.000
48	48	1	شاشة آيفون	1.000	500.00	500.00	300.0000	300.0000	0.000
\.


--
-- Data for Name: sale_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_return_items (id, return_id, product_id, product_name, quantity, unit_price, total_price, original_sale_item_id, unit_cost_at_return, total_cost_at_return) FROM stdin;
1	1	1	شاشة آيفون	1.000	500.00	500.00	1	300.0000	300.0000
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, request_id, invoice_no, customer_name, customer_id, payment_type, total_amount, paid_amount, remaining_amount, status, posting_status, safe_id, safe_name, warehouse_id, warehouse_name, salesperson_id, salesperson_name, discount_percent, discount_amount, notes, date, user_id, company_id, branch_id, created_at, tax_amount, tax_rate) FROM stdin;
1	\N	INV-1776492247852	\N	\N	cash	500.00	500.00	0.00	paid	posted	1	الخزينة الرئيسية	1	المستودع الرئيسي	\N	\N	0.00	0.00	\N	2026-04-18	2	1	\N	2026-04-18 06:04:07.852867+00	0.00	0.00
47	\N	INV-1776590636323	\N	\N	cash	500.00	500.00	0.00	paid	draft	1	الخزينة الرئيسية	1	المستودع الرئيسي	2	المدير الافتراضي	0.00	0.00	\N	2026-04-19	2	1	\N	2026-04-19 09:23:56.323885+00	0.00	0.00
48	\N	INV-1776590675764	111111	1	credit	500.00	0.00	500.00	unpaid	draft	\N	\N	1	المستودع الرئيسي	2	المدير الافتراضي	0.00	0.00	\N	2026-04-19	2	1	\N	2026-04-19 09:24:35.765083+00	0.00	0.00
\.


--
-- Data for Name: sales_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_returns (id, request_id, return_no, sale_id, customer_id, customer_name, total_amount, refund_type, safe_id, safe_name, date, reason, notes, user_id, warehouse_id, company_id, created_at) FROM stdin;
1	\N	SR-1776492292015	1	\N	\N	500.00	cash	1	الخزينة الرئيسية	2026-04-18	منتج معيب	\N	2	\N	1	2026-04-18 06:04:52.017896+00
\.


--
-- Data for Name: shift_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_schedules (id, company_id, name_en, name_ar, start_time, end_time, break_duration, grace_minutes, weekly_hours, working_days, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: statutory_contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statutory_contributions (id, company_id, contribution_type, name_ar, name_en, employee_percentage, employer_percentage, is_mandatory, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_count_items (id, session_id, product_id, system_qty, physical_qty, notes, created_at) FROM stdin;
\.


--
-- Data for Name: stock_count_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_count_sessions (id, warehouse_id, status, notes, company_id, created_by, applied_at, created_at) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, product_id, product_name, movement_type, quantity, quantity_before, quantity_after, unit_cost, reference_type, reference_id, reference_no, notes, date, warehouse_id, company_id, branch_id, created_at) FROM stdin;
1	1	شاشة آيفون	opening_balance	10.000	0.000	10.000	300.0000	opening_balance	\N	OB-1	رصيد افتتاحي	2026-04-18	1	1	\N	2026-04-18 06:03:09.532398+00
2	1	شاشة آيفون	sale	-1.000	10.000	9.000	300.0000	sale	1	INV-1776492247852	فاتورة مبيعات	2026-04-18	1	1	\N	2026-04-18 06:04:07.852867+00
3	1	شاشة آيفون	sale_return	1.000	9.000	10.000	300.0000	sale_return	1	SR-1776492292015	مرتجع مبيعات	2026-04-18	1	1	\N	2026-04-18 06:04:52.017896+00
61	1	شاشة آيفون	sale	-1.000	10.000	9.000	300.0000	sale	47	INV-1776590636323	فاتورة مبيعات	2026-04-19	1	1	\N	2026-04-19 09:23:56.323885+00
62	1	شاشة آيفون	sale	-1.000	9.000	8.000	300.0000	sale	48	INV-1776590675764	مبيعات لـ 111111	2026-04-19	1	1	\N	2026-04-19 09:24:35.765083+00
63	1	شاشة آيفون	purchase	1.000	8.000	9.000	300.0000	purchase	46	PUR-1776590797017	مشتريات من 111111	2026-04-19	1	1	\N	2026-04-19 09:26:37.018473+00
\.


--
-- Data for Name: stock_transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfer_items (id, transfer_id, product_id, product_name, quantity, unit_cost, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_transfers (id, from_warehouse_id, to_warehouse_id, status, notes, company_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, company_id, value, updated_at) FROM stdin;
\.


--
-- Data for Name: tax_brackets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tax_brackets (id, company_id, fiscal_year, min_salary, max_salary, tax_rate, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, type, reference_type, reference_id, safe_id, safe_name, customer_id, customer_name, amount, direction, description, date, company_id, created_at) FROM stdin;
1	sale_cash	sale	1	1	الخزينة الرئيسية	\N	\N	500.00	in	فاتورة مبيعات INV-1776492247852	2026-04-18	1	2026-04-18 06:04:07.852867+00
2	sale_return	sale_return	1	1	الخزينة الرئيسية	\N	\N	500.00	out	مرتجع مبيعات نقدي SR-1776492292015	2026-04-18	1	2026-04-18 06:04:52.017896+00
3	expense	expense	1	1	الخزينة الرئيسية	\N	\N	100.00	out	اختبار	2026-04-18	1	2026-04-18 06:06:10.96056+00
4	expense	expense	2	1	الخزينة الرئيسية	\N	\N	100.00	out	test	2026-04-18	1	2026-04-18 06:06:40.296669+00
5	expense	expense	3	1	الخزينة الرئيسية	\N	\N	100.00	out	اختبار مغلق	2026-04-18	1	2026-04-18 06:07:02.556137+00
6	expense	expense	4	1	الخزينة الرئيسية	\N	\N	200.00	out	نفقة شهر فبراير	2026-04-18	1	2026-04-18 06:07:02.63684+00
142	custody_grant	employee_custody	1	1	الخزينة الرئيسية	\N	\N	5000.00	out	صرف عهدة للموظف صالح المليجي — 6	2026-04-18	1	2026-04-18 09:22:55.287826+00
143	sale_cash	sale	47	1	الخزينة الرئيسية	\N	\N	500.00	in	فاتورة مبيعات INV-1776590636323	2026-04-19	1	2026-04-19 09:23:56.323885+00
144	sale_credit	sale	48	\N	\N	1	111111	500.00	none	فاتورة مبيعات INV-1776590675764	2026-04-19	1	2026-04-19 09:24:35.765083+00
145	purchase_credit	purchase	46	\N	\N	1	111111	300.00	out	مشتريات آجل من 111111 — فاتورة PUR-1776590797017	2026-04-19	1	2026-04-19 09:26:37.018473+00
146	expense	expense	68	1	الخزينة الرئيسية	\N	\N	500.00	out	ااااا	2026-04-19	1	2026-04-19 11:47:54.394954+00
147	income	income	1	1	الخزينة الرئيسية	\N	\N	10000.00	in	عععع	2026-04-19	1	2026-04-19 11:48:17.881531+00
148	expense	expense	69	1	الخزينة الرئيسية	\N	\N	1000.00	out	ااااا	2026-04-19	1	2026-04-19 12:01:29.075603+00
149	expense	expense	70	1	الخزينة الرئيسية	\N	\N	1500.00	out	250	2026-04-19	1	2026-04-19 12:01:50.755582+00
\.


--
-- Data for Name: treasury_vouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treasury_vouchers (id, voucher_no, type, safe_id, safe_name, amount, party_name, description, category, company_id, created_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, name, address, company_id, branch_id, created_at) FROM stdin;
49	33333	55555	1	1	2026-04-19 11:21:39.073191+00
1	المستودع الرئيسي	\N	1	1	2026-04-18 06:03:09.414906+00
\.


--
-- Data for Name: warranty_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warranty_records (id, company_id, sale_id, product_id, product_name, customer_id, customer_name, customer_phone, serial_number, device_model, warranty_months, warranty_start, warranty_end, status, notes, created_at) FROM stdin;
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.accounts_id_seq', 54, true);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, true);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_records_id_seq', 1, false);


--
-- Name: attendance_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_summary_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 59, true);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backups_id_seq', 3, true);


--
-- Name: branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branches_id_seq', 3, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 3, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 61, true);


--
-- Name: customer_classifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_classifications_id_seq', 1, true);


--
-- Name: customer_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_ledger_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, true);


--
-- Name: daily_incentive_accrual_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_incentive_accrual_id_seq', 1, false);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, true);


--
-- Name: deposit_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deposit_vouchers_id_seq', 1, false);


--
-- Name: employee_bonuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_bonuses_id_seq', 1, true);


--
-- Name: employee_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_contacts_id_seq', 1, false);


--
-- Name: employee_custody_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_custody_id_seq', 1, true);


--
-- Name: employee_custody_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_custody_lines_id_seq', 1, false);


--
-- Name: employee_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_documents_id_seq', 1, false);


--
-- Name: employee_incentive_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_incentive_assignments_id_seq', 1, false);


--
-- Name: employee_leave_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_leave_balances_id_seq', 1, false);


--
-- Name: employee_shift_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_shift_assignments_id_seq', 1, false);


--
-- Name: employee_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_status_history_id_seq', 1, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 1, true);


--
-- Name: erp_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erp_users_id_seq', 62, true);


--
-- Name: expense_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expense_categories_id_seq', 2, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.expenses_id_seq', 70, true);


--
-- Name: fiscal_years_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fiscal_years_id_seq', 1, false);


--
-- Name: idempotency_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.idempotency_keys_id_seq', 1, false);


--
-- Name: incentive_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_metrics_id_seq', 1, false);


--
-- Name: incentive_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_rules_id_seq', 1, false);


--
-- Name: incentive_schemes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_schemes_id_seq', 1, false);


--
-- Name: incentive_slabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incentive_slabs_id_seq', 1, false);


--
-- Name: income_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.income_id_seq', 1, true);


--
-- Name: job_titles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_titles_id_seq', 1, true);


--
-- Name: journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entries_id_seq', 69, true);


--
-- Name: journal_entry_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journal_entry_lines_id_seq', 107, true);


--
-- Name: leave_accrual_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_accrual_history_id_seq', 1, false);


--
-- Name: leave_approvals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_approvals_id_seq', 1, false);


--
-- Name: leave_blackout_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_blackout_dates_id_seq', 1, false);


--
-- Name: leave_policies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_policies_id_seq', 1, false);


--
-- Name: leave_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_requests_id_seq', 1, false);


--
-- Name: leave_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_types_id_seq', 1, false);


--
-- Name: monthly_incentive_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.monthly_incentive_summary_id_seq', 1, false);


--
-- Name: overtime_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.overtime_records_id_seq', 1, false);


--
-- Name: payment_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_vouchers_id_seq', 1, false);


--
-- Name: payroll_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_adjustments_id_seq', 1, false);


--
-- Name: payroll_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_line_items_id_seq', 1, false);


--
-- Name: payroll_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_periods_id_seq', 1, false);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_records_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 47, true);


--
-- Name: public_holidays_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.public_holidays_id_seq', 1, false);


--
-- Name: purchase_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_items_id_seq', 46, true);


--
-- Name: purchase_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_return_items_id_seq', 1, false);


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_returns_id_seq', 1, false);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchases_id_seq', 46, true);


--
-- Name: receipt_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.receipt_vouchers_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 22, true);


--
-- Name: safe_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.safe_transfers_id_seq', 63, true);


--
-- Name: safes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.safes_id_seq', 60, true);


--
-- Name: salary_advance_deductions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_deductions_id_seq', 1, true);


--
-- Name: salary_advance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_history_id_seq', 3, true);


--
-- Name: salary_advance_ledger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_ledger_id_seq', 2, true);


--
-- Name: salary_advance_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advance_settings_id_seq', 1, false);


--
-- Name: salary_advances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_advances_id_seq', 1, true);


--
-- Name: salary_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_components_id_seq', 1, false);


--
-- Name: salary_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_history_id_seq', 1, false);


--
-- Name: salary_structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_structures_id_seq', 1, false);


--
-- Name: sale_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_items_id_seq', 48, true);


--
-- Name: sale_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_return_items_id_seq', 1, true);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_id_seq', 48, true);


--
-- Name: sales_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_returns_id_seq', 1, true);


--
-- Name: shift_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shift_schedules_id_seq', 1, false);


--
-- Name: statutory_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statutory_contributions_id_seq', 1, false);


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_count_items_id_seq', 1, false);


--
-- Name: stock_count_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_count_sessions_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 63, true);


--
-- Name: stock_transfer_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfer_items_id_seq', 1, false);


--
-- Name: stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_transfers_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 8, true);


--
-- Name: tax_brackets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tax_brackets_id_seq', 1, false);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 149, true);


--
-- Name: treasury_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.treasury_vouchers_id_seq', 1, false);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 49, true);


--
-- Name: warranty_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.warranty_records_id_seq', 1, false);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: attendance_records attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_pkey PRIMARY KEY (id);


--
-- Name: attendance_summary attendance_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary
    ADD CONSTRAINT attendance_summary_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: customer_classifications customer_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications
    ADD CONSTRAINT customer_classifications_pkey PRIMARY KEY (id);


--
-- Name: customer_ledger customer_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_pkey PRIMARY KEY (id);


--
-- Name: customers customers_customer_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_code_unique UNIQUE (customer_code);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: deposit_vouchers deposit_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers
    ADD CONSTRAINT deposit_vouchers_pkey PRIMARY KEY (id);


--
-- Name: employee_bonuses employee_bonuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_pkey PRIMARY KEY (id);


--
-- Name: employee_contacts employee_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts
    ADD CONSTRAINT employee_contacts_pkey PRIMARY KEY (id);


--
-- Name: employee_custody_lines employee_custody_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_pkey PRIMARY KEY (id);


--
-- Name: employee_custody employee_custody_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_pkey PRIMARY KEY (id);


--
-- Name: employee_documents employee_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_pkey PRIMARY KEY (id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_leave_balances employee_leave_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_pkey PRIMARY KEY (id);


--
-- Name: employee_shift_assignments employee_shift_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_status_history employee_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history
    ADD CONSTRAINT employee_status_history_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: erp_users erp_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users
    ADD CONSTRAINT erp_users_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: fiscal_years fiscal_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: incentive_metrics incentive_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_pkey PRIMARY KEY (id);


--
-- Name: incentive_rules incentive_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules
    ADD CONSTRAINT incentive_rules_pkey PRIMARY KEY (id);


--
-- Name: incentive_schemes incentive_schemes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes
    ADD CONSTRAINT incentive_schemes_pkey PRIMARY KEY (id);


--
-- Name: incentive_slabs incentive_slabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs
    ADD CONSTRAINT incentive_slabs_pkey PRIMARY KEY (id);


--
-- Name: income income_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_pkey PRIMARY KEY (id);


--
-- Name: job_titles job_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles
    ADD CONSTRAINT job_titles_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_lines journal_entry_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id);


--
-- Name: leave_accrual_history leave_accrual_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_pkey PRIMARY KEY (id);


--
-- Name: leave_approvals leave_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_pkey PRIMARY KEY (id);


--
-- Name: leave_blackout_dates leave_blackout_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates
    ADD CONSTRAINT leave_blackout_dates_pkey PRIMARY KEY (id);


--
-- Name: leave_policies leave_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_pkey PRIMARY KEY (id);


--
-- Name: leave_requests leave_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_pkey PRIMARY KEY (id);


--
-- Name: leave_types leave_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_pkey PRIMARY KEY (id);


--
-- Name: monthly_incentive_summary monthly_incentive_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary
    ADD CONSTRAINT monthly_incentive_summary_pkey PRIMARY KEY (id);


--
-- Name: overtime_records overtime_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records
    ADD CONSTRAINT overtime_records_pkey PRIMARY KEY (id);


--
-- Name: payment_vouchers payment_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers
    ADD CONSTRAINT payment_vouchers_pkey PRIMARY KEY (id);


--
-- Name: payroll_adjustments payroll_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments
    ADD CONSTRAINT payroll_adjustments_pkey PRIMARY KEY (id);


--
-- Name: payroll_line_items payroll_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items
    ADD CONSTRAINT payroll_line_items_pkey PRIMARY KEY (id);


--
-- Name: payroll_periods payroll_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_pkey PRIMARY KEY (id);


--
-- Name: payroll_records payroll_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: public_holidays public_holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays
    ADD CONSTRAINT public_holidays_pkey PRIMARY KEY (id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_return_items purchase_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_returns purchase_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: receipt_vouchers receipt_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers
    ADD CONSTRAINT receipt_vouchers_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_unique UNIQUE (token_hash);


--
-- Name: safe_transfers safe_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers
    ADD CONSTRAINT safe_transfers_pkey PRIMARY KEY (id);


--
-- Name: safes safes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes
    ADD CONSTRAINT safes_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_deductions salary_advance_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions
    ADD CONSTRAINT salary_advance_deductions_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_history salary_advance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history
    ADD CONSTRAINT salary_advance_history_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_ledger salary_advance_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_pkey PRIMARY KEY (id);


--
-- Name: salary_advance_settings salary_advance_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings
    ADD CONSTRAINT salary_advance_settings_pkey PRIMARY KEY (id);


--
-- Name: salary_advances salary_advances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_pkey PRIMARY KEY (id);


--
-- Name: salary_components salary_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_pkey PRIMARY KEY (id);


--
-- Name: salary_history salary_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history
    ADD CONSTRAINT salary_history_pkey PRIMARY KEY (id);


--
-- Name: salary_structures salary_structures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures
    ADD CONSTRAINT salary_structures_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sale_return_items sale_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sales_returns sales_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_pkey PRIMARY KEY (id);


--
-- Name: shift_schedules shift_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules
    ADD CONSTRAINT shift_schedules_pkey PRIMARY KEY (id);


--
-- Name: statutory_contributions statutory_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions
    ADD CONSTRAINT statutory_contributions_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_count_sessions stock_count_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_transfer_items stock_transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_pkey PRIMARY KEY (id);


--
-- Name: stock_transfers stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tax_brackets tax_brackets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets
    ADD CONSTRAINT tax_brackets_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_vouchers treasury_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers
    ADD CONSTRAINT treasury_vouchers_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: warranty_records warranty_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warranty_records
    ADD CONSTRAINT warranty_records_pkey PRIMARY KEY (id);


--
-- Name: accounts_code_company_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_code_company_uidx ON public.accounts USING btree (code, company_id);


--
-- Name: accounts_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_company_id_idx ON public.accounts USING btree (company_id);


--
-- Name: accounts_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_is_active_idx ON public.accounts USING btree (is_active);


--
-- Name: accounts_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_parent_id_idx ON public.accounts USING btree (parent_id);


--
-- Name: accounts_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounts_type_idx ON public.accounts USING btree (type);


--
-- Name: alerts_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_idx ON public.alerts USING btree (created_at);


--
-- Name: alerts_is_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_is_read_idx ON public.alerts USING btree (is_read);


--
-- Name: alerts_is_resolved_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_is_resolved_idx ON public.alerts USING btree (is_resolved);


--
-- Name: alerts_role_target_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_role_target_idx ON public.alerts USING btree (role_target);


--
-- Name: alerts_type_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_ref_idx ON public.alerts USING btree (type, reference_id);


--
-- Name: att_summary_emp_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX att_summary_emp_month_idx ON public.attendance_summary USING btree (employee_id, month);


--
-- Name: attendance_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_date_idx ON public.attendance_records USING btree (attendance_date);


--
-- Name: attendance_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_emp_date_idx ON public.attendance_records USING btree (employee_id, attendance_date);


--
-- Name: attendance_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendance_emp_idx ON public.attendance_records USING btree (employee_id);


--
-- Name: branches_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX branches_company_id_idx ON public.branches USING btree (company_id);


--
-- Name: categories_name_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX categories_name_company_idx ON public.categories USING btree (name, company_id);


--
-- Name: customer_classifications_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_classifications_company_id_idx ON public.customer_classifications USING btree (company_id);


--
-- Name: customer_ledger_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_customer_id_idx ON public.customer_ledger USING btree (customer_id);


--
-- Name: customer_ledger_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_date_idx ON public.customer_ledger USING btree (date);


--
-- Name: customer_ledger_reference_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_reference_idx ON public.customer_ledger USING btree (reference_type, reference_id);


--
-- Name: customer_ledger_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_ledger_type_idx ON public.customer_ledger USING btree (type);


--
-- Name: customers_classification_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_classification_id_idx ON public.customers USING btree (classification_id);


--
-- Name: customers_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_id_idx ON public.customers USING btree (company_id);


--
-- Name: customers_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_name_idx ON public.customers USING btree (company_id, name);


--
-- Name: customers_company_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_company_phone_idx ON public.customers USING btree (company_id, phone);


--
-- Name: daily_accrual_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_date_idx ON public.daily_incentive_accrual USING btree (accrual_date);


--
-- Name: daily_accrual_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_emp_date_idx ON public.daily_incentive_accrual USING btree (employee_id, accrual_date);


--
-- Name: daily_accrual_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX daily_accrual_emp_idx ON public.daily_incentive_accrual USING btree (employee_id);


--
-- Name: departments_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX departments_company_idx ON public.departments USING btree (company_id);


--
-- Name: deposit_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_created_at_idx ON public.deposit_vouchers USING btree (created_at);


--
-- Name: deposit_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_customer_id_idx ON public.deposit_vouchers USING btree (customer_id);


--
-- Name: deposit_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_date_idx ON public.deposit_vouchers USING btree (date);


--
-- Name: deposit_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX deposit_vouchers_request_id_uidx ON public.deposit_vouchers USING btree (request_id);


--
-- Name: deposit_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deposit_vouchers_safe_id_idx ON public.deposit_vouchers USING btree (safe_id);


--
-- Name: emp_bonus_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_bonus_company_idx ON public.employee_bonuses USING btree (company_id);


--
-- Name: emp_bonus_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_bonus_employee_idx ON public.employee_bonuses USING btree (employee_id);


--
-- Name: emp_contacts_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_contacts_employee_idx ON public.employee_contacts USING btree (employee_id);


--
-- Name: emp_custody_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_company_idx ON public.employee_custody USING btree (company_id);


--
-- Name: emp_custody_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_employee_idx ON public.employee_custody USING btree (employee_id);


--
-- Name: emp_custody_lines_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_lines_company_idx ON public.employee_custody_lines USING btree (company_id);


--
-- Name: emp_custody_lines_custody_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_lines_custody_idx ON public.employee_custody_lines USING btree (custody_id);


--
-- Name: emp_custody_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_custody_status_idx ON public.employee_custody USING btree (company_id, status);


--
-- Name: emp_docs_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_docs_employee_idx ON public.employee_documents USING btree (employee_id);


--
-- Name: emp_incentive_assign_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_incentive_assign_emp_idx ON public.employee_incentive_assignments USING btree (employee_id);


--
-- Name: emp_incentive_assign_scheme_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_incentive_assign_scheme_idx ON public.employee_incentive_assignments USING btree (incentive_scheme_id);


--
-- Name: emp_shift_assign_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_shift_assign_emp_idx ON public.employee_shift_assignments USING btree (employee_id);


--
-- Name: emp_shift_assign_shift_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_shift_assign_shift_idx ON public.employee_shift_assignments USING btree (shift_schedule_id);


--
-- Name: emp_status_hist_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emp_status_hist_employee_idx ON public.employee_status_history USING btree (employee_id);


--
-- Name: employees_code_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_code_company_idx ON public.employees USING btree (company_id, employee_code);


--
-- Name: employees_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_company_idx ON public.employees USING btree (company_id);


--
-- Name: employees_dept_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_dept_idx ON public.employees USING btree (department_id);


--
-- Name: employees_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX employees_status_idx ON public.employees USING btree (company_id, employment_status);


--
-- Name: expense_categories_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expense_categories_company_idx ON public.expense_categories USING btree (company_id);


--
-- Name: expenses_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_category_idx ON public.expenses USING btree (category);


--
-- Name: expenses_company_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_company_created_at_idx ON public.expenses USING btree (company_id, created_at);


--
-- Name: expenses_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_created_at_idx ON public.expenses USING btree (created_at);


--
-- Name: expenses_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expenses_safe_id_idx ON public.expenses USING btree (safe_id);


--
-- Name: fiscal_years_company_current_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_years_company_current_idx ON public.fiscal_years USING btree (company_id, is_current);


--
-- Name: fiscal_years_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fiscal_years_company_id_idx ON public.fiscal_years USING btree (company_id);


--
-- Name: holidays_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX holidays_company_idx ON public.public_holidays USING btree (company_id);


--
-- Name: idempotency_keys_company_scope_key_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idempotency_keys_company_scope_key_uidx ON public.idempotency_keys USING btree (company_id, scope, key);


--
-- Name: idempotency_keys_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idempotency_keys_created_at_idx ON public.idempotency_keys USING btree (created_at);


--
-- Name: incentive_metrics_emp_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_metrics_emp_date_idx ON public.incentive_metrics USING btree (employee_id, metric_date);


--
-- Name: incentive_rules_scheme_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_rules_scheme_idx ON public.incentive_rules USING btree (incentive_scheme_id);


--
-- Name: incentive_schemes_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_schemes_company_idx ON public.incentive_schemes USING btree (company_id);


--
-- Name: incentive_slabs_rule_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX incentive_slabs_rule_idx ON public.incentive_slabs USING btree (incentive_rule_id);


--
-- Name: income_company_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_company_created_at_idx ON public.income USING btree (company_id, created_at);


--
-- Name: income_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_company_id_idx ON public.income USING btree (company_id);


--
-- Name: income_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_created_at_idx ON public.income USING btree (created_at);


--
-- Name: income_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_safe_id_idx ON public.income USING btree (safe_id);


--
-- Name: income_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX income_source_idx ON public.income USING btree (source);


--
-- Name: job_titles_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_titles_company_idx ON public.job_titles USING btree (company_id);


--
-- Name: journal_entries_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_company_date_idx ON public.journal_entries USING btree (company_id, date);


--
-- Name: journal_entries_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_company_id_idx ON public.journal_entries USING btree (company_id);


--
-- Name: journal_entries_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_created_at_idx ON public.journal_entries USING btree (created_at);


--
-- Name: journal_entries_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_date_idx ON public.journal_entries USING btree (date);


--
-- Name: journal_entries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_status_idx ON public.journal_entries USING btree (status);


--
-- Name: journal_entry_lines_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entry_lines_account_id_idx ON public.journal_entry_lines USING btree (account_id);


--
-- Name: journal_entry_lines_entry_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entry_lines_entry_id_idx ON public.journal_entry_lines USING btree (entry_id);


--
-- Name: leave_accrual_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_accrual_emp_idx ON public.leave_accrual_history USING btree (employee_id);


--
-- Name: leave_accrual_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_accrual_month_idx ON public.leave_accrual_history USING btree (month);


--
-- Name: leave_approvals_req_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_approvals_req_idx ON public.leave_approvals USING btree (leave_request_id);


--
-- Name: leave_balance_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_balance_emp_idx ON public.employee_leave_balances USING btree (employee_id);


--
-- Name: leave_balance_emp_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_balance_emp_type_idx ON public.employee_leave_balances USING btree (employee_id, leave_type_id);


--
-- Name: leave_blackout_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_blackout_company_idx ON public.leave_blackout_dates USING btree (company_id);


--
-- Name: leave_policy_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_policy_company_idx ON public.leave_policies USING btree (company_id);


--
-- Name: leave_policy_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_policy_type_idx ON public.leave_policies USING btree (leave_type_id);


--
-- Name: leave_req_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_emp_idx ON public.leave_requests USING btree (employee_id);


--
-- Name: leave_req_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_status_idx ON public.leave_requests USING btree (status);


--
-- Name: leave_req_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_req_type_idx ON public.leave_requests USING btree (leave_type_id);


--
-- Name: leave_types_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leave_types_company_idx ON public.leave_types USING btree (company_id);


--
-- Name: monthly_incentive_emp_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monthly_incentive_emp_month_idx ON public.monthly_incentive_summary USING btree (employee_id, month);


--
-- Name: overtime_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX overtime_emp_idx ON public.overtime_records USING btree (employee_id);


--
-- Name: payment_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_created_at_idx ON public.payment_vouchers USING btree (created_at);


--
-- Name: payment_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_customer_id_idx ON public.payment_vouchers USING btree (customer_id);


--
-- Name: payment_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_date_idx ON public.payment_vouchers USING btree (date);


--
-- Name: payment_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payment_vouchers_request_id_uidx ON public.payment_vouchers USING btree (request_id);


--
-- Name: payment_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_vouchers_safe_id_idx ON public.payment_vouchers USING btree (safe_id);


--
-- Name: payroll_adjustments_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_adjustments_record_idx ON public.payroll_adjustments USING btree (payroll_record_id);


--
-- Name: payroll_line_items_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_line_items_record_idx ON public.payroll_line_items USING btree (payroll_record_id);


--
-- Name: payroll_periods_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_periods_company_idx ON public.payroll_periods USING btree (company_id);


--
-- Name: payroll_periods_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_periods_status_idx ON public.payroll_periods USING btree (company_id, status);


--
-- Name: payroll_records_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_employee_idx ON public.payroll_records USING btree (employee_id);


--
-- Name: payroll_records_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_period_idx ON public.payroll_records USING btree (payroll_period_id);


--
-- Name: payroll_records_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_records_status_idx ON public.payroll_records USING btree (status);


--
-- Name: products_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_idx ON public.products USING btree (category_id);


--
-- Name: products_company_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_category_idx ON public.products USING btree (company_id, category_id);


--
-- Name: products_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_id_idx ON public.products USING btree (company_id);


--
-- Name: products_company_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_name_idx ON public.products USING btree (company_id, name);


--
-- Name: products_company_sku_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_company_sku_idx ON public.products USING btree (company_id, sku);


--
-- Name: purchase_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_items_product_id_idx ON public.purchase_items USING btree (product_id);


--
-- Name: purchase_items_purchase_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_items_purchase_id_idx ON public.purchase_items USING btree (purchase_id);


--
-- Name: purchase_return_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_return_items_product_id_idx ON public.purchase_return_items USING btree (product_id);


--
-- Name: purchase_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_return_items_return_id_idx ON public.purchase_return_items USING btree (return_id);


--
-- Name: purchase_returns_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_created_at_idx ON public.purchase_returns USING btree (created_at);


--
-- Name: purchase_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_customer_id_idx ON public.purchase_returns USING btree (customer_id);


--
-- Name: purchase_returns_purchase_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_purchase_id_idx ON public.purchase_returns USING btree (purchase_id);


--
-- Name: purchase_returns_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchase_returns_request_id_uidx ON public.purchase_returns USING btree (request_id);


--
-- Name: purchases_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_company_date_idx ON public.purchases USING btree (company_id, date);


--
-- Name: purchases_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_company_status_idx ON public.purchases USING btree (company_id, posting_status);


--
-- Name: purchases_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_created_at_idx ON public.purchases USING btree (created_at);


--
-- Name: purchases_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_customer_id_idx ON public.purchases USING btree (customer_id);


--
-- Name: purchases_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_date_idx ON public.purchases USING btree (date);


--
-- Name: purchases_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchases_request_id_uidx ON public.purchases USING btree (request_id);


--
-- Name: purchases_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchases_status_idx ON public.purchases USING btree (status);


--
-- Name: receipt_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_created_at_idx ON public.receipt_vouchers USING btree (created_at);


--
-- Name: receipt_vouchers_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_customer_id_idx ON public.receipt_vouchers USING btree (customer_id);


--
-- Name: receipt_vouchers_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_date_idx ON public.receipt_vouchers USING btree (date);


--
-- Name: receipt_vouchers_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX receipt_vouchers_request_id_uidx ON public.receipt_vouchers USING btree (request_id);


--
-- Name: receipt_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receipt_vouchers_safe_id_idx ON public.receipt_vouchers USING btree (safe_id);


--
-- Name: refresh_tokens_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_expires_idx ON public.refresh_tokens USING btree (expires_at);


--
-- Name: refresh_tokens_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_hash_idx ON public.refresh_tokens USING btree (token_hash);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: safe_transfers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_created_at_idx ON public.safe_transfers USING btree (created_at);


--
-- Name: safe_transfers_from_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_from_safe_id_idx ON public.safe_transfers USING btree (from_safe_id);


--
-- Name: safe_transfers_to_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX safe_transfers_to_safe_id_idx ON public.safe_transfers USING btree (to_safe_id);


--
-- Name: sal_comp_struct_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sal_comp_struct_idx ON public.salary_components USING btree (salary_structure_id);


--
-- Name: sal_struct_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sal_struct_company_idx ON public.salary_structures USING btree (company_id);


--
-- Name: salary_adv_deduct_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_deduct_advance_idx ON public.salary_advance_deductions USING btree (salary_advance_id);


--
-- Name: salary_adv_history_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_history_advance_idx ON public.salary_advance_history USING btree (salary_advance_id);


--
-- Name: salary_adv_ledger_advance_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_ledger_advance_idx ON public.salary_advance_ledger USING btree (advance_id);


--
-- Name: salary_adv_ledger_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_adv_ledger_emp_idx ON public.salary_advance_ledger USING btree (employee_id);


--
-- Name: salary_advance_settings_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advance_settings_company_idx ON public.salary_advance_settings USING btree (company_id);


--
-- Name: salary_advances_emp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advances_emp_idx ON public.salary_advances USING btree (employee_id);


--
-- Name: salary_advances_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_advances_status_idx ON public.salary_advances USING btree (status);


--
-- Name: salary_history_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salary_history_employee_idx ON public.salary_history USING btree (employee_id);


--
-- Name: sale_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_items_product_id_idx ON public.sale_items USING btree (product_id);


--
-- Name: sale_items_sale_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_items_sale_id_idx ON public.sale_items USING btree (sale_id);


--
-- Name: sale_return_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_return_items_product_id_idx ON public.sale_return_items USING btree (product_id);


--
-- Name: sale_return_items_return_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sale_return_items_return_id_idx ON public.sale_return_items USING btree (return_id);


--
-- Name: sales_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_company_date_idx ON public.sales USING btree (company_id, date);


--
-- Name: sales_company_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_company_status_idx ON public.sales USING btree (company_id, posting_status);


--
-- Name: sales_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_created_at_idx ON public.sales USING btree (created_at);


--
-- Name: sales_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_customer_id_idx ON public.sales USING btree (customer_id);


--
-- Name: sales_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_date_idx ON public.sales USING btree (date);


--
-- Name: sales_returns_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_created_at_idx ON public.sales_returns USING btree (created_at);


--
-- Name: sales_returns_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_customer_id_idx ON public.sales_returns USING btree (customer_id);


--
-- Name: sales_returns_request_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_returns_request_id_uidx ON public.sales_returns USING btree (request_id);


--
-- Name: sales_returns_sale_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_sale_id_idx ON public.sales_returns USING btree (sale_id);


--
-- Name: sales_returns_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_returns_warehouse_id_idx ON public.sales_returns USING btree (warehouse_id);


--
-- Name: sales_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_safe_id_idx ON public.sales USING btree (safe_id);


--
-- Name: sales_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_status_idx ON public.sales USING btree (status);


--
-- Name: sales_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_user_id_idx ON public.sales USING btree (user_id);


--
-- Name: sales_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_warehouse_id_idx ON public.sales USING btree (warehouse_id);


--
-- Name: shifts_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shifts_company_idx ON public.shift_schedules USING btree (company_id);


--
-- Name: statutory_contrib_company_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX statutory_contrib_company_idx ON public.statutory_contributions USING btree (company_id);


--
-- Name: stock_movements_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_created_at_idx ON public.stock_movements USING btree (created_at);


--
-- Name: stock_movements_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_date_idx ON public.stock_movements USING btree (date);


--
-- Name: stock_movements_movement_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_movement_type_idx ON public.stock_movements USING btree (movement_type);


--
-- Name: stock_movements_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_product_id_idx ON public.stock_movements USING btree (product_id);


--
-- Name: stock_movements_reference_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_reference_type_idx ON public.stock_movements USING btree (reference_type);


--
-- Name: system_settings_key_company_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX system_settings_key_company_uidx ON public.system_settings USING btree (key, company_id);


--
-- Name: tax_brackets_company_year_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tax_brackets_company_year_idx ON public.tax_brackets USING btree (company_id, fiscal_year);


--
-- Name: transactions_company_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_company_date_idx ON public.transactions USING btree (company_id, date);


--
-- Name: transactions_company_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_company_type_idx ON public.transactions USING btree (company_id, type);


--
-- Name: transactions_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_created_at_idx ON public.transactions USING btree (created_at);


--
-- Name: transactions_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_customer_id_idx ON public.transactions USING btree (customer_id);


--
-- Name: transactions_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_date_idx ON public.transactions USING btree (date);


--
-- Name: transactions_direction_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_direction_idx ON public.transactions USING btree (direction);


--
-- Name: transactions_reference_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_reference_type_idx ON public.transactions USING btree (reference_type);


--
-- Name: transactions_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_safe_id_idx ON public.transactions USING btree (safe_id);


--
-- Name: transactions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_type_idx ON public.transactions USING btree (type);


--
-- Name: treasury_vouchers_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_created_at_idx ON public.treasury_vouchers USING btree (created_at);


--
-- Name: treasury_vouchers_safe_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_safe_id_idx ON public.treasury_vouchers USING btree (safe_id);


--
-- Name: treasury_vouchers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX treasury_vouchers_type_idx ON public.treasury_vouchers USING btree (type);


--
-- Name: accounts accounts_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: alerts alerts_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: attendance_records attendance_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: attendance_summary attendance_summary_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_summary
    ADD CONSTRAINT attendance_summary_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: audit_logs audit_logs_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: branches branches_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: categories categories_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customer_classifications customer_classifications_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_classifications
    ADD CONSTRAINT customer_classifications_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customer_ledger customer_ledger_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_ledger
    ADD CONSTRAINT customer_ledger_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: customers customers_classification_id_customer_classifications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_classification_id_customer_classifications_id_fk FOREIGN KEY (classification_id) REFERENCES public.customer_classifications(id);


--
-- Name: customers customers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: daily_incentive_accrual daily_incentive_accrual_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_incentive_accrual
    ADD CONSTRAINT daily_incentive_accrual_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: departments departments_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: deposit_vouchers deposit_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deposit_vouchers
    ADD CONSTRAINT deposit_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_bonuses employee_bonuses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_bonuses employee_bonuses_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_bonuses
    ADD CONSTRAINT employee_bonuses_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_contacts employee_contacts_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_contacts
    ADD CONSTRAINT employee_contacts_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_custody employee_custody_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_custody employee_custody_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody
    ADD CONSTRAINT employee_custody_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_custody_lines employee_custody_lines_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_custody_lines employee_custody_lines_custody_id_employee_custody_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_custody_lines
    ADD CONSTRAINT employee_custody_lines_custody_id_employee_custody_id_fk FOREIGN KEY (custody_id) REFERENCES public.employee_custody(id) ON DELETE CASCADE;


--
-- Name: employee_documents employee_documents_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_documents
    ADD CONSTRAINT employee_documents_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_incentive_assignments employee_incentive_assignments_incentive_scheme_id_incentive_sc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_incentive_assignments
    ADD CONSTRAINT employee_incentive_assignments_incentive_scheme_id_incentive_sc FOREIGN KEY (incentive_scheme_id) REFERENCES public.incentive_schemes(id);


--
-- Name: employee_leave_balances employee_leave_balances_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_leave_balances employee_leave_balances_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_leave_balances
    ADD CONSTRAINT employee_leave_balances_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: employee_shift_assignments employee_shift_assignments_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employee_shift_assignments employee_shift_assignments_shift_schedule_id_shift_schedules_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_shift_assignments
    ADD CONSTRAINT employee_shift_assignments_shift_schedule_id_shift_schedules_id FOREIGN KEY (shift_schedule_id) REFERENCES public.shift_schedules(id);


--
-- Name: employee_status_history employee_status_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_status_history
    ADD CONSTRAINT employee_status_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: employees employees_branch_id_branches_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_branch_id_branches_id_fk FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: employees employees_commission_scope_dept_id_departments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_commission_scope_dept_id_departments_id_fk FOREIGN KEY (commission_scope_dept_id) REFERENCES public.departments(id);


--
-- Name: employees employees_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employees employees_department_id_departments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_department_id_departments_id_fk FOREIGN KEY (department_id) REFERENCES public.departments(id);


--
-- Name: employees employees_job_title_id_job_titles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_job_title_id_job_titles_id_fk FOREIGN KEY (job_title_id) REFERENCES public.job_titles(id);


--
-- Name: erp_users erp_users_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.erp_users
    ADD CONSTRAINT erp_users_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: expense_categories expense_categories_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: expenses expenses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: fiscal_years fiscal_years_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: idempotency_keys idempotency_keys_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: incentive_metrics incentive_metrics_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: incentive_metrics incentive_metrics_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_metrics
    ADD CONSTRAINT incentive_metrics_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: incentive_rules incentive_rules_incentive_scheme_id_incentive_schemes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_rules
    ADD CONSTRAINT incentive_rules_incentive_scheme_id_incentive_schemes_id_fk FOREIGN KEY (incentive_scheme_id) REFERENCES public.incentive_schemes(id);


--
-- Name: incentive_schemes incentive_schemes_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_schemes
    ADD CONSTRAINT incentive_schemes_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: incentive_slabs incentive_slabs_incentive_rule_id_incentive_rules_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incentive_slabs
    ADD CONSTRAINT incentive_slabs_incentive_rule_id_incentive_rules_id_fk FOREIGN KEY (incentive_rule_id) REFERENCES public.incentive_rules(id);


--
-- Name: income income_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.income
    ADD CONSTRAINT income_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: job_titles job_titles_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_titles
    ADD CONSTRAINT job_titles_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: journal_entries journal_entries_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: journal_entry_lines journal_entry_lines_account_id_accounts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_account_id_accounts_id_fk FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: journal_entry_lines journal_entry_lines_entry_id_journal_entries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_entry_id_journal_entries_id_fk FOREIGN KEY (entry_id) REFERENCES public.journal_entries(id);


--
-- Name: leave_accrual_history leave_accrual_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: leave_accrual_history leave_accrual_history_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_accrual_history
    ADD CONSTRAINT leave_accrual_history_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_approvals leave_approvals_leave_request_id_leave_requests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_approvals
    ADD CONSTRAINT leave_approvals_leave_request_id_leave_requests_id_fk FOREIGN KEY (leave_request_id) REFERENCES public.leave_requests(id);


--
-- Name: leave_blackout_dates leave_blackout_dates_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_blackout_dates
    ADD CONSTRAINT leave_blackout_dates_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: leave_policies leave_policies_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: leave_policies leave_policies_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_policies
    ADD CONSTRAINT leave_policies_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_requests leave_requests_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: leave_requests leave_requests_leave_type_id_leave_types_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_requests
    ADD CONSTRAINT leave_requests_leave_type_id_leave_types_id_fk FOREIGN KEY (leave_type_id) REFERENCES public.leave_types(id);


--
-- Name: leave_types leave_types_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_types
    ADD CONSTRAINT leave_types_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: monthly_incentive_summary monthly_incentive_summary_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_incentive_summary
    ADD CONSTRAINT monthly_incentive_summary_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: overtime_records overtime_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.overtime_records
    ADD CONSTRAINT overtime_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payment_vouchers payment_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_vouchers
    ADD CONSTRAINT payment_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: payroll_adjustments payroll_adjustments_payroll_record_id_payroll_records_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_adjustments
    ADD CONSTRAINT payroll_adjustments_payroll_record_id_payroll_records_id_fk FOREIGN KEY (payroll_record_id) REFERENCES public.payroll_records(id);


--
-- Name: payroll_line_items payroll_line_items_payroll_record_id_payroll_records_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_line_items
    ADD CONSTRAINT payroll_line_items_payroll_record_id_payroll_records_id_fk FOREIGN KEY (payroll_record_id) REFERENCES public.payroll_records(id);


--
-- Name: payroll_periods payroll_periods_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_periods
    ADD CONSTRAINT payroll_periods_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: payroll_records payroll_records_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payroll_records payroll_records_payroll_period_id_payroll_periods_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_payroll_period_id_payroll_periods_id_fk FOREIGN KEY (payroll_period_id) REFERENCES public.payroll_periods(id);


--
-- Name: products products_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: public_holidays public_holidays_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_holidays
    ADD CONSTRAINT public_holidays_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: purchase_items purchase_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_items purchase_items_purchase_id_purchases_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_purchase_id_purchases_id_fk FOREIGN KEY (purchase_id) REFERENCES public.purchases(id);


--
-- Name: purchase_return_items purchase_return_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_return_items purchase_return_items_return_id_purchase_returns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_return_items
    ADD CONSTRAINT purchase_return_items_return_id_purchase_returns_id_fk FOREIGN KEY (return_id) REFERENCES public.purchase_returns(id);


--
-- Name: purchase_returns purchase_returns_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: purchases purchases_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: receipt_vouchers receipt_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receipt_vouchers
    ADD CONSTRAINT receipt_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_erp_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_erp_users_id_fk FOREIGN KEY (user_id) REFERENCES public.erp_users(id) ON DELETE CASCADE;


--
-- Name: safe_transfers safe_transfers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safe_transfers
    ADD CONSTRAINT safe_transfers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: safes safes_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.safes
    ADD CONSTRAINT safes_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advance_deductions salary_advance_deductions_salary_advance_id_salary_advances_id_; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_deductions
    ADD CONSTRAINT salary_advance_deductions_salary_advance_id_salary_advances_id_ FOREIGN KEY (salary_advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_history salary_advance_history_salary_advance_id_salary_advances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_history
    ADD CONSTRAINT salary_advance_history_salary_advance_id_salary_advances_id_fk FOREIGN KEY (salary_advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_ledger salary_advance_ledger_advance_id_salary_advances_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_advance_id_salary_advances_id_fk FOREIGN KEY (advance_id) REFERENCES public.salary_advances(id);


--
-- Name: salary_advance_ledger salary_advance_ledger_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_ledger
    ADD CONSTRAINT salary_advance_ledger_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_advance_settings salary_advance_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advance_settings
    ADD CONSTRAINT salary_advance_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advances salary_advances_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: salary_advances salary_advances_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_advances
    ADD CONSTRAINT salary_advances_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_components salary_components_salary_structure_id_salary_structures_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_salary_structure_id_salary_structures_id_fk FOREIGN KEY (salary_structure_id) REFERENCES public.salary_structures(id);


--
-- Name: salary_history salary_history_employee_id_employees_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_history
    ADD CONSTRAINT salary_history_employee_id_employees_id_fk FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: salary_structures salary_structures_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_structures
    ADD CONSTRAINT salary_structures_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: sale_items sale_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_items sale_items_sale_id_sales_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_sale_id_sales_id_fk FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- Name: sale_return_items sale_return_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sale_return_items sale_return_items_return_id_sales_returns_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_return_items
    ADD CONSTRAINT sale_return_items_return_id_sales_returns_id_fk FOREIGN KEY (return_id) REFERENCES public.sales_returns(id);


--
-- Name: sales sales_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: sales_returns sales_returns_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_returns
    ADD CONSTRAINT sales_returns_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: shift_schedules shift_schedules_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_schedules
    ADD CONSTRAINT shift_schedules_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: statutory_contributions statutory_contributions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statutory_contributions
    ADD CONSTRAINT statutory_contributions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_count_items stock_count_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_count_sessions stock_count_sessions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_count_sessions
    ADD CONSTRAINT stock_count_sessions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_movements stock_movements_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: stock_movements stock_movements_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_transfer_items stock_transfer_items_product_id_products_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfer_items
    ADD CONSTRAINT stock_transfer_items_product_id_products_id_fk FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_transfers stock_transfers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_transfers
    ADD CONSTRAINT stock_transfers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: system_settings system_settings_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: tax_brackets tax_brackets_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tax_brackets
    ADD CONSTRAINT tax_brackets_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: transactions transactions_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: treasury_vouchers treasury_vouchers_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treasury_vouchers
    ADD CONSTRAINT treasury_vouchers_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: warehouses warehouses_company_id_companies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_company_id_companies_id_fk FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- PostgreSQL database dump complete
--

\unrestrict emieJbesgMPtRjJDlA11Vbph0rBQ4KPvC4HXPJQp5ryIFWwYnP5FCbciF7Jfk50

