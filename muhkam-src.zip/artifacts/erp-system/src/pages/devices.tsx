import { useState, useRef, useEffect, useMemo, type ElementType } from "react";
import { PaginationBar } from "@/components/PaginationBar";
import { useAppSettings } from "@/contexts/app-settings";
import { openPrintWindow, escapeHtml } from '@/lib/print-utils';
import { useGetCustomers } from "@workspace/api-client-react";
import { safeArray } from "@/lib/safe-data";
import { SearchableSelect } from "@/components/searchable-select";
import {
  CATALOG, BRANDS, DEFAULT_STORAGES, DEFAULT_COLORS, OTHER,
  type ModelSpec,
} from "@/lib/device-catalog";
import { createPortal } from "react-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Smartphone, Plus, Search, X, CheckCircle2, XCircle,
  ShoppingCart, Wrench, BadgeCheck, Info,
  Trash2, RotateCcw, AlertTriangle, Battery, Package,
  Tag, User, TrendingUp, Banknote, Printer,
  MoreVertical, Eye, LayoutGrid, List, Copy, Calendar, FileText, Percent, Shield,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { authFetch } from "@/lib/auth-fetch";
import { useAuth } from "@/contexts/auth";
import { api } from '@/lib/api';
import Warranty from '@/pages/warranty';


/* ── Types ── */
type DeviceStatus = "available" | "sold" | "maintenance";
type PaymentMethod = "cash" | "card" | "instapay" | "transfer";
type PaymentStatus = "paid" | "partial" | "unpaid";

type Device = {
  id: number; company_id: number; branch_id?: number;
  device_no: string;
  brand: string; model: string; color?: string; storage?: string;
  imei?: string; serial_no?: string;
  battery_health?: number; grade?: string; condition_notes?: string;
  purchase_price: string; sale_price: string;
  status: DeviceStatus;
  dual_sim: boolean; with_box: boolean;
  icloud_locked: boolean; network_locked: boolean; previously_opened: boolean; mdm_locked: boolean;
  supplier_name?: string; purchase_invoice_no?: string; inspector_name?: string;
  sold_to_customer_name?: string; sold_at?: string;
  sold_by_user_name?: string; sold_price?: string;
  warranty_months?: number; payment_method?: string; payment_status?: string;
  added_by_user_name?: string; created_at: string;
  supplier_phone?: string; id_card_data?: string;
};

type Stats = {
  total: number; available: number; sold: number; maintenance: number;
  stock_purchase_value: number; stock_sale_value: number; stock_profit_potential: number;
  sold_revenue: number; sold_profit: number;
};

/* ── Helpers ── */
async function apiPost<T>(url: string, body: unknown): Promise<T> {
  const r = await authFetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) { const e = await r.text(); throw new Error(e || `HTTP ${r.status}`); }
  return r.json() as Promise<T>;
}

const GRADES = ["A+", "A", "B", "C", "D"];

/* ── Print Sale Receipt ── */
function printSaleReceipt(d: Device, companyName: string) {
  const price = parseFloat(d.sold_price ?? d.sale_price ?? "0").toLocaleString("ar-EG");
  const profit = parseFloat(d.sold_price ?? "0") - parseFloat(d.purchase_price ?? "0");
  const date = d.sold_at ? new Date(d.sold_at).toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" }) : new Date().toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" });
  const payMethods: Record<string, string> = { cash: "نقداً", card: "بطاقة", instapay: "InstaPay", transfer: "تحويل" };
  const payStatuses: Record<string, string> = { paid: "مدفوع بالكامل", partial: "مدفوع جزئياً", unpaid: "غير مدفوع" };

  const _html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="UTF-8">
<title>فاتورة بيع — ${escapeHtml(d.brand)} ${escapeHtml(d.model)}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #fff; color: #111; padding: 20px; font-size: 13px; }
  .header { text-align: center; border-bottom: 2px solid #7c3aed; padding-bottom: 12px; margin-bottom: 16px; }
  .header h1 { font-size: 22px; font-weight: 900; color: #7c3aed; letter-spacing: 1px; }
  .header p { color: #666; font-size: 11px; margin-top: 2px; }
  .badge { display: inline-block; background: #7c3aed; color: #fff; font-size: 10px; font-weight: 700; padding: 2px 10px; border-radius: 999px; margin-top: 6px; }
  .section { margin-bottom: 12px; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; }
  .section-title { background: #f3f4f6; padding: 6px 12px; font-size: 10px; font-weight: 700; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; }
  .row { display: flex; justify-content: space-between; padding: 7px 12px; border-top: 1px solid #f3f4f6; }
  .row:first-of-type { border-top: none; }
  .label { color: #6b7280; font-size: 12px; }
  .value { font-weight: 600; color: #111; font-size: 12px; }
  .price-box { background: #f0fdf4; border: 1.5px solid #16a34a; border-radius: 8px; padding: 10px 16px; text-align: center; margin: 12px 0; }
  .price-box .amount { font-size: 26px; font-weight: 900; color: #15803d; }
  .price-box .label2 { font-size: 11px; color: #6b7280; margin-top: 2px; }
  .footer { text-align: center; margin-top: 20px; border-top: 1px dashed #d1d5db; padding-top: 12px; color: #9ca3af; font-size: 10px; }
  .warranty { background: #eff6ff; border: 1px solid #3b82f6; border-radius: 8px; padding: 8px 12px; text-align: center; margin: 8px 0; }
  .warranty strong { color: #1d4ed8; }
  .stamp { border: 2px dashed #7c3aed; border-radius: 50%; width: 70px; height: 70px; display: flex; align-items: center; justify-content: center; margin: 10px auto; color: #7c3aed; font-weight: 900; font-size: 11px; text-align: center; }
  @media print { body { padding: 8px; } }
</style>
</head>
<body>
<div class="header">
  <h1>${escapeHtml(companyName)}</h1>
  <p>نظام إدارة الموبايلات المستعملة</p>
  <span class="badge">فاتورة بيع رسمية</span>
</div>

<div class="price-box">
  <div class="amount">${escapeHtml(price)} ج.م</div>
  <div class="label2">إجمالي مبلغ الفاتورة</div>
</div>

<div class="section">
  <div class="section-title">بيانات الجهاز</div>
  <div class="row"><span class="label">الماركة والموديل</span><span class="value">${escapeHtml(d.brand)} ${escapeHtml(d.model)}</span></div>
  ${d.color ? `<div class="row"><span class="label">اللون</span><span class="value">${escapeHtml(d.color)}</span></div>` : ""}
  ${d.storage ? `<div class="row"><span class="label">السعة التخزينية</span><span class="value">${escapeHtml(d.storage)}</span></div>` : ""}
  ${d.imei ? `<div class="row"><span class="label">رقم IMEI</span><span class="value" style="direction:ltr;text-align:right">${escapeHtml(d.imei)}</span></div>` : ""}
  ${d.serial_no ? `<div class="row"><span class="label">الرقم التسلسلي</span><span class="value" style="direction:ltr;text-align:right">${escapeHtml(d.serial_no)}</span></div>` : ""}
  ${d.grade ? `<div class="row"><span class="label">الدرجة</span><span class="value">${escapeHtml(d.grade)}</span></div>` : ""}
  ${d.battery_health ? `<div class="row"><span class="label">صحة البطارية</span><span class="value">${escapeHtml(String(d.battery_health))}%</span></div>` : ""}
  <div class="row"><span class="label">رقم الجهاز</span><span class="value" style="direction:ltr;text-align:right">${escapeHtml(d.device_no)}</span></div>
</div>

<div class="section">
  <div class="section-title">بيانات البيع</div>
  <div class="row"><span class="label">اسم العميل</span><span class="value">${escapeHtml(d.sold_to_customer_name) || "—"}</span></div>
  <div class="row"><span class="label">تاريخ البيع</span><span class="value">${escapeHtml(date)}</span></div>
  <div class="row"><span class="label">طريقة الدفع</span><span class="value">${escapeHtml(payMethods[d.payment_method ?? ""] ?? d.payment_method ?? "—")}</span></div>
  <div class="row"><span class="label">حالة الدفع</span><span class="value">${escapeHtml(payStatuses[d.payment_status ?? ""] ?? d.payment_status ?? "—")}</span></div>
  ${d.sold_by_user_name ? `<div class="row"><span class="label">البائع</span><span class="value">${escapeHtml(d.sold_by_user_name)}</span></div>` : ""}
</div>

${d.warranty_months ? `
<div class="warranty">
  <strong>ضمان ${escapeHtml(String(d.warranty_months))} شهر</strong> — يسري من تاريخ الشراء
</div>
` : ""}

<div class="stamp">${escapeHtml(companyName.split(/[|\-]/)[0].trim())}<br/>ERP</div>

<div class="footer">
  <p>شكراً لثقتك بنا — MUHKAM Enterprise Solutions</p>
  <p style="margin-top:4px">هذه الفاتورة صادرة إلكترونياً وتُعدّ وثيقة رسمية</p>
  <p style="margin-top:4px; color:#bbb;">الربح الصافي من هذه الصفقة: ${profit.toLocaleString("ar-EG")} ج.م</p>
</div>

<script>window.onload = () => { window.print(); }</script>
</body>
</html>`;
  openPrintWindow(_html, { width: 420, height: 680 });
}

const WARRANTY_OPTS = [
  { label: "بدون ضمان", value: 0 },
  { label: "شهر", value: 1 },
  { label: "3 أشهر", value: 3 },
  { label: "6 أشهر", value: 6 },
  { label: "سنة", value: 12 },
];
const PAY_METHODS: { v: PaymentMethod; l: string }[] = [
  { v: "cash", l: "كاش" },
  { v: "card", l: "بطاقة" },
  { v: "instapay", l: "انستاباي" },
  { v: "transfer", l: "تحويل بنكي" },
];

/* ── Grade Badge ── */
function GradeBadge({ grade }: { grade?: string }) {
  const colors: Record<string, string> = {
    "A+": "text-emerald-300 bg-emerald-500/15 border-emerald-500/30",
    "A":  "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    "B":  "text-amber-300 bg-amber-500/10 border-amber-500/20",
    "C":  "text-orange-300 bg-orange-500/10 border-orange-500/20",
    "D":  "text-red-400 bg-red-500/10 border-red-500/20",
  };
  const c = colors[grade ?? "B"] ?? "text-white/40 bg-white/5 border-white/10";
  return (
    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${c}`}>
      {grade ?? "—"}
    </span>
  );
}

/* ── Status Badge ── */
function StatusBadge({ status }: { status: DeviceStatus }) {
  const map: Record<DeviceStatus, { label: string; cls: string }> = {
    available:   { label: "متاح",     cls: "text-emerald-300 bg-emerald-500/15 border-emerald-500/30" },
    sold:        { label: "مباع",     cls: "text-blue-300 bg-blue-500/15 border-blue-500/30" },
    maintenance: { label: "صيانة",   cls: "text-amber-300 bg-amber-500/15 border-amber-500/30" },
  };
  const { label, cls } = map[status];
  return (
    <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${cls}`}>
      {label}
    </span>
  );
}


/* ════════════════════════════════════════════════════════
   ADD DEVICE MODAL  — 4-level cascade: Brand → Category → Model → Color/Storage
════════════════════════════════════════════════════════ */
function AddDeviceModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();

  /* ── wizard step 1 | 2 ── */
  const [step, setStep] = useState<1 | 2>(1);
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  /* ── cascade selectors ── */
  const [brandSel,      setBrandSel]      = useState("");
  const [catSel,        setCatSel]        = useState("");
  const [modelSel,      setModelSel]      = useState("");
  const [colorSel,      setColorSel]      = useState("");
  const [brandCustom,   setBrandCustom]   = useState("");
  const [modelCustom,   setModelCustom]   = useState("");
  const [colorCustom,   setColorCustom]   = useState("");
  const [storageCustom, setStorageCustom] = useState("");
  const [storageModeOther, setStorageModeOther] = useState(false);

  /* ── device form fields ── */
  const [form, setForm] = useState({ storage: "128GB", imei: "", battery_health: "", grade: "B" });
  const f = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  /* ── supplier / customer ── */
  const [supplierPhone, setSupplierPhone] = useState("");
  const [supplierName,  setSupplierName]  = useState("");  // for new (not in DB)
  const [foundCustomer, setFoundCustomer] = useState<{ id: number; name: string; balance?: string } | null>(null);
  const [lookingUp,     setLookingUp]     = useState(false);

  /* ── ID card ── */
  const [idCardFile,    setIdCardFile]    = useState<File | null>(null);
  const [idCardPreview, setIdCardPreview] = useState<string>("");

  /* ── financial (step 2) ── */
  const [fin, setFin] = useState({
    purchase_price: "",
    sale_price: "",
    payment_type: "cash" as "cash" | "credit" | "partial",
    paid_amount: "",
    safe_id: "",
    warehouse_id: "",
  });
  const fp = (k: string, v: string) => setFin(p => ({ ...p, [k]: v }));

  const [safes,      setSafes]      = useState<{ id: number; name: string; balance: string }[]>([]);
  const [warehouses, setWarehouses] = useState<{ id: number; name: string }[]>([]);
  const [saving,     setSaving]     = useState(false);

  /* ── documents / condition notes ── */
  const [conditionNotes, setConditionNotes] = useState("");

  /* cascade derived */
  const isOtherBrand   = brandSel === OTHER;
  const isOtherModel   = modelSel === OTHER;
  const isOtherColor   = colorSel === OTHER;
  const isOtherStorage = storageModeOther;
  const categories  = brandSel && !isOtherBrand ? Object.keys(CATALOG[brandSel] ?? {}) : [];
  const modelSpecs  = catSel  && !isOtherBrand  ? CATALOG[brandSel]?.[catSel] ?? {}    : {};
  const modelNames  = Object.keys(modelSpecs);
  const currentSpec: ModelSpec | null = (modelSel && !isOtherModel) ? modelSpecs[modelSel] ?? null : null;
  const availColors   = currentSpec?.colors.length ? [...currentSpec.colors, OTHER] : [...DEFAULT_COLORS, OTHER];
  const availStorages = currentSpec?.storages.length ? [...currentSpec.storages, OTHER] : [...DEFAULT_STORAGES, OTHER];
  const effectiveBrand   = isOtherBrand   ? brandCustom   : brandSel;
  const effectiveModel   = isOtherModel   ? modelCustom   : modelSel;
  const effectiveColor   = isOtherColor   ? colorCustom   : colorSel;
  const finalStorage     = storageCustom.trim() || form.storage;

  /* new customer (phone entered but not found in DB) */
  const isNewSupplier = supplierPhone.trim().length > 0 && !lookingUp && !foundCustomer;

  /* if new supplier and currently credit/partial → reset to cash */
  useEffect(() => {
    if (isNewSupplier && fin.payment_type !== "cash") fp("payment_type", "cash");
  }, [isNewSupplier]);

  /* cascade resets */
  const resetStorageOther = () => { setStorageModeOther(false); setStorageCustom(""); };
  const handleBrandChange = (v: string) => {
    setBrandSel(v); setCatSel(""); setModelSel(""); setColorSel("");
    setColorCustom(""); setBrandCustom(""); setModelCustom(""); resetStorageOther();
    setForm(p => ({ ...p, storage: "" }));
  };
  const handleCatChange = (v: string) => {
    setCatSel(v); setModelSel(""); setColorSel("");
    setColorCustom(""); setModelCustom(""); resetStorageOther();
    setForm(p => ({ ...p, storage: "" }));
  };
  const handleModelChange = (v: string) => {
    setModelSel(v); setColorSel(""); setColorCustom(""); setModelCustom(""); resetStorageOther();
    const spec = catSel && brandSel ? CATALOG[brandSel]?.[catSel]?.[v] : undefined;
    setForm(p => ({ ...p, storage: spec?.storages.length ? spec.storages[0] : "128GB" }));
    if (spec?.colors.length === 1) setColorSel(spec.colors[0]);
  };
  const handleStorageChange = (v: string) => {
    if (v === OTHER) { setStorageModeOther(true); setStorageCustom(""); }
    else { setStorageModeOther(false); setStorageCustom(""); setForm(p => ({ ...p, storage: v })); }
  };

  /* phone lookup with debounce */
  useEffect(() => {
    if (supplierPhone.length < 7) { setFoundCustomer(null); return; }
    const t = setTimeout(async () => {
      setLookingUp(true);
      try {
        const res = await authFetch(api(`/api/devices/customer-lookup?phone=${encodeURIComponent(supplierPhone)}`));
        const data = await res.json() as { found: boolean; customer?: { id: number; name: string; balance?: string } };
        setFoundCustomer(data.found && data.customer ? data.customer : null);
      } catch { setFoundCustomer(null); }
      finally { setLookingUp(false); }
    }, 600);
    return () => clearTimeout(t);
  }, [supplierPhone]);

  /* Load safes + warehouses when entering step 2 */
  useEffect(() => {
    if (step !== 2) return;
    authFetch(api("/api/devices/safes")).then(r => r.json() as Promise<{ id: number; name: string; balance: string }[]>)
      .then(setSafes).catch(() => setSafes([]));
    authFetch(api("/api/devices/warehouses")).then(r => r.json() as Promise<{ id: number; name: string }[]>)
      .then(setWarehouses).catch(() => setWarehouses([]));
  }, [step]);

  /* ID card file handler */
  const handleIdFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast({ title: "حجم الملف يتجاوز 2MB", variant: "destructive" });
      e.target.value = ""; return;
    }
    setIdCardFile(file);
    const reader = new FileReader();
    reader.onload = ev => setIdCardPreview(ev.target?.result as string ?? "");
    reader.readAsDataURL(file);
  };

  /* Step 1 validation → go to step 2 */
  const handleNext = () => {
    const e: Record<string, boolean> = {};
    if (!effectiveBrand.trim()) e.brand = true;
    if (!catSel.trim() && !isOtherBrand) e.cat = true;
    if (!effectiveModel.trim()) e.model = true;
    if (!effectiveColor.trim()) e.color = true;
    if (!finalStorage.trim()) e.storage = true;
    if (!form.imei.trim()) e.imei = true;
    if (!form.battery_health) e.battery = true;
    const cleanPhone = supplierPhone.replace(/\D/g, '');
    if (cleanPhone.length !== 11) e.phone = true;
    if (isNewSupplier && !supplierName.trim()) e.supplierName = true;
    setErrors(e);
    if (Object.keys(e).length > 0) {
      toast({ title: "يرجى تعبئة الحقول المطلوبة", variant: "destructive" });
      return;
    }
    setStep(2);
  };

  /* Final save — calls POST /api/devices/purchase */
  const handleSave = async () => {
    const e: Record<string, boolean> = {};
    const pp = parseFloat(fin.purchase_price);
    if (!pp || pp <= 0) e.purchase_price = true;
    if (!fin.warehouse_id) e.warehouse_id = true;
    if (fin.payment_type !== "credit" && !fin.safe_id) e.safe_id = true;
    if (fin.payment_type === "partial") {
      const pa = parseFloat(fin.paid_amount);
      if (!pa || pa <= 0 || pa >= pp) e.paid_amount = true;
    }
    setErrors(e);
    if (Object.keys(e).length > 0) {
      toast({ title: "يرجى تعبئة الحقول المطلوبة", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      let idCardData: string | undefined;
      if (idCardFile) {
        idCardData = await new Promise<string>((res, rej) => {
          const r = new FileReader();
          r.onload = ev => res(ev.target?.result as string);
          r.onerror = rej;
          r.readAsDataURL(idCardFile);
        });
      }

      await apiPost("/api/devices/purchase", {
        /* device */
        brand:          effectiveBrand,
        model:          effectiveModel,
        color:          effectiveColor  || undefined,
        storage:        finalStorage    || undefined,
        grade:          form.grade,
        imei:           form.imei       || undefined,
        battery_health: form.battery_health ? Math.min(100, parseInt(form.battery_health)) : null,
        supplier_phone: supplierPhone.trim() || undefined,
        id_card_data:   idCardData,
        condition_notes: conditionNotes.trim() || undefined,
        /* supplier / customer */
        customer_id:        foundCustomer ? foundCustomer.id : undefined,
        new_customer_name:  isNewSupplier && supplierName.trim() ? supplierName.trim() : undefined,
        /* financial */
        purchase_price: pp,
        sale_price:     fin.sale_price ? parseFloat(fin.sale_price) : 0,
        payment_type:   fin.payment_type,
        safe_id:        fin.safe_id    ? parseInt(fin.safe_id)    : undefined,
        warehouse_id:   fin.warehouse_id ? parseInt(fin.warehouse_id) : undefined,
        paid_amount:    fin.payment_type === "partial" ? parseFloat(fin.paid_amount) : undefined,
      });

      toast({ title: "✅ تم إضافة الجهاز وتسجيل فاتورة الشراء" });
      onSaved(); onClose();
    } catch (err: unknown) {
      let msg = "خطأ في الحفظ";
      if (err instanceof Error) {
        try { const j = JSON.parse(err.message); msg = j.error || err.message; }
        catch { msg = err.message; }
      }
      toast({ title: msg, variant: "destructive" });
    } finally { setSaving(false); }
  };

  /* helper classes */
  const errCls  = (k: string) => errors[k] ? "border-red-500/60 bg-red-500/5" : "";
  const iCls    = (k = "") => `erp-input w-full text-sm ${errCls(k)}`;
  const sCls    = (k = "") => `erp-input w-full text-sm ${errCls(k)}`;
  const dCls    = "erp-input w-full text-sm opacity-40 cursor-not-allowed";
  const lCls    = "text-[11px] text-white/40 mb-1.5 block text-right";
  const lReq    = "text-[11px] mb-1.5 block text-right text-white/40";

  const PAYMENT_LABELS = { cash: "نقدي", credit: "آجل", partial: "جزئي" };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-4 bg-black/70 backdrop-blur-sm" dir="rtl">
      <div className="glass-panel rounded-2xl border border-white/10 w-full max-w-xl mx-4 overflow-hidden flex flex-col" style={{ maxHeight: "94vh" }}>

        {/* ── Header ── */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-violet-500/15 border border-violet-500/25 flex items-center justify-center">
              <Smartphone className="w-4 h-4 text-violet-400" />
            </div>
            <div>
              <span className="font-bold text-white text-sm">إضافة جهاز مستعمل</span>
              <p className="text-[10px] text-white/30 mt-0.5">
                الخطوة {step} من 2 — {step === 1 ? "بيانات الجهاز والمورد" : "التسعير وطريقة الدفع"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5">
              {[1, 2].map(s => (
                <div key={s} className={`h-1.5 rounded-full transition-all ${s <= step ? "bg-violet-500 w-8" : "bg-white/10 w-4"}`} />
              ))}
            </div>
            <button onClick={onClose} className="btn-icon text-white/40 hover:text-white">
              <XCircle className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ── Body ── */}
        <div className="overflow-y-auto flex-1 p-5 space-y-4">

          {/* ══════════ STEP 1: Device + Supplier ══════════ */}
          {step === 1 && (
            <>
              {/* ─ Brand / Category / Model ─ */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className={lReq}>الشركة المصنعة *</label>
                  <select value={brandSel} onChange={e => handleBrandChange(e.target.value)} className={sCls("brand")}>
                    <option value="">— اختر —</option>
                    {BRANDS.map(b => <option key={b} value={b}>{b}</option>)}
                  </select>
                  {isOtherBrand && (
                    <input value={brandCustom} onChange={e => setBrandCustom(e.target.value)}
                      placeholder="اسم الشركة" className={`${iCls("brand")} mt-1.5`} />
                  )}
                </div>
                <div>
                  <label className={lReq}>الفئة *</label>
                  {isOtherBrand ? (
                    <input value={catSel} onChange={e => setCatSel(e.target.value)}
                      placeholder="مثال: iPhone" className={iCls("cat")} />
                  ) : (
                    <select value={catSel} onChange={e => handleCatChange(e.target.value)}
                      className={brandSel ? sCls("cat") : dCls} disabled={!brandSel}>
                      <option value="">— اختر —</option>
                      {categories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  )}
                </div>
                <div>
                  <label className={lReq}>الموديل *</label>
                  {isOtherBrand || (catSel && modelNames.length === 0) ? (
                    <input value={modelCustom} onChange={e => setModelCustom(e.target.value)}
                      placeholder="اكتب الموديل" className={iCls("model")} />
                  ) : (
                    <>
                      <select value={modelSel} onChange={e => handleModelChange(e.target.value)}
                        className={catSel ? sCls("model") : dCls} disabled={!catSel}>
                        <option value="">— اختر —</option>
                        {modelNames.map(m => <option key={m} value={m}>{m}</option>)}
                      </select>
                      {isOtherModel && (
                        <input value={modelCustom} onChange={e => setModelCustom(e.target.value)}
                          placeholder="اكتب الموديل" className={`${iCls("model")} mt-1.5`} />
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* ─ Color / Storage / Grade ─ */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className={lReq}>اللون *</label>
                  <select value={colorSel} onChange={e => setColorSel(e.target.value)}
                    className={(modelSel || isOtherBrand) ? sCls("color") : dCls}
                    disabled={!modelSel && !isOtherBrand}>
                    <option value="">— اللون —</option>
                    {availColors.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {isOtherColor && (
                    <input value={colorCustom} onChange={e => setColorCustom(e.target.value)}
                      placeholder="اكتب اللون" className={`${iCls("color")} mt-1.5`} />
                  )}
                </div>
                <div>
                  <label className={lReq}>السعة *</label>
                  <select value={isOtherStorage ? OTHER : form.storage}
                    onChange={e => handleStorageChange(e.target.value)}
                    className={(modelSel || isOtherBrand) ? sCls("storage") : dCls}
                    disabled={!modelSel && !isOtherBrand}>
                    <option value="">— السعة —</option>
                    {availStorages.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  {isOtherStorage && (
                    <input value={storageCustom} onChange={e => setStorageCustom(e.target.value)}
                      placeholder="مثال: 256GB" className={`${iCls("storage")} mt-1.5`} />
                  )}
                </div>
                <div>
                  <label className={lCls}>الدرجة</label>
                  <select value={form.grade} onChange={e => f("grade", e.target.value)} className={iCls()}>
                    {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>
              </div>

              {/* ─ IMEI / Battery ─ */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={lReq}>IMEI *</label>
                  <input value={form.imei} onChange={e => f("imei", e.target.value)}
                    placeholder="123456789012345" className={iCls("imei")}
                    inputMode="numeric" maxLength={20} />
                </div>
                <div>
                  <label className={lReq}>نسبة البطارية % *</label>
                  <input type="number" min={1} max={100}
                    value={form.battery_health}
                    onChange={e => f("battery_health", String(Math.min(100, Math.max(1, parseInt(e.target.value) || 0))))}
                    placeholder="85" className={iCls("battery")} />
                  {form.battery_health && (
                    <div className="mt-1.5 h-1 rounded-full bg-white/8 overflow-hidden">
                      <div className={`h-full rounded-full transition-all ${
                        parseInt(form.battery_health) >= 85 ? "bg-emerald-400" :
                        parseInt(form.battery_health) >= 70 ? "bg-amber-400" : "bg-red-400"
                      }`} style={{ width: `${form.battery_health}%` }} />
                    </div>
                  )}
                </div>
              </div>

              {/* ─ Divider ─ */}
              <div className="flex items-center gap-3 py-0.5">
                <div className="flex-1 h-px bg-white/6" />
                <span className="text-[10px] text-white/20">بيانات المورد</span>
                <div className="flex-1 h-px bg-white/6" />
              </div>

              {/* ─ Supplier Phone lookup ─ */}
              <div>
                <label className={lReq}>رقم هاتف المورد * <span className="text-white/25">(11 رقم)</span></label>
                <div className="relative">
                  <input type="tel" value={supplierPhone}
                    onChange={e => setSupplierPhone(e.target.value.replace(/\D/g, '').slice(0, 11))}
                    placeholder="01xxxxxxxxx" className={`${iCls("phone")} pl-10`}
                    inputMode="numeric" maxLength={11} dir="ltr" />
                  <div className="absolute left-3 top-1/2 -translate-y-1/2">
                    {lookingUp
                      ? <div className="w-3.5 h-3.5 border-2 border-violet-400/30 border-t-violet-400 rounded-full animate-spin" />
                      : foundCustomer
                        ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        : supplierPhone.length > 0
                          ? <XCircle className="w-3.5 h-3.5 text-amber-400/60" />
                          : <User className="w-3.5 h-3.5 text-white/20" />}
                  </div>
                </div>

                {/* Found: existing customer card */}
                {foundCustomer && (
                  <div className="mt-2 flex items-center gap-2.5 px-3 py-2.5 bg-emerald-500/8 border border-emerald-500/20 rounded-xl">
                    <div className="w-8 h-8 rounded-full bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center shrink-0">
                      <User className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-emerald-300 text-sm font-bold">{foundCustomer.name}</p>
                      <p className="text-emerald-400/50 text-[10px]">مسجّل في قاعدة البيانات — سيظهر في كشف حسابه</p>
                    </div>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  </div>
                )}

                {/* New supplier: name field — temporary, not added to customers list */}
                {isNewSupplier && (
                  <div className="mt-2 space-y-2">
                    <div className="flex items-center gap-1.5 text-[11px] text-amber-400/70">
                      <Info className="w-3 h-3" /> مورد مؤقت — لن يُضاف لقائمة العملاء (نقدي فقط)
                    </div>
                    <input value={supplierName} onChange={e => setSupplierName(e.target.value)}
                      placeholder="اسم المورد *" className={iCls("supplierName")} />
                  </div>
                )}
              </div>

              {/* ─ ID card upload ─ */}
              <div>
                <label className={lCls}>البطاقة الشخصية <span className="text-white/20">(اختياري — حتى 2MB)</span></label>
                {!idCardPreview ? (
                  <label className="flex items-center gap-3 p-3 border border-dashed border-white/8 rounded-xl cursor-pointer hover:border-violet-500/30 hover:bg-violet-500/4 transition-all group">
                    <div className="w-8 h-8 rounded-full bg-white/5 group-hover:bg-violet-500/10 flex items-center justify-center shrink-0">
                      <FileText className="w-4 h-4 text-white/25 group-hover:text-violet-400 transition-colors" />
                    </div>
                    <div>
                      <p className="text-white/35 text-sm">انقر لرفع صورة البطاقة</p>
                      <p className="text-white/20 text-[10px]">JPG, PNG, PDF</p>
                    </div>
                    <input type="file" accept="image/*,application/pdf" onChange={handleIdFile} className="hidden" />
                  </label>
                ) : (
                  <div className="relative rounded-xl overflow-hidden border border-white/10 bg-white/3">
                    {idCardPreview.startsWith("data:image") ? (
                      <img src={idCardPreview} alt="بطاقة شخصية" className="w-full h-32 object-cover" />
                    ) : (
                      <div className="flex items-center gap-3 p-3">
                        <FileText className="w-7 h-7 text-violet-400" />
                        <div>
                          <p className="text-white/70 text-sm font-medium">{idCardFile?.name}</p>
                          <p className="text-white/30 text-xs">{((idCardFile?.size ?? 0) / 1024).toFixed(0)} KB</p>
                        </div>
                      </div>
                    )}
                    <button onClick={() => { setIdCardPreview(""); setIdCardFile(null); }}
                      className="absolute top-2 left-2 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center hover:bg-red-500/60 transition-colors">
                      <X className="w-3 h-3 text-white" />
                    </button>
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/30 rounded-lg text-[10px] text-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> تم الرفع
                    </div>
                  </div>
                )}
              </div>

              {/* ─ Documents / Condition Notes ─ */}
              <div>
                <label className={lCls}>
                  <span className="flex items-center gap-1.5">
                    <FileText className="w-3 h-3 text-white/30" />
                    المستندات وحالة الجهاز
                    <span className="text-white/20">(اختياري — يُحفظ كمرجع دائم)</span>
                  </span>
                </label>
                <textarea
                  value={conditionNotes}
                  onChange={e => setConditionNotes(e.target.value)}
                  placeholder={"مثال: الجهاز يعمل بشكل طبيعي، شاشة سليمة، بدون كسور\nرقم بطاقة البائع: 123456789\nالجهاز مفتوح من البائع ولم يُعاد تهيئته..."}
                  rows={4}
                  className="erp-input w-full text-sm resize-none leading-relaxed"
                />
                <p className="text-[10px] text-white/20 mt-1 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  يظهر في تبويب "المصدر" بصفحة الجهاز — مرجع دائم في حالة وجود نزاع لاحقاً
                </p>
              </div>
            </>
          )}

          {/* ══════════ STEP 2: Pricing + Payment ══════════ */}
          {step === 2 && (
            <>
              {/* Device summary pill */}
              <div className="flex items-center gap-3 p-3 bg-white/3 rounded-xl border border-white/6">
                <div className="w-9 h-9 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center shrink-0">
                  <Smartphone className="w-4 h-4 text-violet-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-white text-sm">{effectiveBrand} {effectiveModel}</p>
                  <p className="text-[11px] text-white/30">
                    {finalStorage && <span>{finalStorage}</span>}
                    {effectiveColor && <span> · {effectiveColor}</span>}
                    {form.imei && <span className="font-mono"> · {maskImei(form.imei)}</span>}
                    {foundCustomer && <span className="text-emerald-400/70"> · {foundCustomer.name}</span>}
                    {isNewSupplier && supplierName && <span className="text-amber-400/70"> · {supplierName}</span>}
                  </p>
                </div>
                <button onClick={() => setStep(1)} className="text-[10px] text-violet-400/70 hover:text-violet-300 flex items-center gap-1 px-2 py-1 rounded-lg border border-violet-500/20 hover:border-violet-500/40 transition-all shrink-0">
                  تعديل
                </button>
              </div>

              {/* Prices row */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={lReq}>سعر الشراء *</label>
                  <div className="relative">
                    <input type="number" min={0} value={fin.purchase_price}
                      onChange={e => fp("purchase_price", e.target.value)}
                      placeholder="0" className={`${iCls("purchase_price")} pl-12`} />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] text-white/30 font-mono">EGP</span>
                  </div>
                </div>
                <div>
                  <label className={lCls}>سعر البيع المقترح</label>
                  <div className="relative">
                    <input type="number" min={0} value={fin.sale_price}
                      onChange={e => fp("sale_price", e.target.value)}
                      placeholder="0" className={`${iCls()} pl-12`} />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] text-white/30 font-mono">EGP</span>
                  </div>
                  {fin.purchase_price && fin.sale_price &&
                    parseFloat(fin.sale_price) > parseFloat(fin.purchase_price) && (
                    <p className="text-[10px] text-emerald-400/70 mt-1">
                      هامش ربح: {(parseFloat(fin.sale_price) - parseFloat(fin.purchase_price)).toLocaleString("ar-EG")} ج
                    </p>
                  )}
                </div>
              </div>

              {/* Warehouse */}
              <div>
                <label className={lReq}>المخزن *</label>
                <select value={fin.warehouse_id} onChange={e => fp("warehouse_id", e.target.value)}
                  className={sCls("warehouse_id")}>
                  <option value="">— اختر المخزن —</option>
                  {warehouses.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
                </select>
                {warehouses.length === 0 && (
                  <p className="text-[10px] text-amber-400/60 mt-1 flex items-center gap-1">
                    <Info className="w-3 h-3" /> لا يوجد مخزن — أضف مخزناً من إعدادات النظام
                  </p>
                )}
              </div>

              {/* Payment type */}
              <div>
                <label className={lCls}>طريقة الدفع</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["cash", "credit", "partial"] as const).map(pt => {
                    const disabled = isNewSupplier && pt !== "cash";
                    return (
                      <button key={pt}
                        onClick={() => !disabled && fp("payment_type", pt)}
                        disabled={disabled}
                        className={`py-2 rounded-xl border text-sm font-bold transition-all ${
                          fin.payment_type === pt
                            ? "bg-violet-500/20 border-violet-500/50 text-violet-300"
                            : disabled
                              ? "border-white/5 text-white/15 cursor-not-allowed"
                              : "border-white/10 text-white/40 hover:border-violet-500/30 hover:text-white/70"
                        }`}>
                        {PAYMENT_LABELS[pt]}
                      </button>
                    );
                  })}
                </div>
                {isNewSupplier && (
                  <p className="text-[10px] text-amber-400/50 mt-1.5 flex items-center gap-1">
                    <Info className="w-3 h-3" /> مورد مؤقت غير مسجّل — نقدي فقط
                  </p>
                )}
              </div>

              {/* Safe selector (not for full credit) */}
              {fin.payment_type !== "credit" && (
                <div>
                  <label className={lReq}>الخزينة *</label>
                  <select value={fin.safe_id} onChange={e => fp("safe_id", e.target.value)}
                    className={sCls("safe_id")}>
                    <option value="">— اختر الخزينة —</option>
                    {safes.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} — {parseFloat(s.balance).toLocaleString("ar-EG")} ج
                      </option>
                    ))}
                  </select>
                  {safes.length === 0 && (
                    <p className="text-[10px] text-amber-400/60 mt-1 flex items-center gap-1">
                      <Info className="w-3 h-3" /> لا يوجد خزينة — أضف خزينة من إعدادات النظام
                    </p>
                  )}
                </div>
              )}

              {/* Partial: paid amount */}
              {fin.payment_type === "partial" && (
                <div>
                  <label className={lReq}>المبلغ المدفوع الآن *</label>
                  <div className="relative">
                    <input type="number" min={0} value={fin.paid_amount}
                      onChange={e => fp("paid_amount", e.target.value)}
                      placeholder="0" className={`${iCls("paid_amount")} pl-12`} />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[11px] text-white/30 font-mono">EGP</span>
                  </div>
                  {fin.purchase_price && fin.paid_amount && (
                    <p className="text-[10px] text-amber-400/70 mt-1">
                      المتبقي: {(parseFloat(fin.purchase_price) - parseFloat(fin.paid_amount)).toLocaleString("ar-EG")} ج
                      {foundCustomer && " — سيُضاف لكشف حساب المورد"}
                    </p>
                  )}
                </div>
              )}

              {/* Credit summary */}
              {fin.payment_type === "credit" && foundCustomer && (
                <div className="flex items-start gap-2.5 p-3 bg-amber-500/6 border border-amber-500/20 rounded-xl">
                  <Info className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                  <div className="text-[11px] text-amber-300/70 leading-relaxed">
                    سيُضاف المبلغ كاملاً ({fin.purchase_price ? Number(fin.purchase_price).toLocaleString("ar-EG") : 0} ج) إلى ذمة{" "}
                    <span className="text-amber-300 font-bold">{foundCustomer.name}</span> في كشف الحساب
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* ── Footer ── */}
        <div className="px-5 py-3.5 border-t border-white/10 shrink-0 flex gap-2 justify-between">
          {step === 2 ? (
            <button onClick={() => setStep(1)}
              className="px-4 py-2 rounded-xl border border-white/10 text-white/50 text-sm hover:text-white/80 transition-all flex items-center gap-1.5">
              ← السابق
            </button>
          ) : (
            <button onClick={onClose}
              className="px-4 py-2 rounded-xl border border-white/10 text-white/50 text-sm hover:text-white/80 transition-all">
              إلغاء
            </button>
          )}

          {step === 1 ? (
            <button onClick={handleNext} disabled={lookingUp}
              className="px-6 py-2 rounded-xl bg-violet-500/20 border border-violet-500/40 text-violet-300 text-sm font-bold hover:bg-violet-500/30 transition-all flex items-center gap-2 disabled:opacity-40">
              {lookingUp
                ? <div className="w-3.5 h-3.5 border-2 border-violet-400/40 border-t-violet-400 rounded-full animate-spin" />
                : null}
              التالي ←
            </button>
          ) : (
            <button onClick={handleSave} disabled={saving}
              className="px-7 py-2.5 rounded-xl bg-gradient-to-r from-violet-600/30 to-violet-500/20 border border-violet-500/50 text-violet-200 text-sm font-bold hover:from-violet-600/40 hover:to-violet-500/30 transition-all disabled:opacity-40 flex items-center gap-2">
              {saving
                ? <div className="w-3.5 h-3.5 border-2 border-violet-400/40 border-t-violet-400 rounded-full animate-spin" />
                : <ShoppingCart className="w-3.5 h-3.5" />}
              حفظ وشراء
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   SELL DEVICE MODAL
════════════════════════════════════════════════════════ */
function SellModal({ device, onClose, onDone }: { device: Device; onClose: () => void; onDone: () => void }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [customerName, setCustomerName] = useState("");
  const [customerId, setCustomerId] = useState<string>("");
  const { data: customersRaw } = useGetCustomers();
  const customerItems = useMemo(() => {
    const list = safeArray(customersRaw as { id: number; name: string }[] | undefined);
    return list.map(c => ({ value: String(c.id), label: c.name, searchKeys: [c.name] }));
  }, [customersRaw]);
  const [basePrice, setBasePrice] = useState(parseFloat(device.sale_price ?? "0"));
  const [discountType, setDiscountType] = useState<"none" | "percent" | "fixed">("none");
  const [discountVal, setDiscountVal] = useState(0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>("cash");
  const [payStatus, setPayStatus] = useState<PaymentStatus>("paid");
  const [warrantyMonths, setWarrantyMonths] = useState(3);
  const [saving, setSaving] = useState(false);

  const discountAmount = discountType === "percent"
    ? Math.round(basePrice * discountVal / 100)
    : discountType === "fixed" ? discountVal : 0;
  const finalPrice = Math.max(0, basePrice - discountAmount);

  const handleSell = async () => {
    if (!customerName.trim() && !customerId) { toast({ title: "أدخل اسم العميل أو اختر عميلاً", variant: "destructive" }); return; }
    const resolvedName = customerId
      ? (customerItems.find(c => c.value === customerId)?.label ?? customerName.trim())
      : customerName.trim();
    setSaving(true);
    try {
      await apiPost(`/api/devices/${device.id}/sell`, {
        customer_name: resolvedName,
        customer_id: customerId ? Number(customerId) : undefined,
        sold_price: finalPrice,
        payment_method: payMethod,
        payment_status: payStatus,
        warranty_months: warrantyMonths,
        sold_by_name: (user as { name?: string })?.name,
      });
      toast({ title: "✅ تم بيع الجهاز بنجاح" });
      onDone(); onClose();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "خطأ";
      toast({ title: msg || "خطأ في البيع", variant: "destructive" });
    } finally { setSaving(false); }
  };

  const lCls = "text-[11px] text-white/40 mb-1 block text-right";

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-6 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
      <div className="glass-panel rounded-2xl border border-white/10 w-full max-w-sm mx-4 my-4">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="font-bold text-white text-sm">بيع الجهاز</span>
              <p className="text-[10px] text-white/30">{device.brand} {device.model}</p>
            </div>
          </div>
          <button onClick={onClose} className="btn-icon text-white/40 hover:text-white">
            <XCircle className="w-4 h-4" />
          </button>
        </div>

        {/* Device summary */}
        <div className="mx-4 mt-4 flex items-center gap-3 p-3 bg-white/4 rounded-xl border border-white/8">
          <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5 text-violet-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-white text-sm truncate">{device.brand} {device.model}</p>
            <p className="text-white/40 text-xs mt-0.5">
              {device.storage && <span className="ml-2">{device.storage}</span>}
              {device.color && <span className="ml-2">· {device.color}</span>}
              {device.imei && <span className="ml-2 font-mono">· IMEI: ···{device.imei.slice(-4)}</span>}
            </p>
          </div>
          <div className="text-right">
            <p className="text-emerald-400 font-bold text-sm">{finalPrice.toLocaleString()} ج.م</p>
            <p className="text-white/25 text-[10px]">سعر البيع</p>
          </div>
        </div>

        <div className="p-4 space-y-3.5">
          {/* Customer */}
          <div>
            <label className={lCls}>العميل *</label>
            {customerItems.length > 0 ? (
              <SearchableSelect
                items={customerItems}
                value={customerId}
                onChange={id => { setCustomerId(id); setCustomerName(""); }}
                placeholder="ابحث في العملاء..."
              />
            ) : null}
            {!customerId && (
              <input value={customerName} onChange={e => setCustomerName(e.target.value)}
                placeholder={customerItems.length > 0 ? "أو أدخل اسم عميل جديد..." : "اسم العميل..."}
                className={`erp-input w-full text-sm ${customerItems.length > 0 ? "mt-2" : ""}`} />
            )}
            {customerId && (
              <button onClick={() => setCustomerId("")}
                className="mt-1 text-xs text-white/30 hover:text-red-400 transition-colors">
                × إلغاء التحديد
              </button>
            )}
          </div>

          {/* Base price */}
          <div>
            <label className={lCls}>سعر البيع الأساسي</label>
            <input type="number" value={basePrice}
              onChange={e => setBasePrice(parseFloat(e.target.value) || 0)}
              className="erp-input w-full text-sm" />
          </div>

          {/* Discount */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={lCls}>نوع الخصم</label>
              <select value={discountType} onChange={e => { setDiscountType(e.target.value as "none"|"percent"|"fixed"); setDiscountVal(0); }}
                className="erp-input w-full text-sm">
                <option value="none">بدون خصم</option>
                <option value="percent">نسبة %</option>
                <option value="fixed">مبلغ ثابت</option>
              </select>
            </div>
            <div>
              <label className={lCls}>قيمة الخصم</label>
              <div className="relative">
                <input type="number" min={0} value={discountVal} onChange={e => setDiscountVal(parseFloat(e.target.value) || 0)}
                  disabled={discountType === "none"}
                  className="erp-input w-full text-sm disabled:opacity-40 disabled:cursor-not-allowed" />
                {discountType === "percent" && (
                  <Percent className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-white/30 pointer-events-none" />
                )}
              </div>
            </div>
          </div>
          {discountType !== "none" && discountAmount > 0 && (
            <div className="flex items-center justify-between bg-amber-500/8 border border-amber-500/20 rounded-lg px-3 py-2 text-xs">
              <span className="text-white/50">الخصم: {discountAmount.toLocaleString()} ج.م</span>
              <span className="text-emerald-400 font-bold">الإجمالي بعد الخصم: {finalPrice.toLocaleString()} ج.م</span>
            </div>
          )}

          {/* Payment method */}
          <div>
            <label className={lCls}>طريقة الدفع</label>
            <div className="grid grid-cols-4 gap-1.5">
              {PAY_METHODS.map(({ v, l }) => (
                <button key={v} onClick={() => setPayMethod(v)}
                  className={`py-2 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-0.5 ${
                    payMethod === v
                      ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-300"
                      : "border-white/10 bg-white/3 text-white/40 hover:text-white/70"
                  }`}>{l}</button>
              ))}
            </div>
          </div>

          {/* Payment status */}
          <div>
            <label className={lCls}>حالة الدفع</label>
            <div className="grid grid-cols-3 gap-1.5">
              {([
                ["paid",    "مدفوع بالكامل", "text-emerald-300 bg-emerald-500/15 border-emerald-500/50"],
                ["partial", "دفع جزئي",      "text-amber-300 bg-amber-500/15 border-amber-500/50"],
                ["unpaid",  "غير مدفوع",     "text-red-300 bg-red-500/15 border-red-500/50"],
              ] as [PaymentStatus, string, string][]).map(([v, l, cls]) => (
                <button key={v} onClick={() => setPayStatus(v)}
                  className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                    payStatus === v ? cls : "border-white/10 bg-white/3 text-white/40 hover:text-white/70"
                  }`}>{l}</button>
              ))}
            </div>
          </div>

          {/* Warranty + Seller */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={lCls}>فترة الضمان</label>
              <select value={warrantyMonths} onChange={e => setWarrantyMonths(parseInt(e.target.value))} className="erp-input w-full text-sm">
                {WARRANTY_OPTS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
            <div>
              <label className={lCls}>البائع</label>
              <div className="erp-input w-full text-sm text-white/50 flex items-center gap-1.5">
                <User className="w-3 h-3 shrink-0" />
                <span className="truncate">{(user as { name?: string })?.name ?? "—"}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 pb-4 flex gap-2">
          <button onClick={onClose} className="flex-1 py-2 rounded-xl border border-white/10 text-white/50 text-sm hover:text-white/80">
            إلغاء
          </button>
          <button onClick={handleSell} disabled={saving}
            className="flex-1 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold hover:bg-emerald-500/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2">
            {saving ? <div className="w-3.5 h-3.5 border-2 border-emerald-400/40 border-t-emerald-400 rounded-full animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
            تأكيد البيع
          </button>
        </div>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   RETURN DEVICE MODAL
════════════════════════════════════════════════════════ */
const RETURN_REASONS = [
  "عيب مصنعي",
  "الجهاز لا يعمل بشكل صحيح",
  "لم يعجب العميل",
  "وجد جهاز آخر",
  "تغيير رأي العميل",
  "الجهاز تالف",
  "خلاف على السعر",
  "أخرى",
];

function ReturnModal({ device, onClose, onDone }: { device: Device; onClose: () => void; onDone: () => void }) {
  const { toast } = useToast();
  const [reason, setReason] = useState(RETURN_REASONS[0]);
  const [customReason, setCustomReason] = useState("");
  const [saving, setSaving] = useState(false);

  const handleReturn = async () => {
    setSaving(true);
    try {
      await apiPost(`/api/devices/${device.id}/return`, {
        return_reason: reason === "أخرى" ? customReason.trim() || "أخرى" : reason,
      });
      toast({ title: "✅ تم إرجاع الجهاز وأصبح متاحاً" });
      onDone(); onClose();
    } catch {
      toast({ title: "خطأ في عملية الإرجاع", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const returnPrice = device.sold_price ?? device.sale_price;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm" dir="rtl">
      <div className="glass-panel rounded-2xl border border-amber-500/20 w-full max-w-sm mx-4 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-white">إرجاع الجهاز من العميل</span>
          </div>
          <button onClick={onClose} className="btn-icon text-white/40 hover:text-white">
            <XCircle className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Device info */}
          <div className="bg-amber-500/8 border border-amber-500/20 rounded-xl p-3 text-sm space-y-1">
            <p className="text-white/80 font-bold">{device.brand} {device.model}</p>
            <p className="text-white/40 text-xs">{device.device_no} — {device.color ?? ""}</p>
            {device.sold_to_customer_name && (
              <p className="text-white/50 text-xs">العميل: {device.sold_to_customer_name}</p>
            )}
          </div>

          {/* Return price (read-only, equals sale price) */}
          <div>
            <label className="text-[11px] text-white/40 mb-1 block text-right">سعر الإرجاع (نفس سعر الفاتورة)</label>
            <div className="erp-input w-full text-sm flex items-center justify-between opacity-70 cursor-not-allowed">
              <span className="text-emerald-300 font-bold">
                {parseFloat(returnPrice ?? "0").toLocaleString("ar-EG")} ج.م
              </span>
              <span className="text-white/30 text-xs">غير قابل للتعديل</span>
            </div>
          </div>

          {/* Return reason */}
          <div>
            <label className="text-[11px] text-white/40 mb-1 block text-right">سبب الإرجاع *</label>
            <select value={reason} onChange={e => setReason(e.target.value)} className="erp-input w-full text-sm">
              {RETURN_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
            {reason === "أخرى" && (
              <input value={customReason} onChange={e => setCustomReason(e.target.value)}
                placeholder="اكتب سبب الإرجاع" className="erp-input w-full text-sm mt-1.5" />
            )}
          </div>

          <p className="text-[11px] text-amber-400/70 bg-amber-500/8 border border-amber-500/15 rounded-lg p-2.5">
            سيتم إرجاع الجهاز لحالة «متاح» وحفظ سبب الإرجاع في ملاحظات الجهاز.
          </p>
        </div>

        <div className="px-5 pb-5 flex gap-2">
          <button onClick={onClose}
            className="flex-1 py-2 rounded-xl border border-white/10 text-white/50 text-sm hover:text-white/80">
            إلغاء
          </button>
          <button onClick={handleReturn} disabled={saving}
            className="flex-1 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-sm font-bold hover:bg-amber-500/30 transition-all disabled:opacity-40 flex items-center justify-center gap-2">
            {saving ? <div className="w-3.5 h-3.5 border-2 border-amber-400/40 border-t-amber-400 rounded-full animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
            تأكيد الإرجاع
          </button>
        </div>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════
   DEVICE DETAIL PANEL — 4 TABS
════════════════════════════════════════════════════════ */
function DeviceDetail({ device, onClose, onRefresh }: { device: Device; onClose: () => void; onRefresh: () => void }) {
  const { toast } = useToast();
  const { settings } = useAppSettings();
  const [tab, setTab] = useState<1 | 2 | 3 | 4>(1);
  const [showSell, setShowSell] = useState(false);
  const [showReturn, setShowReturn] = useState(false);
  const [confirming, setConfirming] = useState<"delete" | "maintenance" | "available" | null>(null);

  const doAction = async (action: "delete" | "maintenance" | "available") => {
    try {
      if (action === "delete") {
        const r = await authFetch(api(`/api/devices/${device.id}`), { method: "DELETE" });
        if (!r.ok) throw new Error();
        toast({ title: "تم حذف الجهاز" });
      } else {
        await apiPost(`/api/devices/${device.id}/${action}`, {});
        toast({ title: action === "maintenance" ? "تم إرسال الجهاز للصيانة" : "تم إرجاع الجهاز كمتاح" });
      }
      onRefresh(); onClose();
    } catch {
      toast({ title: "خطأ في العملية", variant: "destructive" });
    }
    setConfirming(null);
  };

  const InfoCard = ({ icon: Icon, label, value, color = "text-white/70", copyable = false }: {
    icon: ElementType; label: string; value: string | number | undefined; color?: string; copyable?: boolean;
  }) => {
    const { toast: t } = useToast();
    return (
      <div className="bg-white/3 rounded-xl border border-white/6 p-2.5 flex flex-col gap-0.5 group">
        <div className="flex items-center justify-between text-white/30 text-[10px]">
          <div className="flex items-center gap-1.5"><Icon className="w-3 h-3" /> {label}</div>
          {copyable && value && (
            <button onClick={() => { navigator.clipboard.writeText(String(value)); t({ title: "تم النسخ" }); }}
              className="opacity-0 group-hover:opacity-100 transition-opacity">
              <Copy className="w-3 h-3 hover:text-white/60" />
            </button>
          )}
        </div>
        <span className={`font-bold text-sm ${color}`}>{value ?? "—"}</span>
      </div>
    );
  };

  const FlagChip = ({ label, val, warn = false }: { label: string; val: boolean; warn?: boolean }) => (
    <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-medium ${
      val
        ? warn
          ? "border-red-500/30 bg-red-500/10 text-red-300"
          : "border-emerald-500/20 bg-emerald-500/8 text-emerald-400"
        : "border-white/6 bg-white/3 text-white/25"
    }`}>
      {val ? warn ? <AlertTriangle className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
      {label}
    </div>
  );

  const profit = device.sold_price
    ? parseFloat(device.sold_price) - parseFloat(device.purchase_price)
    : parseFloat(device.sale_price) - parseFloat(device.purchase_price);

  const TABS = [
    { id: 1 as const, label: "بيانات الجهاز" },
    { id: 2 as const, label: "المصدر" },
    { id: 3 as const, label: "السجل" },
    { id: 4 as const, label: "سجل المبيعات" },
  ];

  const PAY_LABELS: Record<string, string> = { cash: "نقداً", card: "بطاقة", instapay: "InstaPay", transfer: "تحويل بنكي" };
  const STATUS_LABELS: Record<string, string> = { paid: "مدفوع بالكامل", partial: "دفع جزئي", unpaid: "غير مدفوع" };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-4 bg-black/70 backdrop-blur-sm" dir="rtl">
        <div className="glass-panel rounded-2xl border border-white/10 w-full max-w-lg mx-4 overflow-hidden flex flex-col" style={{ maxHeight: "94vh" }}>

          {/* ── Header ── */}
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
                <Smartphone className="w-4.5 h-4.5 text-violet-400" />
              </div>
              <div>
                <p className="font-bold text-white text-sm">{device.brand} {device.model}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[11px] text-white/30 font-mono">{device.device_no}</span>
                  <button onClick={() => { navigator.clipboard.writeText(device.device_no); }}
                    className="text-white/20 hover:text-white/50 transition-colors">
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={device.status} />
              <button onClick={onClose} className="btn-icon text-white/40 hover:text-white">
                <XCircle className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ── Tabs ── */}
          <div className="flex border-b border-white/8 shrink-0 px-1">
            {TABS.map(({ id, label }) => (
              <button key={id} onClick={() => setTab(id)}
                className={`flex-1 py-2.5 text-xs font-bold transition-all border-b-2 ${
                  tab === id
                    ? "border-violet-500 text-violet-300"
                    : "border-transparent text-white/30 hover:text-white/60"
                }`}>
                <span>{id}</span>
                <span className="mr-1">{label}</span>
              </button>
            ))}
          </div>

          {/* ── Tab Body ── */}
          <div className="overflow-y-auto flex-1 p-4 space-y-4">

            {/* ══ TAB 1: Device Data ══ */}
            {tab === 1 && (
              <>
                {/* Specs grid 3-col */}
                <div className="grid grid-cols-3 gap-2">
                  <InfoCard icon={Package}   label="السعة"     value={device.storage} />
                  <InfoCard icon={Battery}   label="البطارية"  value={device.battery_health ? `${device.battery_health}%` : undefined}
                    color={device.battery_health && device.battery_health < 80 ? "text-amber-300" : "text-white/70"} />
                  <div className="bg-white/3 rounded-xl border border-white/6 p-2.5 flex flex-col gap-0.5">
                    <div className="flex items-center gap-1.5 text-white/30 text-[10px]"><BadgeCheck className="w-3 h-3" /> الدرجة</div>
                    <GradeBadge grade={device.grade} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {device.color && <InfoCard icon={Tag}  label="اللون"  value={device.color} />}
                  {device.imei  && <InfoCard icon={Info} label="IMEI / SN" value={device.imei} copyable />}
                </div>

                {/* Flags */}
                <div className="bg-white/2 rounded-xl border border-white/6 p-3">
                  <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest mb-2.5 flex items-center gap-1.5">
                    <BadgeCheck className="w-3 h-3" /> حالة الجهاز
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    <FlagChip label="شريحتين"       val={device.dual_sim} />
                    <FlagChip label="بالعلبة"        val={device.with_box} />
                    <FlagChip label="الضريبة مدفوعة" val={true} />
                    <FlagChip label="مفتوح من قبل"   val={device.previously_opened} warn />
                    <FlagChip label="مقفول iCloud"   val={device.icloud_locked} warn />
                    <FlagChip label="مقفول شبكة"     val={device.network_locked} warn />
                    <FlagChip label="مقفول MDM"      val={device.mdm_locked} warn />
                  </div>
                </div>

                {/* Pricing */}
                <div className="bg-white/3 rounded-xl border border-white/6 p-3">
                  <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                    <Banknote className="w-3 h-3" /> التسعير
                  </p>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-white/3 rounded-lg p-2">
                      <p className="text-[10px] text-white/30 mb-1">سعر الشراء</p>
                      <p className="font-bold text-white/60 text-sm">{parseFloat(device.purchase_price).toLocaleString()}</p>
                      <p className="text-[10px] text-white/20">ج.م</p>
                    </div>
                    <div className="bg-white/3 rounded-lg p-2">
                      <p className="text-[10px] text-white/30 mb-1">{device.status === "sold" ? "بيع بـ" : "سعر البيع"}</p>
                      <p className="font-bold text-white text-sm">
                        {parseFloat(device.status === "sold" ? (device.sold_price ?? device.sale_price) : device.sale_price).toLocaleString()}
                      </p>
                      <p className="text-[10px] text-white/20">ج.م</p>
                    </div>
                    <div className="bg-white/3 rounded-lg p-2">
                      <p className="text-[10px] text-white/30 mb-1">الربح</p>
                      <p className={`font-bold text-sm ${profit > 0 ? "text-emerald-400" : "text-red-400"}`}>
                        {profit >= 0 ? "+" : ""}{profit.toLocaleString()}
                      </p>
                      <p className={`text-[10px] ${profit > 0 ? "text-emerald-400/40" : "text-red-400/40"}`}>
                        {parseFloat(device.purchase_price) > 0
                          ? `${Math.round((profit / parseFloat(device.purchase_price)) * 100)}%`
                          : "—"}
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* ══ TAB 2: Source & Notes ══ */}
            {tab === 2 && (
              <div className="space-y-3">
                <div className="bg-white/3 rounded-xl border border-white/6 p-3 space-y-3">
                  <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest flex items-center gap-1.5">
                    <User className="w-3 h-3" /> بيانات المصدر
                  </p>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-[10px] text-white/30 mb-0.5">المورد / البائع</p>
                      <p className="text-white/80 font-medium">{device.supplier_name || "—"}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-white/30 mb-0.5">فاتورة الشراء</p>
                      <p className="text-white/80 font-mono text-xs">{device.purchase_invoice_no || "—"}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-white/30 mb-0.5">الفاحص</p>
                      <p className="text-white/80 font-medium">{device.inspector_name || "—"}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-white/30 mb-0.5">مسجل بواسطة</p>
                      <p className="text-white/80 font-medium">{device.added_by_user_name || "—"}</p>
                    </div>
                  </div>
                  <div className="border-t border-white/6 pt-2.5 flex items-center gap-1.5 text-xs text-white/30">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>تاريخ الإضافة:</span>
                    <span className="text-white/50">{new Date(device.created_at).toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" })}</span>
                  </div>
                </div>

                {device.condition_notes && (
                  <div className="bg-white/2 rounded-xl border border-white/6 p-3">
                    <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                      <FileText className="w-3 h-3" /> ملاحظات الحالة
                    </p>
                    <p className="text-sm text-white/60 leading-relaxed">{device.condition_notes}</p>
                  </div>
                )}
              </div>
            )}

            {/* ══ TAB 3: Maintenance Log ══ */}
            {tab === 3 && (
              <div>
                {device.status === "maintenance" || (device.condition_notes && device.condition_notes.includes("صيانة")) ? (
                  <div className="space-y-2">
                    <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                      <Wrench className="w-3 h-3" /> سجل الصيانة
                    </p>
                    {device.status === "maintenance" && (
                      <div className="flex items-start gap-3 p-3 bg-amber-500/8 border border-amber-500/20 rounded-xl">
                        <div className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                        <div>
                          <p className="text-sm text-amber-300 font-semibold">الجهاز حالياً في الصيانة</p>
                          <p className="text-[11px] text-white/30 mt-0.5">{new Date(device.created_at).toLocaleDateString("ar-EG")}</p>
                        </div>
                      </div>
                    )}
                    {device.condition_notes && (
                      <div className="flex items-start gap-3 p-3 bg-white/3 border border-white/6 rounded-xl">
                        <div className="w-2 h-2 rounded-full bg-white/30 mt-1.5 shrink-0" />
                        <div>
                          <p className="text-sm text-white/70">{device.condition_notes}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-3">
                      <Wrench className="w-5 h-5 text-white/20" />
                    </div>
                    <p className="text-white/40 font-medium">لا يوجد سجل صيانة</p>
                    <p className="text-white/20 text-xs mt-1">هذا الجهاز لم يتم إرساله للصيانة من قبل</p>
                  </div>
                )}
              </div>
            )}

            {/* ══ TAB 4: Sales Log ══ */}
            {tab === 4 && (
              <div>
                {device.status === "sold" && device.sold_to_customer_name ? (
                  <div className="space-y-3">
                    <p className="text-[10px] font-bold text-white/25 uppercase tracking-widest flex items-center gap-1.5">
                      <ShoppingCart className="w-3 h-3" /> بيانات البيع
                    </p>

                    {/* Customer card */}
                    <div className="flex items-center gap-3 p-3 bg-blue-500/8 border border-blue-500/15 rounded-xl">
                      <div className="w-9 h-9 rounded-full bg-blue-500/15 border border-blue-500/20 flex items-center justify-center">
                        <User className="w-4 h-4 text-blue-400" />
                      </div>
                      <div>
                        <p className="font-bold text-white text-sm">{device.sold_to_customer_name}</p>
                        <p className="text-[11px] text-white/30">العميل</p>
                      </div>
                    </div>

                    {/* Sale details grid */}
                    <div className="bg-white/3 rounded-xl border border-white/6 p-3 grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">تاريخ البيع</p>
                        <p className="text-white/80">{device.sold_at ? new Date(device.sold_at).toLocaleDateString("ar-EG", { year: "numeric", month: "long", day: "numeric" }) : "—"}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">البائع</p>
                        <p className="text-white/80">{device.sold_by_user_name || "—"}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">سعر البيع</p>
                        <p className="text-emerald-400 font-bold">{parseFloat(device.sold_price ?? "0").toLocaleString()} ج.م</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">صافي الربح</p>
                        <p className={`font-bold ${profit >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                          {profit >= 0 ? "+" : ""}{profit.toLocaleString()} ج.م
                        </p>
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">طريقة الدفع</p>
                        <p className="text-white/70">{PAY_LABELS[device.payment_method ?? ""] ?? device.payment_method ?? "—"}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 mb-0.5">حالة الدفع</p>
                        <p className={`font-medium text-xs ${device.payment_status === "paid" ? "text-emerald-400" : device.payment_status === "partial" ? "text-amber-400" : "text-red-400"}`}>
                          {STATUS_LABELS[device.payment_status ?? ""] ?? device.payment_status ?? "—"}
                        </p>
                      </div>
                      {device.warranty_months && (
                        <div className="col-span-2">
                          <p className="text-[10px] text-white/30 mb-0.5">فترة الضمان</p>
                          <p className="text-blue-300 font-medium">{device.warranty_months} شهر</p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-3">
                      <ShoppingCart className="w-5 h-5 text-white/20" />
                    </div>
                    <p className="text-white/40 font-medium">لم يُباع بعد</p>
                    <p className="text-white/20 text-xs mt-1">هذا الجهاز لم يتم بيعه بعد</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── Actions footer ── */}
          <div className="px-4 py-3.5 border-t border-white/10 shrink-0">
            {confirming ? (
              <div className="flex items-center justify-between">
                <span className="text-sm text-white/60">
                  {confirming === "delete" ? "تأكيد الحذف؟" : confirming === "maintenance" ? "إرسال للصيانة؟" : "إرجاع كمتاح؟"}
                </span>
                <div className="flex gap-2">
                  <button onClick={() => setConfirming(null)} className="px-3 py-1.5 rounded-xl border border-white/10 text-white/50 text-xs">إلغاء</button>
                  <button onClick={() => doAction(confirming)}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-bold ${
                      confirming === "delete" ? "border-red-500/40 bg-red-500/15 text-red-300" : "border-amber-500/40 bg-amber-500/15 text-amber-300"
                    }`}>تأكيد</button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                {device.status === "available" && (
                  <>
                    <button onClick={() => setShowSell(true)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold hover:bg-emerald-500/30 transition-all">
                      <ShoppingCart className="w-3.5 h-3.5" /> بيع الجهاز
                    </button>
                    <button onClick={() => setConfirming("maintenance")} title="إرسال للصيانة"
                      className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-400 text-sm hover:bg-amber-500/20 transition-all">
                      <Wrench className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
                {device.status === "sold" && (
                  <>
                    <button onClick={() => printSaleReceipt(device, settings.companyName)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-violet-500/15 border border-violet-500/30 text-violet-300 text-sm font-bold hover:bg-violet-500/25 transition-all">
                      <Printer className="w-3.5 h-3.5" /> طباعة الفاتورة
                    </button>
                    <button onClick={() => setShowReturn(true)} title="إرجاع من العميل"
                      className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm hover:bg-amber-500/20 transition-all">
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
                {device.status === "maintenance" && (
                  <button onClick={() => setConfirming("available")}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-sm hover:bg-emerald-500/20 transition-all">
                    <RotateCcw className="w-3.5 h-3.5" /> إرجاع كمتاح
                  </button>
                )}
                <button onClick={() => setConfirming("delete")} title="حذف الجهاز"
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm hover:bg-red-500/20 transition-all">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {showSell && (
        <SellModal device={device} onClose={() => setShowSell(false)} onDone={onRefresh} />
      )}
      {showReturn && (
        <ReturnModal device={device} onClose={() => setShowReturn(false)} onDone={() => { onRefresh(); onClose(); }} />
      )}
    </>
  );
}

/* ════════════════════════════════════════════════════════
   MAIN DEVICES PAGE
════════════════════════════════════════════════════════ */

/** Mask IMEI: first 6 + ••••• + last 3 */
function maskImei(imei: string): string {
  if (!imei || imei.length < 9) return imei;
  return `${imei.slice(0, 6)}•••••${imei.slice(-3)}`;
}

/** Row action menu (three-dot) */
function RowMenu({ device, onDetail, onRefresh }: {
  device: Device; onDetail: () => void; onRefresh: () => void;
}) {
  const { toast } = useToast();
  const { settings } = useAppSettings();
  const [open, setOpen] = useState(false);
  const [menuPos, setMenuPos] = useState({ top: 0, left: 0 });
  const [showSell, setShowSell] = useState(false);
  const [confirming, setConfirming] = useState<"delete" | "maintenance" | "available" | "return" | null>(null);
  const wrapperRef  = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const btnRef      = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onMouse = (e: MouseEvent) => {
      const t = e.target as Node;
      const inWrapper  = wrapperRef.current?.contains(t);
      const inDropdown = dropdownRef.current?.contains(t);
      if (!inWrapper && !inDropdown) setOpen(false);
    };
    const onScroll = () => setOpen(false);
    document.addEventListener("mousedown", onMouse);
    window.addEventListener("scroll", onScroll, true);
    return () => {
      document.removeEventListener("mousedown", onMouse);
      window.removeEventListener("scroll", onScroll, true);
    };
  }, [open]);

  const handleOpenMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      const dropdownWidth = 176; // w-44 = 11rem = 176px
      // Align dropdown's right edge with button's right edge, clamped to viewport
      const leftPos = Math.max(4, Math.min(rect.right - dropdownWidth, window.innerWidth - dropdownWidth - 4));
      setMenuPos({ top: rect.bottom + 4, left: leftPos });
    }
    setOpen(v => !v);
  };

  const doAction = async (action: "delete" | "maintenance" | "available") => {
    try {
      if (action === "delete") {
        const r = await authFetch(api(`/api/devices/${device.id}`), { method: "DELETE" });
        if (!r.ok) throw new Error();
        toast({ title: "تم حذف الجهاز" });
      } else {
        await apiPost(`/api/devices/${device.id}/${action}`, {});
        toast({ title: action === "maintenance" ? "أُرسل للصيانة" : "أُرجع كمتاح" });
      }
      onRefresh();
    } catch {
      toast({ title: "خطأ في العملية", variant: "destructive" });
    }
    setConfirming(null); setOpen(false);
  };

  const menuItems = device.status === "available"
    ? [
        { label: "بيع الجهاز",     icon: ShoppingCart, action: () => { setOpen(false); setShowSell(true); }, cls: "text-emerald-300" },
        { label: "إرسال للصيانة",  icon: Wrench,       action: () => { setOpen(false); setConfirming("maintenance"); }, cls: "text-amber-300" },
        { label: "حذف الجهاز",     icon: Trash2,       action: () => { setOpen(false); setConfirming("delete"); }, cls: "text-red-400" },
      ]
    : device.status === "sold"
      ? [
          { label: "طباعة الفاتورة", icon: Printer,   action: () => { setOpen(false); printSaleReceipt(device, settings.companyName); }, cls: "text-violet-300" },
          { label: "إرجاع من العميل",icon: RotateCcw, action: () => { setOpen(false); setConfirming("return"); }, cls: "text-amber-300" },
          { label: "حذف الجهاز",    icon: Trash2,     action: () => { setOpen(false); setConfirming("delete"); }, cls: "text-red-400" },
        ]
      : [
          { label: "إرجاع كمتاح",  icon: RotateCcw, action: () => { setOpen(false); setConfirming("available"); }, cls: "text-emerald-300" },
          { label: "حذف الجهاز",   icon: Trash2,    action: () => { setOpen(false); setConfirming("delete"); }, cls: "text-red-400" },
        ];

  return (
    <div ref={wrapperRef} className="relative flex items-center gap-1">
      {/* Eye icon */}
      <button onClick={(e) => { e.stopPropagation(); onDetail(); }}
        title="تفاصيل الجهاز"
        className="p-1.5 rounded-lg text-white/25 hover:text-violet-300 hover:bg-violet-500/10 transition-all">
        <Eye className="w-3.5 h-3.5" />
      </button>

      {/* Three-dot */}
      <button ref={btnRef} onClick={handleOpenMenu}
        className="p-1.5 rounded-lg text-white/25 hover:text-white/70 hover:bg-white/8 transition-all">
        <MoreVertical className="w-3.5 h-3.5" />
      </button>

      {open && createPortal(
        <div
          ref={dropdownRef}
          className="row-menu-dropdown"
          onMouseDown={e => e.stopPropagation()}
          style={{ position: "fixed", top: menuPos.top, left: menuPos.left, zIndex: 99999 }}
          dir="rtl">
          {menuItems.map(({ label, icon: Icon, action, cls }) => (
            <button key={label} onClick={(e) => { e.stopPropagation(); action(); }}
              className={cls}>
              <Icon className="w-3.5 h-3.5 shrink-0" />
              {label}
            </button>
          ))}
        </div>,
        document.body
      )}

      {/* Confirm dialog */}
      {confirming && confirming !== "return" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" dir="rtl"
          onClick={e => e.stopPropagation()}>
          <div className="glass-panel rounded-2xl border border-white/10 p-5 w-72 space-y-4">
            <p className="font-bold text-white text-center">
              {confirming === "delete" ? "حذف الجهاز؟" : confirming === "maintenance" ? "إرسال للصيانة؟" : "إرجاع كمتاح؟"}
            </p>
            <p className="text-white/40 text-xs text-center">{device.brand} {device.model}</p>
            <div className="flex gap-2">
              <button onClick={(e) => { e.stopPropagation(); setConfirming(null); }}
                className="flex-1 py-2 rounded-xl border border-white/10 text-white/50 text-sm">إلغاء</button>
              <button onClick={(e) => { e.stopPropagation(); doAction(confirming as "delete" | "maintenance" | "available"); }}
                className={`flex-1 py-2 rounded-xl border text-sm font-bold ${
                  confirming === "delete" ? "border-red-500/40 bg-red-500/15 text-red-300" : "border-amber-500/40 bg-amber-500/15 text-amber-300"
                }`}>تأكيد</button>
            </div>
          </div>
        </div>
      )}

      {showSell && (
        <SellModal device={device} onClose={() => setShowSell(false)} onDone={onRefresh} />
      )}
      {confirming === "return" && (
        <ReturnModal device={device} onClose={() => setConfirming(null)} onDone={() => { onRefresh(); setConfirming(null); }} />
      )}
    </div>
  );
}

export default function Devices() {
  const qc = useQueryClient();
  const [pageView, setPageView] = useState<"devices" | "warranty">("devices");
  const [statusFilter, setStatusFilter] = useState<"all" | DeviceStatus>("all");
  const [search, setSearch] = useState("");
  const [devicePage, setDevicePage] = useState(1);
  const DEVICE_PAGE_SIZE = 30;
  const [showAdd, setShowAdd] = useState(false);
  const [selected, setSelected] = useState<Device | null>(null);
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["/api/devices"] });
    qc.invalidateQueries({ queryKey: ["/api/devices/stats"] });
  };

  const { data: stats } = useQuery<Stats>({
    queryKey: ["/api/devices/stats"],
    queryFn: () => authFetch(api("/api/devices/stats")).then(r => r.json() as Promise<Stats>),
    staleTime: 30_000,
  });

  const { data: allDevices = [], isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices", statusFilter, search],
    queryFn: () => {
      const p = new URLSearchParams();
      if (statusFilter !== "all") p.set("status", statusFilter);
      if (search.trim()) p.set("search", search.trim());
      return authFetch(api(`/api/devices?${p}`)).then(r => r.json() as Promise<Device[]>);
    },
    staleTime: 30_000,
    select: (d) => (Array.isArray(d) ? d : []),
  });

  useEffect(() => { setDevicePage(1); }, [search, statusFilter]);

  const paginatedDevices = useMemo(
    () => allDevices.slice((devicePage - 1) * DEVICE_PAGE_SIZE, devicePage * DEVICE_PAGE_SIZE),
    [allDevices, devicePage, DEVICE_PAGE_SIZE]
  );

  const FILTERS: { v: "all" | DeviceStatus; l: string; count: number }[] = [
    { v: "all",        l: "الكل",   count: stats?.total ?? 0 },
    { v: "available",  l: "متاح",   count: stats?.available ?? 0 },
    { v: "maintenance",l: "صيانة",  count: stats?.maintenance ?? 0 },
    { v: "sold",       l: "مباع",   count: stats?.sold ?? 0 },
  ];

  return (
    <div className="p-4 space-y-4 max-w-5xl mx-auto" dir="rtl">

      {/* ── Page header ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center">
            <Smartphone className="w-4 h-4 text-violet-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">الأجهزة المستعملة</h1>
            <p className="text-[11px] text-white/30">شراء وبيع الأجهزة — البيع والصيانة</p>
          </div>
        </div>
        {pageView === "devices" && (
          <button onClick={() => setShowAdd(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-500/20 border border-violet-500/40 text-violet-300 text-sm font-bold hover:bg-violet-500/30 transition-all">
            <Plus className="w-4 h-4" /> إضافة جهاز
          </button>
        )}
      </div>

      {/* ── Page-level tab bar ── */}
      <div className="flex gap-1 border-b border-white/8 pb-0">
        {[
          { id: "devices" as const, label: "الأجهزة", icon: Smartphone },
          { id: "warranty" as const, label: "الضمانات", icon: Shield },
        ].map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setPageView(id)}
            className={`flex items-center gap-1.5 px-4 py-2 text-sm font-bold border-b-2 transition-all -mb-px ${
              pageView === id
                ? id === "warranty"
                  ? "border-amber-500 text-amber-300"
                  : "border-violet-500 text-violet-300"
                : "border-transparent text-white/40 hover:text-white/70"
            }`}>
            <Icon className="w-3.5 h-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* ── Warranty tab ── */}
      {pageView === "warranty" && <Warranty embedded />}

      {/* ── Devices content (hidden on warranty tab) ── */}
      {pageView === "devices" && <>

      {/* ── Stats cards — Row 1: Counts ── */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: "إجمالي الأجهزة", value: stats?.total ?? 0,        color: "text-white",       icon: Smartphone },
          { label: "متاح للبيع",     value: stats?.available ?? 0,     color: "text-emerald-400", icon: CheckCircle2 },
          { label: "في الصيانة",     value: stats?.maintenance ?? 0,   color: "text-amber-400",   icon: Wrench },
          { label: "إجمالي المباع",  value: stats?.sold ?? 0,          color: "text-blue-400",    icon: ShoppingCart },
        ].map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="glass-panel rounded-xl border border-white/8 p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-white/30">{label}</span>
              <Icon className={`w-3.5 h-3.5 ${color} opacity-60`} />
            </div>
            <p className={`text-2xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* ── Stats cards — Row 2: Financial ── */}
      <div className="grid grid-cols-3 gap-2">
        <div className="glass-panel rounded-xl border border-violet-500/15 p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-white/30">قيمة المخزون (شراء)</span>
            <Package className="w-3.5 h-3.5 text-violet-400/60" />
          </div>
          <p className="text-lg font-bold text-violet-300">
            {(stats?.stock_purchase_value ?? 0).toLocaleString("ar-EG")}
            <span className="text-[10px] font-normal text-white/25 mr-1">ج.م</span>
          </p>
          <p className="text-[10px] text-white/20 mt-0.5">
            سعر بيع متوقع: {(stats?.stock_sale_value ?? 0).toLocaleString("ar-EG")} ج.م
          </p>
        </div>
        <div className="glass-panel rounded-xl border border-emerald-500/15 p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-white/30">ربح متوقع من المخزون</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400/60" />
          </div>
          <p className="text-lg font-bold text-emerald-300">
            {(stats?.stock_profit_potential ?? 0).toLocaleString("ar-EG")}
            <span className="text-[10px] font-normal text-white/25 mr-1">ج.م</span>
          </p>
          <p className="text-[10px] text-white/20 mt-0.5">هامش متوقع على الأجهزة المتاحة</p>
        </div>
        <div className="glass-panel rounded-xl border border-blue-500/15 p-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-white/30">إيراد المبيعات الفعلي</span>
            <Banknote className="w-3.5 h-3.5 text-blue-400/60" />
          </div>
          <p className="text-lg font-bold text-blue-300">
            {(stats?.sold_revenue ?? 0).toLocaleString("ar-EG")}
            <span className="text-[10px] font-normal text-white/25 mr-1">ج.م</span>
          </p>
          <p className={`text-[10px] mt-0.5 font-semibold ${(stats?.sold_profit ?? 0) >= 0 ? "text-emerald-400/70" : "text-red-400/70"}`}>
            صافي الربح: {(stats?.sold_profit ?? 0).toLocaleString("ar-EG")} ج.م
          </p>
        </div>
      </div>

      {/* ── Filters + Search + View toggle ── */}
      <div className="flex items-center gap-2 flex-wrap">
        {/* Status tabs */}
        <div className="flex gap-1">
          {FILTERS.map(({ v, l, count }) => (
            <button key={v} onClick={() => setStatusFilter(v)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                statusFilter === v
                  ? "bg-violet-500/25 border-violet-500/50 text-violet-200"
                  : "border-white/8 text-white/40 hover:text-white/70 hover:border-white/20"
              }`}>
              {l}
              <span className={`text-[10px] px-1.5 rounded-full ${
                statusFilter === v ? "bg-violet-500/30 text-violet-300" : "bg-white/5 text-white/25"
              }`}>{count}</span>
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative flex-1 min-w-44">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="ابحث بالموديل / IMEI / العميل..."
            className="erp-input w-full icon-pr text-sm" />
          {search && (
            <button onClick={() => setSearch("")} className="absolute left-3 top-1/2 -translate-y-1/2">
              <X className="w-3.5 h-3.5 text-white/30 hover:text-white/60" />
            </button>
          )}
        </div>

        {/* View toggle */}
        <div className="flex gap-0.5 bg-white/4 rounded-xl border border-white/8 p-0.5">
          <button onClick={() => setViewMode("list")}
            title="عرض قائمة"
            className={`p-2 rounded-lg transition-all ${viewMode === "list" ? "bg-violet-500/25 text-violet-300" : "text-white/30 hover:text-white/60"}`}>
            <List className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setViewMode("grid")}
            title="عرض شبكة"
            className={`p-2 rounded-lg transition-all ${viewMode === "grid" ? "bg-violet-500/25 text-violet-300" : "text-white/30 hover:text-white/60"}`}>
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ── Device List / Grid ── */}
      {isLoading ? (
        <div className="glass-panel rounded-xl border border-white/8 flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-violet-500/30 border-t-violet-500 rounded-full animate-spin" />
        </div>
      ) : allDevices.length === 0 ? (
        <div className="glass-panel rounded-xl border border-white/8 text-center py-16 space-y-2">
          <Smartphone className="w-10 h-10 text-white/10 mx-auto" />
          <p className="text-white/30 text-sm">لا توجد أجهزة</p>
          <p className="text-white/15 text-xs">اضغط "إضافة جهاز" لتسجيل أول جهاز</p>
        </div>
      ) : viewMode === "list" ? (
        /* ── LIST VIEW ── */
        <div className="glass-panel rounded-xl border border-white/8 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-right text-[11px] font-bold text-white/25 px-4 py-2.5">الجهاز</th>
                <th className="text-right text-[11px] font-bold text-white/25 px-3 py-2.5 hidden sm:table-cell">المواصفات</th>
                <th className="text-right text-[11px] font-bold text-white/25 px-3 py-2.5 hidden sm:table-cell">IMEI</th>
                <th className="text-right text-[11px] font-bold text-white/25 px-3 py-2.5">الأسعار</th>
                <th className="text-center text-[11px] font-bold text-white/25 px-3 py-2.5">الحالة</th>
                <th className="text-right text-[11px] font-bold text-white/25 px-3 py-2.5 hidden md:table-cell">المورد / العميل</th>
                <th className="text-center text-[11px] font-bold text-white/25 px-3 py-2.5 w-16">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {paginatedDevices.map((d, idx) => (
                <tr key={d.id}
                  className={`border-b border-white/4 hover:bg-white/3 transition-colors group ${idx % 2 === 0 ? "" : "bg-white/1"}`}>
                  {/* Device */}
                  <td className="px-4 py-3 cursor-pointer" onClick={() => setSelected(d)}>
                    <p className="font-semibold text-white/90 text-sm">{d.brand} {d.model}</p>
                    <p className="text-[11px] text-white/30 font-mono">{d.device_no}</p>
                  </td>
                  {/* Specs */}
                  <td className="px-3 py-3 hidden sm:table-cell cursor-pointer" onClick={() => setSelected(d)}>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {d.storage && <span className="text-[11px] text-white/50 bg-white/5 px-1.5 py-0.5 rounded">{d.storage}</span>}
                      {d.color  && <span className="text-[11px] text-white/40">{d.color}</span>}
                      {d.battery_health && (
                        <span className={`text-[11px] flex items-center gap-0.5 ${d.battery_health < 80 ? "text-amber-400/70" : "text-white/35"}`}>
                          <Battery className="w-2.5 h-2.5" />{d.battery_health}%
                        </span>
                      )}
                    </div>
                    <GradeBadge grade={d.grade} />
                  </td>
                  {/* IMEI masked */}
                  <td className="px-3 py-3 hidden sm:table-cell cursor-pointer" onClick={() => setSelected(d)}>
                    {d.imei
                      ? <span className="text-[11px] text-white/35 font-mono tracking-wide">{maskImei(d.imei)}</span>
                      : <span className="text-[11px] text-white/15">—</span>}
                  </td>
                  {/* Prices + Profit */}
                  <td className="px-3 py-3 cursor-pointer" onClick={() => setSelected(d)}>
                    <p className="text-white/80 font-semibold">
                      {parseFloat(d.status === "sold" && d.sold_price ? d.sold_price : d.sale_price).toLocaleString()}
                      <span className="text-[10px] text-white/25 mr-0.5">ج.م</span>
                    </p>
                    {(() => {
                      const sellP = parseFloat(d.status === "sold" && d.sold_price ? d.sold_price : d.sale_price);
                      const buyP  = parseFloat(d.purchase_price);
                      const prof  = sellP - buyP;
                      const pct   = buyP > 0 ? Math.round((prof / buyP) * 100) : 0;
                      return (
                        <span className={`text-[10px] font-bold ${prof >= 0 ? "text-emerald-400/80" : "text-red-400/80"}`}>
                          {prof >= 0 ? "+" : ""}{prof.toLocaleString()} ({pct}%)
                        </span>
                      );
                    })()}
                  </td>
                  {/* Status */}
                  <td className="px-3 py-3 text-center cursor-pointer" onClick={() => setSelected(d)}>
                    <StatusBadge status={d.status} />
                  </td>
                  {/* Source/customer */}
                  <td className="px-3 py-3 hidden md:table-cell cursor-pointer" onClick={() => setSelected(d)}>
                    <p className="text-[11px] text-white/40">
                      {d.status === "sold" ? d.sold_to_customer_name : d.supplier_name ?? "—"}
                    </p>
                  </td>
                  {/* Actions */}
                  <td className="px-3 py-3 text-center">
                    <div className="flex items-center justify-center">
                      <RowMenu device={d} onDetail={() => setSelected(d)} onRefresh={refresh} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* ── GRID VIEW ── */
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {paginatedDevices.map(d => {
            const sellP = parseFloat(d.status === "sold" && d.sold_price ? d.sold_price : d.sale_price);
            const buyP  = parseFloat(d.purchase_price);
            const prof  = sellP - buyP;
            return (
              <div key={d.id}
                className="glass-panel rounded-xl border border-white/8 hover:border-violet-500/25 transition-all group overflow-hidden">
                {/* Card top */}
                <div className="p-3 cursor-pointer" onClick={() => setSelected(d)}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
                      <Smartphone className="w-5 h-5 text-violet-400" />
                    </div>
                    <StatusBadge status={d.status} />
                  </div>
                  <p className="font-bold text-white text-sm leading-tight">{d.brand} {d.model}</p>
                  <p className="text-[10px] text-white/25 font-mono mt-0.5">{d.device_no}</p>

                  <div className="mt-2.5 flex flex-wrap gap-1">
                    {d.storage && <span className="text-[10px] text-white/45 bg-white/5 px-1.5 py-0.5 rounded">{d.storage}</span>}
                    {d.color   && <span className="text-[10px] text-white/35">{d.color}</span>}
                    {d.battery_health && (
                      <span className={`text-[10px] flex items-center gap-0.5 ${d.battery_health < 80 ? "text-amber-400/70" : "text-white/30"}`}>
                        <Battery className="w-2.5 h-2.5" />{d.battery_health}%
                      </span>
                    )}
                  </div>

                  {d.imei && (
                    <p className="text-[10px] text-white/25 font-mono mt-1.5 tracking-wide">{maskImei(d.imei)}</p>
                  )}

                  <div className="mt-3 pt-2.5 border-t border-white/6 flex items-end justify-between">
                    <div>
                      <p className="text-emerald-300 font-bold text-sm">{sellP.toLocaleString()} ج.م</p>
                      <p className={`text-[10px] font-semibold ${prof >= 0 ? "text-emerald-400/60" : "text-red-400/60"}`}>
                        {prof >= 0 ? "+" : ""}{prof.toLocaleString()} ج.م
                      </p>
                    </div>
                    {d.grade && <GradeBadge grade={d.grade} />}
                  </div>
                </div>

                {/* Card bottom — actions */}
                <div className="px-3 pb-3 flex items-center justify-between">
                  <p className="text-[10px] text-white/25 truncate flex-1">
                    {d.status === "sold" ? d.sold_to_customer_name : d.supplier_name ?? ""}
                  </p>
                  <RowMenu device={d} onDetail={() => setSelected(d)} onRefresh={refresh} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!isLoading && allDevices.length > 0 && (
        <PaginationBar
          page={devicePage}
          totalItems={allDevices.length}
          pageSize={DEVICE_PAGE_SIZE}
          onPageChange={setDevicePage}
          itemLabel="جهاز"
        />
      )}

      </>}

      {/* ── Modals ── */}
      {showAdd && <AddDeviceModal onClose={() => setShowAdd(false)} onSaved={refresh} />}
      {selected && <DeviceDetail device={selected} onClose={() => setSelected(null)} onRefresh={refresh} />}
    </div>
  );
}
