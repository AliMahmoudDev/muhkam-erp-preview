import { api } from '@/lib/api';
/**
 * backup-tab.tsx — النسخ الاحتياطية والاستعادة
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { authFetch } from '@/lib/auth-fetch';
import { useAuth } from '@/contexts/auth';
import { useToast } from '@/hooks/use-toast';
import {
  Loader2,
  HardDrive,
  History,
  RefreshCcw,
  Download,
  Upload,
  Save,
  CheckCircle2,
  AlertTriangle,
  X,
  Check,
  Database,
  Trash2,
  Clock,
  LogIn,
  LogOut,
  Shield,
} from 'lucide-react';
import { PageHeader, PrimaryBtn } from './_shared';
import { BACKUP_MODULES_LIST, RESTORE_MODULE_GROUPS } from './_constants';


/* TypeScript shim for File System Access API */
declare global {
  interface Window {
    showSaveFilePicker?: (opts?: {
      suggestedName?: string;
      types?: { description?: string; accept?: Record<string, string[]> }[];
    }) => Promise<{ createWritable: () => Promise<{ write: (d: unknown) => Promise<void>; close: () => Promise<void> }> }>;
  }
}

const LAST_BK_KEY   = 'halal_erp_last_backup';
const AUTO_BK_KEY   = 'halal_erp_auto_backup';

/**
 * saveFile — يحاول فتح حوار "حفظ باسم" (Chrome/Edge) وإلا يستخدم تنزيل مباشر.
 * @param blob  محتوى الملف
 * @param fname اسم الملف المقترح
 * @param silent إذا true لا يفتح حوار الاختيار (للنسخ التلقائية)
 */
async function saveFile(blob: Blob, fname: string, silent = false): Promise<void> {
  // استخدم File System Access API فقط إذا لم تكن صامتة
  if (!silent && typeof window.showSaveFilePicker === 'function') {
    try {
      const ext  = fname.split('.').pop() ?? 'json';
      const mime = blob.type || 'application/json';
      const handle = await window.showSaveFilePicker({
        suggestedName: fname,
        types: [{ description: 'ملف النسخة الاحتياطية', accept: { [mime]: [`.${ext}`] } }],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return;
    } catch (e) {
      // المستخدم ألغى الحوار
      if (e instanceof Error && e.name === 'AbortError') throw e;
      // المتصفح لا يدعم أو خطأ آخر — نرجع للتنزيل العادي
    }
  }
  // fallback: تنزيل مباشر إلى مجلد التنزيلات
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = fname;
  a.click();
  URL.revokeObjectURL(url);
}

type AutoSettings = { on_login?: boolean; on_logout?: boolean; daily?: boolean };

function loadAutoSettings(): AutoSettings {
  try { return JSON.parse(localStorage.getItem(AUTO_BK_KEY) || '{}'); } catch { return {}; }
}

type BackupRecord = {
  id: number;
  filename: string;
  size: number;
  trigger: string;
  created_at: string;
};

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  return `${(b / 1048576).toFixed(2)} MB`;
}
function formatTrigger(t: string) {
  return (
    (
      {
        login: 'تسجيل دخول',
        logout: 'تسجيل خروج',
        sale_post: 'ترحيل مبيعات',
        purchase_post: 'ترحيل مشتريات',
        scheduled: 'جدولة تلقائية',
        manual: 'يدوي',
      } as Record<string, string>
    )[t] ?? t
  );
}
function nextBackupTime(sched: string, last: string | null) {
  if (!last || sched === 'none') return null;
  const hours = sched === 'daily' ? 24 : sched === 'weekly' ? 168 : 720;
  return new Date(new Date(last).getTime() + hours * 3600000).toLocaleString('ar-EG-u-nu-latn');
}

const MODULE_ICONS: Record<string, string> = {
  sales: '🛍️',
  purchases: '🛒',
  products: '📦',
  treasury: '💰',
  customers: '👥',
  settings: '⚙️',
  reports: '📊',
};

export default function BackupTab() {
  const { toast } = useToast();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === 'super_admin';

  /* ── نوع التبويب ── */
  const [bkMode, setBkMode] = useState<'local' | 'server'>('local');
  const [bkModules, setBkModules] = useState<Set<string>>(
    new Set(BACKUP_MODULES_LIST.map((m) => m.key))
  );
  const [bkLoading, setBkLoading] = useState(false);
  const [bkProgress, setBkProgress] = useState(0);
  const [bkResult, setBkResult] = useState<{ name: string; size: string; count: number } | null>(
    null
  );
  const [lastBackup, setLastBackup] = useState<string | null>(() =>
    localStorage.getItem(LAST_BK_KEY)
  );

  /* ── إعدادات الخادم ── */
  const [schedule, setSchedule] = useState('none');
  const [destination, setDestination] = useState('local');
  const [lastScheduled, setLastScheduled] = useState<string | null>(null);
  const [onLogin, setOnLogin] = useState(false);
  const [onLogout, setOnLogout] = useState(false);
  const [schedSaving, setSchedSaving] = useState(false);
  const [serverBkBusy, setServerBkBusy] = useState(false);

  /* ── سجل الخادم ── */
  const [backupList, setBackupList] = useState<BackupRecord[]>([]);
  const [listLoading, setListLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  /* ── الاستعادة ── */
  const [restoreLoading, setRestoreLoading] = useState(false);
  const [restoreResult, setRestoreResult] = useState<{
    counts: Record<string, number>;
    meta: { file_version: string; file_date: string | null; is_legacy: boolean };
  } | null>(null);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const restoreFileRef = useRef<HTMLInputElement>(null);
  const pendingEncFileRef = useRef<File | null>(null);

  /* ── Modal تأكيد الاستعادة ── */
  const [modal, setModal] = useState(false);
  const [modalText, setModalText] = useState('');
  const [understood, setUnderstood] = useState(false);
  const [pending, setPending] = useState<{
    fileName: string;
    parsed: unknown;
    version: string | null;
    date: string | null;
    tableCount: number;
  } | null>(null);

  /* ── اختيار وحدات الاستعادة ── */
  const [showModSelect, setShowModSelect] = useState(false);
  const [availMods, setAvailMods] = useState<string[]>([]);
  const [selectedRestoreMods, setSelectedRestoreMods] = useState<Set<string>>(new Set());
  const [isStructuredBackup, setIsStructuredBackup] = useState(false);

  /* ── النسخة الشاملة ── */
  const [compBusy, setCompBusy] = useState(false);
  const [compResult, setCompResult] = useState<string | null>(null);

  /* ── الجدولة التلقائية ── */
  const [autoSettings, setAutoSettings] = useState<AutoSettings>(loadAutoSettings);

  const saveAutoSettings = useCallback((patch: Partial<AutoSettings>) => {
    const next = { ...autoSettings, ...patch };
    localStorage.setItem(AUTO_BK_KEY, JSON.stringify(next));
    setAutoSettings(next);
  }, [autoSettings]);

  /* ── النسخة الشاملة (POST /api/system/backup → تنزيل) ── */
  const handleComprehensiveBackup = useCallback(async (silent = false) => {
    setCompBusy(true);
    setCompResult(null);
    try {
      const r = await authFetch(api('/api/system/backup'), { method: 'POST' });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error ?? 'فشل الطلب');
      const disp = r.headers.get('Content-Disposition') ?? '';
      const match = disp.match(/filename="([^"]+)"/);
      const fname = match?.[1] ?? `backup_comprehensive_${new Date().toISOString().slice(0,10)}.json`;
      const blob = await r.blob();
      await saveFile(blob, fname, silent);
      const now = new Date().toISOString();
      localStorage.setItem(LAST_BK_KEY, now);
      setLastBackup(now);
      setCompResult(fname);
      toast({ title: `✅ نسخة شاملة محفوظة — ${fname}` });
    } catch (e: unknown) {
      if (e instanceof Error && e.name === 'AbortError') return; // المستخدم ألغى حوار الحفظ
      const msg = e instanceof Error ? e.message : String(e);
      toast({ title: 'فشل إنشاء النسخة الشاملة', description: msg, variant: 'destructive' });
    } finally {
      setCompBusy(false);
    }
  }, [toast]);

  /* ── التحقق من التشغيل التلقائي عند التحميل ── */
  useEffect(() => {
    const auto = loadAutoSettings();
    const loginFlag  = localStorage.getItem('halal_erp_login_flag');
    const logoutFlag = localStorage.getItem('halal_erp_logout_flag');

    if (loginFlag) {
      localStorage.removeItem('halal_erp_login_flag');
      if (auto.on_login) setTimeout(() => void handleComprehensiveBackup(true), 1500);
    }
    if (logoutFlag) {
      localStorage.removeItem('halal_erp_logout_flag');
      if (auto.on_logout) setTimeout(() => void handleComprehensiveBackup(true), 500);
    }
    if (auto.daily) {
      const last = localStorage.getItem(LAST_BK_KEY);
      const stale = !last || Date.now() - new Date(last).getTime() > 86_400_000;
      if (stale) setTimeout(() => void handleComprehensiveBackup(true), 3000);
    }
  }, [handleComprehensiveBackup]);

  /* ── تحميل الإعدادات ── */
  const loadSettings = useCallback(async () => {
    try {
      const r = await authFetch(api('/api/backups/settings'));
      if (r.ok) {
        const d = (await r.json()) as {
          schedule: string;
          destination: string;
          last_scheduled: string | null;
          on_login: boolean;
          on_logout: boolean;
        };
        setSchedule(d.schedule ?? 'none');
        setDestination(d.destination ?? 'local');
        setLastScheduled(d.last_scheduled ?? null);
        setOnLogin(!!d.on_login);
        setOnLogout(!!d.on_logout);
      }
    } catch {}
  }, []);

  const loadList = useCallback(async () => {
    setListLoading(true);
    try {
      const r = await authFetch(api('/api/backups'));
      if (r.ok) setBackupList((await r.json()) as BackupRecord[]);
    } catch {
    } finally {
      setListLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isSuperAdmin) {
      void loadSettings();
      void loadList();
    }
  }, [loadSettings, loadList, isSuperAdmin]);

  /* ── نسخة محلية انتقائية ── */
  const toggleModule = (key: string) =>
    setBkModules((prev) => {
      const s = new Set(prev);
      if (s.has(key)) {
        s.delete(key);
      } else {
        s.add(key);
      }
      return s;
    });
  const toggleAll = () =>
    setBkModules(
      bkModules.size === BACKUP_MODULES_LIST.length
        ? new Set()
        : new Set(BACKUP_MODULES_LIST.map((m) => m.key))
    );

  const lastBackupLabel = () => {
    if (!lastBackup) return 'لم يتم إنشاء نسخة بعد';
    const d = Math.floor((Date.now() - new Date(lastBackup).getTime()) / 86400000);
    return d === 0
      ? 'اليوم'
      : d === 1
        ? 'منذ يوم'
        : d < 30
          ? `منذ ${d} أيام`
          : new Date(lastBackup).toLocaleDateString('ar-EG-u-nu-latn');
  };

  const handleLocalBackup = async () => {
    if (bkModules.size === 0) {
      toast({ title: 'اختر وحدة واحدة على الأقل', variant: 'destructive' });
      return;
    }
    setBkLoading(true);
    setBkProgress(5);
    setBkResult(null);
    try {
      const selected = BACKUP_MODULES_LIST.filter((m) => bkModules.has(m.key));
      const bundle: Record<string, unknown> = {
        version: '1.0',
        created_at: new Date().toISOString(),
        app: 'مُحكم - MUHKAM ERP',
        modules: selected.map((m) => m.label),
      };
      const step = Math.floor(75 / selected.length);
      for (const mod of selected) {
        setBkProgress((p) => Math.min(p + step, 85));
        if (mod.url) {
          try {
            const r = await authFetch(api(mod.url));
            bundle[mod.key] = r.ok ? await r.json() : [];
          } catch {
            bundle[mod.key] = [];
          }
        } else if (mod.key === 'settings') {
          bundle[mod.key] = JSON.parse(localStorage.getItem('halal_erp_settings') || '{}');
        }
      }
      setBkProgress(90);
      const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
      const dt = new Date().toISOString().replace('T', '_').replace(/:/g, '-').slice(0, 19);
      const fname = `backup_${dt}.json`;
      await saveFile(blob, fname);
      setBkResult({
        name: fname,
        size: `${(blob.size / 1024).toFixed(1)} KB`,
        count: selected.length,
      });
      setBkProgress(100);
      const now = new Date().toISOString();
      localStorage.setItem(LAST_BK_KEY, now);
      setLastBackup(now);
      toast({ title: `✅ تم إنشاء النسخة — ${fname}` });
    } catch {
      toast({ title: 'فشل إنشاء النسخة', variant: 'destructive' });
    } finally {
      setBkLoading(false);
      setTimeout(() => setBkProgress(0), 1500);
    }
  };

  /* ── نسخة الخادم ── */
  const handleServerDownload = async () => {
    setServerBkBusy(true);
    try {
      const r = await authFetch(api('/api/system/backup'), { method: 'POST' });
      if (!r.ok) throw new Error(await r.text());
      const blob = await r.blob();
      const cd = r.headers.get('Content-Disposition') ?? '';
      const m = cd.match(/filename="([^"]+)"/);
      const fname = m?.[1] ?? `halal-tech-backup_${new Date().toISOString().slice(0, 10)}.json`;
      await saveFile(blob, fname);
      const now = new Date().toISOString();
      localStorage.setItem(LAST_BK_KEY, now);
      setLastBackup(now);
      toast({ title: `✅ تم تنزيل النسخة الكاملة — ${fname}` });
    } catch (e) {
      toast({ title: 'فشل إنشاء النسخة الكاملة', description: String(e), variant: 'destructive' });
    } finally {
      setServerBkBusy(false);
    }
  };

  const handleServerSave = async () => {
    setServerBkBusy(true);
    try {
      const r = await authFetch(api('/api/backups'), { method: 'POST' });
      if (r.ok) {
        toast({ title: '✅ تم حفظ النسخة على الخادم' });
        void loadList();
        void loadSettings();
      } else {
        const d = (await r.json().catch(() => ({ error: 'فشل' }))) as { error?: string };
        toast({ title: d.error ?? 'فشل', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'خطأ في الاتصال', variant: 'destructive' });
    } finally {
      setServerBkBusy(false);
    }
  };

  const handleSaveSettings = async (overrides: {
    schedule?: string;
    destination?: string;
    on_login?: boolean;
    on_logout?: boolean;
  }) => {
    setSchedSaving(true);
    try {
      const payload = {
        schedule: overrides.schedule ?? schedule,
        destination: overrides.destination ?? destination,
        on_login: overrides.on_login ?? onLogin,
        on_logout: overrides.on_logout ?? onLogout,
      };
      const r = await authFetch(api('/api/backups/settings'), {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      if (r.ok) {
        if (overrides.schedule !== undefined) setSchedule(overrides.schedule);
        if (overrides.destination !== undefined) setDestination(overrides.destination);
        if (overrides.on_login !== undefined) setOnLogin(overrides.on_login);
        if (overrides.on_logout !== undefined) setOnLogout(overrides.on_logout);
        toast({ title: '✅ تم حفظ إعدادات النسخ الاحتياطي' });
      }
    } catch {
    } finally {
      setSchedSaving(false);
    }
  };

  const handleDeleteBackup = async (id: number) => {
    setDeletingId(id);
    try {
      const r = await authFetch(api(`/api/backups/${id}`), { method: 'DELETE' });
      if (r.ok) {
        setBackupList((p) => p.filter((b) => b.id !== id));
        toast({ title: 'تم حذف النسخة' });
      }
    } catch {
    } finally {
      setDeletingId(null);
    }
  };

  const handleDownloadById = async (id: number, filename: string) => {
    try {
      const r = await authFetch(api(`/api/backups/${id}/download`));
      if (!r.ok) {
        toast({ title: 'فشل التنزيل', variant: 'destructive' });
        return;
      }
      const a = document.createElement('a');
      a.href = URL.createObjectURL(await r.blob());
      a.download = filename;
      a.click();
    } catch {
      toast({ title: 'خطأ في التنزيل', variant: 'destructive' });
    }
  };

  /* ── اختيار ملف الاستعادة (.json أو .json.enc) ── */
  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    const isEnc = file.name.endsWith('.json.enc');
    const isJson = file.name.endsWith('.json');
    if (!isJson && !isEnc) {
      toast({ title: 'يجب اختيار ملف .json أو .json.enc', variant: 'destructive' });
      return;
    }
    if (isEnc) {
      /* Encrypted backup — skip JSON parsing, store file directly */
      setPending({
        fileName: file.name,
        parsed: null,          /* sentinel: encrypted */
        version: 'مشفّر',
        date: null,
        tableCount: 0,
      });
      /* Keep raw file in a closure via a temporary ref hack */
      (pendingEncFileRef as React.MutableRefObject<File | null>).current = file;
      setModalText('');
      setUnderstood(false);
      setModal(true);
      return;
    }
    try {
      const parsed = JSON.parse(await file.text()) as Record<string, unknown>;
      const dataSection = (parsed.data ?? parsed.tables ?? parsed) as Record<string, unknown>;
      const tableCount  = Object.values(dataSection).filter(Array.isArray).length;
      const structured  = typeof parsed.data === 'object' && parsed.data !== null;

      setPending({
        fileName: file.name,
        parsed,
        version: typeof parsed.version === 'string' ? parsed.version : null,
        date: typeof parsed.created_at === 'string' ? parsed.created_at : null,
        tableCount,
      });
      setIsStructuredBackup(structured);
      setModalText('');
      setUnderstood(false);

      if (structured) {
        /* اكتشاف الوحدات المتاحة في الملف */
        const data = parsed.data as Record<string, unknown[]>;
        const MODULE_TABLE_MAP: Record<string, string[]> = {
          products:       ['products', 'stock_movements'],
          customers:      ['customers'],
          sales:          ['sales', 'sale_items', 'sales_returns', 'sale_return_items'],
          purchases:      ['purchases', 'purchase_items', 'purchase_returns', 'purchase_return_items'],
          finance:        ['expenses', 'income', 'transactions', 'accounts', 'journal_entries', 'receipt_vouchers', 'payment_vouchers'],
          infrastructure: ['safes', 'warehouses'],
          alerts:         ['alerts'],
        };
        const found = RESTORE_MODULE_GROUPS
          .map(g => g.key)
          .filter(k => (MODULE_TABLE_MAP[k] ?? []).some(t => Array.isArray(data[t])));
        setAvailMods(found);
        setSelectedRestoreMods(new Set(found));
        setShowModSelect(true);
      } else {
        /* ملف v1.0 (تصدير محلي) — لا يدعم الاستعادة الكاملة */
        toast({
          title: '⚠️ هذا الملف للتصدير فقط',
          description: 'ملفات النسخ المحلية (v1.0) لا يمكن استعادتها. استخدم "النسخة الشاملة" التي تنزّلها بالزر الأخضر.',
          variant: 'destructive',
        });
      }
    } catch {
      toast({ title: 'ملف JSON غير صالح', variant: 'destructive' });
    }
  };

  const handleConfirmRestore = async () => {
    if (!pending) return;
    setModal(false);
    setRestoreLoading(true);
    setRestoreResult(null);
    setRestoreError(null);
    try {
      let body: BodyInit;
      let contentType: string;
      const encFile = (pendingEncFileRef as React.MutableRefObject<File | null>).current;
      if (pending.parsed === null && encFile) {
        /* Encrypted file — send binary */
        body = await encFile.arrayBuffer();
        contentType = 'application/octet-stream';
        (pendingEncFileRef as React.MutableRefObject<File | null>).current = null;
      } else {
        /* For structured backups with module selection, inject restore_modules */
        const payload = isStructuredBackup && selectedRestoreMods.size > 0
          ? { ...(pending.parsed as object), restore_modules: Array.from(selectedRestoreMods) }
          : pending.parsed;
        body = JSON.stringify(payload);
        contentType = 'application/json';
      }
      const idemKey = `restore-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
      const r = await authFetch(api('/api/system/restore'), {
        method: 'POST',
        headers: { 'Content-Type': contentType, 'Idempotency-Key': idemKey },
        body,
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error ?? 'فشل الاستعادة');
      setRestoreResult({
        counts: data.counts ?? {},
        meta: data.meta ?? { file_version: 'legacy', file_date: null, is_legacy: true },
      });
      toast({ title: '✅ تمت الاستعادة بنجاح' });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setRestoreError(msg);
      toast({ title: 'فشل الاستعادة', description: msg, variant: 'destructive' });
    } finally {
      setRestoreLoading(false);
      setPending(null);
    }
  };

  const canConfirm = modalText === 'RESTORE' && understood;

  const triggerBadge = (trigger: string) => {
    const cls =
      trigger === 'login'
        ? 'bg-blue-500/15 text-blue-400'
        : trigger === 'logout'
          ? 'bg-purple-500/15 text-purple-400'
          : trigger === 'sale_post' || trigger === 'purchase_post'
            ? 'bg-emerald-500/15 text-emerald-400'
            : trigger === 'scheduled'
              ? 'bg-sky-500/15 text-sky-400'
              : 'bg-white/8 text-white/40';
    return (
      <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold ${cls}`}>
        {formatTrigger(trigger)}
      </span>
    );
  };

  /* ── مكوّن Toggle صغير ── */
  const Toggle = ({
    checked,
    onChange,
    disabled,
  }: {
    checked: boolean;
    onChange: (v: boolean) => void;
    disabled?: boolean;
  }) => (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative w-10 h-5 rounded-full transition-all shrink-0 ${checked ? 'bg-amber-500' : 'bg-white/10'} disabled:opacity-40`}
    >
      <span
        className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all duration-200 ${checked ? 'translate-x-[-0.125rem] left-5' : 'left-0.5'}`}
      />
    </button>
  );

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="النسخ الاحتياطية"
        sub="احمِ بياناتك — آخر نسخة"
        action={<span className="text-white/30 text-xs">{lastBackupLabel()}</span>}
      />

      {/* ═══ البطاقة الرئيسية ═══ */}
      <div className="bg-[#111827] border border-white/8 rounded-2xl overflow-hidden">
        {/* Tabs */}
        <div className="flex border-b border-white/8">
          {(
            [
              { id: 'local'  as const, label: '💾 نسخة محلية',  sub: 'تنزيل + استعادة'       },
              { id: 'server' as const, label: '☁️ نسخة الخادم', sub: 'جدولة + حفظ + سجل', superOnly: true },
            ].filter(t => !t.superOnly || isSuperAdmin)
          ).map(({ id, label, sub }) => (
            <button
              key={id}
              onClick={() => setBkMode(id)}
              className={`flex-1 px-4 py-3.5 text-right transition-all border-b-2 ${bkMode === id ? 'border-amber-400 bg-amber-500/5' : 'border-transparent hover:bg-white/3'}`}
            >
              <p
                className={`text-sm font-bold ${bkMode === id ? 'text-amber-400' : 'text-white/50'}`}
              >
                {label}
              </p>
              <p className="text-white/25 text-xs">{sub}</p>
            </button>
          ))}
        </div>

        {/* ══ تبويب المحلي ══ */}
        {bkMode === 'local' && (
          <div className="p-5 space-y-5">
            {/* اختيار الوحدات */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-white/50 text-xs">اختر الوحدات المطلوبة في النسخة</p>
                <button
                  onClick={toggleAll}
                  className="text-xs text-amber-400 hover:text-amber-300 transition-colors font-semibold"
                >
                  {bkModules.size === BACKUP_MODULES_LIST.length ? 'إلغاء الكل' : 'تحديد الكل'}
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {BACKUP_MODULES_LIST.map((m) => {
                  const on = bkModules.has(m.key);
                  return (
                    <button
                      key={m.key}
                      onClick={() => toggleModule(m.key)}
                      className={`flex items-center gap-2.5 p-3 rounded-xl border text-right transition-all ${on ? 'bg-amber-500/10 border-amber-500/25' : 'bg-[#1A2235] border-[#2D3748] hover:border-amber-500/15'}`}
                    >
                      <span className="text-lg shrink-0">{MODULE_ICONS[m.key] ?? '📁'}</span>
                      <div className="flex-1 min-w-0">
                        <p
                          className={`text-xs font-bold truncate ${on ? 'text-amber-300' : 'text-white/60'}`}
                        >
                          {m.label}
                        </p>
                        <p className="text-white/20 text-[10px] truncate">{m.sub}</p>
                      </div>
                      <div
                        className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-all ${on ? 'bg-amber-500 border-amber-500' : 'border-white/20'}`}
                      >
                        {on && <Check className="w-2.5 h-2.5 text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {bkLoading && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-white/40">
                    <span>جاري إنشاء النسخة...</span>
                    <span>{bkProgress}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <div
                      className="h-full bg-amber-400 rounded-full transition-all duration-300"
                      style={{ width: `${bkProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {bkResult && !bkLoading && (
                <div className="flex items-center gap-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-emerald-400 font-bold flex-1 truncate">
                    {bkResult.name}
                  </span>
                  <span className="text-white/40">{bkResult.size}</span>
                  <span className="text-white/40">{bkResult.count} وحدات</span>
                </div>
              )}

              <PrimaryBtn
                onClick={handleLocalBackup}
                disabled={bkLoading || bkModules.size === 0}
                className="w-full"
              >
                {bkLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                {bkLoading
                  ? `جاري الإنشاء... ${bkProgress}%`
                  : `تنزيل نسخة (${bkModules.size} وحدات)`}
              </PrimaryBtn>
            </div>

            {/* ── فاصل + النسخة الشاملة ── */}
            <div className="h-px bg-white/5" />
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div>
                  <p className="font-bold text-white text-sm">نسخة شاملة (كل البيانات)</p>
                  <p className="text-white/30 text-xs">تُصدِّر جميع بيانات شركتك في ملف JSON واحد</p>
                </div>
              </div>
              {compResult && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-emerald-400 font-bold flex-1 truncate">{compResult}</span>
                </div>
              )}
              <button
                onClick={() => handleComprehensiveBackup()}
                disabled={compBusy}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-sm transition-all"
              >
                {compBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
                {compBusy ? 'جاري التصدير...' : 'تنزيل النسخة الشاملة'}
              </button>
            </div>

            {/* ── فاصل + الإعدادات التلقائية ── */}
            <div className="h-px bg-white/5" />
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Clock className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <div>
                  <p className="font-bold text-white text-sm">تشغيل تلقائي للنسخة الشاملة</p>
                  <p className="text-white/30 text-xs">يبدأ التنزيل التلقائي عند تحقق الشروط</p>
                </div>
              </div>
              <div className="flex items-start gap-2 p-2.5 rounded-xl bg-blue-500/5 border border-blue-500/15 text-xs text-blue-300/70">
                <span className="shrink-0 mt-0.5">📂</span>
                <span>
                  النسخ التلقائية تُحفَظ دائماً في مجلد <strong className="text-blue-300">التنزيلات</strong> بجهازك.
                  أما النسخ اليدوية (بالزر الأخضر) فيظهر حوار <strong className="text-blue-300">اختيار المسار</strong> على Chrome/Edge.
                </span>
              </div>
              <div className="space-y-2">
                {[
                  { key: 'on_login' as const,  Icon: LogIn,  label: 'عند تسجيل الدخول',  color: 'emerald' },
                  { key: 'on_logout' as const, Icon: LogOut, label: 'عند تسجيل الخروج', color: 'amber'   },
                  { key: 'daily' as const,     Icon: Clock,  label: 'مرة يومياً (إذا مرّ 24 ساعة)',  color: 'blue'    },
                ].map(({ key, Icon, label, color }) => {
                  const on = !!autoSettings[key];
                  return (
                    <button
                      key={key}
                      onClick={() => saveAutoSettings({ [key]: !on })}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border transition-all ${on ? `bg-${color}-500/8 border-${color}-500/20` : 'bg-white/3 border-white/8 hover:border-white/15'}`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${on ? `text-${color}-400` : 'text-white/30'}`} />
                      <p className={`flex-1 text-right text-sm font-semibold ${on ? `text-${color}-300` : 'text-white/50'}`}>{label}</p>
                      <div className={`w-9 h-5 rounded-full relative transition-all ${on ? `bg-${color}-500` : 'bg-white/10'}`}>
                        <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${on ? 'right-0.5' : 'left-0.5'}`} />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ── فاصل + قسم الاستعادة (داخل المحلي) ── */}
            <div className="h-px bg-white/5" />
            <div className="space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-violet-500/10 flex items-center justify-center">
                  <Upload className="w-3.5 h-3.5 text-violet-400" />
                </div>
                <div>
                  <p className="font-bold text-white text-sm">استعادة نسخة احتياطية</p>
                  <p className="text-white/30 text-xs">
                    ارفع ملف <strong className="text-emerald-400">النسخة الشاملة</strong> فقط (الزر الأخضر أعلاه)
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/5 border border-amber-500/15 text-amber-300/70 text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <span>
                  ستُحذف البيانات الحالية وتُستبدل بمحتوى الملف. المستخدمون والإعدادات تبقى.
                </span>
              </div>

              <input
                ref={restoreFileRef}
                type="file"
                accept=".json,.json.enc"
                className="hidden"
                onChange={handleRestoreFile}
              />

              {restoreLoading && (
                <div className="flex items-center gap-3 p-3 rounded-xl bg-violet-500/10 border border-violet-500/20">
                  <Loader2 className="w-4 h-4 text-violet-400 animate-spin" />
                  <p className="text-violet-300 text-sm">جاري الاستعادة...</p>
                </div>
              )}

              {restoreResult && !restoreLoading && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 font-bold text-sm">تمت الاستعادة بنجاح</span>
                    <span className="mr-auto px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                      v{restoreResult.meta.file_version}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    {Object.entries(restoreResult.counts)
                      .filter(([, v]) => (v as number) > 0)
                      .slice(0, 9)
                      .map(([k, v]) => (
                        <div key={k} className="bg-white/5 rounded-lg p-2">
                          <p className="text-white/35 text-[10px]">{k}</p>
                          <p className="text-white font-bold">{String(v)}</p>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {restoreError && !restoreLoading && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                  <X className="w-4 h-4 shrink-0" /> {restoreError}
                </div>
              )}

              <button
                onClick={() => restoreFileRef.current?.click()}
                disabled={restoreLoading}
                className="w-full py-3.5 rounded-xl border-2 border-dashed border-violet-500/30 hover:border-violet-500/55 text-violet-400 hover:text-violet-300 transition-all flex items-center justify-center gap-2 text-sm font-bold disabled:opacity-40"
              >
                <Upload className="w-4 h-4" /> اختر ملف النسخة الاحتياطية (.json)
              </button>
            </div>
          </div>
        )}

        {/* ══ تبويب الخادم ══ */}
        {bkMode === 'server' && (
          <div className="p-5 space-y-4">
            {/* ─── الجدولة التلقائية ─── */}
            <div className="space-y-3">
              <p className="text-white/40 text-xs font-black uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3.5 h-3.5" /> الجدولة التلقائية
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  { v: 'none', l: 'بدون' },
                  { v: 'daily', l: 'يومياً' },
                  { v: 'weekly', l: 'أسبوعياً' },
                  { v: 'monthly', l: 'شهرياً' },
                ].map((s) => (
                  <button
                    key={s.v}
                    onClick={() => void handleSaveSettings({ schedule: s.v })}
                    disabled={schedSaving}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${schedule === s.v ? 'bg-sky-500/20 border-sky-500/40 text-sky-300' : 'border-white/10 text-white/40 hover:text-white/70 hover:border-white/20'}`}
                  >
                    {schedSaving && schedule === s.v ? (
                      <Loader2 className="w-3 h-3 animate-spin inline ml-1" />
                    ) : null}
                    {s.l}
                  </button>
                ))}
              </div>
              {schedule !== 'none' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-white/3 border border-white/5">
                    <p className="text-white/30 mb-0.5">آخر نسخة تلقائية</p>
                    <p className="text-white font-bold">
                      {lastScheduled
                        ? new Date(lastScheduled).toLocaleString('ar-EG-u-nu-latn')
                        : '—'}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/3 border border-white/5">
                    <p className="text-white/30 mb-0.5">النسخة القادمة</p>
                    <p className="text-sky-300 font-bold">
                      {nextBackupTime(schedule, lastScheduled) ?? 'قريباً'}
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="h-px bg-white/5" />

            {/* ─── تريغر الدخول والخروج ─── */}
            <div className="space-y-2.5">
              <p className="text-white/40 text-xs font-black uppercase tracking-wider">
                نسخ تلقائي عند
              </p>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/3 border border-white/5">
                  <div className="flex items-center gap-2.5">
                    <LogIn className="w-4 h-4 text-blue-400" />
                    <div>
                      <p className="text-white text-xs font-bold">تسجيل الدخول</p>
                      <p className="text-white/30 text-[10px]">نسخة تلقائية لكل دخول ناجح</p>
                    </div>
                  </div>
                  <Toggle
                    checked={onLogin}
                    disabled={schedSaving}
                    onChange={(v) => void handleSaveSettings({ on_login: v })}
                  />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/3 border border-white/5">
                  <div className="flex items-center gap-2.5">
                    <LogOut className="w-4 h-4 text-purple-400" />
                    <div>
                      <p className="text-white text-xs font-bold">تسجيل الخروج</p>
                      <p className="text-white/30 text-[10px]">نسخة تلقائية قبل كل خروج</p>
                    </div>
                  </div>
                  <Toggle
                    checked={onLogout}
                    disabled={schedSaving}
                    onChange={(v) => void handleSaveSettings({ on_logout: v })}
                  />
                </div>
              </div>
            </div>

            <div className="h-px bg-white/5" />

            {/* ─── أزرار الحفظ/التنزيل ─── */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => void handleServerSave()}
                disabled={serverBkBusy}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/25 text-sky-300 font-bold text-xs transition-all disabled:opacity-40"
              >
                {serverBkBusy ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Save className="w-3.5 h-3.5" />
                )}
                حفظ على الخادم
              </button>
              <button
                onClick={() => void handleServerDownload()}
                disabled={serverBkBusy}
                className="flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/25 text-emerald-300 font-bold text-xs transition-all disabled:opacity-40"
              >
                {serverBkBusy ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Database className="w-3.5 h-3.5" />
                )}
                تنزيل نسخة كاملة
              </button>
            </div>
            <p className="text-white/25 text-xs text-center">
              "حفظ" تحفظ في السجل · "تنزيل" تُصدِّر مباشرةً من قاعدة البيانات
            </p>

            <div className="h-px bg-white/5" />

            {/* ─── سجل النسخ ─── */}
            <div className="rounded-xl border border-white/8 overflow-hidden">
              <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between bg-white/2">
                <div className="flex items-center gap-2">
                  <History className="w-3.5 h-3.5 text-white/35" />
                  <p className="text-white/60 text-xs font-bold">سجل النسخ</p>
                  <span className="text-white/25 text-[10px]">
                    {backupList.length > 0 ? `${backupList.length} نسخة` : 'لا توجد نسخ'}
                  </span>
                </div>
                <button
                  onClick={() => void loadList()}
                  disabled={listLoading}
                  className="p-1.5 rounded-lg text-white/25 hover:text-white hover:bg-white/8 transition-colors"
                >
                  <RefreshCcw className={`w-3 h-3 ${listLoading ? 'animate-spin' : ''}`} />
                </button>
              </div>

              {listLoading && backupList.length === 0 ? (
                <div className="flex items-center justify-center gap-2 py-8 text-white/25 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  جاري التحميل...
                </div>
              ) : backupList.length === 0 ? (
                <div className="text-center py-8 text-white/20 text-sm">
                  <HardDrive className="w-6 h-6 mx-auto mb-1.5 opacity-25" />
                  لا توجد نسخ محفوظة بعد
                </div>
              ) : (
                <div className="divide-y divide-white/4 max-h-56 overflow-y-auto">
                  {backupList.map((b) => (
                    <div
                      key={b.id}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-white/2 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-xs font-mono truncate">{b.filename}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-white/25 text-[10px]">
                            {new Date(b.created_at).toLocaleString('ar-EG-u-nu-latn')}
                          </span>
                          <span className="text-white/15">·</span>
                          <span className="text-white/25 text-[10px]">{formatBytes(b.size)}</span>
                          <span className="text-white/15">·</span>
                          {triggerBadge(b.trigger)}
                        </div>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <button
                          onClick={() => void handleDownloadById(b.id, b.filename)}
                          className="p-1.5 rounded-lg text-emerald-400/50 hover:text-emerald-400 hover:bg-emerald-500/10 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => void handleDeleteBackup(b.id)}
                          disabled={deletingId === b.id}
                          className="p-1.5 rounded-lg text-red-400/40 hover:text-red-400 hover:bg-red-500/10 transition-colors disabled:opacity-40"
                        >
                          {deletingId === b.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Trash2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ═══ Modal اختيار وحدات الاستعادة ═══ */}
      {showModSelect && pending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowModSelect(false)} />
          <div className="relative w-full max-w-md bg-[#0F1623] border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/20 bg-amber-500/5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 flex items-center justify-center">
                  <Database className="w-4 h-4 text-amber-400" />
                </div>
                <div>
                  <p className="font-bold text-amber-400 text-sm">اختر وحدات الاستعادة</p>
                  <p className="text-white/30 text-xs">{pending.fileName}</p>
                </div>
              </div>
              <button onClick={() => setShowModSelect(false)} className="p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/8">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-white/50 text-xs">الوحدات المتاحة في هذا الملف</p>
                <button
                  onClick={() => setSelectedRestoreMods(
                    selectedRestoreMods.size === availMods.length ? new Set() : new Set(availMods)
                  )}
                  className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  {selectedRestoreMods.size === availMods.length ? 'إلغاء الكل' : 'تحديد الكل'}
                </button>
              </div>
              <div className="space-y-2">
                {RESTORE_MODULE_GROUPS.filter(g => availMods.includes(g.key)).map(g => {
                  const on = selectedRestoreMods.has(g.key);
                  return (
                    <button
                      key={g.key}
                      onClick={() => setSelectedRestoreMods(prev => {
                        const s = new Set(prev);
                        if (s.has(g.key)) s.delete(g.key); else s.add(g.key);
                        return s;
                      })}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border text-right transition-all ${on ? 'bg-amber-500/10 border-amber-500/25' : 'bg-white/3 border-white/8 hover:border-amber-500/15'}`}
                    >
                      <span className="text-xl shrink-0">{g.icon}</span>
                      <div className="flex-1">
                        <p className={`text-sm font-bold ${on ? 'text-amber-300' : 'text-white/60'}`}>{g.label}</p>
                        <p className="text-white/25 text-xs">{g.note}</p>
                      </div>
                      <div className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 ${on ? 'bg-amber-500 border-amber-500' : 'border-white/20'}`}>
                        {on && <Check className="w-3 h-3 text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>
              {selectedRestoreMods.size === 0 && (
                <p className="text-center text-red-400 text-xs">اختر وحدة واحدة على الأقل</p>
              )}
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => setShowModSelect(false)}
                  className="flex-1 py-2.5 rounded-xl border border-white/10 text-white/50 text-sm font-bold hover:text-white transition-colors"
                >
                  إلغاء
                </button>
                <button
                  onClick={() => { setShowModSelect(false); setModal(true); }}
                  disabled={selectedRestoreMods.size === 0}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-sm font-bold disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  متابعة ({selectedRestoreMods.size} وحدات)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══ Modal تأكيد الاستعادة ═══ */}
      {modal && pending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setModal(false)}
          />
          <div className="relative w-full max-w-md bg-[#0F1623] border border-red-500/30 rounded-2xl shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-red-500/20 bg-red-500/5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-red-500/15 flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                </div>
                <div>
                  <p className="font-bold text-red-400 text-sm">تأكيد الاستعادة</p>
                  <p className="text-white/30 text-xs">{pending.fileName}</p>
                </div>
              </div>
              <button
                onClick={() => setModal(false)}
                className="p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/8 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-center">
                <p className="text-red-300 font-bold text-sm">
                  ⚠️ سيتم حذف البيانات الحالية واستبدالها
                </p>
                <p className="text-white/35 text-xs mt-0.5">
                  {pending.tableCount} جداول · الإصدار {pending.version ?? 'legacy'}
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-white/55 text-sm block">
                  اكتب <span className="text-red-400 font-black tracking-widest">RESTORE</span>{' '}
                  للمتابعة:
                </label>
                <input
                  type="text"
                  value={modalText}
                  onChange={(e) => setModalText(e.target.value)}
                  placeholder="RESTORE"
                  spellCheck={false}
                  autoComplete="off"
                  className={`w-full bg-white/5 border rounded-xl px-4 py-3 text-sm font-bold text-center tracking-widest outline-none transition-all ${modalText === 'RESTORE' ? 'border-emerald-500/50 text-emerald-400' : modalText.length > 0 ? 'border-red-500/40 text-white' : 'border-white/10 text-white'}`}
                />
              </div>

              <label
                className="flex items-start gap-3 cursor-pointer"
                onClick={() => setUnderstood((v) => !v)}
              >
                <div
                  className={`mt-0.5 w-5 h-5 shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${understood ? 'bg-red-500 border-red-500' : 'border-white/20'}`}
                >
                  {understood && <Check className="w-3 h-3 text-white" />}
                </div>
                <span className="text-white/55 text-sm leading-relaxed select-none">
                  أفهم أن{' '}
                  <span className="text-red-400 font-bold">جميع البيانات الحالية ستُحذف</span>
                </span>
              </label>

              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => setModal(false)}
                  className="flex-1 py-3 rounded-xl border border-white/10 text-white/40 hover:text-white transition-all text-sm font-bold"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleConfirmRestore}
                  disabled={!canConfirm}
                  className={`flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${canConfirm ? 'bg-red-500 hover:bg-red-400 text-white' : 'bg-white/5 text-white/20 cursor-not-allowed'}`}
                >
                  <Upload className="w-4 h-4" /> استعادة
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
