/* ── Types ──────────────────────────────────────── */
export interface BackupFile {
  filename: string;
  size_mb: string;
  created_at: string;
}

export interface CompanyFeatures {
  accounting: boolean;
  hr: boolean;
  pos: boolean;
  warranty: boolean;
  consignment: boolean;
  fixed_assets: boolean;
  maintenance: boolean;
  budgets: boolean;
  bank_reconciliation: boolean;
}

export interface Company {
  id: number;
  name: string;
  plan_type: string;
  edition?: 'advanced' | 'ultimate' | null;
  start_date: string;
  end_date: string;
  is_active: boolean;
  admin_email: string | null;
  daysRemaining: number;
  status: 'active' | 'trial' | 'expired' | 'suspended';
  userCount: number;
  created_at: string;
  features?: CompanyFeatures | null;
}

export interface Stats {
  total: number;
  active: number;
  trial: number;
  paid: number;
  expired: number;
  suspended: number;
  totalUsers: number;
  expiringSoon: number;
  expiringSoonList: { id: number; name: string; end_date: string; plan_type: string; days_left: number }[];
  recentSignups: number;
  monthlySignups: { month: string; count: number }[];
  userCountByCompany: Record<number, number>;
}

export interface Manager {
  id: number;
  name: string;
  username: string;
  email: string | null;
  active: boolean | null;
  last_login: string | null;
  created_at: string;
}

/* ── Constants ───────────────────────────────────── */
export const STATUS: Record<string, { bg: string; text: string; border: string; label: string }> = {
  active:    { bg: 'rgba(34,197,94,0.12)',   text: '#22C55E', border: 'rgba(34,197,94,0.3)',   label: 'نشط' },
  trial:     { bg: 'rgba(249,115,22,0.12)',  text: '#F97316', border: 'rgba(249,115,22,0.3)',  label: 'تجريبي' },
  expired:   { bg: 'rgba(239,68,68,0.12)',   text: '#EF4444', border: 'rgba(239,68,68,0.3)',   label: 'منتهي' },
  suspended: { bg: 'rgba(148,163,184,0.1)',  text: '#94A3B8', border: 'rgba(148,163,184,0.2)', label: 'موقوف' },
};

export const PLAN_LABELS: Record<string, string> = {
  trial: 'تجريبي',
  basic: 'أساسي',
  professional: 'احترافي',
  pro: 'احترافي',
  paid: 'مدفوع',
};

export const translatePlan = (p: string) => PLAN_LABELS[p] ?? p;

/*
 * C — colour tokens wired to CSS custom properties.
 * Works in both dark and light mode automatically.
 * Semantic accent colours (orange, success, danger…) stay fixed
 * because they carry meaning regardless of theme.
 */
export const C = {
  /* ── surfaces ──────────────────────────────── */
  bg:        'var(--erp-bg-app)',    // outermost background
  card:      'var(--erp-bg-card)',   // card / panel surface
  surface:   'var(--erp-bg-app)',    // input well (slightly recessed from card)
  border:    'var(--erp-border)',    // generic border

  /* ── typography ─────────────────────────────── */
  text:      'var(--erp-text-1)',    // primary text
  muted:     'var(--erp-text-3)',    // secondary / helper text

  /* ── brand & semantic (fixed regardless of theme) ─ */
  orange:    '#F97316',
  orangeDim: 'rgba(249,115,22,0.15)',
  success:   '#22C55E',
  danger:    '#EF4444',
  warning:   '#F59E0B',
  blue:      '#3B82F6',
};

export const PER_PAGE = 10;
export const FONT = "'Tajawal','Cairo',sans-serif";

export function authHeaders(_ignored?: string) {
  return { 'Content-Type': 'application/json' };
}
