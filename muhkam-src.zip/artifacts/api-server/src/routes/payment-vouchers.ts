import { Router, type IRouter } from "express";
import { eq, desc, and, sql } from "drizzle-orm";
import { db, paymentVouchersTable, safesTable, customersTable, transactionsTable, accountsTable, customerLedgerTable } from "@workspace/db";
import { nextPaymentVoucherNo } from "../lib/invoice-no";

import { wrap, httpError } from "../lib/async-handler";
import { assertPeriodOpen } from "../lib/period-lock";
import { getOrCreateSafeAccount, getOrCreateGeneralExpenseAccount, createAutoJournalEntry, type AccountRef } from "../lib/auto-account";
import { hasPermission } from "../lib/permissions";

const router: IRouter = Router();

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getCid(req: any): number {
  return req.user!.company_id!;
}

function fmt(v: typeof paymentVouchersTable.$inferSelect) {
  return { ...v, amount: Number(v.amount), created_at: v.created_at.toISOString() };
}

router.get("/payment-vouchers", wrap(async (req, res) => {
  const cid = getCid(req);
  const limit = Math.min(2000, Math.max(1, parseInt(String(req.query["limit"] ?? "500"), 10)));
  const items = await db.select().from(paymentVouchersTable)
    .where(eq(paymentVouchersTable.company_id, cid))
    .orderBy(desc(paymentVouchersTable.created_at))
    .limit(limit);
  res.json(items.map(fmt));
}));

router.post("/payment-vouchers", wrap(async (req, res) => {
  if (!hasPermission(req.user, "can_add_payment_voucher")) {
    res.status(403).json({ error: "غير مصرح بإضافة سندات صرف" }); return;
  }

  const cid = getCid(req);
  const { customer_id, customer_name, safe_id, amount, notes, date } = req.body;
  if (!customer_name || !safe_id || !amount) {
    return res.status(400).json({ error: "البيانات غير مكتملة" });
  }
  const amt = Number(amount);
  if (isNaN(amt) || amt <= 0) { return res.status(400).json({ error: "المبلغ غير صحيح" }); }

  const requestId = req.headers["x-request-id"]
    ? String(req.headers["x-request-id"])
    : null;

  if (requestId) {
    const [existing] = await db.select().from(paymentVouchersTable)
      .where(and(eq(paymentVouchersTable.request_id, requestId), eq(paymentVouchersTable.company_id, cid))).limit(1);
    if (existing) return res.json(fmt(existing));
  }

  await assertPeriodOpen(date ?? null, req);

  const voucher = await db.transaction(async (tx) => {
    const [safe] = await tx.select().from(safesTable).where(and(
      eq(safesTable.id, parseInt(safe_id)),
      eq(safesTable.company_id, cid),
    ));
    if (!safe) throw httpError(400, "الخزينة غير موجودة");
    // خصم ذرّي مع شرط كفاية الرصيد لمنع التضارب المتزامن
    const debited = await tx.update(safesTable)
      .set({ balance: sql`${safesTable.balance} - ${String(amt)}` })
      .where(and(
        eq(safesTable.id, safe.id),
        eq(safesTable.company_id, cid),
        sql`${safesTable.balance} >= ${String(amt)}`,
      ))
      .returning();
    if (!debited[0]) throw httpError(400, "رصيد الخزينة غير كافٍ");

    let resolvedCustomerId: number | null = null;
    if (customer_id) {
      const [cust] = await tx.select().from(customersTable).where(and(
        eq(customersTable.id, parseInt(customer_id)),
        eq(customersTable.company_id, cid),
      ));
      if (!cust) throw httpError(400, "العميل غير موجود أو لا ينتمي لهذه الشركة");
      resolvedCustomerId = cust.id;
      await tx.update(customersTable).set({ balance: String(Number(cust.balance) + amt) }).where(and(
        eq(customersTable.id, cust.id),
        eq(customersTable.company_id, cid),
      ));
    }

    const voucher_no = await nextPaymentVoucherNo(cid);
    const [v] = await tx.insert(paymentVouchersTable).values({
      request_id: requestId,
      voucher_no,
      date: date ?? new Date().toISOString().split("T")[0],
      customer_id: resolvedCustomerId,
      customer_name,
      safe_id: safe.id,
      safe_name: safe.name,
      amount: String(amt),
      notes: notes ?? null,
      company_id: cid,
    }).returning();

    const txDate = date ?? new Date().toISOString().split("T")[0];
    await tx.insert(transactionsTable).values({
      type: "payment_voucher",
      reference_type: "payment_voucher",
      reference_id: v.id,
      safe_id: safe.id,
      safe_name: safe.name,
      customer_id: resolvedCustomerId,
      customer_name,
      amount: String(amt),
      direction: "out",
      description: `سند دفع ${voucher_no} — ${customer_name} (تسديد ما علينا)`,
      date: txDate,
      company_id: cid,
    });

    if (resolvedCustomerId) {
      await tx.insert(customerLedgerTable).values({
        customer_id: resolvedCustomerId,
        type: "payment_voucher",
        amount: String(amt),
        reference_type: "payment_voucher",
        reference_id: v.id,
        reference_no: voucher_no,
        description: `سند دفع ${voucher_no} — ${customer_name}`,
        date: txDate,
        company_id: cid,
      });
    }

    return v;
  });

  return res.status(201).json(fmt(voucher));
}));

/* ── مساعد: جلب حساب العميل ────────────────────────────────────────────── */
async function getVoucherCustomerAcct(customerId: number | null, companyId: number): Promise<AccountRef | null> {
  if (!customerId) return null;
  const [cust] = await db.select({ account_id: customersTable.account_id, name: customersTable.name })
    .from(customersTable).where(and(eq(customersTable.id, customerId), eq(customersTable.company_id, companyId)));
  if (!cust?.account_id) return null;
  const [acctRow] = await db.select({ id: accountsTable.id, code: accountsTable.code, name: accountsTable.name })
    .from(accountsTable).where(and(eq(accountsTable.id, cust.account_id), eq(accountsTable.company_id, companyId)));
  return acctRow ?? null;
}

/* ── ترحيل سند الدفع (draft → posted) ─────────────────────────────────── */
router.post("/payment-vouchers/:id/post", wrap(async (req, res) => {
  const cid = getCid(req);
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) throw httpError(400, "معرّف غير صحيح");

  const [v] = await db.select().from(paymentVouchersTable)
    .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)));
  if (!v) throw httpError(404, "سند الدفع غير موجود");
  if (v.posting_status === "posted")    throw httpError(400, "السند مرحَّل بالفعل");
  if (v.posting_status === "cancelled") throw httpError(400, "لا يمكن ترحيل سند ملغى");

  await assertPeriodOpen(v.date, req);

  const custAcct = await getVoucherCustomerAcct(v.customer_id, cid);
  const safeAcct = await getOrCreateSafeAccount(v.safe_id, v.safe_name, cid);
  if (custAcct) {
    await createAutoJournalEntry({
      date: v.date,
      description: `سند دفع ${v.voucher_no} — ${v.customer_name}`,
      reference: v.voucher_no,
      debit: custAcct,
      credit: safeAcct,
      amount: Number(v.amount),
      companyId: cid,
    });
  } else {
    const expAcct = await getOrCreateGeneralExpenseAccount(cid);
    await createAutoJournalEntry({
      date: v.date,
      description: `سند دفع ${v.voucher_no} — مصروف عمومي`,
      reference: v.voucher_no,
      debit: expAcct,
      credit: safeAcct,
      amount: Number(v.amount),
      companyId: cid,
    });
  }

  const [updated] = await db.update(paymentVouchersTable)
    .set({ posting_status: "posted" })
    .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)))
    .returning();

  res.json(fmt(updated));
}));

/* ── إلغاء سند الدفع → قيد عكسي ───────────────────────────────────────── */
router.post("/payment-vouchers/:id/cancel", wrap(async (req, res) => {
  const cid = getCid(req);
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) throw httpError(400, "معرّف غير صحيح");

  const [v] = await db.select().from(paymentVouchersTable)
    .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)));
  if (!v) throw httpError(404, "سند الدفع غير موجود");
  if (v.posting_status === "cancelled") throw httpError(400, "السند ملغى بالفعل");

  await assertPeriodOpen(v.date, req);

  if (v.posting_status === "posted") {
    const custAcct = await getVoucherCustomerAcct(v.customer_id, cid);
    if (custAcct) {
      const safeAcct = await getOrCreateSafeAccount(v.safe_id, v.safe_name, cid);
      await createAutoJournalEntry({
        date: new Date().toISOString().split("T")[0],
        description: `إلغاء سند دفع ${v.voucher_no} — ${v.customer_name}`,
        reference: `REV-${v.voucher_no}`,
        debit: safeAcct,
        credit: custAcct,
        amount: Number(v.amount),
        companyId: cid,
      });
    }
  }

  const [updated] = await db.update(paymentVouchersTable)
    .set({ posting_status: "cancelled" })
    .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)))
    .returning();

  res.json(fmt(updated));
}));

/* ── حذف (draft فقط — posted مقفل) ─────────────────────────────────────── */
router.delete("/payment-vouchers/:id", wrap(async (req, res) => {
  const cid = getCid(req);
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) { res.status(400).json({ error: "معرّف غير صالح" }); return; }

  const [preCheck] = await db.select({ date: paymentVouchersTable.date, posting_status: paymentVouchersTable.posting_status })
    .from(paymentVouchersTable)
    .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)));
  if (!preCheck) throw httpError(404, "غير موجود");
  if (preCheck.posting_status === "posted") throw httpError(400, "لا يمكن حذف سند مرحَّل — استخدم الإلغاء");
  await assertPeriodOpen(preCheck.date, req);

  await db.transaction(async (tx) => {
    const [v] = await tx.select().from(paymentVouchersTable)
      .where(and(eq(paymentVouchersTable.id, id), eq(paymentVouchersTable.company_id, cid)));
    if (!v) throw httpError(404, "غير موجود");
    if (v.posting_status === "posted") throw httpError(400, "لا يمكن حذف سند مرحَّل — استخدم الإلغاء");

    const [safe] = await tx.select().from(safesTable).where(and(
      eq(safesTable.id, v.safe_id),
      eq(safesTable.company_id, cid),
    ));
    if (safe) {
      await tx.update(safesTable)
        .set({ balance: sql`${safesTable.balance} + ${String(Number(v.amount))}` })
        .where(and(eq(safesTable.id, safe.id), eq(safesTable.company_id, cid)));
    }

    if (v.customer_id) {
      const [cust] = await tx.select().from(customersTable).where(and(
        eq(customersTable.id, v.customer_id),
        eq(customersTable.company_id, cid),
      ));
      if (cust) await tx.update(customersTable).set({ balance: String(Number(cust.balance) - Number(v.amount)) }).where(and(
        eq(customersTable.id, cust.id),
        eq(customersTable.company_id, cid),
      ));
      await tx.insert(customerLedgerTable).values({
        customer_id: v.customer_id,
        type: "payment_voucher",
        amount: String(-Number(v.amount)),
        reference_type: "payment_voucher_cancel",
        reference_id: v.id,
        reference_no: v.voucher_no,
        description: `إلغاء سند دفع ${v.voucher_no}`,
        date: new Date().toISOString().split("T")[0],
        company_id: cid,
      });
    }

    await tx.delete(paymentVouchersTable).where(eq(paymentVouchersTable.id, id));
  });
  res.json({ success: true });
}));

export default router;
