/**
 * GET /api/contacts/:id/full-statement?type=customer
 * كشف الحساب الشامل للعميل — يدمج مبيعات + مشتريات + مرتجعات + سندات قبض/صرف
 */
import { Router, type IRouter } from "express";
import { eq, desc, and } from "drizzle-orm";
import {
  db,
  customersTable,
  transactionsTable,
  salesTable,
  salesReturnsTable,
  purchasesTable,
  purchaseReturnsTable,
} from "@workspace/db";
import { wrap } from "../lib/async-handler";

const router: IRouter = Router();

type StatRow = {
  date: string;
  type: string;
  description: string;
  debit: number;
  credit: number;
  reference_no?: string | null;
  balance?: number;
};

router.get("/contacts/:id/full-statement", wrap(async (req, res) => {
  const cid: number = req.user!.company_id!;
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) { res.status(400).json({ error: "معرّف غير صالح" }); return; }

  const [c] = await db.select().from(customersTable)
    .where(and(eq(customersTable.id, id), eq(customersTable.company_id, cid)));
  if (!c) { res.status(404).json({ error: "العميل غير موجود" }); return; }

  const rows: StatRow[] = [];

  // رصيد أول المدة
  const openings = await db.select().from(transactionsTable)
    .where(and(
      eq(transactionsTable.reference_type, "customer_opening"),
      eq(transactionsTable.company_id, cid),
    ));
  const ob = openings.filter(o => o.reference_id === id);
  const openingCredit = ob.reduce((s, o) => s + Number(o.amount), 0);
  if (openingCredit !== 0) {
    rows.push({ date: "2000-01-01", type: "opening_balance", description: "رصيد أول المدة", debit: 0, credit: openingCredit });
  }

  // مبيعات
  const sales = await db.select().from(salesTable)
    .where(and(eq(salesTable.customer_id, id), eq(salesTable.company_id, cid)))
    .orderBy(desc(salesTable.created_at));
  for (const s of sales) {
    rows.push({ date: s.date ?? s.created_at.toISOString().split("T")[0], type: "sale", description: `فاتورة مبيعات ${s.invoice_no ?? ""}`, debit: 0, credit: Number(s.total_amount), reference_no: s.invoice_no });
  }

  // مرتجعات مبيعات
  const saleReturns = await db.select().from(salesReturnsTable)
    .where(and(eq(salesReturnsTable.customer_id, id), eq(salesReturnsTable.company_id, cid)))
    .orderBy(desc(salesReturnsTable.created_at));
  for (const r of saleReturns) {
    rows.push({ date: r.date ?? r.created_at.toISOString().split("T")[0], type: "sale_return", description: `مرتجع مبيعات ${r.return_no ?? ""}`, debit: Number(r.total_amount), credit: 0, reference_no: r.return_no });
  }

  // سندات قبض
  const receiptTx = await db.select().from(transactionsTable)
    .where(and(
      eq(transactionsTable.reference_type, "receipt_voucher"),
      eq(transactionsTable.company_id, cid),
    ))
    .orderBy(desc(transactionsTable.created_at));
  for (const v of receiptTx.filter(v => v.customer_id === id)) {
    rows.push({ date: v.date ?? v.created_at.toISOString().split("T")[0], type: "receipt_voucher", description: v.description ?? "سند قبض", debit: Number(v.amount), credit: 0 });
  }

  // سندات صرف للعميل
  const payTx = await db.select().from(transactionsTable)
    .where(and(
      eq(transactionsTable.reference_type, "payment_voucher"),
      eq(transactionsTable.company_id, cid),
    ))
    .orderBy(desc(transactionsTable.created_at));
  for (const v of payTx.filter(v => v.customer_id === id)) {
    rows.push({ date: v.date ?? v.created_at.toISOString().split("T")[0], type: "payment_voucher", description: v.description ?? "سند صرف", debit: 0, credit: Number(v.amount) });
  }

  // إذا كان عميل-مورد: مشتريات + مرتجعات مشتريات + سداد موردين
  if (c.is_supplier) {
    const purchases = await db.select().from(purchasesTable)
      .where(and(eq(purchasesTable.customer_id, id), eq(purchasesTable.company_id, cid)))
      .orderBy(desc(purchasesTable.created_at));
    for (const p of purchases) {
      rows.push({ date: p.date ?? p.created_at.toISOString().split("T")[0], type: "purchase", description: `فاتورة شراء ${p.invoice_no ?? ""}`, debit: 0, credit: Number(p.total_amount), reference_no: p.invoice_no });
    }

    const purchaseReturns = await db.select().from(purchaseReturnsTable)
      .where(and(eq(purchaseReturnsTable.customer_id, id), eq(purchaseReturnsTable.company_id, cid)))
      .orderBy(desc(purchaseReturnsTable.created_at));
    for (const r of purchaseReturns) {
      rows.push({ date: r.date ?? r.created_at.toISOString().split("T")[0], type: "purchase_return", description: `مرتجع مشتريات ${r.return_no}`, debit: Number(r.total_amount), credit: 0, reference_no: r.return_no });
    }

    const supplierPayTx = await db.select().from(transactionsTable)
      .where(and(
        eq(transactionsTable.reference_type, "supplier_payment"),
        eq(transactionsTable.company_id, cid),
      ))
      .orderBy(desc(transactionsTable.created_at));
    for (const p of supplierPayTx.filter(p => p.reference_id === id)) {
      rows.push({ date: p.date ?? p.created_at.toISOString().split("T")[0], type: "supplier_payment", description: p.description ?? "سداد للمورد", debit: Number(p.amount), credit: 0 });
    }
  }

  rows.sort((a, b) => a.date.localeCompare(b.date));

  let runningBalance = 0;
  const statement = rows.map(row => {
    runningBalance = Math.round((runningBalance + row.credit - row.debit) * 100) / 100;
    return { ...row, balance: runningBalance };
  });

  const totalSales = statement.filter(r => r.type === "sale").reduce((s, r) => s + r.credit, 0);
  const totalPurchases = statement.filter(r => r.type === "purchase").reduce((s, r) => s + r.credit, 0);
  const totalReceipts = statement.filter(r => r.type === "receipt_voucher").reduce((s, r) => s + r.debit, 0);
  const totalPayments = statement.filter(r => r.type === "supplier_payment").reduce((s, r) => s + r.debit, 0);

  res.json({
    contact: {
      id,
      name: c.name,
      phone: c.phone ?? null,
      type: c.is_supplier ? "both" : "customer",
      customer_id: id,
    },
    summary: {
      total_sales: totalSales,
      total_purchases: totalPurchases,
      total_receipts: totalReceipts,
      total_payments: totalPayments,
      closing_balance: runningBalance,
    },
    statement,
  });
}));

export default router;
