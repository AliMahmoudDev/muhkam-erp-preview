import { Router, type IRouter } from "express";
import { eq, desc, and, sql, inArray } from "drizzle-orm";
import { z } from "zod";
import {
  db, salesReturnsTable, saleReturnItemsTable,
  purchaseReturnsTable, purchaseReturnItemsTable,
  productsTable, customersTable, safesTable, transactionsTable, stockMovementsTable,
  saleItemsTable, purchaseItemsTable, customerLedgerTable, salesTable, purchasesTable,
} from "@workspace/db";

const returnItemSchema = z.object({
  product_id: z.number().int().positive(),
  quantity: z.number().positive("الكمية يجب أن تكون أكبر من صفر"),
  unit_price: z.number().min(0),
  total_price: z.number().min(0),
});

const createSaleReturnSchema = z.object({
  items: z.array(returnItemSchema).min(1, "أضف أصناف المرتجع"),
  sale_id: z.number().int().positive().optional().nullable(),
  customer_id: z.number().int().positive().optional().nullable(),
  customer_name: z.string().max(200).optional().nullable(),
  reason: z.string().max(500).optional().nullable(),
  notes: z.string().max(500).optional().nullable(),
  date: z.string().optional().nullable(),
  refund_type: z.enum(["cash", "credit"]).optional().default("credit"),
  safe_id: z.number().int().positive().optional().nullable(),
});

const createPurchaseReturnSchema = z.object({
  items: z.array(returnItemSchema).min(1, "أضف أصناف المرتجع"),
  purchase_id: z.number().int().positive().optional().nullable(),
  customer_id: z.number().int().positive().optional().nullable(),
  customer_name: z.string().max(200).optional().nullable(),
  supplier_name: z.string().max(200).optional().nullable(),
  reason: z.string().max(500).optional().nullable(),
  notes: z.string().max(500).optional().nullable(),
  date: z.string().optional().nullable(),
  refund_type: z.enum(["cash", "balance_credit"]).optional().default("balance_credit"),
  safe_id: z.number().int().positive().optional().nullable(),
});
import { nextSaleReturnNo, nextPurchaseReturnNo } from "../lib/invoice-no";

import { wrap, httpError } from "../lib/async-handler";
import { assertPeriodOpen } from "../lib/period-lock";
import { writeAuditLog } from "../lib/audit-log";
import { hasPermission } from "../lib/permissions";
import { resolveTenantWarehouseId } from "../lib/warehouse-guard";
import {
  getOrCreateCOGSAccount,
  getOrCreateInventoryAccount,
  createJournalEntry,
} from "../lib/auto-account";

const router: IRouter = Router();

// ══════════════════════════════════════════════════════════════════════════════
// مرتجعات المبيعات
// ══════════════════════════════════════════════════════════════════════════════

router.get("/sales-returns", wrap(async (req, res) => {
  const companyId: number = req.user!.company_id!;
  const items = await db
    .select({
      id: salesReturnsTable.id,
      return_no: salesReturnsTable.return_no,
      sale_id: salesReturnsTable.sale_id,
      customer_id: salesReturnsTable.customer_id,
      customer_name: salesReturnsTable.customer_name,
      total_amount: salesReturnsTable.total_amount,
      reason: salesReturnsTable.reason,
      notes: salesReturnsTable.notes,
      date: salesReturnsTable.date,
      refund_type: salesReturnsTable.refund_type,
      created_at: salesReturnsTable.created_at,
      sale_no: salesTable.invoice_no,
    })
    .from(salesReturnsTable)
    .leftJoin(salesTable, eq(salesReturnsTable.sale_id, salesTable.id))
    .where(eq(salesReturnsTable.company_id, companyId))
    .orderBy(desc(salesReturnsTable.created_at));
  res.json(items.map(r => ({ ...r, total_amount: Number(r.total_amount), created_at: r.created_at?.toISOString() })));
}));

router.get("/sales-returns/:id", wrap(async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) { res.status(400).json({ error: "معرّف غير صالح" }); return; }
  const [ret] = await db.select().from(salesReturnsTable).where(and(eq(salesReturnsTable.id, id), eq(salesReturnsTable.company_id, req.user!.company_id!)));
  if (!ret) { res.status(404).json({ error: "غير موجود" }); return; }
  const items = await db.select().from(saleReturnItemsTable).where(eq(saleReturnItemsTable.return_id, id));
  res.json({
    ...ret,
    total_amount: Number(ret.total_amount),
    created_at: ret.created_at.toISOString(),
    items: items.map(i => ({
      ...i,
      quantity: Number(i.quantity),
      unit_price: Number(i.unit_price),
      total_price: Number(i.total_price),
      unit_cost_at_return: Number(i.unit_cost_at_return),
      total_cost_at_return: Number(i.total_cost_at_return),
    })),
  });
}));

/*
 * POST /sales-returns
 *
 * كل بند مرتجع يجب أن يحمل:
 *   original_sale_item_id  — معرّف البند الدقيق من sale_items (مطلوب عند وجود sale_id)
 *   product_id
 *   product_name
 *   quantity               — الكمية المُرتجَعة
 *   unit_price             — سعر البيع (للمبلغ المسترد)
 *   total_price
 *
 * الرابط بـ original_sale_item_id يحل مشكلة الغموض عندما يظهر نفس المنتج
 * في أكثر من بند بنفس الفاتورة وبتكاليف مختلفة.
 */
router.post("/sales-returns", wrap(async (req, res) => {
  if (!hasPermission(req.user, "can_return_sale")) {
    res.status(403).json({ error: "غير مصرح بتسجيل المرتجعات" }); return;
  }

  const vr = createSaleReturnSchema.safeParse(req.body);
  if (!vr.success) { return res.status(400).json({ error: vr.error.errors[0]?.message ?? "بيانات غير صالحة" }); }
  const { sale_id, customer_id, customer_name, items, reason, notes, date, refund_type, safe_id } = req.body;

  // Tenant validation: customer_id must belong to my company if provided
  if (customer_id) {
    const [ownC] = await db.select({ id: customersTable.id }).from(customersTable)
      .where(and(eq(customersTable.id, parseInt(customer_id)), eq(customersTable.company_id, req.user!.company_id!)));
    if (!ownC) { res.status(400).json({ error: "العميل غير موجود" }); return; }
  }

  // Tenant validation: every product_id in items must belong to my company
  const reqProductIds = Array.from(new Set(items.map((i: { product_id: number }) => Number(i.product_id))));
  if (reqProductIds.length > 0) {
    const ownedProducts = await db.select({ id: productsTable.id }).from(productsTable)
      .where(and(inArray(productsTable.id, reqProductIds as number[]), eq(productsTable.company_id, req.user!.company_id!)));
    if (ownedProducts.length !== reqProductIds.length) {
      res.status(400).json({ error: "أحد المنتجات غير موجود" }); return;
    }
  }

  const requestId = req.headers["x-request-id"]
    ? String(req.headers["x-request-id"])
    : null;

  if (requestId) {
    const [existing] = await db.select().from(salesReturnsTable)
      .where(and(eq(salesReturnsTable.request_id, requestId), eq(salesReturnsTable.company_id, req.user!.company_id!))).limit(1);
    if (existing) return res.json({ ...existing, total_amount: Number(existing.total_amount), created_at: existing.created_at.toISOString() });
  }

  const total: number = items.reduce((s: number, i: { total_price: number }) => s + Number(i.total_price), 0);
  const return_no = await nextSaleReturnNo(req.user!.company_id!);
  const rtype: string = refund_type === "cash" ? "cash" : "credit";
  const txDate = date ?? new Date().toISOString().split("T")[0];

  // ── Pre-transaction validation ────────────────────────────────────────────
  // Validation 1: total returned for this invoice must not exceed invoice total
  if (sale_id) {
    const [origSale] = await db
      .select({ total_amount: salesTable.total_amount })
      .from(salesTable)
      .where(and(eq(salesTable.id, parseInt(sale_id)), eq(salesTable.company_id, req.user!.company_id!)));

    if (!origSale) {
      res.status(400).json({ error: "الفاتورة الأصلية غير موجودة" }); return;
    }

    const [retAgg] = await db
      .select({ returned: sql<string>`coalesce(sum(total_amount::numeric), 0)` })
      .from(salesReturnsTable)
      .where(and(eq(salesReturnsTable.sale_id, parseInt(sale_id)), eq(salesReturnsTable.company_id, req.user!.company_id!)));

    const alreadyReturnedForInvoice = Number(retAgg?.returned ?? 0);
    const invoiceTotal = Number(origSale.total_amount);

    if (alreadyReturnedForInvoice + total > invoiceTotal + 0.01) {
      res.status(400).json({
        error: `إجمالي المرتجعات (${(alreadyReturnedForInvoice + total).toFixed(2)}) يتجاوز إجمالي الفاتورة (${invoiceTotal.toFixed(2)}). تم إرجاع ${alreadyReturnedForInvoice.toFixed(2)} مسبقاً`,
      }); return;
    }
  }

  // Validation 2: total returned for this customer must not exceed total purchased
  if (customer_id) {
    const custId = parseInt(customer_id);

    const [salesAgg] = await db
      .select({ total: sql<string>`coalesce(sum(total_amount::numeric), 0)` })
      .from(salesTable)
      .where(and(eq(salesTable.customer_id, custId), eq(salesTable.company_id, req.user!.company_id!)));

    const [returnsAgg] = await db
      .select({ returned: sql<string>`coalesce(sum(total_amount::numeric), 0)` })
      .from(salesReturnsTable)
      .where(and(eq(salesReturnsTable.customer_id, custId), eq(salesReturnsTable.company_id, req.user!.company_id!)));

    const totalSalesForCustomer = Number(salesAgg?.total ?? 0);
    const alreadyReturnedForCustomer = Number(returnsAgg?.returned ?? 0);

    if (alreadyReturnedForCustomer + total > totalSalesForCustomer + 0.01) {
      res.status(400).json({
        error: "لا يمكن إرجاع كمية أكبر من المباعة للعميل",
      }); return;
    }
  }
  // ── End validation ────────────────────────────────────────────────────────

  await assertPeriodOpen(txDate, req);

  const role = req.user?.role ?? "cashier";
  const effectiveWarehouseId = (role === "admin" || role === "manager")
    ? (req.body.warehouse_id ? Number(req.body.warehouse_id) : null)
    : (req.user?.warehouse_id ?? null);

  const tenantWarehouseId = await resolveTenantWarehouseId(
    effectiveWarehouseId,
    req.user!.company_id!,
  );

  const ret = await db.transaction(async (tx) => {
    let safeName: string | null = null;
    let safeIdInt: number | null = null;
    if (rtype === "cash" && safe_id) {
      const [safe] = await tx.select().from(safesTable).where(and(eq(safesTable.id, parseInt(safe_id)), eq(safesTable.company_id, req.user!.company_id!)));
      if (!safe) throw httpError(400, "الخزينة غير موجودة");
      safeName = safe.name;
      safeIdInt = safe.id;
    }

    const [ret] = await tx.insert(salesReturnsTable).values({
      request_id: requestId,
      return_no,
      sale_id: sale_id ?? null,
      customer_id: customer_id ? parseInt(customer_id) : null,
      customer_name: customer_name ?? null,
      total_amount: String(total),   // سيُحدَّث بالقيمة المقفولة بعد الحلقة
      refund_type: rtype,
      safe_id: safeIdInt,
      safe_name: safeName,
      date: txDate,
      reason: reason ?? null,
      notes: notes ?? null,
      user_id: req.user?.id ?? null,
      warehouse_id: effectiveWarehouseId ?? null,
      company_id: req.user!.company_id!,
    }).returning();

    let actualTotal = 0;
    let totalCOGSReversed = 0;

    for (const item of items) {
      const retQty = Number(item.quantity);
      if (retQty <= 0) throw httpError(400, `كمية المرتجع للصنف "${item.product_name}" يجب أن تكون أكبر من صفر`);
      const origSaleItemId: number | null = item.original_sale_item_id
        ? parseInt(item.original_sale_item_id)
        : null;

      // ── التحقق من البند الأصلي وحساب التكلفة ──────────────────────────────
      // القاعدة 1: إن كان original_sale_item_id موجوداً نستخدمه مباشرة (الأدق)
      //   → سعر المرتجع يُقفل على سعر البيع الأصلي (لا override)
      // القاعدة 2: إن لم يوجد نبحث بـ sale_id + product_id (احتياطي)
      // القاعدة 3: إن لم يوجد نستخدم cost_price الحالي للمنتج
      let unitCostAtSale  = 0;
      let resolvedItemId: number | null = origSaleItemId;
      // السعر الفعلي للمرتجع — يُقفل على الأصل إن وُجد
      let lockedSalePrice = Number(item.unit_price);

      if (origSaleItemId) {
        if (!sale_id) throw httpError(400, "يجب تحديد الفاتورة الأصلية عند تمرير بند بيع أصلي");
        const [origItem] = await tx
          .select()
          .from(saleItemsTable)
          .where(and(eq(saleItemsTable.id, origSaleItemId), eq(saleItemsTable.sale_id, parseInt(sale_id))));

        if (!origItem) throw httpError(400, `بند البيع الأصلي ${origSaleItemId} غير موجود`);

        const alreadyReturned = Number(origItem.quantity_returned);
        const remaining       = Number(origItem.quantity) - alreadyReturned;

        if (retQty > remaining + 0.0001) {
          throw httpError(400,
            `الكمية المطلوب إرجاعها (${retQty}) تتجاوز الكمية المتاحة للإرجاع (${remaining.toFixed(3)}) للبند ${origItem.product_name}`
          );
        }

        // قفل السعر على سعر البيع الأصلي — لا يمكن تعديله من الواجهة
        lockedSalePrice = Number(origItem.unit_price);
        unitCostAtSale  = Number(origItem.cost_price);

        // تحديث quantity_returned على البند الأصلي
        await tx.update(saleItemsTable)
          .set({ quantity_returned: String((alreadyReturned + retQty).toFixed(3)) })
          .where(and(eq(saleItemsTable.id, origSaleItemId), eq(saleItemsTable.sale_id, parseInt(sale_id))));

      } else if (sale_id) {
        // احتياطي — بحث بـ sale_id + product_id (قد يكون غامضاً)
        const origItems = await tx
          .select()
          .from(saleItemsTable)
          .where(and(
            eq(saleItemsTable.sale_id, parseInt(sale_id)),
            eq(saleItemsTable.product_id, item.product_id),
          ));

        if (origItems.length > 0) {
          // في حالة التعدد، نختار أول بند لا يزال لديه كمية متاحة
          const available = origItems.find(r =>
            (Number(r.quantity) - Number(r.quantity_returned)) >= retQty - 0.0001
          ) ?? origItems[0];

          unitCostAtSale  = Number(available.cost_price);
          resolvedItemId  = available.id;

          const alreadyReturned = Number(available.quantity_returned);
          await tx.update(saleItemsTable)
            .set({ quantity_returned: String((alreadyReturned + retQty).toFixed(3)) })
            .where(and(eq(saleItemsTable.id, available.id), eq(saleItemsTable.sale_id, parseInt(sale_id))));
        }
      }

      if (unitCostAtSale === 0) {
        const [prod] = await tx.select({ cost_price: productsTable.cost_price })
          .from(productsTable).where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));
        if (prod) unitCostAtSale = Number(prod.cost_price);
      }

      const totalCostAtReturn = unitCostAtSale * retQty;
      totalCOGSReversed += totalCostAtReturn;

      const lockedTotalPrice = lockedSalePrice * retQty;
      actualTotal += lockedTotalPrice;

      // ── إدراج بند المرتجع ─────────────────────────────────────────────────
      await tx.insert(saleReturnItemsTable).values({
        return_id:              ret.id,
        product_id:             item.product_id,
        product_name:           item.product_name,
        quantity:               String(retQty),
        unit_price:             String(lockedSalePrice),
        total_price:            String(lockedTotalPrice.toFixed(2)),
        original_sale_item_id:  resolvedItemId,
        unit_cost_at_return:    String(unitCostAtSale),
        total_cost_at_return:   String(totalCostAtReturn),
      });

      // ── إعادة المخزون بالتكلفة الأصلية + تحديث WAC ───────────────────────
      const [prodNow] = await tx.select().from(productsTable).where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));
      if (prodNow) {
        const oldQty = Number(prodNow.quantity);
        const oldWAC = Number(prodNow.cost_price);
        const newQty = oldQty + retQty;
        const newWAC = newQty > 0
          ? ((oldQty * oldWAC) + (retQty * unitCostAtSale)) / newQty
          : unitCostAtSale;

        await tx.update(productsTable)
          .set({
            quantity:   String(newQty),
            cost_price: String(newWAC.toFixed(4)),
          })
          .where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));

        await tx.insert(stockMovementsTable).values({
          product_id:      item.product_id,
          product_name:    item.product_name,
          movement_type:   "sale_return",
          quantity:        String(retQty),
          quantity_before: String(oldQty),
          quantity_after:  String(newQty),
          unit_cost:       String(unitCostAtSale),
          reference_type:  "sale_return",
          reference_id:    ret.id,
          reference_no:    return_no,
          notes: customer_name ? `مرتجع مبيعات من ${customer_name}` : "مرتجع مبيعات",
          date: txDate,
          warehouse_id: tenantWarehouseId,
          company_id:   req.user!.company_id!,
        });
      }
    }

    // ── قيد عكس COGS: DR ASSET-INVENTORY / CR EXP-COGS ─────────────────────
    // يعكس تكلفة البضاعة التي كانت خُصمت عند ترحيل البيع الأصلي،
    // ليبقى رصيد EXP-COGS و ASSET-INVENTORY متوافقاً مع الحركة المخزنية.
    if (totalCOGSReversed > 0) {
      const cidRet = req.user!.company_id!;
      const inventoryAcct = await getOrCreateInventoryAccount(cidRet);
      const cogsAcct      = await getOrCreateCOGSAccount(cidRet);
      await createJournalEntry({
        date:        txDate,
        description: `عكس تكلفة مرتجع مبيعات ${return_no}${customer_name ? ` — ${customer_name}` : ""}`,
        reference:   return_no,
        lines: [
          { account: inventoryAcct, debit: totalCOGSReversed, credit: 0 },
          { account: cogsAcct,      debit: 0, credit: totalCOGSReversed },
        ],
        companyId: cidRet,
      }, tx);
    }

    // تحديث المبلغ بالقيمة المقفولة إن اختلفت
    if (Math.abs(actualTotal - total) > 0.001) {
      await tx.update(salesReturnsTable)
        .set({ total_amount: String(actualTotal.toFixed(2)) })
        .where(eq(salesReturnsTable.id, ret.id));
      ret.total_amount = String(actualTotal.toFixed(2));
    }

    const finalTotal = actualTotal > 0 ? actualTotal : total;

    // ── أثر الأرصدة ────────────────────────────────────────────────────────
    if (rtype === "credit") {
      if (customer_id) {
        const [cust] = await tx.select().from(customersTable).where(and(eq(customersTable.id, parseInt(customer_id)), eq(customersTable.company_id, req.user!.company_id!)));
        if (cust) {
          await tx.update(customersTable)
            .set({ balance: String(Number(cust.balance) - finalTotal) })
            .where(and(eq(customersTable.id, cust.id), eq(customersTable.company_id, req.user!.company_id!)));
        }
      }
    } else if (rtype === "cash" && safeIdInt) {
      const [safe] = await tx.select().from(safesTable).where(and(eq(safesTable.id, safeIdInt), eq(safesTable.company_id, req.user!.company_id!)));
      if (safe) {
        await tx.update(safesTable)
          .set({ balance: String(Number(safe.balance) - finalTotal) })
          .where(eq(safesTable.id, safeIdInt));
      }
      await tx.insert(transactionsTable).values({
        type: "sale_return",
        reference_type: "sale_return",
        reference_id: ret.id,
        safe_id: safeIdInt,
        safe_name: safeName ?? "",
        customer_id: customer_id ? parseInt(customer_id) : null,
        customer_name: customer_name ?? null,
        amount: String(finalTotal.toFixed(2)),
        direction: "out",
        description: `مرتجع مبيعات نقدي ${return_no}${customer_name ? ` — ${customer_name}` : ""}`,
        date: txDate,
        company_id: req.user!.company_id!,
      });
    }

    // ── دفتر أستاذ العميل — تسجيل مرتجع المبيعات (يُقلّل الدين) ─────────
    if (customer_id) {
      await tx.insert(customerLedgerTable).values({
        customer_id: parseInt(customer_id),
        type: "sale_return",
        amount: String(-finalTotal),
        reference_type: "sale_return",
        reference_id: ret.id,
        reference_no: return_no,
        description: `مرتجع مبيعات ${return_no}${customer_name ? ` — ${customer_name}` : ""}`,
        date: txDate,
        company_id: req.user!.company_id!,
      });
    }

    return ret;
  });

  void writeAuditLog({
    action: "create",
    record_type: "sale_return",
    record_id: ret.id,
    new_value: { return_no, total, customer_id: customer_id ?? null, refund_type: rtype, date: txDate },
    user: { id: req.user?.id, username: req.user?.username },
  });

  return res.status(201).json({ ...ret, total_amount: Number(ret.total_amount), created_at: ret.created_at.toISOString() });
}));

router.delete("/sales-returns/:id", wrap(async (req, res) => {
  if (!hasPermission(req.user, "can_cancel_sale")) {
    res.status(403).json({ error: "غير مصرح بحذف المرتجعات" }); return;
  }
  const id = parseInt(req.params.id as string);
  const [preCheck] = await db.select({ date: salesReturnsTable.date })
    .from(salesReturnsTable).where(and(eq(salesReturnsTable.id, id), eq(salesReturnsTable.company_id, req.user!.company_id!)));
  if (!preCheck) throw httpError(404, "المرتجع غير موجود");
  await assertPeriodOpen(preCheck.date, req);

  const effectiveWarehouseId = req.user?.warehouse_id ?? null;
  const tenantWarehouseId = await resolveTenantWarehouseId(
    effectiveWarehouseId,
    req.user!.company_id!,
  );

  await db.transaction(async (tx) => {
    const [ret] = await tx.select().from(salesReturnsTable).where(and(eq(salesReturnsTable.id, id), eq(salesReturnsTable.company_id, req.user!.company_id!)));
    if (!ret) throw httpError(400, "المرتجع غير موجود");

    const retItems = await tx.select().from(saleReturnItemsTable).where(eq(saleReturnItemsTable.return_id, id));
    const total = Number(ret.total_amount);
    let totalCOGSRebook = 0;

    for (const item of retItems) {
      const retQty = Number(item.quantity);

      // ── إرجاع quantity_returned على البند الأصلي ─────────────────────────
      if (item.original_sale_item_id && ret.sale_id) {
        const [origItem] = await tx.select().from(saleItemsTable)
          .where(and(eq(saleItemsTable.id, item.original_sale_item_id), eq(saleItemsTable.sale_id, ret.sale_id)));
        if (origItem) {
          const newReturned = Math.max(0, Number(origItem.quantity_returned) - retQty);
          await tx.update(saleItemsTable)
            .set({ quantity_returned: String(newReturned.toFixed(3)) })
            .where(and(eq(saleItemsTable.id, origItem.id), eq(saleItemsTable.sale_id, ret.sale_id)));
        }
      }

      // ── عكس المخزون (البضاعة تخرج مرة أخرى) ─────────────────────────────
      const unitCost = Number(item.unit_cost_at_return) || Number(item.unit_price);
      totalCOGSRebook += retQty * unitCost;
      const cidDel = req.user!.company_id!;
      const [prod] = await tx.select().from(productsTable).where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, cidDel)));
      if (prod) {
        const oldQty = Number(prod.quantity);
        const qtyStr = String(retQty);
        // Atomic check + decrement (race-safe). 0 rows → would go negative.
        const dec = await tx.update(productsTable)
          .set({ quantity: sql`${productsTable.quantity}::numeric - ${qtyStr}::numeric` })
          .where(and(
            eq(productsTable.id, item.product_id),
            eq(productsTable.company_id, cidDel),
            sql`${productsTable.quantity}::numeric >= ${qtyStr}::numeric`,
          ))
          .returning({ quantity: productsTable.quantity });
        if (dec.length === 0) {
          throw httpError(400, `لا يمكن إلغاء المرتجع: المخزون الحالي لـ "${item.product_name}" أقل من الكمية المُراد سحبها (${retQty})`);
        }
        const newQty = Number(dec[0].quantity);

        // تعديل WAC عند إزالة الكمية المُرتجَعة (عكس الإضافة)
        const oldWAC = Number(prod.cost_price);
        let newWAC   = oldWAC;
        if (newQty > 0) {
          const currentValue = oldQty * oldWAC;
          const removedValue = retQty * unitCost;
          newWAC = Math.max(0, (currentValue - removedValue) / newQty);
        }

        await tx.update(productsTable)
          .set({ cost_price: String(newWAC.toFixed(4)) })
          .where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, cidDel)));

        await tx.insert(stockMovementsTable).values({
          product_id:      item.product_id,
          product_name:    item.product_name,
          movement_type:   "adjustment",
          quantity:        String(-retQty),
          quantity_before: String(oldQty),
          quantity_after:  String(newQty),
          unit_cost:       String(unitCost),
          reference_type:  "sale_return_cancel",
          reference_id:    ret.id,
          reference_no:    ret.return_no,
          notes:           `إلغاء مرتجع مبيعات ${ret.return_no}`,
          date:            new Date().toISOString().split("T")[0],
          warehouse_id:    tenantWarehouseId,
          company_id:      req.user!.company_id!,
        });
      }
    }

    // ── إعادة تطبيق COGS عند إلغاء المرتجع: DR EXP-COGS / CR ASSET-INVENTORY ─
    // البضاعة تخرج من المخزون مرة أخرى، لذا يعود COGS كما كان قبل المرتجع.
    if (totalCOGSRebook > 0) {
      const cidRebook = req.user!.company_id!;
      const inventoryAcct = await getOrCreateInventoryAccount(cidRebook);
      const cogsAcct      = await getOrCreateCOGSAccount(cidRebook);
      await createJournalEntry({
        date:        new Date().toISOString().split("T")[0],
        description: `إلغاء مرتجع مبيعات — إعادة COGS ${ret.return_no}`,
        reference:   `REV-${ret.return_no}`,
        lines: [
          { account: cogsAcct,      debit: totalCOGSRebook, credit: 0 },
          { account: inventoryAcct, debit: 0, credit: totalCOGSRebook },
        ],
        companyId: cidRebook,
      }, tx);
    }

    // ── عكس الأرصدة ─────────────────────────────────────────────────────────
    if (ret.refund_type === "credit" && ret.customer_id) {
      const [cust] = await tx.select().from(customersTable).where(and(eq(customersTable.id, ret.customer_id), eq(customersTable.company_id, req.user!.company_id!)));
      if (cust) {
        await tx.update(customersTable)
          .set({ balance: String(Number(cust.balance) + total) })
          .where(and(eq(customersTable.id, cust.id), eq(customersTable.company_id, req.user!.company_id!)));
      }
    } else if (ret.refund_type === "cash" && ret.safe_id) {
      const [safe] = await tx.select().from(safesTable).where(and(eq(safesTable.id, ret.safe_id), eq(safesTable.company_id, req.user!.company_id!)));
      if (safe) {
        await tx.update(safesTable)
          .set({ balance: String(Number(safe.balance) + total) })
          .where(and(eq(safesTable.id, ret.safe_id), eq(safesTable.company_id, req.user!.company_id!)));
      }
      await tx.insert(transactionsTable).values({
        type: "sale_return_cancel",
        reference_type: "sale_return_cancel",
        reference_id: ret.id,
        safe_id: ret.safe_id,
        safe_name: ret.safe_name ?? "",
        customer_id: ret.customer_id ?? null,
        customer_name: ret.customer_name ?? null,
        amount: String(total),
        direction: "in",
        description: `إلغاء مرتجع مبيعات نقدي ${ret.return_no}`,
        date: new Date().toISOString().split("T")[0],
        company_id: req.user!.company_id!,
      });
    }

    await tx.delete(saleReturnItemsTable).where(eq(saleReturnItemsTable.return_id, id));
    await tx.delete(salesReturnsTable).where(eq(salesReturnsTable.id, id));
  });

  void writeAuditLog({
    action: "delete",
    record_type: "sale_return",
    record_id: id,
    user: { id: req.user?.id, username: req.user?.username },
  });

  res.json({ success: true });
}));

// ══════════════════════════════════════════════════════════════════════════════
// مرتجعات المشتريات
// ══════════════════════════════════════════════════════════════════════════════

router.get("/purchase-returns", wrap(async (req, res) => {
  const companyId: number = req.user!.company_id!;
  const items = await db
    .select({
      id: purchaseReturnsTable.id,
      return_no: purchaseReturnsTable.return_no,
      purchase_id: purchaseReturnsTable.purchase_id,
      customer_id: purchaseReturnsTable.customer_id,
      customer_name: purchaseReturnsTable.customer_name,
      total_amount: purchaseReturnsTable.total_amount,
      reason: purchaseReturnsTable.reason,
      notes: purchaseReturnsTable.notes,
      date: purchaseReturnsTable.date,
      refund_type: purchaseReturnsTable.refund_type,
      created_at: purchaseReturnsTable.created_at,
      invoice_no: purchasesTable.invoice_no,
    })
    .from(purchaseReturnsTable)
    .leftJoin(purchasesTable, eq(purchaseReturnsTable.purchase_id, purchasesTable.id))
    .where(eq(purchaseReturnsTable.company_id, companyId))
    .orderBy(desc(purchaseReturnsTable.created_at));
  res.json(items.map(r => ({ ...r, total_amount: Number(r.total_amount), created_at: r.created_at?.toISOString() })));
}));

router.get("/purchase-returns/:id", wrap(async (req, res) => {
  const id = parseInt(req.params.id as string);
  if (isNaN(id)) { res.status(400).json({ error: "معرّف غير صالح" }); return; }
  const [ret] = await db.select().from(purchaseReturnsTable).where(and(eq(purchaseReturnsTable.id, id), eq(purchaseReturnsTable.company_id, req.user!.company_id!)));
  if (!ret) { res.status(404).json({ error: "غير موجود" }); return; }
  const items = await db.select().from(purchaseReturnItemsTable).where(eq(purchaseReturnItemsTable.return_id, id));
  res.json({
    ...ret,
    total_amount: Number(ret.total_amount),
    created_at: ret.created_at.toISOString(),
    items: items.map(i => ({
      ...i,
      quantity: Number(i.quantity),
      unit_price: Number(i.unit_price),
      total_price: Number(i.total_price),
      unit_cost_at_return: Number(i.unit_cost_at_return),
      total_cost_at_return: Number(i.total_cost_at_return),
    })),
  });
}));

/*
 * POST /purchase-returns
 *
 * كل بند مرتجع يجب أن يحمل (اختياري عند وجود purchase_id):
 *   original_purchase_item_id — معرّف البند الدقيق من purchase_items
 *   product_id / product_name / quantity / unit_price / total_price
 *
 * التكلفة المستخدمة في WAC = unit_price من البند الأصلي (وليس من نموذج الإدخال)
 * لأن التكلفة الأصلية مخزّنة في purchase_items.unit_price.
 */
router.post("/purchase-returns", wrap(async (req, res) => {
  const vpr = createPurchaseReturnSchema.safeParse(req.body);
  if (!vpr.success) { return res.status(400).json({ error: vpr.error.errors[0]?.message ?? "بيانات غير صالحة" }); }
  const {
    purchase_id, customer_id, customer_name, supplier_name,
    items, reason, notes, date,
    refund_type, safe_id,
  } = req.body;

  // Tenant validation: if linked to a parent purchase, ensure it belongs to my company
  if (purchase_id) {
    const [origPurch] = await db.select({ id: purchasesTable.id })
      .from(purchasesTable)
      .where(and(eq(purchasesTable.id, parseInt(purchase_id)), eq(purchasesTable.company_id, req.user!.company_id!)));
    if (!origPurch) {
      res.status(400).json({ error: "فاتورة الشراء الأصلية غير موجودة" }); return;
    }
  }

  // Tenant validation: customer_id must belong to my company
  if (customer_id) {
    const [ownC] = await db.select({ id: customersTable.id }).from(customersTable)
      .where(and(eq(customersTable.id, parseInt(customer_id)), eq(customersTable.company_id, req.user!.company_id!)));
    if (!ownC) { res.status(400).json({ error: "المورد غير موجود" }); return; }
  }

  // Tenant validation: every product_id in items must belong to my company
  const reqProductIds2 = Array.from(new Set(items.map((i: { product_id: number }) => Number(i.product_id))));
  if (reqProductIds2.length > 0) {
    const ownedProducts2 = await db.select({ id: productsTable.id }).from(productsTable)
      .where(and(inArray(productsTable.id, reqProductIds2 as number[]), eq(productsTable.company_id, req.user!.company_id!)));
    if (ownedProducts2.length !== reqProductIds2.length) {
      res.status(400).json({ error: "أحد المنتجات غير موجود" }); return;
    }
  }

  const requestId = req.headers["x-request-id"]
    ? String(req.headers["x-request-id"])
    : null;

  if (requestId) {
    const [existing] = await db.select().from(purchaseReturnsTable)
      .where(and(eq(purchaseReturnsTable.request_id, requestId), eq(purchaseReturnsTable.company_id, req.user!.company_id!))).limit(1);
    if (existing) return res.json({ ...existing, total_amount: Number(existing.total_amount), created_at: existing.created_at.toISOString() });
  }

  const total: number = items.reduce((s: number, i: { total_price: number }) => s + Number(i.total_price), 0);
  const return_no = await nextPurchaseReturnNo(req.user!.company_id!);
  const txDate = date ?? new Date().toISOString().split("T")[0];
  const rtype: string = refund_type === "cash" ? "cash" : "balance_credit";

  await assertPeriodOpen(txDate, req);

  const effectiveWarehouseId = req.user?.warehouse_id ?? null;
  const tenantWarehouseId = await resolveTenantWarehouseId(
    effectiveWarehouseId,
    req.user!.company_id!,
  );

  const ret = await db.transaction(async (tx) => {
    // ── الاسترداد النقدي: إضافة للخزينة ─────────────────────────────────────
    let safeIdInt: number | null = null;
    let safeNameStr: string | null = null;
    if (rtype === "cash") {
      if (!safe_id) throw httpError(400, "يجب اختيار الخزينة للاسترداد النقدي");
      const [safe] = await tx.select().from(safesTable).where(and(eq(safesTable.id, parseInt(safe_id)), eq(safesTable.company_id, req.user!.company_id!)));
      if (!safe) throw httpError(400, "الخزينة غير موجودة");
      safeIdInt   = safe.id;
      safeNameStr = safe.name;

      await tx.update(safesTable)
        .set({ balance: String(Number(safe.balance) + total) })
        .where(and(eq(safesTable.id, safe.id), eq(safesTable.company_id, req.user!.company_id!)));

      await tx.insert(transactionsTable).values({
        type: "purchase_return",
        reference_type: "purchase_return",
        safe_id: safe.id,
        safe_name: safe.name,
        amount: String(total),
        direction: "in",
        description: `مرتجع مشتريات نقدي ${return_no}${supplier_name ? ` — ${supplier_name}` : ""}`,
        date: txDate,
        company_id: req.user!.company_id!,
      });
    } else {
      // ── خصم من رصيد العميل-المورد في دفتر الأستاذ ─────────────────────────
      if (customer_id) {
        const custId = parseInt(customer_id);
        const [cust] = await tx.select().from(customersTable).where(and(eq(customersTable.id, custId), eq(customersTable.company_id, req.user!.company_id!)));
        if (cust) {
          await tx.update(customersTable)
            .set({ balance: String(Number(cust.balance) + total) })
            .where(and(eq(customersTable.id, custId), eq(customersTable.company_id, req.user!.company_id!)));
        }
        await tx.insert(customerLedgerTable).values({
          customer_id: custId,
          type: "purchase_return",
          amount: String(total),
          reference_type: "purchase_return",
          reference_id: 0,
          reference_no: return_no,
          description: `مرتجع مشتريات ${return_no}${customer_name ? ` — ${customer_name}` : ""}`,
          date: txDate,
          company_id: req.user!.company_id!,
        });
      }
    }

    // ── إنشاء سجل المرتجع ─────────────────────────────────────────────────
    const [ret] = await tx.insert(purchaseReturnsTable).values({
      request_id: requestId,
      return_no,
      purchase_id: purchase_id ?? null,
      customer_id: customer_id ? parseInt(customer_id) : null,
      customer_name: customer_name ?? supplier_name ?? null,
      total_amount: String(total),
      refund_type: rtype,
      safe_id: safeIdInt,
      safe_name: safeNameStr,
      date: txDate,
      reason: reason ?? null,
      notes: notes ?? null,
      company_id: req.user!.company_id!,
    }).returning();

    // ── بنود المرتجع: التحقق + المخزون + WAC ────────────────────────────────
    for (const item of items) {
      const retQty    = Number(item.quantity);
      if (retQty <= 0) throw httpError(400, `كمية المرتجع للصنف "${item.product_name}" يجب أن تكون أكبر من صفر`);
      const origPurchaseItemId: number | null = item.original_purchase_item_id
        ? parseInt(item.original_purchase_item_id)
        : null;

      // ── تحديد التكلفة التاريخية من بند الشراء الأصلي ─────────────────────
      // القاعدة 1: original_purchase_item_id (الأدق)
      // القاعدة 2: purchase_id + product_id (احتياطي)
      // القاعدة 3: unit_price من نموذج الإدخال (آخر احتياط)
      let historicalUnitCost: number = Number(item.unit_price); // fallback
      let resolvedPurchItemId: number | null = origPurchaseItemId;

      if (origPurchaseItemId) {
        if (!purchase_id) throw httpError(400, "يجب تحديد فاتورة الشراء الأصلية عند تمرير بند شراء أصلي");
        const [origItem] = await tx.select().from(purchaseItemsTable)
          .where(and(eq(purchaseItemsTable.id, origPurchaseItemId), eq(purchaseItemsTable.purchase_id, parseInt(purchase_id))));

        if (!origItem) throw httpError(400, `بند الشراء الأصلي ${origPurchaseItemId} غير موجود`);

        const alreadyReturned = Number(origItem.quantity_returned);
        const remaining       = Number(origItem.quantity) - alreadyReturned;

        if (retQty > remaining + 0.0001) {
          throw httpError(400,
            `الكمية المطلوب إرجاعها (${retQty}) تتجاوز الكمية المتاحة للإرجاع (${remaining.toFixed(3)}) للبند ${origItem.product_name}`
          );
        }

        historicalUnitCost = Number(origItem.unit_price);

        await tx.update(purchaseItemsTable)
          .set({ quantity_returned: String((alreadyReturned + retQty).toFixed(3)) })
          .where(and(eq(purchaseItemsTable.id, origPurchaseItemId), eq(purchaseItemsTable.purchase_id, parseInt(purchase_id))));

      } else if (purchase_id) {
        // احتياطي — بحث بـ purchase_id + product_id
        const origItems = await tx.select().from(purchaseItemsTable)
          .where(and(
            eq(purchaseItemsTable.purchase_id, parseInt(purchase_id)),
            eq(purchaseItemsTable.product_id, item.product_id),
          ));

        if (origItems.length > 0) {
          const available = origItems.find(r =>
            (Number(r.quantity) - Number(r.quantity_returned)) >= retQty - 0.0001
          ) ?? origItems[0];

          historicalUnitCost = Number(available.unit_price);
          resolvedPurchItemId = available.id;

          const alreadyReturned = Number(available.quantity_returned);
          await tx.update(purchaseItemsTable)
            .set({ quantity_returned: String((alreadyReturned + retQty).toFixed(3)) })
            .where(and(eq(purchaseItemsTable.id, available.id), eq(purchaseItemsTable.purchase_id, parseInt(purchase_id))));
        }
      }

      const totalCostAtReturn = historicalUnitCost * retQty;

      // ── إدراج بند المرتجع ─────────────────────────────────────────────────
      await tx.insert(purchaseReturnItemsTable).values({
        return_id:                  ret.id,
        product_id:                 item.product_id,
        product_name:               item.product_name,
        quantity:                   String(retQty),
        unit_price:                 String(item.unit_price),
        total_price:                String(item.total_price),
        original_purchase_item_id:  resolvedPurchItemId,
        unit_cost_at_return:        String(historicalUnitCost),
        total_cost_at_return:       String(totalCostAtReturn),
      });

      // ── خصم المخزون + إعادة حساب WAC ────────────────────────────────────
      //
      // عكس المشتريات: نُخرج الوحدات بتكلفة الشراء الأصلية (historicalUnitCost)
      // حتى يبقى رصيد المخزون صحيحاً.
      //
      // NewWAC = (currentQty × currentWAC − returnedQty × historicalUnitCost)
      //          / (currentQty − returnedQty)
      //
      const [prod] = await tx.select().from(productsTable).where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));
      if (prod) {
        const oldQty  = Number(prod.quantity);
        const oldWAC  = Number(prod.cost_price);
        const newQty  = Math.max(0, oldQty - retQty);
        let   newWAC  = oldWAC;

        if (newQty > 0) {
          const oldTotalValue   = oldQty * oldWAC;
          const returnedValue   = retQty * historicalUnitCost;
          newWAC = Math.max(0, (oldTotalValue - returnedValue) / newQty);
        }

        await tx.update(productsTable)
          .set({ quantity: String(newQty), cost_price: String(newWAC.toFixed(4)) })
          .where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));

        await tx.insert(stockMovementsTable).values({
          product_id:      item.product_id,
          product_name:    item.product_name,
          movement_type:   "purchase_return",
          quantity:        String(-retQty),
          quantity_before: String(oldQty),
          quantity_after:  String(newQty),
          unit_cost:       String(historicalUnitCost),
          reference_type:  "purchase_return",
          reference_id:    ret.id,
          reference_no:    return_no,
          notes: supplier_name ? `مرتجع مشتريات لـ ${supplier_name}` : "مرتجع مشتريات",
          date: txDate,
          warehouse_id: tenantWarehouseId,
          company_id:   req.user!.company_id!,
        });
      }
    }

    return ret;
  });

  void writeAuditLog({
    action: "create",
    record_type: "purchase_return",
    record_id: ret.id,
    new_value: { return_no: ret.return_no, total: Number(ret.total_amount) },
    user: { id: req.user?.id, username: req.user?.username },
  });

  return res.status(201).json({ ...ret, total_amount: Number(ret.total_amount), created_at: ret.created_at.toISOString() });
}));

router.delete("/purchase-returns/:id", wrap(async (req, res) => {
  if (!hasPermission(req.user, "can_cancel_sale")) {
    res.status(403).json({ error: "غير مصرح بحذف مرتجعات المشتريات" }); return;
  }
  const id = parseInt(req.params.id as string);
  const [preCheck] = await db.select({ date: purchaseReturnsTable.date })
    .from(purchaseReturnsTable).where(and(eq(purchaseReturnsTable.id, id), eq(purchaseReturnsTable.company_id, req.user!.company_id!)));
  if (!preCheck) throw httpError(404, "غير موجود");
  await assertPeriodOpen(preCheck.date, req);

  const effectiveWarehouseId = req.user?.warehouse_id ?? null;
  const tenantWarehouseId = await resolveTenantWarehouseId(
    effectiveWarehouseId,
    req.user!.company_id!,
  );

  await db.transaction(async (tx) => {
    const [ret] = await tx.select().from(purchaseReturnsTable).where(and(eq(purchaseReturnsTable.id, id), eq(purchaseReturnsTable.company_id, req.user!.company_id!)));
    if (!ret) throw httpError(400, "غير موجود");

    const retItems = await tx.select().from(purchaseReturnItemsTable)
      .where(eq(purchaseReturnItemsTable.return_id, id));

    for (const item of retItems) {
      const retQty       = Number(item.quantity);
      const unitCostUsed = Number(item.unit_cost_at_return) || Number(item.unit_price);

      // ── استعادة quantity_returned على البند الأصلي ───────────────────────
      if (item.original_purchase_item_id && ret.purchase_id) {
        const [origItem] = await tx.select().from(purchaseItemsTable)
          .where(and(eq(purchaseItemsTable.id, item.original_purchase_item_id), eq(purchaseItemsTable.purchase_id, ret.purchase_id)));
        if (origItem) {
          const newReturned = Math.max(0, Number(origItem.quantity_returned) - retQty);
          await tx.update(purchaseItemsTable)
            .set({ quantity_returned: String(newReturned.toFixed(3)) })
            .where(and(eq(purchaseItemsTable.id, origItem.id), eq(purchaseItemsTable.purchase_id, ret.purchase_id)));
        }
      }

      // ── إعادة المخزون + تعديل WAC ────────────────────────────────────────
      const [prod] = await tx.select().from(productsTable).where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));
      if (prod) {
        const oldQty = Number(prod.quantity);
        const oldWAC = Number(prod.cost_price);
        const newQty = oldQty + retQty;
        const newWAC = newQty > 0
          ? ((oldQty * oldWAC) + (retQty * unitCostUsed)) / newQty
          : unitCostUsed;

        await tx.update(productsTable)
          .set({ quantity: String(newQty), cost_price: String(newWAC.toFixed(4)) })
          .where(and(eq(productsTable.id, item.product_id), eq(productsTable.company_id, req.user!.company_id!)));

        await tx.insert(stockMovementsTable).values({
          product_id:      item.product_id,
          product_name:    item.product_name,
          movement_type:   "adjustment",
          quantity:        String(retQty),
          quantity_before: String(oldQty),
          quantity_after:  String(newQty),
          unit_cost:       String(unitCostUsed),
          reference_type:  "purchase_return_cancel",
          reference_id:    ret.id,
          reference_no:    ret.return_no,
          notes:           `إلغاء مرتجع مشتريات ${ret.return_no}`,
          date:            new Date().toISOString().split("T")[0],
          warehouse_id:    tenantWarehouseId,
          company_id:      req.user!.company_id!,
        });
      }
    }

    const total = Number(ret.total_amount);

    if (ret.refund_type === "cash" && ret.safe_id) {
      const [safe] = await tx.select().from(safesTable).where(and(eq(safesTable.id, ret.safe_id), eq(safesTable.company_id, req.user!.company_id!)));
      if (safe) {
        await tx.update(safesTable)
          .set({ balance: String(Number(safe.balance) - total) })
          .where(and(eq(safesTable.id, ret.safe_id), eq(safesTable.company_id, req.user!.company_id!)));
      }
    } else if (ret.refund_type === "balance_credit" || !ret.refund_type) {
      // عكس: المرتجع كان يُضاف لرصيد العميل-المورد → نخصمه الآن
      if (ret.customer_id) {
        const [cust] = await tx.select().from(customersTable).where(and(eq(customersTable.id, ret.customer_id), eq(customersTable.company_id, req.user!.company_id!)));
        if (cust) {
          await tx.update(customersTable)
            .set({ balance: String(Number(cust.balance) - total) })
            .where(and(eq(customersTable.id, ret.customer_id), eq(customersTable.company_id, req.user!.company_id!)));
        }
        await tx.insert(customerLedgerTable).values({
          customer_id: ret.customer_id,
          type: "purchase_return_cancel",
          amount: String(-total),
          reference_type: "purchase_return_cancel",
          reference_id: ret.id,
          reference_no: ret.return_no,
          description: `إلغاء مرتجع مشتريات ${ret.return_no}`,
          date: new Date().toISOString().split("T")[0],
          company_id: req.user!.company_id!,
        });
      }
    }

    await tx.delete(purchaseReturnItemsTable).where(eq(purchaseReturnItemsTable.return_id, id));
    await tx.delete(purchaseReturnsTable).where(eq(purchaseReturnsTable.id, id));
  });

  void writeAuditLog({
    action: "delete",
    record_type: "purchase_return",
    record_id: id,
    user: { id: req.user?.id, username: req.user?.username },
  });

  res.json({ success: true });
}));

export default router;
